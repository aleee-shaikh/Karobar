﻿Public Class DesignationSettings
    Inherits System.Web.UI.UserControl

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            BindProductCatagory()

        End If
    End Sub

    Private Sub BindProductCatagory()
        Dim tbl As New DataTable

        tbl = Payroll.GetDesignations(Val(Session("CurrentBusinessID")))
        If tbl.Rows.Count = 0 Then
            Dim dr As DataRow
            dr = tbl.NewRow
            tbl.Rows.Add(dr)
        End If
        GrdProductCatagory.DataSource = tbl
        GrdProductCatagory.DataBind()
    End Sub

    Protected Sub GrdProductCatagory_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GrdProductCatagory.RowCancelingEdit
        GrdProductCatagory.EditIndex = -1
        BindProductCatagory()

    End Sub

    Protected Sub GrdProductCatagory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdProductCatagory.RowCommand
        If e.CommandName = "AddNewSettings" Then
            GrdProductCatagory.ShowFooter = True
        ElseIf e.CommandName = "Insert" Then
            Dim DesignationName As String = CType(GrdProductCatagory.FooterRow.FindControl("txtDesignationName"), TextBox).Text
            Payroll.AddDesignation(Val(Session("CurrentBusinessID")), DesignationName, True)
            GrdProductCatagory.EditIndex = -1
        ElseIf e.CommandName = "Cancel" Then
            GrdProductCatagory.EditIndex = -1
        ElseIf e.CommandName = "Update" Then
            Dim DesignationName As String = CType(GrdProductCatagory.Rows(GrdProductCatagory.EditIndex).FindControl("txtEditDesignationName"), TextBox).Text.Trim
            Dim HdnDesignationID As HiddenField = CType(GrdProductCatagory.Rows(GrdProductCatagory.EditIndex).FindControl("HdnDesignationID"), HiddenField)

            Payroll.UpdateDesignation(HdnDesignationID.Value, DesignationName, True)
            GrdProductCatagory.EditIndex = -1
        ElseIf e.CommandName = "DeleteDesignation" Then
            If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
                Page.RegisterStartupScript("SettingIssue", "<script>parent.ShowMessage('Delete is disabled on demo business','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                Exit Sub
            End If
            Dim DesignationID As Integer = Val(e.CommandArgument)

            Payroll.DeleteDesignation(DesignationID)
            GrdProductCatagory.EditIndex = -1
        End If
        BindProductCatagory()

    End Sub

    Private Sub GrdProductCatagory_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdProductCatagory.PageIndexChanging
        GrdProductCatagory.PageIndex = e.NewPageIndex
        BindProductCatagory()
    End Sub

    Protected Sub GrdProductCatagory_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GrdProductCatagory.RowEditing

        GrdProductCatagory.EditIndex = e.NewEditIndex
        BindProductCatagory()

    End Sub

    Private Sub GrdProductCatagory_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProductCatagory.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LblParentCatagory As Label = CType(e.Row.FindControl("LblParentCatagory"), Label)
            Dim DDLEditParentType As DropDownList = CType(e.Row.FindControl("DDLEditParentType"), DropDownList)
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)

            If Not DDLEditParentType Is Nothing Then
                DDLEditParentType.DataValueField = "ArticleTypeID"
                DDLEditParentType.DataTextField = "ArticleType"
                DDLEditParentType.DataSource = ds.Tables(0)
                DDLEditParentType.DataBind()
                For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                    If (IsDBNull(drview("GroupTypeID")) = False AndAlso IsDBNull(ds.Tables(0).Rows(i)("ArticleTypeID")) = False) AndAlso ds.Tables(0).Rows(i)("ArticleTypeID") = drview("GroupTypeID") Then
                        If Not DDLEditParentType Is Nothing Then
                            DDLEditParentType.SelectedValue = drview("GroupTypeID")
                        End If
                        Exit For
                    End If
                Next
            End If

            If Not LblParentCatagory Is Nothing Then
                For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                    If (IsDBNull(drview("GroupTypeID")) = False AndAlso IsDBNull(ds.Tables(0).Rows(i)("ArticleTypeID")) = False) AndAlso ds.Tables(0).Rows(i)("ArticleTypeID") = drview("GroupTypeID") Then
                        LblParentCatagory.Text = ds.Tables(0).Rows(i)("ArticleType")
                        Exit For
                    End If
                Next
            End If


        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim DDLFooterParentType As DropDownList = CType(e.Row.FindControl("DDLFooterParentType"), DropDownList)
            If Not DDLFooterParentType Is Nothing Then
                Dim ds As New DataSet
                ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
                DDLFooterParentType.DataValueField = "ArticleTypeID"
                DDLFooterParentType.DataTextField = "ArticleType"
                DDLFooterParentType.DataSource = ds.Tables(0)
                DDLFooterParentType.DataBind()
            End If
        End If
    End Sub

    Private Sub GrdProductCatagory_RowUpdating(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewUpdateEventArgs) Handles GrdProductCatagory.RowUpdating

    End Sub
End Class