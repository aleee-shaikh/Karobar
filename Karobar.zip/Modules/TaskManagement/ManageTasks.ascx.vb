﻿Public Class ManageTasks
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(LoggedInUserSession.UserID, 172) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open projects screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
    End Sub

    Sub LoadData()
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = TaskManagement.SearchTask(LoggedInUserSession.BusinessID, FreeText:=txtFreeText.Text)
        'tbl = ds.Tables(0)

        Dim dv As DataView = tbl.DefaultView
        dv.Sort = SortExpression + " " + If(IsAscendingSort, "ASC", "DESC")
        GrdTasks.DataSource = dv
        GrdTasks.DataBind()
    End Sub


    Private Sub GrdTasks_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdTasks.PageIndexChanging
        GrdTasks.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdTasks_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdTasks.RowCommand
        If e.CommandName = "DeleteTask" Then
            TaskManagement.DeleteTask(LoggedInUserSession.BusinessID, e.CommandArgument, LoggedInUserSession.UserID)
            LoadData()
            Log.WriteLog(LoggedInUserSession.BusinessID, LoggedInUserSession.UserID, "Task", "Deleted Task " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, e.CommandArgument)
        End If
    End Sub

    Private Sub GrdTasks_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdTasks.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LnkEditTask As New System.Web.UI.WebControls.LinkButton
            LnkEditTask = CType(e.Row.FindControl("LnkEditTask"), LinkButton)
            If Not LnkEditTask Is Nothing Then
                LnkEditTask.OnClientClick = "javascript:ShowEditTask('" & Cryptography.Encrypt(drview("TaskID").ToString().Trim()) & "');return false"
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub GrdTasks_Sorting(sender As Object, e As GridViewSortEventArgs) Handles GrdTasks.Sorting

        Dim columnIndex As Integer = 0
        For Each headerCell In GrdTasks.HeaderRow.Cells
            If (headerCell.ContainingField.SortExpression = e.SortExpression) Then
                columnIndex = GrdTasks.HeaderRow.Cells.GetCellIndex(headerCell)
            End If
        Next

        If e.SortExpression = SortExpression Then
            IsAscendingSort = Not IsAscendingSort

        Else
            IsAscendingSort = False
            SortExpression = e.SortExpression
        End If


        For i As Integer = 0 To GrdTasks.Columns.Count - 1
            GrdTasks.Columns(i).HeaderText = GrdTasks.Columns(i).HeaderText.Replace("▲", "").Replace("▼", "")
        Next

        If (IsAscendingSort) Then
            GrdTasks.Columns(columnIndex).HeaderText = GrdTasks.Columns(columnIndex).HeaderText + "▲"
        Else
            GrdTasks.Columns(columnIndex).HeaderText = GrdTasks.Columns(columnIndex).HeaderText + "▼"
        End If
        LoadData()
    End Sub

    Protected Property IsAscendingSort As Boolean
        Get
            Dim value As Object = ViewState("IsAscendingSort")
            Return If(Not IsNothing(value), CBool(value), False)
        End Get
        Set(value As Boolean)
            ViewState("IsAscendingSort") = value
        End Set
    End Property

    Protected Property SortExpression As String
        Get
            Dim value As Object = ViewState("SortExpression")
            Return If(Not IsNothing(value), CStr(value), "TaskID")
        End Get
        Set(value As String)
            ViewState("SortExpression") = value
        End Set
    End Property


End Class