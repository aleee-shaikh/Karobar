﻿Public Class ProductSlider
    Inherits System.Web.UI.UserControl

End Class
