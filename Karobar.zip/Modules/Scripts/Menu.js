function WebSection_GetDetail(BID, SID,ContainerID) {
    var Data = [];


    var RequestData = {
        WebsiteID: BID,
        SectionID: SID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Menus.asmx/GetWebSectionDetail',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("WebSection").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("WebSection").each(function () {
                    Data.push({
                        SectionDetailID: $(this).find("SectionDetailID").text(),
                        WebsiteID: $(this).find("WebsiteID").text(),
                        SectionDescription: $(this).find("SectionDescription").text()
                    });
                });
            }

            $(ContainerID).html(Data.SectionDescription)
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Data
}

function LoadWelcomeMenu(ControlID) {
    var RequestData = {
        UserID: -1
    };

    var MenusData = [];
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Menus.asmx/LoadWelcomeMenu',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Menus").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("Menus").each(function () {

                    MenusData.push({
                        MenuID: $(this).find("PageID").text(),
                        ParentMenuID: $(this).find("ParentPageID").text(),
                        MenuTitle: $(this).find("PageTitle").text(),
                        MenuImage: $(this).find("PageIconImagePath").text(),
                        Visible: $(this).find("Visible").text(),
                        MenuURL: $(this).find("MenuURL").text(),
                        AccessRead: $(this).find("AccessRead").text(),
                        AccessModify: $(this).find("AccessModify").text(),
                        AccessAdd: $(this).find("AccessAdd").text(),
                        AccessDelete: $(this).find("AccessDelete").text()
                    });

                });

            }

            $('#WelcomeMenuOptions .welcomemenuOptions').remove();
            var ParentMenu = ''//= '<li>Hi, abc<ul>'

            for (var i = 0; i < MenusData.length; i++) {
                ParentMenu = ParentMenu + '<li class="submenu" style="margin-top:15px;" id="MenuItem' + i + '"><a href="' + MenusData[i].MenuURL + '">' + MenusData[i].MenuTitle + '</a></li>'
            }
            //ParentMenu = ParentMenu + '</ul></li>'
            $(document).ready(function () {
                $('.welcomemenuOptions').append(ParentMenu)
            })
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });


    

    
      
}


function LoadMenus(ControlID, UserID) {
    var RequestData = {
        UserID: UserID
    };
    
    var MenusData = [];
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Menus.asmx/LoadLoggedinUserMenu',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Menus").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("Menus").each(function () {

                    MenusData.push({
                        MenuID: $(this).find("PageID").text(),
                        ParentMenuID: $(this).find("ParentPageID").text(),
                        MenuTitle: $(this).find("PageTitle").text(),
                        MenuImage: $(this).find("PageIconImagePath").text(),
                        Visible: $(this).find("Visible").text(),
                        MenuURL: $(this).find("MenuURL").text(),
                        AccessRead: $(this).find("AccessRead").text(),
                        AccessModify: $(this).find("AccessModify").text(),
                        AccessAdd: $(this).find("AccessAdd").text(),
                        AccessDelete: $(this).find("AccessDelete").text()
                    });
                });

            }

            $('.menu').html('');
            $('#Menu .menu').remove();
            var ParentMenu = ''//'<li>'

            for (var i = 0; i < MenusData.length; i++) {
                var MenuChildCnt = 0;
                for (var j = 0; j < MenusData.length; j++) {
                    if (MenusData[j].ParentMenuID > 0) {
                        if (MenusData[j].ParentMenuID == MenusData[i].MenuID) {
                            MenuChildCnt++;
                        }
                    }
                }
                if (MenusData[i].ParentMenuID == -1) {
                    if (MenusData[i].MenuImage != "" && MenusData[i].MenuImage.indexOf(".") >= 0) {
                        if (MenusData[i].MenuURL.indexOf("javascript:") >= 0) {
                            ParentMenu = ParentMenu + '<li style="text-align:center"><a href="' + MenusData[i].MenuURL + ';$(\'.SubMenu\').hide();"><img style="width:16px;border:none;" src="/Images/PagesIcons/' + MenusData[i].MenuImage + '"><br>' + MenusData[i].MenuTitle + '</a>'
                        }
                        else if (MenuChildCnt <= 1) {
                            ParentMenu = ParentMenu + '<li style="text-align:center"><a href="' + MenusData[i].MenuURL + '"><img style="width:16px;border:none;" src="/Images/PagesIcons/' + MenusData[i].MenuImage + '"><br>' + MenusData[i].MenuTitle + '</a>'
                        }
                        else {
                            ParentMenu = ParentMenu + '<li style="text-align:center"><a href="#" onclick="$(\'.SubMenu\').hide();ShowMenu(\'#SubMenus' + MenusData[i].MenuID + '\')"><img style="width:16px;border:none;" src="/Images/PagesIcons/' + MenusData[i].MenuImage + '"><br>' + MenusData[i].MenuTitle + '</a>'
                        }
                    }
                    else {
                        ParentMenu = ParentMenu + '<li style="text-align:center"><a href="#" onclick="$(\'.SubMenu\').hide();ShowMenu(\'#SubMenus' + MenusData[i].MenuID +'\')"><br>' + MenusData[i].MenuTitle + '</a>'
                    }
                    ParentMenu = ParentMenu + AddMenuItems(MenusData, MenusData[i].MenuID)
                }
            }
            $('.menu').append(ParentMenu)
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });


    
}

function ShowMenu(MenuID) {
    $(MenuID).show();
}

function AddMenuItems(MenusData, ParentMenuID) {
    var MenuChildCnt = 0;
    var MenuHtml = '<ul class="SubMenu" id="SubMenus' + ParentMenuID+'">'
    for (var i = 0; i < MenusData.length; i++) {
        if (MenusData[i].ParentMenuID == ParentMenuID) {
            MenuChildCnt++;
        }
    }

    if (MenuChildCnt > 0) {
        for (var i = 0; i < MenusData.length; i++) {
            if (MenusData[i].ParentMenuID == ParentMenuID) {
                var URL = MenusData[i].MenuURL;
                MenuChildCnt = 0;
                for (var j = 0; j < MenusData.length; j++) {
                    if (MenusData[j].ParentMenuID == MenusData[i].MenuID) {
                        MenuChildCnt++;
                    }
                }
                if (MenuChildCnt > 0) {
                    MenuHtml = MenuHtml + '<li style="text-align:left"><a href="#"  onclick="ShowMenu(\'#SubMenus' + MenusData[i].MenuID + '\')">' + MenusData[i].MenuTitle + '</a>'
                }
                else {
                    if (URL.indexOf("javascript:") >= 0) {
                        MenuHtml = MenuHtml + '<li style="text-align:left"><a href="' + URL + ';$(\'.SubMenu\').hide();"  onclick="ShowMenu(\'#SubMenus' + MenusData[i].MenuID + '\')">' + MenusData[i].MenuTitle + '</a>'
                    }
                    else {
                        MenuHtml = MenuHtml + '<li style="text-align:left"><a href="' + URL + '"  onclick="ShowMenu(\'#SubMenus' + MenusData[i].MenuID + '\')">' + MenusData[i].MenuTitle + '</a>'
                    }
                }
                MenuHtml = MenuHtml + AddMenuItems(MenusData, MenusData[i].MenuID) + '</li>'
            }
        }

    }
    MenuHtml = MenuHtml+'</ul>'
    return MenuHtml
}