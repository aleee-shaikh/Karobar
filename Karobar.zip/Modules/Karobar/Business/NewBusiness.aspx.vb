﻿Public Class NewBusiness
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Session("CurrentBusinessID") Is Nothing Then
            If Person.DoesPersonHavePageRights(Session("UserID"), 8) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                Exit Sub
            End If
        End If

        If Not Page.IsPostBack Then
            DDLBusinessCategory.DataSource = Website.GetWebsitesCategories
            DDLBusinessCategory.DataTextField = "CategoryTitle"
            DDLBusinessCategory.DataValueField = "WebsiteCategoryID"
            DDLBusinessCategory.DataBind()


            DDLCurrency.DataSource = Website.GetCurrencies(Website.WebsiteID, HttpContext.Current.Session("UserID"))
            DDLCurrency.DataTextField = "CurrencyName"
            DDLCurrency.DataValueField = "CurrencyCode"
            DDLCurrency.DataBind()
            DDLCurrency.SelectedValue = ReferenceData.Setting("DefaultCurrency", "PKR", Val(Session("CurrentBusinessID")))

            DDLBusinessTypes.DataSource = Website.GetBusinessTypes()
            DDLBusinessTypes.DataTextField = "TypeName"
            DDLBusinessTypes.DataValueField = "BusinessTypeID"
            DDLBusinessTypes.DataBind()

            Settings.ParentTypeID = Website.DataTypes.ProductCatagories * -1
            Settings.Title = "Product Catagories"
            SetUnbold()
            LnkProductCatagories.Font.Bold = True
        End If




    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim BusinessLogoFilename As String = ""
        If FileUploadBusinessLogo.PostedFile.FileName <> "" Then
            BusinessLogoFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadBusinessLogo.PostedFile.FileName)
        End If

        Try
            ''tbl = Website.AddWebsite(HttpContext.Current.Session("UserID"), txtBusinessName.Text.Trim, txtBusinessDescription.Text.Trim, DDLBusinessCategory.SelectedItem.Value, DDLCurrency.SelectedItem.Value, BusinessLogoFilename, txtPhone.Text.Trim, txtBusinessFax.Text.Trim, txtEmail.Text.Trim, txtBusinessAddress.Text.Trim, BusinessTypeID:=DDLBusinessTypes.SelectedValue)
            tbl = Website.AddWebsite(HttpContext.Current.Session("UserID"), txtBusinessName.Text.Trim,
                                     txtBusinessDescription.Text.Trim, Val(DDLBusinessCategory.SelectedValue), DDLCurrency.SelectedItem.Value,
                                     BusinessLogoFilename, txtPhone.Text.Trim, txtBusinessFax.Text.Trim, txtEmail.Text.Trim, txtBusinessAddress.Text.Trim,
                                     BusinessTypeID:=DDLBusinessTypes.SelectedValue)
            If tbl.Rows.Count > 0 Then
                Session("CurrentBusinessID") = tbl.Rows(0)("WebsiteID")
                Dim ds As New DataSet
                ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
                If (ds.Tables.Count > 0) Then
                    If ds.Tables(0).Rows.Count > 0 Then
                        Session("CurrentBusinessCategoryID") = ds.Tables(0).Rows(0)("WebsiteCategoryID")
                    End If
                End If
                Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Website.WebsiteID & "/Businesses/") & tbl.Rows(0)("WebsiteID") & "/Images"
                System.IO.Directory.CreateDirectory(BusinessDirectory)
                If BusinessLogoFilename <> "" Then FileUploadBusinessLogo.SaveAs(BusinessDirectory & "/" & BusinessLogoFilename)
            End If
            ''ClientScript.RegisterClientScriptBlock(Me.GetType(), "BusinessAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Business added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1');parent.window.location='/Business';</script>")
            pnlBusinessSettings.Visible = True
            pnlNewBusiness.Visible = False
            LnkTableNos.Visible = False
            If (DDLBusinessCategory.SelectedItem.Text.ToLower().IndexOf("job ") >= 0) Then
                LnkProductSubCatagories.Visible = False
                LnkProductUnits.Visible = False
            ElseIf DDLBusinessCategory.SelectedValue = 16 Then
                LnkTableNos.Visible = True
            End If
        Catch ex As Exception

        End Try
    End Sub


#Region "Business Settings"

    Private Sub LnkProductCatagories_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductCatagories.Click
        Settings.ParentTypeID = Website.DataTypes.ProductCatagories * -1
        Settings.Title = "Product Catagories"
        SetUnbold()
        LnkProductCatagories.Font.Bold = True
    End Sub

    Private Sub LnkProductSubCatagories_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductSubCatagories.Click
        Settings.ParentTypeID = Website.DataTypes.ProductSubCatagories * -1
        Settings.Title = "Product Sub Catagories"
        SetUnbold()
        LnkProductSubCatagories.Font.Bold = True
    End Sub

    Private Sub LnkProductUnits_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductUnits.Click
        Settings.ParentTypeID = Website.DataTypes.ProductUnits * -1
        Settings.Title = "Product Units"
        SetUnbold()
        LnkProductUnits.Font.Bold = True
    End Sub

    Sub SetUnbold()
        LnkProductCatagories.Font.Bold = False
        LnkProductSubCatagories.Font.Bold = False
        LnkProductUnits.Font.Bold = False
        LnkPersonTitles.Font.Bold = False
        LnkMaritalStatus.Font.Bold = False
        LnkStockLocations.Font.Bold = False
        LnkSupplierType.Font.Bold = False
        LnkCustomerType.Font.Bold = False
        LnkBankAccountType.Font.Bold = False
        LnkSupplierStatus.Font.Bold = False
        LnkCustomerStatus.Font.Bold = False
        LnkWeeklyOffDays.Font.Bold = False
        LabelSettings.Visible = False
        Settings.Visible = True

    End Sub

    Private Sub LnkPersonTitles_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkPersonTitles.Click
        Settings.ParentTypeID = Website.DataTypes.PersonTitles * -1
        Settings.Title = "Person Titles"
        SetUnbold()
        LnkPersonTitles.Font.Bold = True
    End Sub

    Private Sub LnkMaritalStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkMaritalStatus.Click
        Settings.ParentTypeID = Website.DataTypes.MaritalStatus * -1
        Settings.Title = "Person Marital Status"
        SetUnbold()
        LnkMaritalStatus.Font.Bold = True
    End Sub

    Private Sub LnkStockLocations_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkStockLocations.Click
        Settings.ParentTypeID = Website.DataTypes.StockLocations * -1
        Settings.Title = "Product Stock Location"
        SetUnbold()
        LnkStockLocations.Font.Bold = True
    End Sub

    Private Sub LnkSupplierType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSupplierType.Click
        Settings.ParentTypeID = Website.DataTypes.SupplierType * -1
        Settings.Title = "Supplier Type"
        SetUnbold()
        LnkSupplierType.Font.Bold = True
    End Sub

    Private Sub LnkCustomerType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkCustomerType.Click
        Settings.ParentTypeID = Website.DataTypes.CustomerType * -1
        Settings.Title = "Customer Type"
        SetUnbold()
        LnkCustomerType.Font.Bold = True
    End Sub

    Private Sub LnkBankAccountType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkBankAccountType.Click
        Settings.ParentTypeID = Website.DataTypes.BankAccountType * -1
        Settings.Title = "Bank Account Type"
        SetUnbold()
        LnkBankAccountType.Font.Bold = True
    End Sub

    Private Sub LnkCustomerStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkCustomerStatus.Click
        Settings.ParentTypeID = Website.DataTypes.CustomerStatus * -1
        Settings.Title = "Customer Status"
        SetUnbold()
        LnkCustomerStatus.Font.Bold = True
    End Sub

    Private Sub LnkSupplierStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSupplierStatus.Click
        Settings.ParentTypeID = Website.DataTypes.SupplierStatus * -1
        Settings.Title = "Supplier Status"
        SetUnbold()
        LnkSupplierStatus.Font.Bold = True
    End Sub

    Private Sub LnkSaleType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSaleType.Click
        Settings.ParentTypeID = Website.DataTypes.SaleType * -1
        Settings.Title = "Sale Type"
        SetUnbold()
        LnkSaleType.Font.Bold = True
    End Sub

    Private Sub LnkLabels_Click(sender As Object, e As EventArgs) Handles LnkLabels.Click
        LabelSettings.Visible = True
        Settings.Visible = False
        DesignationSettings.Visible = False
        DepartmentsSettings.Visible = False
        OFFDays.Visible = False
    End Sub

    Private Sub LnkDesignations_Click(sender As Object, e As EventArgs) Handles LnkDesignations.Click
        LabelSettings.Visible = False
        Settings.Visible = False
        DesignationSettings.Visible = True
        DepartmentsSettings.Visible = False
        OFFDays.Visible = False
    End Sub

    Private Sub LnkDepartments_Click(sender As Object, e As EventArgs) Handles LnkDepartments.Click
        LabelSettings.Visible = False
        Settings.Visible = False
        DesignationSettings.Visible = False
        DepartmentsSettings.Visible = True
        OFFDays.Visible = False
    End Sub

    Private Sub BtnFinish_Click(sender As Object, e As EventArgs) Handles BtnFinish.Click
        OFFDays.Save()
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "BusinessAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Business added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1');parent.window.location='/Business';</script>")
    End Sub

    Private Sub LnkWeeklyOffDays_Click(sender As Object, e As EventArgs) Handles LnkWeeklyOffDays.Click
        LabelSettings.Visible = False
        Settings.Visible = False
        DesignationSettings.Visible = False
        DepartmentsSettings.Visible = False
        OFFDays.Visible = True
        OFFDays.LoadData()
    End Sub


    Private Sub LnkTableNos_Click(sender As Object, e As EventArgs) Handles LnkTableNos.Click
        Settings.ParentTypeID = Website.DataTypes.TableNos * -1
        Settings.Title = "Table Nos"
        SetUnbold()
        LnkTableNos.Font.Bold = True
        Settings.Visible = True
    End Sub
#End Region
End Class