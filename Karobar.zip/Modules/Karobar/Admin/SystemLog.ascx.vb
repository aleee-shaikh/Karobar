﻿Public Class SystemLog
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtSystemLogFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtSystemLogToDate.Text = Now.ToString("dd-MM-yyyy")
            LoadData()
        Else

        End If
    End Sub

    Sub LoadData()
        Dim FDate As String = ""
        Dim FdateAry() = txtSystemLogFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtSystemLogToDate.Text.Replace("/", "-").Split("-")
        Dim tbl As New DataTable
        tbl = Log.GetLog(BusinessID:=Val(Session("CurrentBusinessID")), Keywords:=txtFreeText.Text.Trim, FromDate:=CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2) & " 00:00:00 AM"), ToDate:=CDate(TdateAry(1) & "-" & TdateAry(0) & "-" & TdateAry(2) & " 23:59:59 PM"), EventType:=DDLLogType.SelectedValue).Tables(0)
        If tbl.Select("LogType='Error'").Length > 0 Then
            tbl = tbl.Select("LogType<>'Error'").CopyToDataTable()
        End If

        Dim dataView As New DataView(tbl)
        dataView.Sort = " LogID DESC"
        Dim dataTable As DataTable = dataView.ToTable()

        GrdSystemLogs.DataSource = dataTable
        GrdSystemLogs.DataBind()
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        If Person.DoesPersonHavePageRights(Session("UserID"), 56) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open system log screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
    End Sub
End Class