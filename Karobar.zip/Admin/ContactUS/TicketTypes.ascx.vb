﻿Public Class TicketTypes
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            DDLBusinesses.DataTextField = "WebsiteTitle"
            DDLBusinesses.DataValueField = "WebsiteID"
            DDLBusinesses.DataSource = Website.GetWebsites()
            DDLBusinesses.DataBind()

            DDLBusiness4TicketType.DataTextField = "WebsiteTitle"
            DDLBusiness4TicketType.DataValueField = "WebsiteID"
            DDLBusiness4TicketType.DataSource = Website.GetWebsites()
            DDLBusiness4TicketType.DataBind()
            LoadData()
            MultiView1.ActiveViewIndex = 0
        End If
    End Sub

    Sub LoadData()
        GrdTicketTypes.DataSource = Tickets.GetTicketTypes(DDLBusinesses.SelectedItem.Value, ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
        GrdTicketTypes.DataBind()
    End Sub

    Private Sub GrdTicketTypes_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdTicketTypes.PageIndexChanging
        GrdTicketTypes.PageIndex = e.NewPageIndex
        LoadData()
    End Sub


    Protected Sub GrdTicketTypes_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GrdTicketTypes.RowCancelingEdit
        GrdTicketTypes.EditIndex = -1
        LoadData()
    End Sub

    Private Sub GrdTicketTypes_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GrdTicketTypes.RowEditing
        GrdTicketTypes.EditIndex = e.NewEditIndex
        LoadData()
        GrdTicketTypes.ShowFooter = False
    End Sub


    Private Sub GrdTicketTypes_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdTicketTypes.RowCommand
        If e.CommandName = "EditSection" Then

        ElseIf e.CommandName = "Update" Then
            Dim TicketTypeID As String = CType(GrdTicketTypes.Rows(GrdTicketTypes.EditIndex).FindControl("HdnTicketTypeID"), TextBox).Text.Trim
            Dim TicketType As String = CType(GrdTicketTypes.Rows(GrdTicketTypes.EditIndex).FindControl("txteditTicketType"), TextBox).Text.Trim

            Tickets.UpdateTicketType(TicketTypeID, TicketType)
            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=ManageTicketTypes")
        ElseIf e.CommandName = "DeleteTicketType" Then
            Tickets.DeleteTicketType(e.CommandArgument)
            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=ManageTicketTypes")
        End If
    End Sub

    Protected Sub DDLBusinesses_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DDLBusinesses.SelectedIndexChanged
        LoadData()
    End Sub

    Private Sub BtnAddNewTicketType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAddNewTicketType.Click
        MultiView1.ActiveViewIndex = 1
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Tickets.AddTicketType(DDLBusiness4TicketType.SelectedItem.Value, ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")), txtTicketType.Text.Trim)
        MultiView1.ActiveViewIndex = 0

    End Sub
End Class