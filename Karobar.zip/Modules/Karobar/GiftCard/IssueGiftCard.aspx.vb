﻿Public Class IssueGiftCard
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 145) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open Gift card issue screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then
            Dim tbl As New DataTable
            tbl = GiftCard.GetGiftCards(Val(Session("CurrentBusinessID")))

            DDLGiftCard.DataTextField = "GiftCardName"
            DDLGiftCard.DataValueField = "GiftCardID"
            DDLGiftCard.DataSource = tbl
            DDLGiftCard.DataBind()
            DDLGiftCard.Items.Insert(0, New ListItem(" -- Select Gift Card --", "-1"))

            tbl = Person.GetUsersList(Val(Session("CurrentBusinessID")), "", 4)
            DDLUsers.DataTextField = "FirstName"
            DDLUsers.DataValueField = "UserID"
            DDLUsers.DataSource = tbl
            DDLUsers.DataBind()
            DDLUsers.Items.Insert(0, New ListItem(" -- Select User -- ", "-1"))
        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        tbl = GiftCard.IssueGiftCard(Session("CurrentBusinessID"), DDLUsers.SelectedValue, DDLGiftCard.SelectedValue, HttpContext.Current.Session("UserID"))
        If tbl.Columns.Contains("Error") Then
            If tbl.Rows.Count > 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAlreadyExist", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card issued successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
            DDLGiftCard.SelectedIndex = 0
            DDLUsers.SelectedIndex = 0

        End If
    End Sub
End Class