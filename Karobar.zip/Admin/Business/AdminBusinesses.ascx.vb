﻿Public Class AdminBusinesses
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            GrdBusinesses.DataSource = Website.SearchBusinesses(SearchText:=txtFreeText.Text)
            GrdBusinesses.DataBind()
        End If
    End Sub

    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        GrdBusinesses.DataSource = Website.SearchBusinesses(SearchText:=txtFreeText.Text)
        GrdBusinesses.DataBind()
    End Sub

    Private Sub GrdBusinesses_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdBusinesses.RowCommand
        If e.CommandName = "DisableBusiness" Then
            Website.DisableWebsites(Val(e.CommandArgument))
            GrdBusinesses.DataSource = Website.SearchBusinesses(SearchText:=txtFreeText.Text)
            GrdBusinesses.DataBind()
        End If
    End Sub

    Private Sub GrdBusinesses_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdBusinesses.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            If drview("IsDisabled") = True Then
                e.Row.Attributes.Add("style", "background:red;color:white")
            End If
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='whitesmoke';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub
End Class