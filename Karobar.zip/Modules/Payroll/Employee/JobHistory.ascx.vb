﻿Public Class JobHistory
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer

    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(value As Integer)
            _EmployeeID = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
            If GrdJobHistory.Rows.Count > 0 Then
                GrdJobHistory.Columns(7).Visible = True
                GrdJobHistory.Columns(8).Visible = True
                GrdJobHistory.Columns(9).Visible = False
            Else
                GrdJobHistory.Columns(7).Visible = False
                GrdJobHistory.Columns(8).Visible = False
                GrdJobHistory.Columns(9).Visible = True
            End If


        End If

    End Sub

    Private Sub GrdJobHistory_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdJobHistory.RowCommand
        If e.CommandName = "AddNewJobHistory" Then
            GrdJobHistory.ShowFooter = True
            GrdJobHistory.Columns(7).Visible = False
            GrdJobHistory.Columns(8).Visible = False
            GrdJobHistory.Columns(9).Visible = True


        ElseIf e.CommandName = "SaveNewJobHistory" Then
            Dim CompanyName As String = CType(GrdJobHistory.FooterRow.FindControl("txtCompanyName"), TextBox).Text
            Dim Designation As String = CType(GrdJobHistory.FooterRow.FindControl("DDLDesignation"), DropDownList).SelectedValue
            Dim Responsibilities As String = CType(GrdJobHistory.FooterRow.FindControl("txtResponsibilities"), TextBox).Text
            Dim Salary As String = CType(GrdJobHistory.FooterRow.FindControl("txtSalary"), TextBox).Text
            Dim ReasonForLeaving As String = CType(GrdJobHistory.FooterRow.FindControl("txtReasonforLeaving"), TextBox).Text
            Dim JoiningDate As String = CType(GrdJobHistory.FooterRow.FindControl("txtJoiningDate"), TextBox).Text
            Dim EndDate As String = CType(GrdJobHistory.FooterRow.FindControl("txtTerminationDate"), TextBox).Text
            If JoiningDate Is Nothing Then JoiningDate = ""
            If EndDate Is Nothing Then EndDate = ""
            If Designation = "" Then Designation = -1
            Payroll.AddEmployeeJobHistory(EmployeeID, CompanyName, Designation, Responsibilities, Salary, JoiningDate, EndDate, ReasonForLeaving)
            GrdJobHistory.ShowFooter = False
            GrdJobHistory.Columns(7).Visible = True
            GrdJobHistory.Columns(8).Visible = True
            GrdJobHistory.Columns(9).Visible = False
        ElseIf e.CommandName = "Insert" Then

        ElseIf e.CommandName = "Cancel" Then
            GrdJobHistory.ShowFooter = False
            GrdJobHistory.EditIndex = -1
            GrdJobHistory.Columns(7).Visible = True
            GrdJobHistory.Columns(8).Visible = True
            GrdJobHistory.Columns(9).Visible = False
        ElseIf e.CommandName = "DeleteJobHistory" Then
            Dim ID As Integer = Val(e.CommandArgument)
            Payroll.DeleteEmployeeJobHistory(ID)
        ElseIf e.CommandName = "Edit" Then
            GrdJobHistory.Columns(7).Visible = True
            GrdJobHistory.Columns(8).Visible = True
            GrdJobHistory.Columns(9).Visible = False

        ElseIf e.CommandName = "Update" Then
            Dim ID As Integer = Val(CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("HdnJobHistoryID"), HiddenField).Value)
            Dim CompanyName As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditCompanyName"), TextBox).Text
            Dim Designation As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("DDLEditDesignation"), DropDownList).SelectedValue
            Dim Responsibilities As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditResponsibilities"), TextBox).Text
            Dim Salary As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditSalary"), TextBox).Text
            Dim ReasonForLeaving As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditReasonforLeaving"), TextBox).Text
            Dim JoiningDate As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditJoiningDate"), TextBox).Text
            Dim EndDate As String = CType(GrdJobHistory.Rows(GrdJobHistory.EditIndex).FindControl("txtEditTerminationDate"), TextBox).Text
            If JoiningDate Is Nothing Then JoiningDate = ""
            If EndDate Is Nothing Then EndDate = ""
            If Designation = "" Then
                Designation = -1
            End If
            Payroll.UpdateEmployeeJobHistory(ID, CompanyName, Designation, Responsibilities, Salary, JoiningDate, EndDate, ReasonForLeaving)
            GrdJobHistory.EditIndex = -1
            GrdJobHistory.Columns(7).Visible = True
            GrdJobHistory.Columns(8).Visible = True
            GrdJobHistory.Columns(9).Visible = False
        End If
        LoadData()

    End Sub

    Sub LoadData()
        GrdJobHistory.DataSource = Payroll.GetEmployeeJobHistory(EmployeeID)
        GrdJobHistory.DataBind()
    End Sub

    Private Sub LnkAddEmpJobHistory_Click(sender As Object, e As EventArgs) Handles LnkAddEmpJobHistory.Click
        GrdJobHistory.ShowFooter = True
        Dim tbl As New DataTable
        Dim row As DataRow

        tbl = Payroll.GetEmployeeJobHistory(EmployeeID)
        If tbl.Rows.Count = 0 Then
            row = tbl.NewRow
            tbl.Rows.InsertAt(row, 0)
        End If
        GrdJobHistory.Columns(7).Visible = False
        GrdJobHistory.Columns(8).Visible = False
        GrdJobHistory.Columns(9).Visible = True
        GrdJobHistory.EditIndex = -1
        GrdJobHistory.DataSource = tbl
        GrdJobHistory.DataBind()
    End Sub

    Private Sub GrdJobHistory_DataBound(sender As Object, e As EventArgs) Handles GrdJobHistory.DataBound

    End Sub

    Private Sub GrdJobHistory_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdJobHistory.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then


            Dim DDLDesignation As New DropDownList
            DDLDesignation = CType(e.Row.FindControl("DDLEditDesignation"), DropDownList)
            If Not DDLDesignation Is Nothing Then

                DDLDesignation.DataTextField = "DesignationName"
                DDLDesignation.DataValueField = "DesignationID"
                DDLDesignation.DataSource = Payroll.GetDesignations(Session("CurrentBusinessID"))
                DDLDesignation.DataBind()


                Dim HdnDesignationValue = CType(e.Row.FindControl("HdnDesignation"), HiddenField).Value

                DDLDesignation.SelectedValue = HdnDesignationValue

            End If

        ElseIf e.Row.RowType = DataControlRowType.Footer Then

                If GrdJobHistory.ShowFooter = True Then
                Dim DDLDesignation As New DropDownList
                DDLDesignation = CType(e.Row.FindControl("DDLDesignation"), DropDownList)
                DDLDesignation.DataTextField = "DesignationName"
                DDLDesignation.DataValueField = "DesignationID"
                DDLDesignation.DataSource = Payroll.GetDesignations(Session("CurrentBusinessID"))
                DDLDesignation.DataBind()
            End If

        End If
    End Sub

    Private Sub GrdJobHistory_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdJobHistory.RowUpdating

    End Sub

    Private Sub GrdJobHistory_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdJobHistory.RowCancelingEdit

    End Sub

    Private Sub GrdJobHistory_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdJobHistory.RowEditing
        GrdJobHistory.EditIndex = e.NewEditIndex
        GrdJobHistory.DataBind()

    End Sub
End Class