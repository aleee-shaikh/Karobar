﻿Imports System.Data.SqlClient

Public Class PurchaseProduct
    Inherits System.Web.UI.Page

    Private Sub PurchaseProduct_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 14) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If

        'Dim txt As New TextBox
        'Dim ddl As New DropDownList       
        LblProductReference.Text = ReferenceData.Setting("LblPurchaseProductReference", "Reference", Session("CurrentBusinessID"))
        LblProductSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
        LblStockLocation.Text = ReferenceData.Setting("LblStockLocation", "Stock Location", Session("CurrentBusinessID"))
        LblPurchaseDate.Text = ReferenceData.Setting("LblPurchaseDate", "Purchase Date", Session("CurrentBusinessID"))
        LblDescription.Text = ReferenceData.Setting("LblDescription", "Description", Session("CurrentBusinessID"))
        LblOtherCharges.Text = ReferenceData.Setting("LblOtherCharges", "Other Charges", Session("CurrentBusinessID"))

        OrderDetails.AddColumn("Product", New DropDownList)
        OrderDetails.AddColumn("Quantity", New TextBox)
        OrderDetails.AddColumn("Unit", New TextBox)
        OrderDetails.AddColumn("Price", New TextBox)
        OrderDetails.AddColumn("Discount", New TextBox)
        OrderDetails.AddColumn("Total", New TextBox)
        OrderDetails.AddColumn("ManufacturingDate", New TextBox)
        OrderDetails.AddColumn("ExpiryDate", New TextBox)

        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.StockLocations * -1)
            DDLStockLocation.DataValueField = "ArticleTypeID"
            DDLStockLocation.DataTextField = "ArticleType"
            DDLStockLocation.DataSource = ds.Tables(0)
            DDLStockLocation.DataBind()

            Dim tbl As New DataTable


            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Supplier)
            DDLSupplier.DataValueField = "UserID"
            DDLSupplier.DataTextField = "FirstName"
            DDLSupplier.DataSource = tbl
            DDLSupplier.DataBind()

            txtPurchaseDate.Text = Now.ToString("dd-MM-yyyy")
        End If
    End Sub



    Protected Sub BtnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnSave.Click

        If OrderDetails.DataRowsCount.Value > 0 Then
            OrderDetails.AddRow()
            OrderDetails.UpdateRows()
        End If

        Dim tbl As New DataTable
        Dim PID As Integer
        Dim SupID As Integer = -1
        Dim StockLocation As Integer = -1
        If DDLSupplier.Items.Count > 0 Then
            SupID = DDLSupplier.SelectedItem.Value
        End If
        If DDLStockLocation.Items.Count > 0 Then
            StockLocation = DDLStockLocation.SelectedItem.Value
        End If

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try
            connection.Open()
            trans = connection.BeginTransaction()

            Dim transtbl As New DataTable
            Dim TID As Integer
            transtbl = Transactions.AddTransaction(Session("CurrentBusinessID"), txtReference.Text.Trim, "Buy", "Product Purchase", "Active", True, Now, trans:=trans)
            Dim PurchaseDateAry() = txtPurchaseDate.Text.Replace("/", "-").Split("-")
            tbl = Products.PurchaseProductMaster(Session("CurrentBusinessID"), txtReference.Text.Trim, SupID, StockLocation, Val(txtOtherCharges.Text), txtDescription.Text, CDate(PurchaseDateAry(1) & "-" & PurchaseDateAry(0) & "-" & PurchaseDateAry(2)), trans)

            If tbl.Rows.Count > 0 Then
                PID = tbl.Rows(0)("PurchaseID")
                TID = transtbl.Rows(0)("TransactionID")
                Transactions.AddTransactionDetails(TID, DDLSupplier.SelectedItem.Value, True, "Purchase Product from " & DDLSupplier.SelectedItem.Text, 0, OrderDetails.TotalAmount, 0, Val(txtOtherCharges.Text), "", PID, trans:=trans)
                tbl = New DataTable
                tbl = OrderDetails.GetPurchaseData()
                Dim PurchaseProductCount As Integer
                Dim productsTbl As New DataTable

                productsTbl = Products.GetProductsList(Session("CurrentBusinessID"))
                For i As Integer = 0 To tbl.Rows.Count - 2
                    If tbl.Rows(i)("Product") > 0 Then
                        Dim ds As New DataSet
                        Dim ptbl As New DataTable
                        Try
                            ptbl = productsTbl.Select("articleid=" & tbl.Rows(i)("Product")).CopyToDataTable()
                        Catch ex As Exception

                        End Try

                        ds.Tables.Add(ptbl)
                        ''ds = Products.GetProductDetails(Session("CurrentBusinessID"), tbl.Rows(i)("Product"))

                        ''Dim ExpDateAry() = tbl.Rows(i)("ExpiryDate").ToString.Replace("/", "-").Split("-")
                        ''Dim ManDateAry() = tbl.Rows(i)("ManufacturingDate").ToString.Replace("/", "-").Split("-")

                        Products.PurchaseProductDetails(PID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), Val(tbl.Rows(i)("Quantity")), Val(tbl.Rows(i)("Price")), Val(tbl.Rows(i)("Discount")), Val(tbl.Rows(i)("Total")), tbl.Rows(i)("ManufacturingDate"), tbl.Rows(i)("ExpiryDate"), trans)
                        Transactions.AddTransactionDetails(TID, ReferenceData.Setting("AccountsPayableID", "-1", Session("CurrentBusinessID")), False, "Purchased :" & ds.Tables(0).Rows(0)("ArticleTitle"), Val(tbl.Rows(i)("Total")), 0, 0, 0, "", PID, trans:=trans)
                        PurchaseProductCount += 1
                    End If
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "PurchaseDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Purchase done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product Purchase", "Product Purchase :" & PID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=PID)
                Log.Notifications_Add("Purchase product " & PurchaseProductCount & " item(s) :" & OrderDetails.TotalAmount, PID, "Purchase Product", PurchaseProductCount)
            End If

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "PurchaseAddingIssue", "<script>parent.ShowMessage('Unable to process purchase','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try




    End Sub
End Class