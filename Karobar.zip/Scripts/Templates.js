﻿//renderExternalTemplate function on the my.utils object first retrieves the
// template using the $.get function. When the call completes, the JsRender template
//  is created using the $.templates function from the contents of the response. Finally, 
//  the template is rendered using the template’s render function and the resulting HTML
//   is displayed in the target. This code could be called using the following code where the template name,
// the DOM target and the data context are passed to the custom renderExternalTemplates function:
//my.utils.renderExternalTemplate("templatename", "#templatContainer", data);


var my = my || {};
my.utils = (function () {
    var
    formatTemplatePath = function (name) {
        //prompt("/CMS/" + name + ".tmpl.htm?" + new Date(),"/CMS/" + name + ".tmpl.htm?" + new Date())
        return "/CMS/" + name + ".tmpl.htm?" + new Date();
    },
    renderTemplate = function (tmplName, targetSelector, data) {
        var file = formatTemplatePath(tmplName);
        $.get(file, null, function (template) {
            var tmpl = $.templates(template);
            var htmlString = tmpl.render(data);
            //alert(tmplName+"\n"+htmlString)
            if (targetSelector) {
                if(htmlString=='')
                    alert(tmpl +'\n1111111111111111'+ tmplName + '   \n-->' + htmlString)
                $(targetSelector).html(htmlString);
            }
            return htmlString;
        });
    };
    return {
        formatTemplatePath: formatTemplatePath,
        renderExternalTemplate: renderTemplate
    };
})()