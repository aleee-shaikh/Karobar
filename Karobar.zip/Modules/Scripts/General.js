var todaysEventIDs = '';

function dateAdd(date, interval, units) {
  var ret = new Date(date); //don't change original date
  var checkRollover = function() { if(ret.getDate() != date.getDate()) ret.setDate(0);};
  switch(interval.toLowerCase()) {
    case 'year'   :  ret.setFullYear(ret.getFullYear() + units); checkRollover();  break;
    case 'quarter':  ret.setMonth(ret.getMonth() + 3*units); checkRollover();  break;
    case 'month'  :  ret.setMonth(ret.getMonth() + units); checkRollover();  break;
    case 'week'   :  ret.setDate(ret.getDate() + 7*units);  break;
    case 'day'    :  ret.setDate(ret.getDate() + units);  break;
    case 'hour'   :  ret.setTime(ret.getTime() + units*3600000);  break;
    case 'minute' :  ret.setTime(ret.getTime() + units*60000);  break;
    case 'second' :  ret.setTime(ret.getTime() + units*1000);  break;
    default       :  ret = undefined;  break;
  }
  return ret;
}
function Events_EventsViewed(ControlID) {
    var Data = []
    if (todaysEventIDs != '') {
        var RequestData = {
            EventIDs: todaysEventIDs
        };

        $.ajax({
            type: "POST",
            dataType: 'xml',
            data: JSON.stringify(RequestData),
            async: false,
            url: '/Webservice/Common.asmx/Events_EventsViewed',
            contentType: "application/json; charset=utf-8",
            success: function (xml) {
                todaysEventIDs = '';
            },
            error: function (xhr, status, errord) {
                alert(xhr.responseText);
            }
        });

    }
    return Data;

}


function GetTodaysEvents(ControlID) {
    var Data = []
    var RequestData = {};

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        //async: false,
        url: '/Webservice/Common.asmx/Events_GetTodaysEvents',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Events").length;
            var PDateTime

            $(xml).find("DateTime").each(function () {
                PDateTime = $(this).find("PortalDateime").text()
            });
            if (Count == 0) {
                ;
            }
            else {
                $("#PortalMessage").html('')
                var notifmsg = ""
                var closelnk = "<a href='#' class='close-notify' style='z-index:999999999;'>X</a>"

                $(xml).find("Events").each(function () {
                    var tmary = $(this).find("EventDate").text().split('-')
                    var evtDt = tmary[0] + "/" + tmary[1] + "/" + tmary[2].substring(0, 2)
                    var evtTmAry = tmary[2].split('T')
                    var evtTm = evtTmAry[1].substring(0, 8)

                    var d1 = new Date(evtDt + " " + evtTm)
                    var d2 = new Date(PDateTime)
                    
                    var minutesRemaining = (d1-d2) / 1000 / 60
                    console.log(d1 +" - " + d2)
                    console.log(minutesRemaining)
                    if (minutesRemaining <= 0 && minutesRemaining>=-86400)//
                    {
                        var remindertext = $(this).find("Reason").text();
                        if (remindertext.trim().length > 1) {
                            notifmsg = "<div class='row'><div class='col-lg-12'>" + remindertext + closelnk + "</div><hr/></div>"
                            //prompt(notifmsg, notifmsg)
                            if (notifmsg.trim().length > 1) {
                                $("#PortalMessage").html($("#PortalMessage").html()+notifmsg);
                                $("#PortalMessage").fadeIn("slow");
                            }
                            //ShowMessage(notifmsg, '2', $(window).height() * 2 / 100, $(window).width() * 35 / 100, '1');
                            todaysEventIDs = todaysEventIDs + $(this).find("EventID").text() + ",";

                            Data.push({
                                EventID: $(this).find("EventID").text(),
                                EventTypeID: $(this).find("EventTypeID").text(),
                                EventDate: $(this).find("EventDate").text(),
                                Reason: $(this).find("Reason").text(),
                                EventTypeName: $(this).find("EventTypeName").text(),
                                EventJsScript: $(this).find("EventJsScript").text(),
                                RunScriptAfterMinutes: $(this).find("RunScriptAfterMinutes").text()
                            });

                            if ($(this).find("EventJsScript").text() != "") {
                                if ($(this).find("RunScriptAfterMinutes").text() > 0) {
                                    setTimeout(function () {
                                        eval(Data[Data.length - 1].EventJsScript)
                                    }, ($(this).find("RunScriptAfterMinutes").text() * 1000) * 60)

                                }
                            }
                        }   
                    }
                    
                    $("#PortalMessage a.close-notify").click(function () {
                        $("#PortalMessage").fadeOut("slow");
                        Events_EventsViewed();
                        return false;
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Data;
}

var BlinkTimers = [];

function StopBlinking(key) {
    for (var i = 0; i < BlinkTimers.length; i++) {
        if (BlinkTimers[i].key == key) {
            $(key).css("background-color", "");
            clearInterval(BlinkTimers[i].tmr);
        }
    }
}

function Blink(selector, color, interval) {
    BlinkTimers.push({
        key:selector,
        tmr:setInterval(function () {
            $(selector).css("background-color", function () {
                this.switch = !this.switch
                return this.switch ? color : ""
            });
        }, interval)
    })
    
}

function ShowEditTask(TID) {
    ShowDlgForm('/Modules/TaskManagement/Tasks.aspx?TaskID=' + TID, $(window).height() * 90 / 100, $(window).width() * 75 / 100)
}

function ShowCreateTask() {
    ShowDlgForm('/Modules/TaskManagement/Tasks.aspx', $(window).height() * 90 / 100, $(window).width() * 75 / 100)
}

function ShowAddReminders() {
    ShowDlgForm('/Modules/CRM/Reminders/Reminders.aspx', $(window).height() * 80 / 100, $(window).width() * 50 / 100)
}

function ShowWorkingShifts() {
    ShowDlgForm('/Modules/Payroll/Attendance/WorkingShifts.aspx', $(window).height() * 88 / 100, $(window).width() * 80 / 100)
}

function ShowTimePunch() {
    ShowDlgForm('/Modules/Payroll/Attendance/TimePunch.aspx', $(window).height() * 80 / 100, $(window).width() * 60 / 100)
}

function ShowDayEvents(dt) {
    ShowDlgForm('/Modules/Payroll/Company/ViewEvents.aspx?dt=' + dt, $(window).height() * 70 / 100, $(window).width() * 48 / 100)
}

function ShowAddHolidays() {
    ShowDlgForm('/Modules/Payroll/Company/CompanyHolidays.aspx', $(window).height() * 70 / 100, $(window).width() * 40 / 100)
}

function ShowAddOFFDays() {
    ShowDlgForm('/Modules/Payroll/Company/CompanyOffDays.aspx', $(window).height() * 56 / 100, $(window).width() * 50 / 100)
}


function getDateTimeDifference(d1, d2) {
    var d;
    if ((d = getDateDiff.inYears(d1, d2)) > 0)
        return d + " year" + ((d > 1) ? 's' : '')
    else if ((d = getDateDiff.inMonths(d1, d2)) > 0)
        return d + " month" + ((d > 1) ? 's' : '')
    else if ((d = getDateDiff.inWeeks(d1, d2)) > 0)
        return d + " week" + ((d > 1) ? 's' : '')
    else if ((d = getDateDiff.inDays(d1, d2)) > 0)
        return d + " day" + ((d > 1) ? 's' : '')
    else if ((d = getDateDiff.inHours(d1, d2)) > 0)
        return d + " hour" + ((d > 1) ? 's' : '')
    else if ((d = getDateDiff.inMinutes(d1, d2)) > 0)
        return d + " minute" + ((d > 1) ? 's' : '')
    else
        return " few seconds"
}

var getDateDiff = {
    inHours: function (d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();
        var diff = Date.parse(d2) - Date.parse(d1);
        return Math.floor(diff / 3600000 % 24);
    },
    inMinutes: function (d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();
        var diff = Date.parse(d2) - Date.parse(d1);
        return Math.floor(diff / 60000 % 60);
    },

    inDays: function (d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();

        return parseInt((t2 - t1) / (24 * 3600 * 1000));
    },

    inWeeks: function (d1, d2) {
        var t2 = d2.getTime();
        var t1 = d1.getTime();

        return parseInt((t2 - t1) / (24 * 3600 * 1000 * 7));
    },

    inMonths: function (d1, d2) {
        var d1Y = d1.getFullYear();
        var d2Y = d2.getFullYear();
        var d1M = d1.getMonth();
        var d2M = d2.getMonth();

        return (d2M + 12 * d2Y) - (d1M + 12 * d1Y);
    },

    inYears: function (d1, d2) {
        return d2.getFullYear() - d1.getFullYear();
    }
}


function ShowCreateCampaign() {
    ShowDlgForm('/Modules/CRM/Marketing/MarketingEmails.aspx', $(window).height() * 96 / 100, $(window).width() * 80 / 100)
}

// Navigation Start
function ShareProductonFB(url) {
    
    //window.open('https://www.facebook.com/sharer/sharer.php?u=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID='+PID ,'', 'toolbar=0,status=0,width=548,height=325')
    if (url && url.length > 0)
        window.open(url, '', 'toolbar=0,status=0,width=548,height=325')
    else {
        var PID = GetID(2);
        window.open('https://www.facebook.com/sharer/sharer.php?u=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID=' + PID, '', 'toolbar=0,status=0,width=548,height=325')
    }
}

function ShareProductonLinkedIn(url) {
    
    if (url && url.length > 0)
        window.open(url, '', 'toolbar=0,status=0,width=548,height=325')
    else {
        var PID = GetID(2);
        window.open('https://www.linkedin.com/cws/share?url=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID=' + PID, '', 'toolbar=0,status=0,width=548,height=325')
    }
}

function ShareProductonTwitter() {
    var PID = GetID(2);
    if (url && url.length > 0)
        window.open(url, '', 'toolbar=0,status=0,width=548,height=325')
    else
        window.open('https://www.linkedin.com/cws/share?url=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID=' + PID, '', 'toolbar=0,status=0,width=548,height=325')
}
function ShowCreateGRN() {
    ShowDlgForm('/Modules/Karobar/Transaction/GRN/GRN.aspx', $(window).height() * 96 / 100, $(window).width() * 80 / 100)
}

function ShowCreatePO() {
    ShowDlgForm('/Modules/Karobar/Transaction/PO/PO.aspx', $(window).height() * 96 / 100, $(window).width() * 80 / 100)
}


function ShowSaleProduct(TID) {
    ShowDlgForm('/Modules/Karobar/Product/SaleProduct.aspx?TID=' + TID, $(window).height() * 99.5 / 100, $(window).width() * 75 / 100);
    return false;
}

function ShowSaleReturn(TID) {
    ShowDlgForm('/Modules/Karobar/Product/SaleReturn.aspx?TID=' + TID, $(window).height() * 99.5 / 100, $(window).width() * 80 / 100);
    return false;
}

function ShowOrderDetails(OID) {
    ShowDlgForm('/Modules/Karobar/Product/OrderDetails.aspx?OID=' + OID, $(window).height() * 97 / 100, $(window).width() * 95 / 100);
    return false;
}

function ShowPurchaseProduct() {
    ShowDlgForm('/Modules/Karobar/Product/PurchaseProduct.aspx', $(window).height() * 90 / 100, $(window).width() * 80 / 100)
}

function ShowExchangeProduct() {
    ShowDlgForm('/Modules/Karobar/Product/ExchangeProduct.aspx', $(window).height() * 90 / 100, $(window).width() * 72 / 100)
}

function ShowReceivePaymentInvoice(TID) {
    ShowDlgForm('/Modules/Karobar/Reports/PaymentreceivedInvoice.aspx?TID=' + TID, $(window).height() * 90 / 100, $(window).width() * 70 / 100)
}


function ShowCashPaymentInvoice(TID) {
    ShowDlgForm('/Modules/Karobar/Reports/PaymentPaidInvoice.aspx?TID=' + TID, $(window).height() * 90 / 100, $(window).width() * 75 / 100)
}

function ShowCashPaymentVoucher() {
    ShowDlgForm('/Modules/Karobar/Transaction/CashVoucher.aspx', $(window).height() * 90 / 100, $(window).width() * 80 / 100);
}

function ShowBankPaymentInvoice(TID) {
    ShowDlgForm('/Modules/Karobar/Reports/PaymentPaidInvoice.aspx?TID=' + TID, $(window).height() * 85 / 100, $(window).width() * 75 / 100)
}


function ShowReceivePayment() {
    ShowDlgForm('/Modules/Karobar/Transaction/PaymentReceived.aspx', $(window).height() * 90 / 100, $(window).width() * 58 / 100)
}

function ShowBankPaymentVoucher() {
    ShowDlgForm('/Modules/Karobar/Transaction/BankVoucher.aspx', $(window).height() * 89 / 100, $(window).width() * 85 / 100);
}

function ShowAddNewProduct() {
    ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx', $(window).height() * 98 / 100, $(window).width() * 80 / 100)
}

function ShowManageGallary(ID) {
    ShowDlgForm('/Modules/School/Gallary/Gallary.aspx'+ID, $(window).height() * 98 / 100, $(window).width() * 80 / 100)
}

function ShowAddNewOffer() {
    ShowDlgForm('/Modules/Karobar/Offer/Offer.aspx', $(window).height() * 96 / 100, $(window).width() * 80 / 100)
}

function EditOffer(OfferID) {
    ShowDlgForm('/Modules/Karobar/Offer/Offer.aspx?ID='+OfferID, $(window).height() * 96 / 100, $(window).width() * 80 / 100)
}

function ShowEditProduct(PID) {
    ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx?PID=' + PID, $(window).height() * 98 / 100, $(window).width() * 78 / 100)
}
function ShowAddPagesContents() {
    ShowDlgForm('/Modules/Karobar/WebSections/WebSections.aspx', $(window).height() * 90 / 100, $(window).width() * 80 / 100)
}


function ShowAddStaff(SID) {
    ShowDlgForm('/Modules/Payroll/Employee/PayrollStaff.aspx?SID=' + SID, $(window).height() * 95 / 100, $(window).width() * 84 / 100);
    //if (SID > 0) {
    //    ShowDlgForm('/Modules/Karobar/People/Staff.aspx?SID='+SID, $(window).height() * 95 / 100, $(window).width() * 78 / 100);
    //}
    //else {
    //    ShowDlgForm('/Modules/Karobar/People/Staff.aspx', $(window).height() * 95 / 100, $(window).width() * 78 / 100);
    //}
}

function ShowAddStudent(SID) {
    ShowDlgForm('/Modules/School/Student/Student.aspx?SID=' + SID, $(window).height() * 95 / 100, $(window).width() * 84 / 100);
}

function AddCustomer(CID) {
    if (CID > 0) {
        ShowDlgForm('/Modules/Karobar/People/Customer.aspx?CID=' + CID, $(window).height() * 88 / 100, $(window).width() * 88 / 100)
    }
    else {
        ShowDlgForm('/Modules/Karobar/People/Customer.aspx', $(window).height() * 88 / 100, $(window).width() * 80 / 100)
    }
}

function AddSupplier(VID) {
    if (VID > 0) {
        ShowDlgForm('/Modules/Karobar/People/Vendor.aspx?VID=' + VID, $(window).height() * 90 / 100, $(window).width() * 80 / 100);
    }
    else {
        ShowDlgForm('/Modules/Karobar/People/Vendor.aspx', $(window).height() * 90 / 100, $(window).width() * 80 / 100);
    }

    return false
}

function ShowOrderInvoice(OID) {
    ShowDlgForm('/Modules/Karobar/Product/Order_Invoice.aspx?OID' + OID, $(window).height() * 98 / 100, $(window).width() * 80 / 100);
    return false;
}
// Navigation End

function LoadDDLOptions(CtrlID, Options) {
    $('#' + CtrlID).empty();
    for (var i = 0; i < Options.length; i++) {
        $('#' + CtrlID).append("<option value='" + Options[i].ArticleTypeID + "' >" + Options[i].ArticleType + "</option>");
    }
}

function LoadSelectedImages(files, TargetImg) {
    for (var i = 0, f; f = files[i]; i++) {
        $('#filesSize').append(f.name + ' - ' + f.size + '<br />');

        var reader = new FileReader();
        reader.onload = function (evt) {
            $("#" + TargetImg).attr('src', evt.target.result)
        }
        reader.readAsDataURL(f);
    }
}

function GetRandomNumber(min, max) {
    return Math.random() * (max - min) + min;
}

function CharExist(SourceStr, SearchStr) {
    var found = false;

    for (var i = 0; i < SearchStr.length; i++) {
        if (SourceStr.indexOf(SearchStr[i]) >= 0) {
            found = true;
            break;
        }
    }
    return found;
}
function ReplaceWith(SourceStr, ReplaceChars, ReplaceWith) {
    for (var i = 0; i < ReplaceChars.length; i++) {
        //if (SourceStr.indexOf('$') >= 0) alert(SourceStr + '---->' + ReplaceChars[i])
        for (j = 0; j < SourceStr.length; j++)
            SourceStr = SourceStr.replace(ReplaceChars[i], ReplaceWith)
    }
    return SourceStr
}

function isUrlValid(url) {
    return /^(https?|s?ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
}

function verifyEmail(Email) {
    var status = false;
    var emailRegEx = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i;
    if (Email.search(emailRegEx) == -1) {
        status = false;
    }
    else {
        status = true;
    }
    return status;
}

function SubscribeUser(ControlID) {

    var RequestData = {
        ArticleTypeID: document.getElementById(ControlID + "ArticleType").options[document.getElementById(ControlID + "ArticleType").selectedIndex].value,
        UserEmailAddress: $('#' + ControlID + 'EmailAddress').val()
    };

    if ($('#' + ControlID + 'EmailAddress').val() == '') {
        alert('Email address is missing');
        return false
    }
    else if (verifyEmail($('#' + ControlID + 'EmailAddress').val()) == false) {
        alert('Invalid email address');
        return false
    }

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/SubsCribeUserforNewsLetter',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("SubscribeUsers").length;
            alert("Your subscription has been done")

            $('#' + ControlID + 'EmailAddress').val('')
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
}

function GetSubscribeNewsLetterData(ControlID) {
    var RequestData = {
        UserID: ''
    };
    var Data = [];

    Data = GetArticleTypes()
    return Data;
}


function LoadContactUsData(ControlID) {
    var RequestData = {
        UserID: ''
    };
    var Data = [];
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/GetContactUsData',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ContactUsData").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ContactUsData").each(function () {
                    Data.push({
                        FromDepartmentID: $(this).find("FromDepartmentID").text(),
                        FromDepartmentName: $(this).find("FromDepartmentName").text(),
                        FromTeamID: $(this).find("FromTeamID").text(),
                        FromTeamName: $(this).find("FromTeamName").text(),
                        FromPersonID: $(this).find("FromPersonID").text(),
                        ToTeamID: $(this).find("ToTeamID").text(),
                        ToTeamName: $(this).find("ToTeamName").text(),
                        ToPersonID: $(this).find("ToPersonID").text(),
                        ToPersonName: $(this).find("ToPersonName").text(),
                        ToDepartmentID: $(this).find("ToDepartmentID").text(),
                        ToDepartmentName: $(this).find("ToDepartmentName").text(),
                        TicketTypeID: $(this).find("TicketTypeID").text(),
                        TicketTypeName: $(this).find("TicketTypeName").text(),
                        TicketPriorityID: $(this).find("TicketPriorityID").text(),
                        TicketStatusID: $(this).find("TicketStatusID").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Data;
}

function PageNoClicked(PagingCtrlID, PgNo) {
    $("#" + PagingCtrlID + "_PageNo").val(PgNo)
}

function LoadPaging(CtrlID, PagingContainer, Data, CallingFunction) {
    var PagingData = [];
    var Pages = []
    var PagesCount = 0;
    //alert(JSON.stringify(Data))
    for (var i = 0; i < Data.length; i++) {
        PagesCount = Data[i].PagesCount;
    }


    for (var i = 0; i < PagesCount; i++) {
        Pages.push({
            PageNo: (i + 1),
            PagingCtrlID: CtrlID,
            CallingFunction: CallingFunction
        })
    }

    PagingData.push({
        StartPage: 1,
        EndPage: PagesCount,
        Pages: Pages,
        PagingCtrlID: CtrlID,
        CallingFunction: CallingFunction
    })
    my.utils.renderExternalTemplate("Shared/Templates/Website_Pagination", "#" + PagingContainer, PagingData);
}