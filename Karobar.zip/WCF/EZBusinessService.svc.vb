﻿Imports System.ServiceModel
Imports System.ServiceModel.Activation
Imports System.ServiceModel.Web
Imports System.Web.Script.Serialization

<ServiceContract(Namespace:="")>
<AspNetCompatibilityRequirements(RequirementsMode:=AspNetCompatibilityRequirementsMode.Allowed)>
Public Class EZBusinessService

    ' To use HTTP GET, add <WebGet()> attribute. (Default ResponseFormat is WebMessageFormat.Json)
    ' To create an operation that returns XML,
    '     add <WebGet(ResponseFormat:=WebMessageFormat.Xml)>,
    '     and include the following line in the operation body:
    '         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml"
    <OperationContract()>
    <WebInvoke(Method:="GET")>
    Public Function SearchBusinesses() As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.GetWebsites()
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"
        Return ds.GetXml().ToArray
    End Function

    ' Add more operations here and mark them with <OperationContract()>



End Class
