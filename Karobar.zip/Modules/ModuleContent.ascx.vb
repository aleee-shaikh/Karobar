﻿Public Class ModuleContent
    Inherits System.Web.UI.UserControl
    Dim _Text As String

    Public Property Text() As String
        Get
            Return _Text
        End Get
        Set(ByVal value As String)
            _Text = value
            Dim ltrlctrl As New LiteralControl(value)

            Me.Controls.Add(ltrlctrl)
        End Set
    End Property
    
End Class