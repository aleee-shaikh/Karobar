﻿Imports System.ServiceModel
Imports System.ServiceModel.Web

' NOTE: You can use the "Rename" command on the context menu to change the interface name "IEZKarobar" in both code and config file together.
<ServiceContract()>
Public Interface IEZKarobar

    <OperationContract()>
    <WebGet(UriTemplate:="/SearchBusinesses")>
    Function SearchBusinesses() As String

End Interface
