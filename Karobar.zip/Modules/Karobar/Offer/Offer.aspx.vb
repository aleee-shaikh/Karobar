﻿Public Class Offer
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHavePageRights(Session("UserID"), 51) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        '    Exit Sub
        'End If

        If Not Page.IsPostBack Then

            If Val(HdnOfferID.Value) <= 0 Then
                LblScreenTitle.Text = "Create Offer"
            Else
                LblScreenTitle.Text = "Update Offer"
            End If

            If Not Request("ID") Is Nothing Then
                HdnOfferID.Value = Val(Request("ID"))
                BtnSave.Visible = False
                btnUpdate.Visible = True
                BtnUpdateAndSend.Visible = True
            Else
                BtnSave.Visible = True
                btnUpdate.Visible = False
                BtnUpdateAndSend.Visible = False
            End If

            LoadData(Val(HdnOfferID.Value))
        End If

    End Sub

    Sub LoadData(ByVal OfferID As Integer)
        Dim ds As New DataSet

        ds = OffersAndDeals.Offer_GetOffers(Session("CurrentBusinessID"), OfferID)
        If (ds.Tables.Count > 2) Then
            If ds.Tables(0).Rows.Count > 0 Then
                txtOfferTitle.Text = ds.Tables(0).Rows(0)("OfferTitle")
                txtOfferValidityDate.Text = CDate(ds.Tables(0).Rows(0)("ValidTillDate")).ToString("dd-MM-yyyy")
                txtOfferCode.Text = ds.Tables(0).Rows(0)("OfferCode")
                txtOfferDiscount.Text = ds.Tables(0).Rows(0)("OfferDiscount")
                txtOfferTermsConditions.Text = ds.Tables(0).Rows(0)("OfferTermsCondition")

                If (IsDBNull(ds.Tables(0).Rows(0)("OfferImage")) = False AndAlso ds.Tables(0).Rows(0)("OfferImage") <> "") Then
                    Dim BusinessDirectory As String = "~/CMS/Offers/Images"
                    HdnOfferImageFilename.Value = ds.Tables(0).Rows(0)("OfferImage")
                    OfferImage.ImageUrl = BusinessDirectory & "/" & ds.Tables(0).Rows(0)("OfferImage")
                Else
                    OfferImage.ImageUrl = "/Images/no-image.png"
                End If
                OfferImage.AlternateText = txtOfferTitle.Text
                chkAutomaticallySendOffer2NearPeople.Checked = IIf(IsDBNull(ds.Tables(0).Rows(0)("AutoSend2NearCustomers")) = False AndAlso ds.Tables(0).Rows(0)("AutoSend2NearCustomers") = True, True, False)
            End If

            Dim productIDs As String = ""
            Dim productTitles As String = ""
            For i As Integer = 0 To ds.Tables(1).Rows.Count - 1
                productIDs = productIDs & ds.Tables(1).Rows(i)("productID") & ";"
                productTitles = productTitles & ds.Tables(1).Rows(i)("ArticleTitle") & ";"
            Next
            txtOfferProducts.Text = productIDs
            txtOfferProductsTitle.Text = productTitles


            Dim TOEmails As String = ""
            For i As Integer = 0 To ds.Tables(2).Rows.Count - 1
                TOEmails = TOEmails & ds.Tables(2).Rows(i)("LoginID") & ";"
            Next
            txtTOEmails.Text = TOEmails

            RdoSpecificUsers.Checked = True
        End If
    End Sub

    Private Sub btnNextToOfferUsers_Click(sender As Object, e As EventArgs) Handles btnNextToOfferUsers.Click
        Dim products() = txtOfferProducts.Text.Split(";")

        If products.Count <= 1 Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferValidation", "<script>parent.ShowMessage('Atleast one product must be selected for offer','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Else
            pnlOfferUsers.Visible = True
            pnlOfferProducts.Visible = False
            pnlOfferDetails.Visible = False
            LoadUsers()
        End If


    End Sub

    Private Sub BtnNextToOfferProducts_Click(sender As Object, e As EventArgs) Handles BtnNextToOfferProducts.Click
        If txtOfferTitle.Text.Trim() = "" Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferValidation", "<script>parent.ShowMessage('Missing offer title','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        ElseIf txtOfferValidityDate.Text.Trim() = "" Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferValidation", "<script>parent.ShowMessage('Missing offer validity date','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Else
            pnlOfferProducts.Visible = True
            pnlOfferUsers.Visible = False
            pnlOfferDetails.Visible = False
            GrdProducts.DataSource = Products.GetProductsList(Session("CurrentBusinessID"), -1, -1, txtSearchOfferProduct.Text)
            GrdProducts.DataBind()
        End If
        Dim OfferImageFilename As String = HdnOfferImageFilename.Value

        If FileUploadOfferImage.PostedFile.FileName <> "" AndAlso FileUploadOfferImage.PostedFile.FileName <> OfferImageFilename Then
            OfferImageFilename = "Offer-" & Val(HdnOfferID.Value) & System.IO.Path.GetExtension(FileUploadOfferImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/Offers/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If
            FileUploadOfferImage.SaveAs(BusinessDirectory & "/" & OfferImageFilename)
            HdnOfferImageFilename.Value = OfferImageFilename
        End If
    End Sub

    Private Sub btnBackToOfferDetails_Click(sender As Object, e As EventArgs) Handles btnBackToOfferDetails.Click
        pnlOfferDetails.Visible = True
        pnlOfferProducts.Visible = False
        pnlOfferUsers.Visible = False
    End Sub

    Private Sub GrdProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim txtProductID As New TextBox
            Dim products As String = txtOfferProducts.Text.ToLower.Trim()
            chk = CType(e.Row.FindControl("ChkProduct"), CheckBox)
            txtProductID = CType(e.Row.FindControl("txtProductID"), TextBox)
            If (Not txtProductID Is Nothing) Then
                If products.IndexOf(txtProductID.Text.ToLower().Trim() & ";") >= 0 Then
                    chk.Checked = True
                End If
            End If

        End If
    End Sub

    Sub LoadUsers()
        ''GrdWebsiteUsers.DataSource = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
        GrdWebsiteUsers.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", 4)
        GrdWebsiteUsers.DataBind()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        GrdWebsiteUsers.DataSource = Website.User.GetWebsiteUsers(Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
        GrdWebsiteUsers.DataBind()
    End Sub

    Private Sub btnDoneUserSelection_Click(sender As Object, e As EventArgs) Handles btnDoneUserSelection.Click
        HdnSpecificUserSelected.Value = 0
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim BusinessID As Integer = Val(Session("CurrentBusinessID"))
        Dim SelectedUserCount As Integer = 0

        Dim OfferImageFilename As String = HdnOfferImageFilename.Value

        If RdoAllUsers.Checked = False Then
            For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
                Dim chk As New CheckBox
                Dim HdnUserID As New HiddenField
                chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
                HdnUserID = CType(GrdWebsiteUsers.Rows(i).FindControl("HdnUserID"), HiddenField)
                If chk.Checked Then
                    SelectedUserCount += 1
                End If
            Next

            If SelectedUserCount <= 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferValidation", "<script>parent.ShowMessage('Atleast one user must be selected for offer','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                Return
            End If
        End If


        If Val(HdnOfferID.Value) = 0 Then 'Add new Offer
            Dim tbl As New DataTable
            tbl = OffersAndDeals.Offer_Add(BusinessID, txtOfferTitle.Text.Trim(), txtOfferCode.Text.Trim(), txtOfferDiscount.Text.Trim(), txtOfferDescription.Text.Trim(), txtOfferTermsConditions.Text.Trim(), 1, General.GetDateinMMDDYYYY(txtOfferValidityDate.Text, "-"), Session("UserID"), OfferImageFilename, chkAutomaticallySendOffer2NearPeople.Checked)

            If tbl.Rows.Count > 0 Then
                Dim offerID As Integer
                Dim products() = txtOfferProducts.Text.Split(";")
                offerID = tbl.Rows(0)("OfferID")
                For i As Integer = 0 To products.Count - 1
                    If (Val(products(i)) > 0) Then
                        OffersAndDeals.Offer_AddOfferProduct(BusinessID, offerID, products(i))
                    End If
                Next

                Dim offerTitle As String

                offerTitle = txtOfferTitle.Text
                Dim userID As Integer
                If RdoAllUsers.Checked Then
                    Dim tblUser As New DataTable
                    tblUser = Website.User.GetWebsiteUsers(WebsiteID:=BusinessID, IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
                    For i As Integer = 0 To tbl.Rows.Count - 1
                        userID = tblUser.Rows(i)("UserID")
                        OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
                    Next
                Else
                    Dim UsersIds As String = ""
                    For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
                        Dim chk As New CheckBox
                        Dim HdnUserID As New HiddenField
                        chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
                        HdnUserID = CType(GrdWebsiteUsers.Rows(i).FindControl("HdnUserID"), HiddenField)
                        If chk.Checked Then
                            userID = Val(HdnUserID.Value)
                            OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
                        End If
                    Next
                End If

                Log.Notifications_Add(offerTitle, offerID, "ClientNotification", 1, BusinessID) '1=offer

            End If
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferAddedSuccessfully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Offer added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")

        Else 'Update Offer
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferUpdatedSuccessfully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Offer updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        End If
    End Sub

    Private Sub BtnSearchOfferProduct_Click(sender As Object, e As EventArgs) Handles BtnSearchOfferProduct.Click
        GrdProducts.DataSource = Products.GetProductsList(Session("CurrentBusinessID"), -1, -1, txtSearchOfferProduct.Text)
        GrdProducts.DataBind()
    End Sub

    Private Sub GrdWebsiteUsers_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdWebsiteUsers.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnLoginId As New HiddenField
            Dim emls As String = txtTOEmails.Text.ToLower.Trim()
            chk = CType(e.Row.FindControl("ChkUser"), CheckBox)
            hdnLoginId = CType(e.Row.FindControl("HdnLoginID"), HiddenField)
            If (Not hdnLoginId Is Nothing) Then
                If emls.IndexOf(hdnLoginId.Value.ToLower().Trim() & ";") >= 0 Then
                    chk.Checked = True
                End If
            End If

        End If
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim BusinessID As Integer = Val(Session("CurrentBusinessID"))
        Dim offerID As Integer = Val(HdnOfferID.Value)
        Dim tbl As New DataTable

        Dim OfferImageFilename As String = HdnOfferImageFilename.Value


        tbl = OffersAndDeals.Offer_Update(BusinessID, offerID, txtOfferTitle.Text.Trim(), txtOfferCode.Text.Trim(), txtOfferDiscount.Text.Trim(), txtOfferDescription.Text.Trim(), txtOfferTermsConditions.Text.Trim(), 1, General.GetDateinMMDDYYYY(txtOfferValidityDate.Text, "-"), OfferImageFilename, chkAutomaticallySendOffer2NearPeople.Checked)

        Dim products() = txtOfferProducts.Text.Split(";")

        For i As Integer = 0 To products.Count - 1
            If (Val(products(i)) > 0) Then
                OffersAndDeals.Offer_AddOfferProduct(BusinessID, offerID, products(i))
            End If
        Next

        Dim offerTitle As String

        offerTitle = txtOfferTitle.Text
        Dim userID As Integer
        If RdoAllUsers.Checked Then
            Dim tblUser As New DataTable
            tblUser = Website.User.GetWebsiteUsers(WebsiteID:=BusinessID, IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
            For i As Integer = 0 To tbl.Rows.Count - 1
                userID = tblUser.Rows(i)("UserID")
                OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
            Next
        Else
            Dim UsersIds As String = ""
            For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
                Dim chk As New CheckBox
                Dim HdnUserID As New HiddenField
                chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
                HdnUserID = CType(GrdWebsiteUsers.Rows(i).FindControl("HdnUserID"), HiddenField)
                If chk.Checked Then
                    userID = Val(HdnUserID.Value)
                    OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
                End If
            Next
        End If

        ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferUpdatedSuccessfully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Offer updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
    End Sub

    Private Sub BtnUpdateAndSend_Click(sender As Object, e As EventArgs) Handles BtnUpdateAndSend.Click
        Dim BusinessID As Integer = Val(Session("CurrentBusinessID"))
        Dim offerID As Integer = Val(HdnOfferID.Value)
        Dim tbl As New DataTable

        Dim OfferImageFilename As String = HdnOfferImageFilename.Value

        tbl = OffersAndDeals.Offer_Update(BusinessID, offerID, txtOfferTitle.Text.Trim(), txtOfferCode.Text.Trim(), txtOfferDiscount.Text.Trim(), txtOfferDescription.Text.Trim(), txtOfferTermsConditions.Text.Trim(), 1, General.GetDateinMMDDYYYY(txtOfferValidityDate.Text, "-"), OfferImageFilename, chkAutomaticallySendOffer2NearPeople.Checked)

        Dim products() = txtOfferProducts.Text.Split(";")

        For i As Integer = 0 To products.Count - 1
            If (Val(products(i)) > 0) Then
                OffersAndDeals.Offer_AddOfferProduct(BusinessID, offerID, products(i))
            End If
        Next

        Dim offerTitle As String

        offerTitle = txtOfferTitle.Text
        Dim userID As Integer
        If RdoAllUsers.Checked Then
            Dim tblUser As New DataTable
            tblUser = Website.User.GetWebsiteUsers(WebsiteID:=BusinessID, IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
            For i As Integer = 0 To tbl.Rows.Count - 1
                userID = tblUser.Rows(i)("UserID")
                OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
            Next
        Else
            Dim UsersIds As String = ""
            For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
                Dim chk As New CheckBox
                Dim HdnUserID As New HiddenField
                chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
                HdnUserID = CType(GrdWebsiteUsers.Rows(i).FindControl("HdnUserID"), HiddenField)
                If chk.Checked Then
                    userID = Val(HdnUserID.Value)
                    OffersAndDeals.Offer_AssignToUser(BusinessID, userID, offerID)
                End If
            Next
        End If
        Log.Notifications_Add(offerTitle, offerID, "ClientNotification", 1, BusinessID) '1=offer
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "OfferUpdatedSuccessfully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Offer updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
    End Sub

    Private Sub btnBackToOfferProducts_Click(sender As Object, e As EventArgs) Handles btnBackToOfferProducts.Click
        pnlOfferDetails.Visible = False
        pnlOfferProducts.Visible = True
        pnlOfferUsers.Visible = False
    End Sub
End Class