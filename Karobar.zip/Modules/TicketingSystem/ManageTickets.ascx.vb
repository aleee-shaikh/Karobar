﻿Public Class ManageTickets
    Inherits System.Web.UI.UserControl

    Sub LoadData()
        GrdTickets.DataSource = Tickets.GetTickets(Val(Session("CurrentBusinessID")), DDLTicketTypes.SelectedItem.Value, txtFreeText.Text, Now.ToString("yyyyMMdd"), Now.ToString("yyyyMMdd"))
        GrdTickets.DataBind()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
        Else
            DDLTicketTypes.DataSource = Tickets.GetTicketTypes(Session("CurrentBusinessID"), ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
            DDLTicketTypes.DataTextField = "TicketType"
            DDLTicketTypes.DataValueField = "TicketTypeID"
            DDLTicketTypes.DataBind()

            DDLTicketStatus.DataSource = Tickets.GetTicketStatuses(Session("CurrentBusinessID"))
            DDLTicketStatus.DataTextField = "TicketStatusName"
            DDLTicketStatus.DataValueField = "TicketStatusID"
            DDLTicketStatus.DataBind()
            txtTicketFromDate.Text = Now.ToString("MM/dd/yyyy")
            txtTicketToDate.Text = Now.ToString("MM/dd/yyyy")
            LoadData()
        End If
    End Sub

    Private Sub DDLTicketTypes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLTicketTypes.SelectedIndexChanged
        LoadData()
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnSaveTicketDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSaveTicketDetails.Click
        Tickets.SaveTicketDetails(Session("CurrentBusinessID"), Val(HdnTicketID.Value), Val(HdnTicketLogID.Value), DDLTicketStatus.SelectedItem.Value, txtTicketDescription.Text.Trim)
        Response.Redirect("~/Tickets")
    End Sub

    
End Class