﻿Public Class AssignStudents
    Inherits System.Web.UI.UserControl

    Dim _TeacherID As Integer

    Public Property TeacherID() As Integer
        Get
            Return HdnTeacherID.Value
        End Get
        Set(value As Integer)
            _TeacherID = value
            HdnTeacherID.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()

            Dim tbl As New DataTable
            tbl = Payroll.GetDepartments(Val(Session("CurrentBusinessID")))
            DDLClass1.DataValueField = "DepartmentID"
            DDLClass1.DataTextField = "DepartmentName"
            DDLClass1.DataSource = tbl
            DDLClass1.DataBind()
            DDLClass1.Items.Insert(0, New ListItem("All", "-1"))

            tbl = Payroll.GetDepartments(Val(Session("CurrentBusinessID")))
            DDLClass2.DataValueField = "DepartmentID"
            DDLClass2.DataTextField = "DepartmentName"
            DDLClass2.DataSource = tbl
            DDLClass2.DataBind()
            DDLClass2.Items.Insert(0, New ListItem("All", "-1"))
        End If


    End Sub

    Sub LoadAssignedStudents(StudentClass As String)
        Dim tbl As New DataTable
        If (StudentClass = "-1") Then
            StudentClass = ""
        End If

        tbl = Person.GetAssignedUsers(Val(Session("CurrentBusinessID")), TeacherID, "7,", StudentClass)
        ChkLstAssignedStudent.DataTextField = "UserName"
        ChkLstAssignedStudent.DataValueField = "UserID"
        ChkLstAssignedStudent.DataSource = tbl
        ChkLstAssignedStudent.DataBind()
    End Sub

    Sub LoadNotAssignedStudents(StudentClass As String)
        Dim tbl As New DataTable
        If (StudentClass = "-1") Then
            StudentClass = ""
        End If

        tbl = Person.GetNotAssignedUsers(Val(Session("CurrentBusinessID")), TeacherID, "7,", StudentClass)
        ChkLstUnAssignedStudent.DataTextField = "UserName"
        ChkLstUnAssignedStudent.DataValueField = "UserID"
        ChkLstUnAssignedStudent.DataSource = tbl
        ChkLstUnAssignedStudent.DataBind()
    End Sub

    Sub LoadData()

        LoadAssignedStudents(DDLClass2.SelectedValue)
        LoadNotAssignedStudents(DDLClass1.SelectedValue)

    End Sub

    Private Sub btnAssign_Click(sender As Object, e As EventArgs) Handles btnAssign.Click
        Dim UserIDs As String = ""

        For i As Integer = ChkLstUnAssignedStudent.Items.Count - 1 To 0 Step -1
            If (ChkLstUnAssignedStudent.Items(i).Selected) Then
                UserIDs = UserIDs & ChkLstUnAssignedStudent.Items(i).Value & ","
                ChkLstAssignedStudent.Items.Add(ChkLstUnAssignedStudent.Items(i))
                ChkLstUnAssignedStudent.Items.RemoveAt(i)
            End If
        Next

        If UserIDs <> "" Then
            Person.Users_AssignUsers(Val(Session("CurrentBusinessID")), UserIDs, TeacherID, Val(Session("UserID")))
        End If
    End Sub

    Private Sub btnUnAssign_Click(sender As Object, e As EventArgs) Handles btnUnAssign.Click
        Dim UserIDs As String = ""

        For i As Integer = ChkLstAssignedStudent.Items.Count - 1 To 0 Step -1
            If (ChkLstAssignedStudent.Items(i).Selected) Then
                UserIDs = UserIDs & ChkLstAssignedStudent.Items(i).Value & ","
                ChkLstUnAssignedStudent.Items.Add(ChkLstAssignedStudent.Items(i))
                ChkLstAssignedStudent.Items.RemoveAt(i)
            End If
        Next

        If UserIDs <> "" Then
            Person.Users_UnAssignUsers(Val(Session("CurrentBusinessID")), UserIDs, TeacherID)
        End If
    End Sub

    Private Sub DDLClass1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLClass1.SelectedIndexChanged
        LoadNotAssignedStudents(DDLClass1.SelectedValue)
    End Sub

    Private Sub DDLClass2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLClass2.SelectedIndexChanged
        LoadAssignedStudents(DDLClass2.SelectedValue)
    End Sub
End Class