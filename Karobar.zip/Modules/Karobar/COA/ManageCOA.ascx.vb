﻿'Imports CMS.COAHeadRow

Public Class ManageCOA
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            If Person.DoesPersonHavePageRights(Session("UserID"), 40) = False Then
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage coa screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            End If
        Else
            'If Not Me.IsPostBack Then
            '    LoadData()
            'Else

            'End If

            'GrdChartOfAccount.Columns(5).Visible = (ReferenceData.Setting("EnabledCOADeleteAddEditFunctionality", "No") = "Yes")
        End If

    End Sub

    'Sub LoadData()
    '    Dim tbl As New DataTable
    '    tbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), FreeText:=txtFreeText.Text.Trim)
    '    GrdChartOfAccount.DataSource = tbl
    '    GrdChartOfAccount.DataBind()


    'End Sub

    'Private Sub GrdChartofAccount_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdChartOfAccount.PageIndexChanging
    '    GrdChartOfAccount.PageIndex = e.NewPageIndex
    '    LoadData()
    'End Sub

    'Private Sub GrdChartofAccount_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdChartOfAccount.RowCommand
    '    If e.CommandName = "DeleteAccountHead" Then
    '        ChartOfAccount.DeleteCOAAccountHead(Session("CurrentBusinessID"), e.CommandArgument)
    '        LoadData()
    '        Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "COA", "Deleted Account Head " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
    '    End If
    'End Sub

    'Private Sub GrdChartofAccount_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdChartOfAccount.RowDataBound
    '    If e.Row.RowType = DataControlRowType.DataRow Then

    '        Dim AccountHeadEditLnkBtn As New System.Web.UI.WebControls.LinkButton
    '        AccountHeadEditLnkBtn = CType(e.Row.FindControl("LnkEditAccountHead"), LinkButton)
    '        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
    '        If Not AccountHeadEditLnkBtn Is Nothing Then
    '            AccountHeadEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/COA/COA.aspx?AHID=" & drview("AccountHeadID") & "',$(window).height()*58/100,$(window).width()*47/100);return false"
    '        End If

    '        'Dim LnkOpeningBalance As New LinkButton
    '        'LnkOpeningBalance = CType(e.Row.FindControl("LnkAddOpeningBalance"), LinkButton)
    '        'If Not LnkOpeningBalance Is Nothing Then
    '        '    LnkOpeningBalance.OnClientClick = "$('#" & txtOpeningBalanceAmount.ClientID & "').val('" & drview("OpeningBalance") & "');$('#" & HdnSelectedAccountHeadID.ClientID & "').val('" & drview("AccountHeadID") & "');return ShowDlg('DlgAccountOpeningBalance');"
    '        'End If

    '        e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
    '        e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
    '    End If
    'End Sub

    'Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
    '    LoadData()
    'End Sub

    'Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
    '    Try
    '        ChartOfAccount.AddUpdateOpeningBalance(Val(Session("CurrentBusinessID")), Val(HdnSelectedAccountHeadID.Value), Val(txtOpeningBalanceAmount.Text))
    '        Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Opening Balance", "Opening Balance : " & HdnSelectedAccountHeadID.Value, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, -1)
    '        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "OpeningBalanceDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Opening Balance done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
    '        LoadData()
    '        Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Account Head Opening Balance Updated", HdnSelectedAccountHeadID.Value & ": Account Head Opening Balance Updated", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)

    '    Catch ex As Exception
    '        Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "UpdateOpeningBalanceIssue", "<script>parent.ShowMessage('Unable to process opening balance','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
    '    End Try
    'End Sub
End Class