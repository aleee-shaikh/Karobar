﻿Public Class NewProductCategory
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            'DDLBankAccountType.DataSource = Website.GetWebsitesCategories
            'DDLBankAccountType.DataTextField = "CategoryTitle"
            'DDLBankAccountType.DataValueField = "WebsiteCategoryID"
            'DDLBankAccountType.DataBind()

            'DDLCurrency.DataSource = Website.GetCurrencies(Website.WebsiteID, HttpContext.Current.Session("UserID"))
            'DDLCurrency.DataTextField = "CurrencyName"
            'DDLCurrency.DataValueField = "CurrencyCode"
            'DDLCurrency.DataBind()
            'DDLCurrency.SelectedValue = ReferenceData.Setting("DefaultCurrency", "PKR")
        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim BusinessLogoFilename As String = ""


        'tbl = Website.AddWebsite(HttpContext.Current.Session("UserID"), txtBusinessName.Text.Trim, txtBusinessDescription.Text.Trim, DDLBusinessCategory.SelectedItem.Value, DDLCurrency.SelectedItem.Value, BusinessLogoFilename, txtPhone.Text.Trim, txtBusinessFax.Text.Trim, txtEmail.Text.Trim, txtBusinessAddress.Text.Trim)
        'If tbl.Rows.Count > 0 Then
        '    Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Website.WebsiteID & "/Businesses/") & tbl.Rows(0)("WebsiteID") & "/Images"
        '    System.IO.Directory.CreateDirectory(BusinessDirectory)
        '    If BusinessLogoFilename <> "" Then FileUploadBusinessLogo.SaveAs(BusinessDirectory & "/" & BusinessLogoFilename)
        'End If
        'ClientScript.RegisterClientScriptBlock(Me.GetType(), "BusinessAddedSuccessFully", "<script>parent.HideDlgForm();parent.ShowMessage('Business added successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
    End Sub

End Class