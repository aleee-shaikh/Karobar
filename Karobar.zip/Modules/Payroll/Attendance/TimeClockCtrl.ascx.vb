﻿Public Class TimeClockCtrl
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer
    Dim _PunchDate As String
    Dim _EmployeeName As String

    Public Property EmployeeID() As Integer
        Get
            Return hdnEmployeeID.Value
        End Get
        Set(value As Integer)
            _EmployeeID = value
            hdnEmployeeID.Value = value
        End Set
    End Property

    Public Property PunchDate() As String
        Get
            Return hdnPunchDate.Value
        End Get
        Set(value As String)
            _PunchDate = value
            hdnPunchDate.Value = value
            LblDate.Text = CDate(hdnPunchDate.Value).ToString("dddd, dd-MM-yyyy")
        End Set
    End Property

    Public Property EmployeeName() As String
        Get
            Return _EmployeeName
        End Get
        Set(value As String)
            _EmployeeName = value
            LblUserName.Text = _EmployeeName
        End Set
    End Property


    Private Sub TimePunch_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then


        End If
    End Sub


    Public Function CheckEmployeeLastPunches() As DataTable
        Dim EmpPunchesTbl As New DataTable
        Dim ds As New DataSet()
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Val(hdnEmployeeID.Value), hdnPunchDate.Value & " 00:00:00 AM", hdnPunchDate.Value & " 23:59:59 PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        Dim rowsCnt As Integer = EmpPunchesTbl.Rows.Count
        Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1

        BtnAddBreak.Visible = True
        BtnAddDutyPunch.Visible = True
        Dim dr As DataRow
        If rowsCnt = 0 Then
            BtnAddBreak.Visible = False
            BtnAddDutyPunch.Visible = False
            dr = EmpPunchesTbl.NewRow
            dr("EmployeeID") = hdnEmployeeID.Value
            dr("BusinessID") = Val(Session("CurrentBusinessID"))
            dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
            dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN
            If (ds.Tables(1).Rows.Count > 0) Then
                dr("ShiftID") = ds.Tables(1).Rows(0)("ShiftID")
                dr("TimeIN") = ds.Tables(1).Rows(0)("TimeIN")
                dr("TimeOut") = ds.Tables(1).Rows(0)("TimeOut")
            End If
            dr("EmpPunch") = "01/01/2001"
            EmpPunchesTbl.Rows.Add(dr)

            'dr = EmpPunchesTbl.NewRow
            'dr("EmployeeID") = hdnEmployeeID.Value
            'dr("BusinessID") = Val(Session("CurrentBusinessID"))
            'dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
            'dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN
            'dr("EmpPunch") = "01/01/2001"
            'EmpPunchesTbl.Rows.Add(dr)

            'dr = EmpPunchesTbl.NewRow
            'dr("EmployeeID") = hdnEmployeeID.Value
            'dr("BusinessID") = Val(Session("CurrentBusinessID"))
            'dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
            'dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
            'dr("EmpPunch") = "01/01/2001"
            'EmpPunchesTbl.Rows.Add(dr)

            dr = EmpPunchesTbl.NewRow
            dr("EmployeeID") = hdnEmployeeID.Value
            dr("BusinessID") = Val(Session("CurrentBusinessID"))
            dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
            dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
            If (ds.Tables(1).Rows.Count > 0) Then
                dr("ShiftID") = ds.Tables(1).Rows(0)("ShiftID")
                dr("TimeIN") = ds.Tables(1).Rows(0)("TimeIN")
                dr("TimeOut") = ds.Tables(1).Rows(0)("TimeOut")
            End If
            dr("EmpPunch") = "01/01/2001"
            EmpPunchesTbl.Rows.Add(dr)
        ElseIf rowsCnt > 0 Then
            If rowsCnt = 1 And EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)

                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)

                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)
            ElseIf rowsCnt = 2 And EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)

                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)
            ElseIf rowsCnt = 3 And EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                dr = EmpPunchesTbl.NewRow
                dr("EmployeeID") = hdnEmployeeID.Value
                dr("BusinessID") = Val(Session("CurrentBusinessID"))
                dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
                dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                dr("EmpPunch") = "01/01/2001"
                EmpPunchesTbl.Rows.Add(dr)
            Else
                If rowsCnt > 4 And (EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch) And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    dr = EmpPunchesTbl.NewRow
                    dr("EmployeeID") = hdnEmployeeID.Value
                    dr("BusinessID") = Val(Session("CurrentBusinessID"))
                    dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
                    dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                    dr("EmpPunch") = "01/01/2001"
                    EmpPunchesTbl.Rows.Add(dr)
                ElseIf rowsCnt > 4 And (EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch) And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    dr = EmpPunchesTbl.NewRow
                    dr("EmployeeID") = hdnEmployeeID.Value
                    dr("BusinessID") = Val(Session("CurrentBusinessID"))
                    dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                    dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                    dr("EmpPunch") = "01/01/2001"
                    EmpPunchesTbl.Rows.Add(dr)

                ElseIf rowsCnt > 4 And (EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch Or EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch) And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                    'dr = EmpPunchesTbl.NewRow
                    'dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                    'dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN
                    'dr("EmpPunch") = "01/01/2001"
                    'dr("EmployeeID") = hdnEmployeeID.Value
                    'dr("BusinessID") = Val(Session("CurrentBusinessID"))
                    'EmpPunchesTbl.Rows.Add(dr)

                    'dr = EmpPunchesTbl.NewRow
                    'dr("EmployeeID") = hdnEmployeeID.Value
                    'dr("BusinessID") = Val(Session("CurrentBusinessID"))
                    'dr("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch
                    'dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
                    'dr("EmpPunch") = "01/01/2001"
                    'EmpPunchesTbl.Rows.Add(dr)
                End If
            End If
        End If
        ViewState("Emp" & hdnEmployeeID.Value) = EmpPunchesTbl
        GrdEmpPunches.DataSource = EmpPunchesTbl
        GrdEmpPunches.DataBind()
        Return EmpPunchesTbl
    End Function

    Private Sub BtnAddBreak_Click(sender As Object, e As EventArgs) Handles BtnAddBreak.Click
        Dim dutyPunchINFound As Boolean
        Dim dutyPunchOUTFound As Boolean

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text

            If EmpPunchTime <> "" AndAlso PunchTypeID = BusinessTMS.PunchTypes.PunchIN AndAlso PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                dutyPunchINFound = True
            ElseIf dutyPunchINFound = True AndAlso EmpPunchTime <> "" AndAlso PunchTypeID = BusinessTMS.PunchTypes.PunchOUT AndAlso PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                dutyPunchOUTFound = True
                Exit For
            End If
        Next
        If (dutyPunchINFound = True AndAlso dutyPunchOUTFound = True) Then
            pnlEmpPunchGrd.Visible = False
            pnlBreakPunch.Visible = True
            pnlDutyPunch.Visible = False
        Else
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Atleast one duty puch shoud be added before adding break.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
            Exit Sub
        End If


    End Sub

    Private Sub BtnAddDutyPunch_Click(sender As Object, e As EventArgs) Handles BtnAddDutyPunch.Click
        Dim dutyPunchINFound As Boolean
        Dim dutyPunchOUTFound As Boolean

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text

            If EmpPunchTime <> "" AndAlso PunchTypeID = BusinessTMS.PunchTypes.PunchIN AndAlso PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                dutyPunchINFound = True
            ElseIf dutyPunchINFound = True AndAlso EmpPunchTime <> "" AndAlso PunchTypeID = BusinessTMS.PunchTypes.PunchOUT AndAlso PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                dutyPunchOUTFound = True
                Exit For
            End If
        Next

        If (dutyPunchINFound = True AndAlso dutyPunchOUTFound = True) Then
            pnlEmpPunchGrd.Visible = False
            pnlBreakPunch.Visible = False
            pnlDutyPunch.Visible = True
        Else
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Atleast one duty puch shoud be added before adding new duty punches.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
            Exit Sub
        End If

    End Sub

    Private Sub BtnSaveDutyPunchCancel_Click(sender As Object, e As EventArgs) Handles BtnSaveDutyPunchCancel.Click
        pnlEmpPunchGrd.Visible = True
        pnlBreakPunch.Visible = False
        pnlDutyPunch.Visible = False
        txtCheckINComments.Text = ""
        txtCheckIN.Text = ""
        txtCheckOUT.Text = ""

    End Sub

    Private Sub BtnSaveBreakPunch_Click(sender As Object, e As EventArgs) Handles BtnSaveBreakPunch.Click
        Dim tbl As New DataTable
        Dim dr As DataRow

        If Not ViewState("Emp" & hdnEmployeeID.Value) Is Nothing Then
            tbl = CType(ViewState("Emp" & hdnEmployeeID.Value), DataTable)
        End If

        If txtBreakTimeStart.Text.Trim = "" Or txtBreakTimeEnd.Text.Trim = "" Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Duty punches can not be empty.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf txtBreakTimeStart.Text.Trim = txtBreakTimeEnd.Text.Trim Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Same break punches(in/out) are not allowed.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf IsDate(hdnPunchDate.Value & " " & txtBreakTimeStart.Text) = False Or IsDate(hdnPunchDate.Value & " " & txtBreakTimeEnd.Text) = False Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Invalid duty punches format.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf CDate(hdnPunchDate.Value & " " & txtBreakTimeStart.Text) > CDate(hdnPunchDate.Value & " " & txtBreakTimeEnd.Text) Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Start time should be less than end time.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf CDate(hdnPunchDate.Value & " " & txtBreakTimeStart.Text) > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Or CDate(hdnPunchDate.Value & " " & txtBreakTimeEnd.Text) > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Future punches are not allowed.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        Else
            Dim res As String = ""
            res = ValidateBreakPunches(CDate(hdnPunchDate.Value & " " & txtBreakTimeStart.Text), CDate(hdnPunchDate.Value & " " & txtBreakTimeEnd.Text))
            If (res <> "") Then
                Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('" & res & "','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
                Exit Sub
            End If
        End If
        dr = tbl.NewRow
        dr("PunchID") = -1
        dr("EmployeeID") = hdnEmployeeID.Value
        dr("BusinessID") = Val(Session("CurrentBusinessID"))
        dr("PunchPurposeID") = 2
        dr("PunchTypeID") = 1
        dr("EmpPunch") = hdnPunchDate.Value & " " & txtBreakTimeStart.Text
        dr("ShiftName") = tbl.Rows(0)("ShiftName")
        dr("Comments") = txtCheckINComments.Text
        tbl.Rows.Add(dr)
        dr = tbl.NewRow
        dr("PunchID") = -1
        dr("EmployeeID") = hdnEmployeeID.Value
        dr("BusinessID") = Val(Session("CurrentBusinessID"))
        dr("PunchPurposeID") = 2
        dr("PunchTypeID") = 2
        dr("EmpPunch") = hdnPunchDate.Value & " " & txtBreakTimeEnd.Text
        dr("ShiftName") = tbl.Rows(0)("ShiftName")
        dr("Comments") = ""
        tbl.Rows.Add(dr)
        ViewState("Emp" & hdnEmployeeID.Value) = tbl
        GrdEmpPunches.DataSource = tbl
        GrdEmpPunches.DataBind()
        pnlEmpPunchGrd.Visible = True
        pnlBreakPunch.Visible = False
        pnlDutyPunch.Visible = False
        txtBreakComments.Text = ""
        txtBreakTimeStart.Text = ""
        txtBreakTimeEnd.Text = ""
    End Sub

    Private Sub BtnSaveBreakPunchCancel_Click(sender As Object, e As EventArgs) Handles BtnSaveBreakPunchCancel.Click
        pnlEmpPunchGrd.Visible = True
        pnlBreakPunch.Visible = False
        pnlDutyPunch.Visible = False
        txtBreakTimeStart.Text = ""
        txtBreakTimeEnd.Text = ""
    End Sub

    Private Sub BtnEmpPunchCancel_Click(sender As Object, e As EventArgs) Handles BtnEmpPunchCancel.Click
        pnlEmpPunchGrd.Visible = True
        pnlBreakPunch.Visible = False
        pnlDutyPunch.Visible = False

        Dim p = Me.Parent.FindControl("DivManageAttendance")
        p.Visible = True
        Dim c = Me.Parent.FindControl("TimeClockCtrl")
        c.Visible = False



    End Sub

    Function ValidateBreakPunches(StartTime As DateTime, EndTime As DateTime) As String
        Dim empPunches As New DataTable
        Dim res As String = ""
        Dim evn As Integer = 1
        Dim BreakPunches As New DataTable
        Dim tm1 As DateTime
        Dim tm2 As DateTime

        empPunches = GetPunchesFromGrid()


        If empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.BreakPunch).Length > 0 Then
            BreakPunches = empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.BreakPunch).CopyToDataTable()
        End If

        evn = 1
        For i As Integer = 0 To BreakPunches.Rows.Count - 1
            If evn Mod 2 = 0 Then
                tm2 = BreakPunches.Rows(i)("PunchDateTime")
                If tm1 <> StartTime And tm2 <> EndTime Then
                    If BreakPunches.Rows(i)("PunchType") <> BusinessTMS.PunchTypes.PunchOUT Then
                        res = "Invalid break punches sequence found."
                        Exit For
                    ElseIf (StartTime >= tm1 And StartTime <= tm2) Or (EndTime >= tm1 And EndTime <= tm2) Then
                        res = "Break punches conflicts with other break punches."
                        Exit For
                    ElseIf (tm1 >= StartTime And tm2 <= EndTime) Or (tm2 >= StartTime And tm2 <= EndTime) Then
                        res = "Break punches conflicts with other break punches."
                        Exit For
                    End If
                End If
            Else
                tm1 = BreakPunches.Rows(i)("PunchDateTime")
            End If
            evn = evn + 1
        Next

        Return res
    End Function

    Function ValidateDutyPunches(StartTime As DateTime, EndTime As DateTime) As String
        Dim empPunches As New DataTable
        Dim res As String = ""
        Dim evn As Integer = 1
        Dim DutyPunches As New DataTable
        Dim BreakPunches As New DataTable
        Dim tm1 As DateTime
        Dim tm2 As DateTime

        empPunches = GetPunchesFromGrid()
        If empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.TimePunch).Length > 0 Then
            DutyPunches = empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.TimePunch).CopyToDataTable()
        End If

        If empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.BreakPunch).Length > 0 Then
            BreakPunches = empPunches.Select("PunchPurpose=" & BusinessTMS.PunchPurpose.BreakPunch).CopyToDataTable()
        End If

        evn = 1
        For i As Integer = 0 To DutyPunches.Rows.Count - 1

            If evn Mod 2 = 0 Then
                tm2 = DutyPunches.Rows(i)("PunchDateTime")
                If tm1 <> StartTime And tm2 <> EndTime Then
                    If DutyPunches.Rows(i)("PunchType") <> BusinessTMS.PunchTypes.PunchOUT Then
                        res = "Invalid duty punches sequence found."
                        Exit For
                    ElseIf (StartTime >= tm1 And StartTime <= tm2) Or (EndTime >= tm1 And EndTime <= tm2) Then
                        res = "Duty punches conflicts with other duty punches."
                        Exit For
                    ElseIf (tm1 >= StartTime And tm2 <= EndTime) Or (tm2 >= StartTime And tm2 <= EndTime) Then
                        res = "Duty punches conflicts with other duty punches."
                        Exit For
                    End If
                End If
            Else
                tm1 = DutyPunches.Rows(i)("PunchDateTime")
            End If
            evn = evn + 1
        Next

        If res = "" Then
            evn = 1
            For i As Integer = 0 To BreakPunches.Rows.Count - 1
                If evn Mod 2 = 0 Then
                    tm2 = BreakPunches.Rows(i)("PunchDateTime")
                    If tm1 <> StartTime And tm2 <> EndTime Then
                        If BreakPunches.Rows(i)("PunchType") <> BusinessTMS.PunchTypes.PunchOUT Then
                            res = "Invalid break punches sequence found."
                            Exit For
                        ElseIf (StartTime >= tm1 And StartTime <= tm2) Or (EndTime >= tm1 And EndTime <= tm2) Then
                            res = "Duty punches conflicts with break punches."
                            Exit For
                        ElseIf (tm1 >= StartTime And tm2 <= EndTime) Or (tm2 >= StartTime And tm2 <= EndTime) Then
                            res = "Duty punches conflicts with break punches."
                            Exit For
                        End If
                    End If
                Else
                    tm1 = BreakPunches.Rows(i)("PunchDateTime")
                End If
                evn = evn + 1
            Next
        End If

        Return res
    End Function

    Function GetPunchesFromGrid() As DataTable
        Dim empPunches As New DataTable
        Dim dr As DataRow
        empPunches.Columns.Add("PunchPurpose", System.Type.GetType("System.Int32"))
        empPunches.Columns.Add("PunchType", System.Type.GetType("System.Int32"))
        empPunches.Columns.Add("PunchDateTime", System.Type.GetType("System.DateTime"))

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text

            dr = empPunches.NewRow
            dr("PunchPurpose") = PunchPurposeID
            dr("PunchType") = PunchTypeID
            dr("PunchDateTime") = IIf(EmpPunchTime = "", "", EmpPunchTime)
            empPunches.Rows.Add(dr)
        Next

        Dim SortedPunches() As DataRow
        SortedPunches = empPunches.Select("1=1", "PunchDateTime Asc")

        Return SortedPunches.CopyToDataTable()
    End Function

    Function ValidateFirstPunch(empPunches As DataTable) As String
        Dim res As String = ""

        If empPunches.Rows(0)("PunchPurpose") <> BusinessTMS.PunchPurpose.TimePunch Then
            res = "First punch must be duty punch"
        End If

        Return res
    End Function

    Function GetPunchesCount() As Integer
        Dim DutyPunchesIdx As Integer = 0
        Dim BreakPunchesIdx As Integer = 0
        Dim PunchesCount As Integer = 0
        Dim DutyCheckINFound As Boolean = False
        Dim BreakStartFound As Boolean = False

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text
            If PunchTypeID = BusinessTMS.PunchTypes.PunchIN And PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                DutyCheckINFound = True
            ElseIf DutyCheckINFound = True And PunchTypeID = BusinessTMS.PunchTypes.PunchOUT And PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch Then
                DutyCheckINFound = False
                DutyPunchesIdx += 1
                PunchesCount += 1
            End If
        Next

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text

            If BreakStartFound = False And PunchTypeID = BusinessTMS.PunchTypes.PunchIN And PunchPurposeID = BusinessTMS.PunchPurpose.BreakPunch Then
                BreakStartFound = True
            ElseIf BreakStartFound = True And PunchTypeID = BusinessTMS.PunchTypes.PunchOUT And PunchPurposeID = BusinessTMS.PunchPurpose.BreakPunch Then
                BreakStartFound = False
                BreakPunchesIdx += 1
                PunchesCount += 1
            End If
        Next
        Return PunchesCount
    End Function

    Function FinalValidateDutyPunches(empPunches As DataTable) As String
        Dim res As String = ""
        Dim evn As Integer = 1

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim PunchComments As String = CType(GrdEmpPunches.Rows(i).FindControl("txtComments"), TextBox).Text
            Dim EmployeeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnEmployeeID"), HiddenField).Value)
            Dim BusinessID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnBusinessID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text
            Dim tm1 As DateTime
            Dim tm2 As DateTime

            If EmpPunchTime.Trim = "" Then
                res = "Punches can not be empty."
            Else
                If (PunchPurposeID = BusinessTMS.PunchPurpose.TimePunch) Then
                    If evn Mod 2 = 0 Then
                        tm2 = CDate(hdnPunchDate.Value & " " & EmpPunchTime)
                        If tm1 > tm2 Then
                            res = "Start time should be less than end time."
                            Exit For
                        ElseIf tm1 > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Or tm2 > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Then
                            res = "Future punches are not allowed."
                            Exit For
                        ElseIf tm1 = tm2 Then
                            res = "Same punches(in/out) are not allowed."
                            Exit For
                        Else
                            res = ValidateDutyPunches(tm1, tm2)
                        End If
                    Else
                        tm1 = CDate(hdnPunchDate.Value & " " & EmpPunchTime)
                    End If
                    evn = evn + 1
                End If
            End If
        Next

        Return res
    End Function

    Function FinalValidateBreakPunches(empPunches As DataTable) As String
        Dim res As String = ""
        Dim evn As Integer = 1

        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim PunchComments As String = CType(GrdEmpPunches.Rows(i).FindControl("txtComments"), TextBox).Text
            Dim EmployeeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnEmployeeID"), HiddenField).Value)
            Dim BusinessID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnBusinessID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text
            Dim tm1 As DateTime
            Dim tm2 As DateTime


            If EmpPunchTime.Trim = "" Then
                res = "Punches can not be empty."
            Else
                If (PunchPurposeID = BusinessTMS.PunchPurpose.BreakPunch) Then
                    If evn Mod 2 = 0 Then
                        tm2 = CDate(hdnPunchDate.Value & " " & EmpPunchTime)
                        If tm1 > tm2 Then
                            res = "Start time should be less than end time."
                            Exit For
                        ElseIf tm1 > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Or tm2 > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Then
                            res = "Future punches are not allowed."
                            Exit For
                        Else
                            res = ValidateBreakPunches(tm1, tm2)
                        End If
                    Else
                        tm1 = CDate(hdnPunchDate.Value & " " & EmpPunchTime)
                    End If
                    evn = evn + 1
                End If
            End If
        Next

        Return res
    End Function

    Private Sub BtnSavePunches_Click(sender As Object, e As EventArgs) Handles BtnSavePunches.Click
        Dim res As String = ""
        Dim empPunches As New DataTable
        empPunches = GetPunchesFromGrid()
        res = FinalValidateDutyPunches(empPunches)
        If res <> "" Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('" & res & "','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        Else
            res = FinalValidateBreakPunches(empPunches)
        End If
        If res <> "" Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('" & res & "','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        End If

        Dim x As Integer = 0
        BusinessTMS.DeleteEmpPunch(Val(Session("CurrentBusinessID")), Val(hdnEmployeeID.Value), CDate(hdnPunchDate.Value))
        For i As Integer = 0 To GrdEmpPunches.Rows.Count - 1
            Dim PunchTypeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchTypeID"), HiddenField).Value)
            Dim PunchPurposeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnPunchPurposeID"), HiddenField).Value)
            Dim PunchComments As String = CType(GrdEmpPunches.Rows(i).FindControl("txtComments"), TextBox).Text
            Dim EmployeeID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnEmployeeID"), HiddenField).Value)
            Dim BusinessID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnBusinessID"), HiddenField).Value)
            Dim ShiftID As Integer = Val(CType(GrdEmpPunches.Rows(i).FindControl("hdnShiftID"), HiddenField).Value)
            Dim EmpPunchTime As String = CType(GrdEmpPunches.Rows(i).FindControl("txtEmpPunchDateTime"), TextBox).Text


            BusinessTMS.AddEmpPunch(Val(Session("CurrentBusinessID")), Val(hdnEmployeeID.Value), ShiftID, PunchTypeID, PunchPurposeID, CDate(hdnPunchDate.Value & " " & EmpPunchTime), PunchComments, 0, 0, Val(Session("UserID")))
            pnlEmpPunchGrd.Visible = True
            pnlBreakPunch.Visible = False
            pnlDutyPunch.Visible = False

            Dim p = Me.Parent.FindControl("DivManageAttendance")
            p.Visible = True
            Dim c = Me.Parent.FindControl("TimeClockCtrl")
            c.Visible = False

        Next

        DirectCast(Me.Parent, ManageAttendanceApproval).LoadData()
    End Sub

    Private Sub GrdEmpPunches_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdEmpPunches.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim txtEmpPunchTime As New TextBox
            Dim txtPunchComments As New TextBox
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            txtEmpPunchTime = CType(e.Row.FindControl("txtEmpPunchDateTime"), TextBox)
            txtPunchComments = CType(e.Row.FindControl("txtComments"), TextBox)

            If (drview("PunchPurposeID") = 1 And drview("PunchTypeID") = 1) Then
                txtPunchComments.Attributes.Add("Placeholder", "Check IN comments")
                txtEmpPunchTime.Attributes.Add("Placeholder", "Time IN")
            ElseIf (drview("PunchPurposeID") = 1 And drview("PunchTypeID") = 2) Then
                txtPunchComments.Attributes.Add("Placeholder", "Check OUT comments")
                txtEmpPunchTime.Attributes.Add("Placeholder", "Time OUT")
            ElseIf (drview("PunchPurposeID") = 2 And drview("PunchTypeID") = 1) Then
                txtPunchComments.Attributes.Add("Placeholder", "Break start comments")
                txtEmpPunchTime.Attributes.Add("Placeholder", "Break Start")
            ElseIf (drview("PunchPurposeID") = 2 And drview("PunchTypeID") = 2) Then
                txtPunchComments.Attributes.Add("Placeholder", "Break end comments")
                txtEmpPunchTime.Attributes.Add("Placeholder", "Break End")
            End If


            If drview("PunchPurposeID") = 1 And drview("PunchTypeID") = 1 And CDate(drview("EmpPunch")).ToString("yyyyMMdd") = "20010101" Then
                If (IsDBNull(drview("TimeIN")) = False) Then
                    txtEmpPunchTime.Text = CDate(drview("TimeIN")).ToString("HH:mm tt")
                End If
            ElseIf drview("PunchPurposeID") = 1 And drview("PunchTypeID") = 2 And CDate(drview("EmpPunch")).ToString("yyyyMMdd") = "20010101" Then
                If (IsDBNull(drview("TimeIN")) = False) Then
                    txtEmpPunchTime.Text = CDate(drview("TimeOUT")).ToString("HH:mm tt")
                End If
            Else
                If (IsDBNull(drview("EmpPunch")) = False) Then
                    txtEmpPunchTime.Text = CDate(drview("EmpPunch")).ToString("HH:mm tt")
                End If
            End If

        End If
    End Sub

    Private Sub BtnSaveDutyPunch_Click(sender As Object, e As EventArgs) Handles BtnSaveDutyPunch.Click
        Dim tbl As New DataTable
        Dim dr As DataRow

        If Not ViewState("Emp" & hdnEmployeeID.Value) Is Nothing Then
            tbl = CType(ViewState("Emp" & hdnEmployeeID.Value), DataTable)
        End If

        If txtCheckIN.Text.Trim = "" Or txtCheckOUT.Text.Trim = "" Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Duty punches can not be empty.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf txtCheckIN.Text.Trim = txtCheckOUT.Text.Trim Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Same duty punches(in/out) are not allowed.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf IsDate(hdnPunchDate.Value & " " & txtCheckIN.Text) = False Or IsDate(hdnPunchDate.Value & " " & txtCheckOUT.Text) = False Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Invalid duty punches format.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf CDate(hdnPunchDate.Value & " " & txtCheckIN.Text) > CDate(hdnPunchDate.Value & " " & txtCheckOUT.Text) Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Start time should be less than end time.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        ElseIf CDate(hdnPunchDate.Value & " " & txtCheckIN.Text) > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Or CDate(hdnPunchDate.Value & " " & txtCheckOUT.Text) > General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone) Then
            Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('Future punches are not allowed.','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
            Exit Sub
        Else
            Dim res As String = ""
            res = ValidateDutyPunches(CDate(hdnPunchDate.Value & " " & txtCheckIN.Text), CDate(hdnPunchDate.Value & " " & txtCheckOUT.Text))
            If (res <> "") Then
                Page.RegisterStartupScript("Validation", "<script>parent.HideDlgForm(1);parent.ShowMessage('" & res & "','1',$(window).height()*2/100,$(window).width()*28/100)</script>")
                Exit Sub
            End If
        End If
        dr = tbl.NewRow
        dr("PunchID") = -1
        dr("EmployeeID") = hdnEmployeeID.Value
        dr("BusinessID") = Val(Session("CurrentBusinessID"))
        dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
        dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN
        dr("EmpPunch") = hdnPunchDate.Value & " " & txtCheckIN.Text
        dr("ShiftName") = tbl.Rows(0)("ShiftName")
        dr("Comments") = txtCheckINComments.Text
        tbl.Rows.Add(dr)
        dr = tbl.NewRow
        dr("PunchID") = -1
        dr("EmployeeID") = hdnEmployeeID.Value
        dr("BusinessID") = Val(Session("CurrentBusinessID"))
        dr("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch
        dr("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT
        dr("EmpPunch") = hdnPunchDate.Value & " " & txtCheckOUT.Text
        dr("ShiftName") = tbl.Rows(0)("ShiftName")
        dr("Comments") = ""
        tbl.Rows.Add(dr)
        ViewState("Emp" & hdnEmployeeID.Value) = tbl
        GrdEmpPunches.DataSource = tbl
        GrdEmpPunches.DataBind()
        pnlEmpPunchGrd.Visible = True
        pnlBreakPunch.Visible = False
        pnlDutyPunch.Visible = False
        txtBreakComments.Text = ""
        txtBreakTimeStart.Text = ""
        txtBreakTimeEnd.Text = ""
    End Sub
End Class