﻿Public Class GenericGRNRow
    Inherits System.Web.UI.UserControl


    Dim _tbl As New DataTable
    Dim _tmptbl As New DataTable
    Dim GRNID As Integer = -1


    Public Sub AddColumn(ByVal ColumnName As String, Optional ByVal Control As Object = Nothing)

        If Not _tbl.Columns.Contains(ColumnName) Then
            _tbl.Columns.Add(ColumnName)
        End If

        Session(Me.ClientID & "GRN") = _tbl
    End Sub

    Public Sub AddRow()
        Dim dr As DataRow
        dr = _tbl.NewRow
        _tbl.Rows.Add(dr)
    End Sub

    Public Sub UpdateRows()
        For i As Integer = 0 To GridView1.Rows.Count - 1
            Dim ddl As New DropDownList
            ddl = CType(GridView1.Rows(i).FindControl("DDLProducts"), DropDownList)
            _tbl.Rows(i)("Product") = ddl.SelectedItem.Value

            Dim txtReceivedQty As New TextBox
            txtReceivedQty = CType(GridView1.Rows(i).FindControl("txtReceivedQty"), TextBox)
            _tbl.Rows(i)("ReceivedQuantity") = txtReceivedQty.Text

            Dim txtRejected As New TextBox
            txtRejected = CType(GridView1.Rows(i).FindControl("txtRejected"), TextBox)
            _tbl.Rows(i)("RejectedQuantity") = txtRejected.Text

            Dim txtBalance As New TextBox
            txtBalance = CType(GridView1.Rows(i).FindControl("txtBalance"), TextBox)
            _tbl.Rows(i)("ActualReceived") = txtBalance.Text

            Dim txtUnit As New TextBox
            txtUnit = CType(GridView1.Rows(i).FindControl("txtUnit"), TextBox)
            _tbl.Rows(i)("Unit") = txtUnit.Text
        Next
    End Sub

    Public Function GetGRNData() As DataTable
        Return _tbl
    End Function


    Public Sub SetGRNData(tbl As DataTable)
        For i As Integer = 0 To tbl.Rows.Count - 1
            Dim dr As DataRow
            dr = _tbl.NewRow
            dr("Product") = tbl.Rows(i)("ArticleTitle")
            dr("Unit") = tbl.Rows(i)("Unit")
            dr("ReceivedQuantity") = tbl.Rows(i)("ReceivedQuantity")
            dr("RejectedQuantity") = tbl.Rows(i)("RejectedQuantity")
            dr("ActualReceived") = tbl.Rows(i)("ActualReceivedQuantity")
            _tbl.Rows.Add(dr)
            GRNID = tbl.Rows(i)("grnid")
        Next
        _tmptbl = _tbl.Copy()
    End Sub



    Sub BindGrid(Optional ByVal Control As Object = Nothing)
        Dim dr As DataRow
        If _tbl.Rows.Count = 0 Then
            dr = _tbl.NewRow
            _tbl.Rows.Add(dr)
        End If
        GridView1.DataSource = _tbl
        GridView1.DataBind()

        'GridView1.Columns(4).HeaderText = ReferenceData.Setting("LblProductGRNPrice", "Price", Session("CurrentBusinessID"))

        'GridView1.Columns(5).HeaderText = ReferenceData.Setting("LblGridProductStockQuantity", "Stock Qty", Session("CurrentBusinessID"))
        '''GridView1.Columns(6).HeaderText = ReferenceData.Setting("LblGridProductQuantity", "Quantity", Session("CurrentBusinessID"))
        'GridView1.Columns(7).HeaderText = ReferenceData.Setting("LblGridGRNProductDiscount", "Discount", Session("CurrentBusinessID"))

        'GridView1.Columns(8).HeaderText = ReferenceData.Setting("LblGridGRNProductTotal", "Total", Session("CurrentBusinessID"))


        ''AddGridControl()
    End Sub

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Session(Me.ClientID & "GRN") Is Nothing Then
            _tbl = CType(Session(Me.ClientID & "GRN"), DataTable)
            BindGrid()
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack Then
            UpdateRows()
        Else
            GridView1.Columns(2).HeaderText = ReferenceData.Setting("LblProductName", "Product", Session("CurrentBusinessID"))
            GridView1.Columns(3).HeaderText = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))

            For i As Integer = _tbl.Rows.Count - 1 To 0 Step -1
                _tbl.Rows.RemoveAt(i)
            Next
            If _tmptbl.Rows.Count > 0 Then

                _tbl = _tmptbl
                _tbl.Rows.RemoveAt(0)
            End If
            Session(Me.ClientID & "GRN") = _tbl
            BindGrid()
        End If
    End Sub


    Private Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "AddRow" Then
            AddRow()
        ElseIf e.CommandName = "DeleteRow" Then
            _tbl.Rows.RemoveAt(Val(e.CommandArgument) - 1)
        End If

        Session(Me.ClientID & "GRN") = _tbl
        BindGrid()

    End Sub

    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim Btn As New Button
            If e.Row.RowIndex = _tbl.Rows.Count - 1 Then
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "+"
                Btn.CommandName = "AddRow"
            Else
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "-"
                Btn.CommandName = "DeleteRow"
            End If


            Dim ddl As New DropDownList
            ddl = CType(e.Row.FindControl("DDLProducts"), DropDownList)
            ddl.DataTextField = "ArticleTitle"
            ddl.DataValueField = "ArticleID"
            ddl.DataSource = Products.GetProductsList(Session("CurrentBusinessID"))
            ddl.DataBind()
            If _tbl.Columns.Contains("Product") Then
                ddl.SelectedValue = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Product")), "", _tbl.Rows(e.Row.RowIndex)("Product"))
            End If
            ddl.AutoPostBack = True
                ddl.Attributes.Add("RowIdx", e.Row.RowIndex)
                AddHandler ddl.SelectedIndexChanged, AddressOf ProductDDL_SelectedIndexChanged

                Dim txtUnit As New TextBox
                txtUnit = CType(e.Row.FindControl("txtUnit"), TextBox)
            If Not txtUnit Is Nothing Then
                If _tbl.Columns.Contains("Unit") Then
                    txtUnit.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Unit")), "", _tbl.Rows(e.Row.RowIndex)("Unit"))
                End If

            End If


            Dim txtReceivedQty As New TextBox
                txtReceivedQty = CType(e.Row.FindControl("txtReceivedQty"), TextBox)
                If Not txtReceivedQty Is Nothing Then
                txtReceivedQty.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("ReceivedQuantity") Then
                    txtReceivedQty.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("ReceivedQuantity")), "", _tbl.Rows(e.Row.RowIndex)("ReceivedQuantity"))
                End If

            End If


                Dim txtRejected As New TextBox
                txtRejected = CType(e.Row.FindControl("txtRejected"), TextBox)
                If Not txtRejected Is Nothing Then
                txtRejected.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("RejectedQuantity") Then
                    txtRejected.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("RejectedQuantity")), "", _tbl.Rows(e.Row.RowIndex)("RejectedQuantity"))
                End If

            End If

                Dim txtBalance As New TextBox
                txtBalance = CType(e.Row.FindControl("txtBalance"), TextBox)
                If Not txtBalance Is Nothing Then
                    txtBalance.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("ActualReceived") Then
                    txtBalance.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("ActualReceived")), "", _tbl.Rows(e.Row.RowIndex)("ActualReceived"))
                End If

            End If

                If Not txtBalance Is Nothing Then
                    txtReceivedQty.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdateGRNBalanceQuantity('" & txtReceivedQty.ClientID & "','" & txtRejected.ClientID & "','" & txtBalance.ClientID & "')")
                    txtRejected.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdateGRNBalanceQuantity('" & txtReceivedQty.ClientID & "','" & txtRejected.ClientID & "','" & txtBalance.ClientID & "')")
                End If

            End If
    End Sub


    Protected Sub ProductDDL_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ridx As Integer = sender.Attributes("RowIdx")
        Dim ProductUnit As New TextBox
        Dim ProductPrice As New TextBox
        Dim txtStockQty As New TextBox
        Dim ProductID As Integer
        ProductUnit = CType(GridView1.Rows(ridx).FindControl("txtUnit"), TextBox)
        ProductPrice = CType(GridView1.Rows(ridx).FindControl("txtPrice"), TextBox)
        txtStockQty = CType(GridView1.Rows(ridx).FindControl("txtStockQty"), TextBox)
        ProductID = sender.selecteditem.value

        If Not (ProductUnit Is Nothing) Then
            Dim ds As New DataSet
            ds = Products.GetProductDetails(Session("CurrentBusinessID"), Val(ProductID))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    ProductUnit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UnitAsText")), "", ds.Tables(0).Rows(0)("UnitAsText"))
                    If Not ProductPrice Is Nothing Then
                        ProductPrice.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("GRNPrice")), "", ds.Tables(0).Rows(0)("GRNPrice"))
                    End If
                    If Not txtStockQty Is Nothing Then
                        txtStockQty.Text = ds.Tables(0).Rows(0)("Purchased") - ds.Tables(0).Rows(0)("Sold")
                    End If
                End If
            End If
        End If
    End Sub

End Class