﻿Public Class ManageEmployees
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "goBack", "history.go(-1);", True)
        'End If
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage people screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
    End Sub

    Sub LoadData()
        GrdPeoples.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), txtFreeText.Text.Trim, DDLUserType.SelectedItem.Value)
        GrdPeoples.DataBind()
    End Sub


    Private Sub GrdPeoples_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdPeoples.PageIndexChanging
        GrdPeoples.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdPeoples_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdPeoples.RowCommand
        If e.CommandName = "DeletePeople" Then

            ''People.DeletePeople(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(HttpContext.Current.Session("UserID"), "People", "Deleted People " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, e.CommandArgument)
        ElseIf e.CommandName = "ViewPeopleAccounts" Then

        ElseIf e.CommandName = "DeleteUser" Then

            Person.DeleteUser(e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "People", "Deleted People Account " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub

    Private Sub GrdPeoples_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdPeoples.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim PeopleEditLnkBtn As New System.Web.UI.WebControls.LinkButton
            PeopleEditLnkBtn = CType(e.Row.FindControl("LnkEditUser"), LinkButton)
            If Not PeopleEditLnkBtn Is Nothing Then
                Select Case IIf(IsDBNull(drview("AccountTypeID")), "-1", drview("AccountTypeID"))
                    'Case Person.UserTypes.Customer
                    '    PeopleEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/People/Customer.aspx?CID=" & drview("UserID") & "',$(window).height()*71/100,$(window).width()*70/100);return false"
                    'Case Person.UserTypes.Supplier
                    '    PeopleEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/People/Vendor.aspx?VID=" & drview("UserID") & "',$(window).height()*71/100,$(window).width()*70/100);return false"
                    Case Person.UserTypes.Staff
                        PeopleEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Payroll/Employee/PayrollStaff.aspx?SID=" & drview("UserID") & "',$(window).height()*88/100,$(window).width()*70/100);return false"

                End Select
            End If

            'Dim GrdPeopleAccounts As New System.Web.UI.WebControls.GridView
            'GrdPeopleAccounts = CType(e.Row.FindControl("GrdPeopleAccounts"), GridView)

            'If Not GrdPeopleAccounts Is Nothing Then
            '    GrdPeopleAccounts.DataSource = People.GetPeoplesAccountsList(Session("CurrentBusinessID"), drview("PeopleID"), "")
            '    GrdPeopleAccounts.DataBind()
            'End If


            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

End Class