﻿Public Class ManagePayscale
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If

        If Not Page.IsPostBack Then
            LoadData()
        End If
        If GrdPayScale.Rows.Count > 0 Then
            GrdPayScale.Columns(3).Visible = True
            GrdPayScale.Columns(4).Visible = True
            GrdPayScale.Columns(5).Visible = False

        Else
            GrdPayScale.Columns(3).Visible = False
            GrdPayScale.Columns(4).Visible = False
            GrdPayScale.Columns(5).Visible = True
        End If
    End Sub

    Sub LoadData()
        Dim _tbl As New DataTable
        _tbl = Payroll.GetPayrollGroups(Val(Session("CurrentBusinessID")))
        GrdPayScale.DataSource = _tbl
        GrdPayScale.DataBind()
    End Sub

    Private Sub GrdPayScale_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdPayScale.RowCommand
        If e.CommandName = "AddNewPayScale" Then
            Dim GroupName As String = CType(GrdPayScale.FooterRow.FindControl("txtGroupName"), TextBox).Text
            Dim GroupDesc As String = CType(GrdPayScale.FooterRow.FindControl("txtPayScaleDescription"), TextBox).Text
            Dim Visible As Boolean = CType(GrdPayScale.FooterRow.FindControl("ChkVisible"), CheckBox).Checked
            Payroll.AddPayrollGroup(Val(Session("CurrentBusinessID")), -1, GroupName, GroupDesc, Visible)
            GrdPayScale.ShowFooter = False
        ElseIf e.CommandName = "Insert" Then
            'Dim Key As String = CType(GrdPayScale.FooterRow.FindControl("txtModuleSettingKey"), TextBox).Text
            'Dim Value As String = CType(GrdPayScale.FooterRow.FindControl("txtModuleSettingValue"), TextBox).Text
            'Website.Modules.AddModuleSettings(HdnModuleID.Value, Key, Value)
            'GrdPayScale.EditIndex = -1
            'GrdPayScale.ShowFooter = False
        ElseIf e.CommandName = "Cancel" Then
            GrdPayScale.ShowFooter = False
            GrdPayScale.EditIndex = -1
            GrdPayScale.Columns(3).Visible = True
            GrdPayScale.Columns(4).Visible = True
            GrdPayScale.Columns(5).Visible = False

        ElseIf e.CommandName = "Edit" Then
            'Dim txtGroupName As TextBox = CType(GrdPayScale.FooterRow.FindControl("txtGroupName"), TextBox)
            'Dim GroupDesc As TextBox = CType(GrdPayScale.FooterRow.FindControl("txtPayScaleDescription"), TextBox)
            'Dim ChkVisible As CheckBox = CType(GrdPayScale.FooterRow.FindControl("ChkVisible"), CheckBox)
            GrdPayScale.Columns(3).Visible = True
            GrdPayScale.Columns(4).Visible = True
            GrdPayScale.Columns(5).Visible = False
        ElseIf e.CommandName = "Update" Then
            Dim GroupName As String = CType(GrdPayScale.Rows(GrdPayScale.EditIndex).FindControl("txteditGroupName"), TextBox).Text
            Dim GroupDesc As String = CType(GrdPayScale.Rows(GrdPayScale.EditIndex).FindControl("txtEditPayScaleDescription"), TextBox).Text
            Dim Visible As Boolean = CType(GrdPayScale.Rows(GrdPayScale.EditIndex).FindControl("ChkEditVisible"), CheckBox).Checked
            Dim GroupID As String = CType(GrdPayScale.Rows(GrdPayScale.EditIndex).FindControl("HdnGroupID"), HiddenField).Value

            Payroll.UpdatePayrollGroup(Val(GroupID), Val(Session("CurrentBusinessID")), -1, GroupName, GroupDesc, Visible)
            GrdPayScale.EditIndex = -1
        ElseIf e.CommandName = "DeletePayrollGroup" Then
            GrdPayScale.ShowFooter = False
            Payroll.DeletePayrollGroup(Val(Session("CurrentBusinessID")), Val(e.CommandArgument))
            GrdPayScale.EditIndex = -1
        End If
        LoadData()
    End Sub

    Private Sub LnkAddPayScale_Click(sender As Object, e As EventArgs) Handles LnkAddPayScale.Click
        GrdPayScale.ShowFooter = True
        GrdPayScale.Columns(3).Visible = False
        GrdPayScale.Columns(4).Visible = False
        GrdPayScale.Columns(5).Visible = True

        ''If GrdPayScale.Rows.Count = 0 Then
        Dim dr As DataRow
            Dim tbl As New DataTable
            tbl = Payroll.GetPayrollGroups(Val(Session("CurrentBusinessID")))
            dr = tbl.NewRow
            tbl.Rows.InsertAt(dr, 0)
            GrdPayScale.DataSource = tbl
            GrdPayScale.DataBind()
        ''End If
    End Sub

    Private Sub GrdPayScale_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdPayScale.RowEditing
        GrdPayScale.EditIndex = e.NewEditIndex
        GrdPayScale.DataBind()
    End Sub

    Private Sub GrdPayScale_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdPayScale.RowUpdating

    End Sub

    Private Sub GrdPayScale_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdPayScale.RowCancelingEdit

    End Sub
End Class