﻿Public Class GenericPurchaseProductRow
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable
    Dim _TotalAmount As Single

    Public Sub AddRow()
        Dim dr As DataRow
        dr = _tbl.NewRow
        _tbl.Rows.Add(dr)

    End Sub

    Public Sub UpdateRows()
        For i As Integer = 0 To GridView1.Rows.Count - 1
            'For j As Integer = 0 To _tbl.Columns.Count - 1 '' GridView1.Rows(i).Cells.Count - 1
            '    If GridView1.Rows(i).Cells(j + 1).Controls.Count > 0 Then
            '        If TypeOf GridView1.Rows(i).Cells(j + 1).Controls(1) Is TextBox Then
            '            Dim txt As New TextBox
            '            txt = CType(GridView1.Rows(i).Cells(j + 1).Controls(1), TextBox)
            '            _tbl.Rows(i)(j) = txt.Text
            '        Else
            '            Dim ddl As New DropDownList
            '            ddl = CType(GridView1.Rows(i).Cells(j + 1).Controls(1), DropDownList)
            '            _tbl.Rows(i)(j) = ddl.SelectedItem.Value
            '        End If

            '    End If


            'Next


            Dim ddl As New DropDownList
            ddl = CType(GridView1.Rows(i).FindControl("DDLProducts"), DropDownList)
            _tbl.Rows(i)("Product") = ddl.SelectedItem.Value

            Dim txtQty As New TextBox
            txtQty = CType(GridView1.Rows(i).FindControl("txtQuantity"), TextBox)
            _tbl.Rows(i)("Quantity") = txtQty.Text

            Dim txtUnit As New TextBox
            txtUnit = CType(GridView1.Rows(i).FindControl("txtUnit"), TextBox)
            _tbl.Rows(i)("Unit") = txtUnit.Text

            Dim txtPrice As New TextBox
            txtPrice = CType(GridView1.Rows(i).FindControl("txtPrice"), TextBox)
            _tbl.Rows(i)("Price") = txtPrice.Text

            Dim txtDiscount As New TextBox
            txtDiscount = CType(GridView1.Rows(i).FindControl("txtDiscount"), TextBox)
            _tbl.Rows(i)("Discount") = txtDiscount.Text

            Dim txtTotal As New TextBox
            txtTotal = CType(GridView1.Rows(i).FindControl("txtTotal"), TextBox)
            _tbl.Rows(i)("Total") = txtTotal.Text

            Dim txtManDate As New TextBox
            txtManDate = CType(GridView1.Rows(i).FindControl("txtManufacturingDate"), TextBox)
            _tbl.Rows(i)("ManufacturingDate") = txtManDate.Text

            Dim txtExpDate As New TextBox
            txtExpDate = CType(GridView1.Rows(i).FindControl("txtExpiryDate"), TextBox)
            _tbl.Rows(i)("ExpiryDate") = txtExpDate.Text

        Next
    End Sub

    Public Sub AddColumn(ByVal ColumnName As String, Optional ByVal Control As Object = Nothing)
        
        If Not _tbl.Columns.Contains(ColumnName) Then
            _tbl.Columns.Add(ColumnName)
        End If

        Session(Me.ClientID & "PurchaseOrder") = _tbl
    End Sub

    Public Function GetPurchaseData() As DataTable
        Return _tbl
    End Function

    Public ReadOnly Property TotalAmount
        Get
            Return _TotalAmount
        End Get
    End Property

    Sub BindGrid(Optional ByVal Control As Object = Nothing)
        Dim dr As DataRow
        If _tbl.Rows.Count = 0 Then
            dr = _tbl.NewRow
            _tbl.Rows.Add(dr)
        End If
        GridView1.DataSource = _tbl
        GridView1.DataBind()
        ''AddGridControl()
    End Sub

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Session(Me.ClientID & "PurchaseOrder") Is Nothing Then
            _tbl = CType(Session(Me.ClientID & "PurchaseOrder"), DataTable)
            BindGrid()


        End If

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack Then
            UpdateRows
        Else
            GridView1.Columns(2).HeaderText = ReferenceData.Setting("LblProductName", "Product", Session("CurrentBusinessID"))
            GridView1.Columns(5).HeaderText = ReferenceData.Setting("LblGridProductQuantity", "Quantity", Session("CurrentBusinessID"))
            GridView1.Columns(3).HeaderText = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))
            GridView1.Columns(4).HeaderText = ReferenceData.Setting("LblProductPurchasePrice", "Price", Session("CurrentBusinessID"))
            GridView1.Columns(6).HeaderText = ReferenceData.Setting("LblProductDiscount", "Discount", Session("CurrentBusinessID"))
            GridView1.Columns(7).HeaderText = ReferenceData.Setting("LblGridPurchaseProductTotal", "Total", Session("CurrentBusinessID"))
            GridView1.Columns(8).HeaderText = ReferenceData.Setting("LblGridPurchaseProductManufacturingDate", "Manufacturing Date", Session("CurrentBusinessID"))
            GridView1.Columns(9).HeaderText = ReferenceData.Setting("LblGridPurchaseProductExpiryDate", "Expiry Date", Session("CurrentBusinessID"))

            For i As Integer = _tbl.Rows.Count - 1 To 0 Step -1
                _tbl.Rows.RemoveAt(i)
            Next
            Session(Me.ClientID & "PurchaseOrder") = _tbl
            BindGrid()
        End If
    End Sub

    Private Function ValidateGridRows() As Boolean
        Dim res As Boolean = True
        For i As Integer = 0 To GridView1.Rows.Count - 1
            Dim DDLProducts As DropDownList = CType(GridView1.Rows(i).FindControl("DDLProducts"), DropDownList)
            If (Val(DDLProducts.SelectedValue) <= -1) Then
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "ValidationError", "parent.ShowMessage('No Product Selected','1',$(window).height()*2/100,$(window).width()*25/100);", True)
                Return False
            End If
            Dim txtQuantity As TextBox = CType(GridView1.Rows(i).FindControl("txtQuantity"), TextBox)
            If (Val(txtQuantity.Text) <= 0) Then
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "ValidationError", "parent.ShowMessage('Invalid quantity entered','1',$(window).height()*2/100,$(window).width()*25/100);", True)
                Return False
            End If
            Dim txtTotal As TextBox = CType(GridView1.Rows(i).FindControl("txtTotal"), TextBox)
            If (Val(txtQuantity.Text) <= 0) Then
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "ValidationError", "parent.ShowMessage('Total amount can not be less than 0','1',$(window).height()*2/100,$(window).width()*25/100);", True)
                Return False
            End If
        Next
        Return res
    End Function

    Private Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "AddRow" Then
            If ValidateGridRows() Then
                Dim dr As DataRow
                dr = _tbl.NewRow

                _tbl.Rows.Add(dr)
                'DataRowsCount.Value = Val(DataRowsCount.Value) + 1
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "success", "$('#" & DataRowsCount.ClientID & "').val(parseInt($('#" & DataRowsCount.ClientID & "').val()) + 1)", True)
            End If

        ElseIf e.CommandName = "DeleteRow" Then
            _tbl.Rows.RemoveAt(Val(e.CommandArgument) - 1)
            'DataRowsCount.Value = Val(DataRowsCount.Value) - 1
            ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "success", "$('#" & DataRowsCount.ClientID & "').val(parseInt($('#" & DataRowsCount.ClientID & "').val()) - 1)", True)
        End If
        Session(Me.ClientID & "PurchaseOrder") = _tbl
        BindGrid()
    End Sub

    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim Btn As New Button
            If e.Row.RowIndex = _tbl.Rows.Count - 1 Then
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "+"
                Btn.CommandName = "AddRow"
            Else
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "-"
                Btn.CommandName = "DeleteRow"
            End If


            Dim ddl As New DropDownList
            ddl = CType(e.Row.FindControl("DDLProducts"), DropDownList)
            ddl.DataTextField = "ArticleTitle"
            ddl.DataValueField = "ArticleID"
            ddl.DataSource = Products.GetProductsList(Session("CurrentBusinessID"))
            ddl.DataBind()
            If _tbl.Columns.Contains("Product") Then
                ddl.SelectedValue = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Product")), "", _tbl.Rows(e.Row.RowIndex)("Product"))

            End If

            ddl.AutoPostBack = True
            ddl.Attributes.Add("RowIdx", e.Row.RowIndex)
            ''ddl.Items.Insert(0, "Select")
            AddHandler ddl.SelectedIndexChanged, AddressOf ProductDDL_SelectedIndexChanged

            Dim txtPrice As New TextBox
            txtPrice = CType(e.Row.FindControl("txtPrice"), TextBox)
            If Not txtPrice Is Nothing Then
                If _tbl.Columns.Contains("Price") Then
                    txtPrice.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Price")), "", _tbl.Rows(e.Row.RowIndex)("Price"))
                End If

                txtPrice.CssClass = "form-control numeric"
            End If

            Dim txtDiscount As New TextBox
            txtDiscount = CType(e.Row.FindControl("txtDiscount"), TextBox)
            If Not txtDiscount Is Nothing Then
                If _tbl.Columns.Contains("Discount") Then
                    txtDiscount.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Discount")), "", _tbl.Rows(e.Row.RowIndex)("Discount"))
                End If

                txtDiscount.CssClass = "form-control numeric"
            End If

            Dim txtTotal As New TextBox
            txtTotal = CType(e.Row.FindControl("txtTotal"), TextBox)
            If Not txtTotal Is Nothing Then
                If _tbl.Columns.Contains("Total") Then
                    txtTotal.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Total")), "", _tbl.Rows(e.Row.RowIndex)("Total"))
                End If

                txtTotal.CssClass = "form-control numeric rowTotal"

            End If

            Dim txtQty As New TextBox
            txtQty = CType(e.Row.FindControl("txtQuantity"), TextBox)
            If Not txtQty Is Nothing Then
                txtQty.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("Quantity") Then
                    txtQty.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Quantity")), "", _tbl.Rows(e.Row.RowIndex)("Quantity"))
                End If

                txtQty.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")
                txtDiscount.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")
                txtPrice.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")

                txtQty.Attributes.Add("onchange", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")
                txtDiscount.Attributes.Add("onchange", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")
                txtPrice.Attributes.Add("onchange", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')")

            End If

            Dim txtUnit As New TextBox
            txtUnit = CType(e.Row.FindControl("txtUnit"), TextBox)
            If Not txtUnit Is Nothing Then
                If _tbl.Columns.Contains("Unit") Then
                    txtUnit.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Unit")), "", _tbl.Rows(e.Row.RowIndex)("Unit"))
                End If

            End If




            Dim txtManDate As New TextBox
            txtManDate = CType(e.Row.FindControl("txtManufacturingDate"), TextBox)
            If Not txtManDate Is Nothing Then
                If _tbl.Columns.Contains("ManufacturingDate") Then
                    txtManDate.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("ManufacturingDate")), "", _tbl.Rows(e.Row.RowIndex)("ManufacturingDate"))
                End If

            End If

            Dim txtExpDate As New TextBox
            txtExpDate = CType(e.Row.FindControl("txtExpiryDate"), TextBox)
            If Not txtExpDate Is Nothing Then
                If _tbl.Columns.Contains("ExpiryDate") Then
                    txtExpDate.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("ExpiryDate")), "", _tbl.Rows(e.Row.RowIndex)("ExpiryDate"))
                End If

            End If

        End If


        If (e.Row.RowType = DataControlRowType.Footer) Then
            Dim TotalLbl As New Label
            Dim TotalPrice As Single

            For i As Integer = 0 To _tbl.Rows.Count - 1
                If _tbl.Columns.Contains("Total") Then
                    TotalPrice += Val(IIf(IsDBNull(_tbl.Rows(i)("Total")), "", _tbl.Rows(i)("Total")))
                End If

            Next
            TotalLbl = CType(e.Row.FindControl("AmountTotal"), Label)
            If Not TotalLbl Is Nothing Then
                TotalLbl.Text = TotalPrice
                _TotalAmount = TotalPrice
            End If
        End If

    End Sub

    Protected Sub ProductDDL_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ridx As Integer = sender.Attributes("RowIdx")
        Dim ProductUnit As New TextBox
        Dim ProductPrice As New TextBox
        Dim txtQty As New TextBox
        Dim txtTotal As New TextBox
        Dim txtDiscount As New TextBox

        Dim ProductID As Integer
        ProductUnit = CType(GridView1.Rows(ridx).FindControl("txtUnit"), TextBox)
        ProductPrice = CType(GridView1.Rows(ridx).FindControl("txtPrice"), TextBox)
        txtQty = CType(GridView1.Rows(ridx).FindControl("txtQuantity"), TextBox)
        txtTotal = CType(GridView1.Rows(ridx).FindControl("txtTotal"), TextBox)
        txtDiscount = CType(GridView1.Rows(ridx).FindControl("txtDiscount"), TextBox)
        ProductID = sender.selecteditem.value

        If Not (ProductUnit Is Nothing) Then
            Dim ds As New DataSet
            ds = Products.GetProductDetails(Session("CurrentBusinessID"), Val(ProductID))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    ProductUnit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UnitAsText")), "", ds.Tables(0).Rows(0)("UnitAsText"))
                    If Not ProductPrice Is Nothing Then
                        ProductPrice.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("PurchasePrice")), "", ds.Tables(0).Rows(0)("PurchasePrice"))
                        ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "success", "ApplyNumericValidation();UpdatePrice('" & ProductPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "')", True)
                    End If
                End If
            End If
        End If
    End Sub
End Class