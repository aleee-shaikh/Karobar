﻿Public Class PurchaseHistory
    Inherits System.Web.UI.UserControl
    Dim _tbl As New DataTable
    Dim _TotalAmount As Single
    Public Property VendorID() As Integer
        Get
            Return Val(HdnVendorID.Value)
        End Get
        Set(value As Integer)
            HdnVendorID.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub

    Sub LoadData()

        Dim FDate As String = ""
        Dim FdateAry() = Now.AddYears(-50).ToString("dd-MM-yyyy").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = Now.ToString("dd-MM-yyyy").Split("-")

        _tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2)) & " 00:00:00 AM", CDate(TdateAry(1) & "-" & TdateAry(0) & "-" & TdateAry(2)) & " 23:59:59 PM", VendorID)
        Session("PurchaseReport-" & Session("UserID")) = _tbl

        GrdProducts.DataSource = _tbl
        GrdProducts.DataBind()

    End Sub


    Private Sub GrdProducts_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdProducts.PageIndexChanging
        GrdProducts.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdProducts_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdProducts.RowCommand
        If e.CommandName = "DeleteProduct" Then
            Products.DeleteProduct(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Deleted Product " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        ElseIf e.CommandName = "ViewProductAccounts" Then

        ElseIf e.CommandName = "DeleteProductAccount" Then

            ''Product.DeleteProductAccount(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Deleted Product Account " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim LnkEditProduct As New System.Web.UI.WebControls.LinkButton
            LnkEditProduct = CType(e.Row.FindControl("LnkEditProduct"), LinkButton)
            If Not LnkEditProduct Is Nothing Then
                LnkEditProduct.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx?PID=" & drview("ArticleID") & "',$(window).height()*79/100,$(window).width()*72/100);return false"
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")


            Dim LnkViewPurchaseInvoice As New System.Web.UI.WebControls.LinkButton
            LnkViewPurchaseInvoice = CType(e.Row.FindControl("LnkViewPurchaseInvoice"), LinkButton)
            If Not LnkViewPurchaseInvoice Is Nothing Then
                LnkViewPurchaseInvoice.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Reports/PurchaseInvoice.aspx?PurchaseID=" & drview("PurchaseID") & "',$(window).height()*95/100,$(window).width()*99/100);return false"
            End If


            _TotalAmount = _TotalAmount + ((drview("Quantity") * drview("PurchasePrice")) + drview("OtherCharges")) - drview("Discount")
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalAmountLbl As New System.Web.UI.WebControls.Label
            TotalAmountLbl = CType(e.Row.FindControl("TotalAmount"), Label)
            If Not TotalAmountLbl Is Nothing Then
                TotalAmountLbl.Text = _TotalAmount
            End If


        End If
    End Sub

End Class