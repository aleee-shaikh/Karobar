﻿Public Class BusinessPageMasterPage
    Inherits System.Web.UI.MasterPage

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.ClientScript.RegisterClientScriptInclude("jsRender", "/Scripts/jsRender.js")
        Page.ClientScript.RegisterClientScriptInclude("json2", "/Scripts/json2.js")
        Page.ClientScript.RegisterClientScriptInclude("Templates", "/Scripts/Templates.js")
        Page.ClientScript.RegisterClientScriptInclude("User", "/Modules/Scripts/User.js")
        Page.ClientScript.RegisterClientScriptInclude("Menu", "/Modules/Scripts/Menu.js")
        Page.ClientScript.RegisterClientScriptInclude("Articles", "/Modules/Scripts/Articles.js")
        Page.ClientScript.RegisterClientScriptInclude("Polling", "/Modules/Scripts/Product.js")
        Page.ClientScript.RegisterClientScriptInclude("General", "/Modules/Scripts/General.js")
        Page.ClientScript.RegisterClientScriptInclude("COA", "/Modules/Scripts/COA.js")


        If Not Page.IsPostBack Then
            txtCurrentURL.Text = Request.Url.PathAndQuery
        End If

        Me.webpagehead.Description = CMS.WebPage.PageSEODescription()
        Me.webpagehead.Keywords = CMS.WebPage.PageSEOKeywords

        'If Session("Visited") Is Nothing Then
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), -1, "Business Visit", "Visited at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        '    Session("Visited") = Now
        'End If


    End Sub

    
End Class