﻿Public Class PaymentreceivedInvoice
    Inherits System.Web.UI.Page


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open purchase invoice", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If Not Page.IsPostBack Then
            HdnTID.Value = Request("TID")
            DDLCreditAccountHead.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("CreditAccountHeads4PaymentReceived", "30,31,32", Session("CurrentBusinessID")))
            DDLCreditAccountHead.DataTextField = "AccountHeadName"
            DDLCreditAccountHead.DataValueField = "AccountHeadID"
            DDLCreditAccountHead.DataBind()

            LblPaymentReceiveDate.Text = ReferenceData.Setting("LblPaymentReceiveDate", "Date", Session("CurrentBusinessID"))
            LblPaymentReceivedParticular.Text = ReferenceData.Setting("LblPaymentReceivedParticular", "Particular", Session("CurrentBusinessID"))
            LblReceivedPaymentAmount.Text = ReferenceData.Setting("LblReceivedPaymentAmount", "Amount", Session("CurrentBusinessID"))
            LblReceivedPaymentCreditAccount.Text = ReferenceData.Setting("LblReceivedPaymentCreditAccount", "Payment (Credit Account)", Session("CurrentBusinessID"))
            LblReceivedPaymentDebitAccount.Text = ReferenceData.Setting("LblReceivedPaymentDebitAccount", "Payment (Debit Account)", Session("CurrentBusinessID"))
            LblReceivedPaymentOtherCharges.Text = ReferenceData.Setting("LblReceivedPaymentOtherCharges", "Other Charges", Session("CurrentBusinessID"))

            LblReceivedPaymentReference.Text = ReferenceData.Setting("LblReceivedPaymentReference", "Reference", Session("CurrentBusinessID"))
            LblReceivedPaymentTax.Text = ReferenceData.Setting("LblReceivedPaymentTax", "Tax", Session("CurrentBusinessID"))

            DDLDebitAccountHead.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("DebitAccountHeadsPaymentReceived", "24,10", Session("CurrentBusinessID")))
            DDLDebitAccountHead.DataTextField = "AccountHeadName"
            DDLDebitAccountHead.DataValueField = "AccountHeadID"
            DDLDebitAccountHead.DataBind()
        End If
        If HdnTID.Value > 0 Then
            Dim tbl As New DataTable
            tbl = Transactions.GetTransactionDetails(Session("CurrentBusinessID"), Val(HdnTID.Value))
            If tbl.Rows.Count > 1 Then
                LblPaymentReceiptInvoiceID.Text = "Receipt-" & tbl.Rows(0)("TransactionID")
                txtDate.Text = General.GetLocalDateTimeByTimeZone(tbl.Rows(0)("Dated"), LoggedInUserSession.TimeZone)
                ReceiptDate.Text = General.GetLocalDateTimeByTimeZone(tbl.Rows(0)("Dated"), LoggedInUserSession.TimeZone)
                ReceiptAmount.Text = txtDate.Text
                txtParticular.Text = tbl.Rows(0)("particular")
                ReceiptParticular.Text = txtParticular.Text
                DDLCreditAccountHead.SelectedValue = tbl.Rows(1)("AccountHeadID")
                ReceiptCreditAccount.Text = DDLCreditAccountHead.SelectedItem.Text
                txtTax.Text = tbl.Rows(0)("Tax")
                ReceiptTax.Text = txtTax.Text
                txtOtherCharges.Text = tbl.Rows(0)("BankCharges")
                ReceiptOtherCharges.Text = txtOtherCharges.Text
                txtAmount.Text = Math.Round(tbl.Rows(0)("TransactionAmount"), 2)
                ReceiptAmount.Text = txtAmount.Text
                txtReference.Text = tbl.Rows(0)("Reference")
                ReceiptReference.Text = txtReference.Text
                DDLDebitAccountHead.SelectedValue = tbl.Rows(0)("AccountHeadID")
                ReceiptDebitAccount.Text = tbl.Rows(0)("AccountHeadName") 'DDLDebitAccountHead.SelectedItem.Text
                LblTotal.Text = CSng(txtAmount.Text) + CSng(txtTax.Text) + CSng(txtOtherCharges.Text)

            End If
        End If
    End Sub


End Class