﻿Public Class ManageBanks
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        If Person.DoesPersonHavePageRights(Session("UserID"), 26) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage banks screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
    End Sub

    Sub LoadData()
        GrdBanks.DataSource = Bank.GetBanksList(Session("CurrentBusinessID"), txtFreeText.Text.Trim)
        GrdBanks.DataBind()
    End Sub


    Private Sub GrdBanks_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdBanks.PageIndexChanging
        GrdBanks.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdBanks_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdBanks.RowCommand
        If e.CommandName = "DeleteBank" Then

            Bank.DeleteBank(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Bank", "Deleted Bank " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        ElseIf e.CommandName = "ViewBankAccounts" Then

        ElseIf e.CommandName = "DeleteBankAccount" Then

            Bank.DeleteBankAccount(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Bank", "Deleted Bank Account " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub

    Private Sub GrdBanks_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdBanks.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim BankEditLnkBtn As New System.Web.UI.WebControls.LinkButton
            BankEditLnkBtn = CType(e.Row.FindControl("LnkEditBank"), LinkButton)
            If Not BankEditLnkBtn Is Nothing Then
                BankEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Banks/NewBank.aspx?BID=" & drview("BankID") & "',$(window).height()*52/100,$(window).width()*47/100);return false"
            End If

            Dim GrdBankAccounts As New System.Web.UI.WebControls.GridView
            GrdBankAccounts = CType(e.Row.FindControl("GrdBankAccounts"), GridView)
            AddHandler GrdBankAccounts.RowDataBound, AddressOf GrdBankAccounts_RowDataBound
            If Not GrdBankAccounts Is Nothing Then
                GrdBankAccounts.DataSource = Bank.GetBanksAccountsList(Session("CurrentBusinessID"), drview("BankID"), "")
                GrdBankAccounts.DataBind()
            End If

            'Dim LblCurBalance As New Label
            'LblCurBalance = CType(GrdBankAccounts.Rows().FindControl("LblCurBalance"), Label)

            'If Not LblCurBalance Is Nothing Then
            '    Dim tbl As New DataTable
            '    tbl = ChartOfAccount.GetCOAAccountHeadsBalance(Session("CurrentBusinessID"), drview("BankID"))
            '    If tbl.Rows.Count > 0 Then
            '        LblCurBalance.Text = tbl.Rows(0)("Balance")
            '    Else
            '        LblCurBalance.Text = 0
            '    End If

            'End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub



    Private Sub GrdBankAccounts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim LblCurBalance As New Label
            LblCurBalance = CType(e.Row.FindControl("LblCurBalance"), Label)

            If Not LblCurBalance Is Nothing Then
                Dim tbl As New DataTable
                tbl = ChartOfAccount.GetCOAAccountHeadsBalance(Session("CurrentBusinessID"), drview("BankAccountID"))
                If tbl.Rows.Count > 0 Then
                    LblCurBalance.Text = tbl.Rows(0)("Balance")
                Else
                    LblCurBalance.Text = 0
                End If

            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='silver';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub
End Class