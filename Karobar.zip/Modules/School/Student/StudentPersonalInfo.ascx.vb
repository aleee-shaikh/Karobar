﻿Public Class StudentPersonalInfo
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer

    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(value As Integer)
            _EmployeeID = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim ds As New DataSet

            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.MaritalStatus * -1)
            DDLMaritalStatus.DataValueField = "ArticleTypeID"
            DDLMaritalStatus.DataTextField = "ArticleType"
            DDLMaritalStatus.DataSource = ds.Tables(0)
            DDLMaritalStatus.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.PersonTitles * -1)
            DDLTitle.DataValueField = "ArticleTypeID"
            DDLTitle.DataTextField = "ArticleType"
            DDLTitle.DataSource = ds.Tables(0)
            DDLTitle.DataBind()



            Dim tbl As New DataTable
            'tbl = Person.GetUserWebsites(Session("CurrentBusinessID"), Session("UserID"))
            'ChkLstBusinessAccessibility.DataValueField = "WebsiteID"
            'ChkLstBusinessAccessibility.DataTextField = "Websitetitle"
            'ChkLstBusinessAccessibility.DataSource = tbl
            'ChkLstBusinessAccessibility.DataBind()

            tbl = Website.GetWebsiteRoles(Session("CurrentBusinessID")).Select("RoleID<>1").CopyToDataTable
            ChkLstUserRoles.DataValueField = "RoleID"
            ChkLstUserRoles.DataTextField = "RoleName"
            ChkLstUserRoles.DataSource = tbl
            ChkLstUserRoles.DataBind()
            If Not Request("SID") Is Nothing Then
                HdnStaffID.Value = Val(Request("SID"))
            End If
            If Val(HdnStaffID.Value) > 0 Then
                LoadData(Val(HdnStaffID.Value))
            End If

            If Val(HdnStaffID.Value) <= 0 Then
                StaffImage.ImageUrl = "/Images/NoUserImage.png"
            End If

            LblTitle.Text = ReferenceData.Setting("LblStudentTitle", "Title", Session("CurrentBusinessID"))
            LblFirstName.Text = ReferenceData.Setting("LblStudentFirstName", "First Name", Session("CurrentBusinessID"))
            LblLastName.Text = ReferenceData.Setting("LblStudentLastName", "Last Name", Session("CurrentBusinessID"))
            LblMiddleName.Text = ReferenceData.Setting("LblStudentMiddleName", "Guardian Name", Session("CurrentBusinessID"))
            LblNTNNumber.Text = ReferenceData.Setting("LblStudentRollNumber", "Roll Number", Session("CurrentBusinessID"))

            If (Not Session("CurrentBusinessCategoryID") Is Nothing) AndAlso Val(Session("CurrentBusinessCategoryID")) = 5 Then
                DivMiddleName.Visible = True
                DivTitle.Visible = False
            End If
        End If


    End Sub

    Sub LoadData(ByVal SID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), SID)

        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
            If ds.Tables(0).Rows.Count > 0 Then
                If IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")) OrElse ds.Tables(0).Rows(0)("WebsiteID") <> Session("CurrentBusinessID") Then
                    BtnSave.Enabled = False
                    BtnSave.Visible = False
                    Exit Sub
                End If
            Else
                BtnSave.Enabled = False
                BtnSave.Visible = False
            End If
        End If
        If tbl.Rows.Count > 0 Then
            txtAddress.Text = IIf(IsDBNull(tbl.Rows(0)("ResidentialAddress")), "", tbl.Rows(0)("ResidentialAddress"))
            txtFirstName.Text = IIf(IsDBNull(tbl.Rows(0)("FirstName")), "", tbl.Rows(0)("FirstName"))
            txtMiddleName.Text = IIf(IsDBNull(tbl.Rows(0)("MiddleName")), "", tbl.Rows(0)("MiddleName"))
            txtLastName.Text = IIf(IsDBNull(tbl.Rows(0)("LastName")), "", tbl.Rows(0)("LastName"))
            txtHomePhone.Text = IIf(IsDBNull(tbl.Rows(0)("TelephoneNo")), "", tbl.Rows(0)("TelephoneNo"))
            txtEmail.Text = IIf(IsDBNull(tbl.Rows(0)("EmailAddress")), "", tbl.Rows(0)("EmailAddress"))
            txtMobileNo.Text = IIf(IsDBNull(tbl.Rows(0)("MobileNo")), "", tbl.Rows(0)("MobileNo"))
            txtOtherContactNo.Text = IIf(IsDBNull(tbl.Rows(0)("OtherContactNo")), "", tbl.Rows(0)("OtherContactNo"))
            DDLTitle.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Title")), "", tbl.Rows(0)("Title"))
            DDLGender.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Gender")), "", tbl.Rows(0)("Gender"))
            If IsDBNull(tbl.Rows(0)("DateOfBirth")) = False Then
                txtDateOfBirth.Text = CDate(tbl.Rows(0)("DateOfBirth")).ToString("dd-MM-yyyy")
            End If

            txtPassword.Text = IIf(IsDBNull(tbl.Rows(0)("Password")), "", tbl.Rows(0)("Password"))
            txtConfirmPassword.Text = IIf(IsDBNull(tbl.Rows(0)("Password")), "", tbl.Rows(0)("Password"))
            ChkAccountEnabled.Checked = IIf(IsDBNull(tbl.Rows(0)("WebAccess")), False, tbl.Rows(0)("WebAccess"))

            Page.RegisterStartupScript("SetPwd", "<script>$(document).ready(function () {$('#" & txtPassword.ClientID & "').val('" & tbl.Rows(0)("Password") & "');$('#" & txtConfirmPassword.ClientID & "').val('" & tbl.Rows(0)("Password") & "');})</script>")

            If (IsDBNull(tbl.Rows(0)("ImageFilename")) = False AndAlso tbl.Rows(0)("ImageFilename") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/" & Session("CurrentBusinessID") & "/Staff/Images/" '' "~/CMS/" & Session("CurrentBusinessID") & "/Staff/Images"
                HdnStaffImageFilename.Value = tbl.Rows(0)("ImageFilename")
                StaffImage.ImageUrl = BusinessDirectory & tbl.Rows(0)("ImageFilename")
                StaffImage.AlternateText = txtFirstName.Text & " " & txtLastName.Text
            Else
                StaffImage.ImageUrl = "/Images/NoUserImage.png"
            End If


            'If tbl.Rows(0)("AccountTypeID") = Person.UserTypes.Student Then
            '    tbl = New DataTable
            '    tbl = Website.User.GetPersonRoles(SID)
            '    For i As Integer = 0 To tbl.Rows.Count - 1
            '        For j = 0 To ChkLstUserRoles.Items.Count - 1
            '            If ChkLstUserRoles.Items(j).Value = tbl.Rows(i)("RoleID") Then
            '                ChkLstUserRoles.Items(j).Selected = True
            '            End If
            '        Next
            '    Next
            'End If
        End If


    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim UserImageFilename As String = HdnStaffImageFilename.Value

        If FileUploadStaffImage.PostedFile.FileName <> "" AndAlso FileUploadStaffImage.PostedFile.FileName <> UserImageFilename Then
            UserImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadStaffImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Session("CurrentBusinessID") & "/Staff/") & "Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If

            FileUploadStaffImage.SaveAs(BusinessDirectory & "\" & UserImageFilename)
        End If
        Dim SelectedBusiness As String = ""
        For i As Integer = 0 To ChkLstBusinessAccessibility.Items.Count - 1
            If ChkLstBusinessAccessibility.Items(i).Selected Then
                SelectedBusiness = SelectedBusiness & ChkLstBusinessAccessibility.Items(i).Value & ","
            End If
        Next

        Dim DOBAry() = txtDateOfBirth.Text.Replace("/", "-").Split("-")
        txtEmail.Text = txtFirstName.Text.Trim().Replace(" ", "_") & "$" & Now.ToString("yyyyMMddhhmmss") & "@" & Session("CurrentBusinessID") & ".com"
        If Val(HdnStaffID.Value) > 0 Then
            tbl = Person.UpdateDetails(Session("CurrentBusinessID"), Val(HdnStaffID.Value), txtEmail.Text.Trim, txtConfirmPassword.Text, txtFirstName.Text.Trim, txtMiddleName.Text.Trim, txtLastName.Text.Trim, DDLTitle.SelectedItem.Value,
            DDLGender.SelectedItem.Value, CDate(DOBAry(1) & "-" & DOBAry(0) & "-" & DOBAry(2)), DDLMaritalStatus.SelectedItem.Value, txtHomePhone.Text.Trim, txtMobileNo.Text.Trim, txtOtherContactNo.Text.Trim,
             txtEmail.Text.Trim, txtAddress.Text.Trim, Person.UserTypes.Student, -1, ChkAccountEnabled.Checked, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, "", "")
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    Person.AssignUserWebsiteAccess(Session("CurrentBusinessID") & ",", tbl.Rows(0)("UserID"))
                    Dim Roles As String = ""
                    For i As Integer = 0 To ChkLstUserRoles.Items.Count - 1
                        If ChkLstUserRoles.Items(i).Selected = True Then
                            Roles = Roles & ChkLstUserRoles.Items(i).Value & ","
                        End If
                    Next
                    Roles = Roles & "6,7,"
                    If Roles.Length > 0 Then Roles = Roles.Substring(0, Roles.Length - 1)
                    Website.User.UpdatePersonRoles(tbl.Rows(0)("UserID"), Roles)

                    Page.RegisterStartupScript("StaffUpdatedSuccessFully", "<script>parent.ShowMessage('Staff updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Else
                    Page.RegisterStartupScript("StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                Page.RegisterStartupScript("StaffUpdatingIssue", "<script>parent.ShowMessage('Unable to add staff','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If

        Else
            tbl = Person.AddUser(Session("CurrentBusinessID"), txtEmail.Text.Trim, txtConfirmPassword.Text, txtFirstName.Text.Trim, txtMiddleName.Text.Trim, txtLastName.Text.Trim, DDLTitle.SelectedItem.Value,
                        DDLGender.SelectedItem.Value, CDate(DOBAry(1) & "-" & DOBAry(0) & "-" & DOBAry(2)), DDLMaritalStatus.SelectedItem.Value, txtHomePhone.Text.Trim, txtMobileNo.Text.Trim, txtOtherContactNo.Text.Trim,
                         txtEmail.Text.Trim, txtAddress.Text.Trim, Person.UserTypes.Student, -1, ChkAccountEnabled.Checked, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, "", "", ParentAccountHeadID:=ReferenceData.Setting("StaffAccountHeadID", "31", Session("CurrentBusinessID")))
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then


                    Person.AssignUserWebsiteAccess(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"))


                    Dim Roles As String = ""
                    For i As Integer = 0 To ChkLstUserRoles.Items.Count - 1
                        If ChkLstUserRoles.Items(i).Selected = True Then
                            Roles = Roles & ChkLstUserRoles.Items(i).Value & ","
                        End If
                    Next
                    Roles = Roles & "6,7,"
                    If Roles.Length > 0 Then Roles = Roles.Substring(0, Roles.Length - 1)
                    Website.User.UpdatePersonRoles(tbl.Rows(0)("UserID"), Roles)
                    ''Page.RegisterStartupScript("StaffAddedSuccessFully", "<script>parent.ShowMessage('Staff added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    Response.Redirect("~/Modules/School/Student/Student.aspx?Add=1&SID=" & tbl.Rows(0)("UserID"))

                Else
                    Page.RegisterStartupScript("StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                Page.RegisterStartupScript("StaffAddingIssue", "<script>parent.ShowMessage('Unable to add staff','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        End If

    End Sub

End Class