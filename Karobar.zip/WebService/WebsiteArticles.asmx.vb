﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class WebsiteArticles1
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetPopularProducts(ByVal TypeID As Integer) As String
        Dim ds As New DataSet

        ds = WebsiteArticles.GetPopularProducts(HttpContext.Current.Session("CurrentBusinessID"), TypeID)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "PopularProducts"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetMostSoldProduct(ByVal TypeID As Integer) As String
        Dim ds As New DataSet

        ds = WebsiteArticles.GetProductMostSoldProducts(HttpContext.Current.Session("CurrentBusinessID"), TypeID)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "MostSoldProducts"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetPopularProducts(BID As Integer, ByVal TypeID As Integer) As String
        Dim ds As New DataSet

        ds = WebsiteArticles.GetProductMostSoldProducts(BID, TypeID)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "MostSoldProducts"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetMostPurchasedProduct(ByVal TypeID As Integer) As String
        Dim ds As New DataSet

        ds = WebsiteArticles.GetProductMostPurchasedProducts(HttpContext.Current.Session("CurrentBusinessID"), TypeID)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "MostPurchasedProducts"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetProductTypes(BusinessID As Integer, ByVal TypeID As Integer) As String
        Dim ds As New DataSet
        If Not (BusinessID > 0) Then
            BusinessID = Val(HttpContext.Current.Session("CurrentBusinessID"))
        End If
        ds = WebsiteArticles.GetProductTypes(BusinessID, TypeID)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "ProductTypes"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function Article_GetArticleTypes(ByVal PrimaryTypeID As Integer) As String
        Dim ds As New DataSet

        ds = WebsiteArticles.GetArticleTypes(Website.WebsiteID, PrimaryTypeID)
        If ds.Tables.Count > 1 Then ds.Tables(1).TableName = "ArticlePrimaryTypes"
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "ArticleSecondaryTypes"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Article_GetDetail(ByVal ArticleID As Integer) As String
        Dim ds As New DataSet
        ds = WebsiteArticles.GetArticle(ArticleID)

        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "ArticleDetail"
        If ds.Tables.Count > 1 Then ds.Tables(1).TableName = "ArticleImages"

        WebsiteArticles.LogArticleDetailVisit(ArticleID, HttpContext.Current.Session("UserID"), HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.UserHostAddress)
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Articles_Search(ByVal TypeID As Integer, ByVal SearchText As String, ByVal PageNumber As Integer, ByVal PageSize As String, ByVal SortBy As String, ByVal SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = WebsiteArticles.GetArticlesList(SearchText, TypeID, PageNumber, PageSize, SortBy, SortOrder)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "ArticlesSearchResults"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Articles_GetPopularArticles(ByVal TypeID As Integer, ByVal SearchText As String, ByVal PageNumber As Integer, ByVal PageSize As String, ByVal SortBy As String, ByVal SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = WebsiteArticles.GetPopularArticles(SearchText, TypeID, PageNumber, PageSize, SortBy, SortOrder)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "ArticlesSearchResults"
        Return ds.GetXml
    End Function


    <WebMethod(True)>
    Public Function Articles_Add(ByVal ArticleTypeID As Integer, ByVal ArticleTitle As String, ByVal ArticleDesc As String, ByVal ArticleImageWebURL As String, ByVal ArticleImageLocalPath As String, ByVal File As HtmlInputFile) As String
        Dim loop1 As Integer
        Dim arr1() As String
        Dim Files As HttpFileCollection

        Dim memFile As HttpPostedFile = HttpContext.Current.Request.Files("Filedata")
        Dim memFilename = File.PostedFile.FileName

        Dim bytReq(0) As Byte
        Dim intLen As Integer
        Dim strParam As String

        Files = HttpContext.Current.Request.Files ' Load File collection into HttpFileCollection variable.
        arr1 = Files.AllKeys ' This will get keys (not file names as incorrectly stated in MSDN article) of all files into a string array.

        memFile.SaveAs("/" & System.IO.Path.GetFileName(ArticleImageLocalPath))
        Dim strResult As String
        Dim strFname As String
        Dim strParams() As String

        For loop1 = 0 To arr1.GetUpperBound(0)
            strResult &= "File control: " & Server.HtmlEncode(arr1(loop1)) & vbCrLf
            memFile = HttpContext.Current.Request.Files(arr1(loop1))
            strFname = memFile.FileName
            strResult &= "File Name: " & strFname & vbCrLf
            memFile.SaveAs("Your server Path" &
            System.IO.Path.GetFileName(strFname))
            strParams = Split(strFname, vbTab)
        Next loop1

        For Each strParam In strParams
            strResult &= vbCrLf & strParam
        Next

        Return strResult

    End Function


    <WebMethod(True)>
    Public Function PlaceAnOrder(ByVal WebsiteID As Integer, ByVal UserID As Integer, ByVal UserName As String,
                               ByVal UserEmail As String, ByVal UserMobileNo As String, ByVal UserLandlineNo As String,
                               UserCity As String, UserAddress As String, OrderMessage As String, ProductIDsList As String) As String


        Dim dr As DataRow

        dr = Website.GetWebsiteDetailRow(WebsiteID)
        If Not (WebsiteID > 0) Then
            WebsiteID = Val(HttpContext.Current.Session("CurrentBusinessID"))
        End If
        Dim tbl As New DataTable

        tbl = Products.PlaceAnOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage, Now, ProductIDsList)
        Dim OrderID As Integer
        If (tbl.Rows.Count > 0) Then
            OrderID = tbl.Rows(0)("OrderID")
            If (tbl.Rows.Count = 1) Then
                ProductIDsList = tbl.Rows(0)("ProductID")
            Else
                ProductIDsList = ""
            End If
            Log.Notifications_Add("Order Received ", OrderID, "Order Received", 0, WebsiteID)
        End If
        Dim ReplacingWords As String = ""
        Dim ToUserEmail As String = ReferenceData.Setting("ToOrderNotificationEmail", UserEmail)
        Dim EmailTemplateFile As String = ""
        Dim FromUserEmail As String = ""
        Dim Subject As String = dr("WebsiteTitle").ToString() & " - " & ReferenceData.Setting("OrderNotificationEmailSubject", "Order Notification") ''& " :" & ProductIDsList

        FromUserEmail = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
        EmailTemplateFile = ReferenceData.Setting("OrderNotificationEmailTemplate", "OrderNotificationTemplate")

        ReplacingWords = ReplacingWords & "[UserName]♦" & UserName & "¤"
        ReplacingWords = ReplacingWords & "[UserEmail]♦" & UserEmail & "¤"
        ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
        ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
        ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
        ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
        ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
        ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
        ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
        ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
        ReplacingWords = ReplacingWords & "[BusinessID]♦" & Cryptography.Encrypt(WebsiteID.ToString()) & "¤"
        ReplacingWords = ReplacingWords & "[BID]♦" & WebsiteID.ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & dr("WebsiteTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & dr("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessWebsiteURL]♦" & dr("WebsiteURL").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & dr("WebsiteLogo").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & dr("CurrencyCode").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & dr("Email").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & dr("Phone").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessFax]♦" & dr("Fax").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCity]♦" & dr("City").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTown]♦" & dr("Town").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & dr("CategoryTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & dr("Address").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[Products]♦" & ProductIDsList & "¤"
        ReplacingWords = ReplacingWords & "[OrderID]♦" & Cryptography.Encrypt(OrderID.ToString()) & "¤"
        Dim CCEmail As String = dr("Email").ToString()

        WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, CCEmail, Subject, EmailTemplateFile, "", ReplacingWords)

        Return "1"
    End Function


    <WebMethod(True)>
    Public Function AddToUserCart(ByVal WebsiteID As Integer, ByVal UserID As Integer, ProductIDsList As String) As String
        Dim dr As DataRow
        Dim tbl As New DataTable
        Dim res As String = "1"

        If Session("UserCart") Is Nothing Then
            tbl.Columns.Add("ProductID")
            tbl.Columns.Add("ProductPrice")
            tbl.Columns.Add("ProductQuantity")
            tbl.Columns.Add("ProductUnit")
            tbl.Columns.Add("ProductTitle")
            tbl.Columns.Add("ProductCurrency")
            tbl.Columns.Add("ProductImage")
            tbl.Columns.Add("ProductSubTotal")
        Else
            tbl = CType(Session("UserCart"), DataTable)
        End If

        dr = tbl.NewRow
        Dim ProductDetailsRow() = ProductIDsList.Split("|") 'ProductID|ProductPrice|ProductQuantity|ProductUnit|ProductTitle|Currency|Image

        If (ProductDetailsRow.Length >= 4) Then
            If tbl.Select("ProductID=" & ProductDetailsRow(0)).Length > 0 Then
                UpdateUserCart(WebsiteID, UserID, ProductIDsList)
            Else
                dr("ProductID") = ProductDetailsRow(0)
                dr("ProductPrice") = ProductDetailsRow(1)
                dr("ProductQuantity") = ProductDetailsRow(2)
                dr("ProductUnit") = ProductDetailsRow(3)
                dr("ProductTitle") = ProductDetailsRow(4)
                dr("ProductCurrency") = ProductDetailsRow(5)
                dr("ProductImage") = ProductDetailsRow(6)
                dr("ProductSubTotal") = 0
                tbl.Rows.Add(dr)
                Session("UserCart") = tbl
            End If
        End If

        Return tbl.Rows.Count
    End Function

    <WebMethod(True)>
    Public Function RemoveProductFromUserCart(ByVal WebsiteID As Integer, ByVal UserID As Integer, ProductID As String) As String
        Dim tbl As New DataTable
        Dim res As String = ""

        If Not Session("UserCart") Is Nothing Then
            tbl = CType(Session("UserCart"), DataTable)
        End If

        If (tbl.Rows.Count > 0) Then
            'Dim ProductDetailsRow() = ProductIDsList.Split("|") 'ProductID|ProductPrice|ProductQuantity|ProductUnit|ProductTitle

            If (tbl.Select("ProductID=" & ProductID).Length > 0) Then
                For i As Integer = tbl.Rows.Count - 1 To 0 Step -1
                    If IsDBNull(tbl.Rows(i)("ProductID")) = False AndAlso tbl.Rows(i)("ProductID") = ProductID Then
                        tbl.Rows.RemoveAt(i)
                    End If
                Next
                'If tbl.Select("ProductID<>" & ProductID).Length > 0 Then
                '    tbl = tbl.Select("ProductID<>" & ProductID).CopyToDataTable()
                'End If
            End If
            Session("UserCart") = tbl
            res = "1"
        Else
            res = "0"
        End If
        Return res
    End Function

    <WebMethod(True)>
    Public Function UpdateUserCart(ByVal WebsiteID As Integer, ByVal UserID As Integer, ProductIDsList As String) As String
        Dim tbl As New DataTable
        Dim res As String = "1"

        If Not Session("UserCart") Is Nothing Then
            tbl = CType(Session("UserCart"), DataTable)
        End If

        Dim ProductDetailsRow() = ProductIDsList.Split("|") 'ProductID|ProductPrice|ProductQuantity|ProductUnit|ProductTitle

        If (ProductDetailsRow.Length >= 4) Then
            For i As Integer = 0 To tbl.Rows.Count - 1
                If (IsDBNull(tbl.Rows(i)("ProductID")) = False AndAlso tbl.Rows(i)("ProductID") = ProductDetailsRow(0)) Then
                    tbl.Rows(i)("ProductPrice") = ProductDetailsRow(1)
                    tbl.Rows(i)("ProductQuantity") = ProductDetailsRow(2)
                    tbl.Rows(i)("ProductUnit") = ProductDetailsRow(3)
                    tbl.Rows(i)("ProductTitle") = ProductDetailsRow(4)
                    tbl.Rows(i)("ProductCurrency") = ProductDetailsRow(5)
                    tbl.Rows(i)("ProductImage") = ProductDetailsRow(6)
                    tbl.Rows(i)("ProductSubTotal") = 0
                End If
            Next
            Session("UserCart") = tbl
        End If

        Return res
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetUserCart(ByVal WebsiteID As Integer, ByVal UserID As Integer, ProductID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet


        If Session("UserCart") Is Nothing Then
            tbl.Columns.Add("ProductID")
            tbl.Columns.Add("ProductPrice")
            tbl.Columns.Add("ProductQuantity")
            tbl.Columns.Add("ProductUnit")
            tbl.Columns.Add("ProductTitle")
            tbl.Columns.Add("ProductCurrency")
            tbl.Columns.Add("ProductImage")
            tbl.Columns.Add("ProductSubTotal")
            Session("UserCart") = tbl
        Else
            tbl = CType(Session("UserCart"), DataTable)
            If ProductID > 0 AndAlso tbl.Select("ProductID=" & ProductID).Length > 0 Then
                tbl = tbl.Select("ProductID=" & ProductID).CopyToDataTable()
            End If
            For i As Integer = tbl.Rows.Count - 1 To 0 Step -1
                If IsDBNull(tbl.Rows(i)("ProductID")) = True Then
                    tbl.Rows.RemoveAt(i)
                Else
                    If IsDBNull(tbl.Rows(i)("ProductPrice")) = False AndAlso IsDBNull(tbl.Rows(i)("ProductQuantity")) = False Then
                        tbl.Rows(i)("ProductSubTotal") = CSng(tbl.Rows(i)("ProductPrice")) * CSng(tbl.Rows(i)("ProductQuantity"))
                    End If
                End If
            Next
        End If

        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "UserCart"
        Return ds.GetXml
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function GetUserCartProductsIDs(ByVal WebsiteID As Integer, ByVal UserID As Integer) As String
        Dim dr As DataRow
        Dim tbl As New DataTable

        If Session("UserCart") Is Nothing Then
            tbl.Columns.Add("ProductID")
            tbl.Columns.Add("ProductPrice")
            tbl.Columns.Add("ProductQuantity")
            tbl.Columns.Add("ProductUnit")
            tbl.Columns.Add("ProductTitle")
            tbl.Columns.Add("ProductCurrency")
            tbl.Columns.Add("ProductImage")
            tbl.Columns.Add("ProductSubTotal")
            Session("UserCart") = tbl
        Else
            tbl = CType(Session("UserCart"), DataTable)
        End If

        Dim ProductIDs As String = ""
        For i As Integer = 0 To tbl.Rows.Count - 1
            ProductIDs = ProductIDs & tbl.Rows(i)("ProductID") & ","
        Next

        Return ProductIDs
    End Function

    <WebMethod(True)>
    Public Function PlaceUserCartOrder(ByVal WebsiteID As Integer, ByVal UserID As Integer, ByVal UserName As String,
                               ByVal UserEmail As String, ByVal UserMobileNo As String, ByVal UserLandlineNo As String,
                               UserCity As String, UserAddress As String, OrderMessage As String) As String
        Dim tbl As New DataTable
        Dim res As String = "1"

        If Not Session("UserCart") Is Nothing Then
            tbl = CType(Session("UserCart"), DataTable)
        End If

        Dim ProductIDsList As String = ""  'ProductID|ProductPrice|ProductQuantity|ProductUnit|ProductTitle


        For i As Integer = 0 To tbl.Rows.Count - 1
            If (IsDBNull(tbl.Rows(i)("ProductID")) = False) Then
                ProductIDsList = ProductIDsList & tbl.Rows(i)("ProductID") & "|"
                ProductIDsList = ProductIDsList & tbl.Rows(i)("ProductPrice") & "|"
                ProductIDsList = ProductIDsList & tbl.Rows(i)("ProductQuantity") & "|"
                ProductIDsList = ProductIDsList & "'" & tbl.Rows(i)("ProductUnit") & "'|"
                ProductIDsList = ProductIDsList & "'" & tbl.Rows(i)("ProductTitle") & "',"
            End If
        Next
        PlaceAnOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage, ProductIDsList)
        Session("UserCart") = Nothing

        Return res
    End Function
End Class