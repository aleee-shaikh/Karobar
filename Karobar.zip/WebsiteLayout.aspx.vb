﻿Public Class WebsiteLayout
    Inherits WebPage

    Public WebsiteID As Integer = CMS.Website.GetWebsiteID(HttpContext.Current.Request.Url.AbsoluteUri)
    Public WebsiteDetails As String

    Private Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim ds As New DataSet
        'If Session(WebsiteID.ToString()) Is Nothing Then
        '    ds = Website.GetWebsiteDetails(WebsiteID)
        '    Session(WebsiteID.ToString()) = ds
        '    ds.Tables(0).Columns.Remove("DBConnectionString")
        'Else
        '    ds = CType(Session(WebsiteID.ToString()), DataSet)
        'End If
        If HttpContext.Current.Session("Visited") Is Nothing Then
            Log.WriteLog(-1, -1, "User Visited", "User Visited", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Session("Visited") = Now
        End If
        ds = Website.GetWebsiteDetails(WebsiteID)
        ds.Tables(0).Columns.Remove("DBConnectionString")
        If ds.Tables.Count > 0 Then

            WebsiteDetails = General.GetDataTableJson(ds.Tables(0))
        End If

    End Sub

End Class