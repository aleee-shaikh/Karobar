﻿Public Class Student
    Inherits System.Web.UI.Page
    Dim _EmployeeID As Integer

    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(value As Integer)
            _EmployeeID = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Person.DoesPersonHavePageRights(Session("UserID"), 48) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then

            If Not Request("Add") Is Nothing Then
                If Request("Add") = "1" Then
                    Page.RegisterStartupScript("StaffAddedSuccessFully", "<script>parent.ShowMessage('Staff added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                End If
            End If
        End If
        If Not Request("SID") Is Nothing Then
            HdnStaffID.Value = Val(Request("SID"))
        End If
        If Val(HdnStaffID.Value) <= 0 Then
            LblScreenTitle.Text = "Add New Student Record"
        Else
            LblScreenTitle.Text = "Update Student Record"
            EmployeeID = Val(HdnStaffID.Value)
        End If
        EducationHistory1.EmployeeID = EmployeeID
        StuClassFeeDetail1.EmployeeID = EmployeeID
        JobHistory1.EmployeeID = EmployeeID
        UploadDocHistory1.EmployeeID = EmployeeID
        NotesBook.EmployeeID = EmployeeID
        UploadDocHistory1.UploadDocumentPath = "/CMS/" & Session("CurrentBusinessID") & "/Staff/"
        pnlHeaderLnks.Visible = (EmployeeID > 0)

    End Sub


    'Private Sub LnkEmployementDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkEmployementHistory.Click




    '    StudentPersonalInfo1.Visible = False
    '    EducationHistory1.Visible = False
    '    StuClassFeeDetail1.Visible = False
    '    UploadDocHistory1.Visible = False
    '    JobHistory1.Visible = True
    '    pnlNoteBook.Visible = False
    'End Sub

    Private Sub LnkStaffPersonalDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkStaffPersonalDetails.Click

        StudentPersonalInfo1.Visible = True
        EducationHistory1.Visible = False
        StuClassFeeDetail1.Visible = False
        UploadDocHistory1.Visible = False
        JobHistory1.Visible = False
        pnlNoteBook.Visible = False
    End Sub

    Private Sub LnkEducationHistory_Click(sender As Object, e As EventArgs) Handles LnkEducationHistory.Click


        StudentPersonalInfo1.Visible = False
        EducationHistory1.Visible = True
        StuClassFeeDetail1.Visible = False
        UploadDocHistory1.Visible = False
        JobHistory1.Visible = False
        pnlNoteBook.Visible = False
    End Sub

    Private Sub LnkEmployeeDocuments_Click(sender As Object, e As EventArgs) Handles LnkEmployeeDocuments.Click


        StudentPersonalInfo1.Visible = False
        EducationHistory1.Visible = False
        StuClassFeeDetail1.Visible = False
        UploadDocHistory1.Visible = True
        JobHistory1.Visible = False
        pnlNoteBook.Visible = False
    End Sub

    Private Sub LnkJobDetails_Click(sender As Object, e As EventArgs) Handles LnkJobDetails.Click


        StudentPersonalInfo1.Visible = False
        EducationHistory1.Visible = False
        StuClassFeeDetail1.Visible = True
        UploadDocHistory1.Visible = False
        JobHistory1.Visible = False
        pnlNoteBook.Visible = False
        StuClassFeeDetail1.LoadData()

    End Sub

    Private Sub LnkNotes_Click(sender As Object, e As EventArgs) Handles LnkNotes.Click
        StudentPersonalInfo1.Visible = False
        EducationHistory1.Visible = False
        StuClassFeeDetail1.Visible = False
        UploadDocHistory1.Visible = False
        JobHistory1.Visible = False
        pnlNoteBook.Visible = True
    End Sub
End Class