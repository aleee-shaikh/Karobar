function Products_GetProductDetails(BID, PID) {
    var Data = [];
    

    var RequestData = {
        BID: BID,
        PID: PID
    };
    var ProductData = [];
    var ProductImages = [];

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/Products_GetProductDetails',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            //alert(JSON.stringify(xml))
            var Count = $(xml).find("ProductDetail").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ProductDetail").each(function () {
                    var ArticleTitle = $(this).find("ArticleTitle").text()

                    Data.push({
                        BusinessID: $(this).find("WebsiteID").text(),
                        ProductID: $(this).find("ArticleID").text(),
                        ProductTitle: $(this).find("ArticleTitle").text(),
                        ProductTitle4URL: ArticleTitle.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),//.replace(/[\s]/g, ""),
                        ProductDescription: $(this).find("ArticleText").text().toLowerCase().replace(new RegExp("</xmp>", 'g'), "").replace(new RegExp("<xmp>", 'g'), ""),
                        ProductImage: $(this).find("ArticleImage").text(),
                        Model: $(this).find("Model").text(),
                        Manufacturer: $(this).find("Manufacturer").text(),
                        Price: $(this).find("SalePrice").text(),
                        Catagory: $(this).find("Catagory").text(),
                        SubCatagory: $(this).find("SubCatagory").text(),
                        Unit: $(this).find("UnitAsText").text(),
                        Color: $(this).find("Color").text(),
                        Weight: $(this).find("Weight").text(),
                        Featured: $(this).find("Featured").text(),
                        PostedOn: $(this).find("PostedOnFormattedDate").text(),
                        Currency: $(this).find("CurrencyCode").text(),
                        WebsiteCategoryID: $(this).find("WebsiteCategoryID").text(),
                        ThemeID: $(this).find("ThemeID").text()
                    });
                });

                $(xml).find("ProductImages").each(function () {
                  if($(this).find("ImageVideoURL").text()!='')
                    ProductImages.push({
                        ProductID: $(this).find("ArticleID").text(),
                        ImageVideoURL: $(this).find("ImageVideoURL").text(),
                        ProductTitle: $(this).find("ArticleTitle").text(),
                        ProductImageDesc: $(this).find("Description").text()

                    })
                });

            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    //alert(JSON.stringify(ProductImages))
    ProductData.push({
        Details: Data,
        Images: ProductImages
    });

    return ProductData
}

function Products_GetProducts(CtrlID, BID, Catagory, SubCatagory, SearchText, PageNo, PageSize) {
    var Data = [];
    //var PageNo = 0;
    //var PageSize = 10;
    //PageNo = $("#" + CtrlID + "_PageNo").val();
    //PageSize = $("#" + CtrlID + "_PageSize").val();

    var RequestData = {
        BID: BID,
        Catagory: Catagory,
        SubCatagory: SubCatagory,
        SearchText: SearchText,
        PageNo: PageNo,
        PageSize: PageSize
    };
    
    
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/Products_GetProducts',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            //alert(JSON.stringify(xml))
            var Count = $(xml).find("ProductsList").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ProductsList").each(function () {
                    var ArticleTitle = $(this).find("ArticleTitle").text()
                    Data.push({
                        PagesCount: $(this).find("PagesCount").text(),
                        BusinessID: $(this).find("WebsiteID").text(),
                        ProductID: $(this).find("ArticleID").text(),
                        ProductTitle: $(this).find("ArticleTitle").text(),
                        ProductTitle4URL: ArticleTitle.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),//.replace(/[^a-zA-Z\s]/g,"").replace(/[\s]/g,""),
                        ProductDescription: $(this).find("ArticleText").text(),
                        ProductImage: $(this).find("ArticleImage").text(),
                        Model: $(this).find("Model").text(),
                        Manufacturer: $(this).find("Manufacturer").text(),
                        Price: $(this).find("SalePrice").text(),
                        Catagory: $(this).find("Catagory").text(),
                        SubCatagory: $(this).find("SubCatagory").text(),
                        Unit: $(this).find("UnitAsText").text(),
                        Color: $(this).find("Color").text(),
                        Weight: $(this).find("Weight").text(),
                        Featured: $(this).find("Featured").text(),
                        PostedOn: $(this).find("PostedOnFormattedDate").text(),
                        Currency: $(this).find("CurrencyCode").text(),
                        WebsiteCategoryID: $(this).find("WebsiteCategoryID").text(),
                        ThemeID: $(this).find("ThemeID").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });


    return Data
}

function Products_GetNewProducts4Web(CtrlID, BID, Catagory, SubCatagory, SearchText, PageNo, PageSize, ContainerID, Template) {
    var Data = [];
    //var PageNo = 0;
    //var PageSize = 10;
    //PageNo = $("#" + CtrlID + "_PageNo").val();
    //PageSize = $("#" + CtrlID + "_PageSize").val();

    var RequestData = {
        BID: BID,
        Catagory: Catagory,
        SubCatagory: SubCatagory,
        SearchText: SearchText,
        PageNo: PageNo,
        PageSize: PageSize
    };


    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/Products_GetProducts',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            //alert(JSON.stringify(xml))
            var Count = $(xml).find("ProductsList").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ProductsList").each(function () {
                    var ArticleTitle = $(this).find("ArticleTitle").text()
                    Data.push({
                        PagesCount: $(this).find("PagesCount").text(),
                        BusinessID: $(this).find("WebsiteID").text(),
                        ProductID: $(this).find("ArticleID").text(),
                        ProductTitle: $(this).find("ArticleTitle").text(),
                        ProductTitle4URL: ArticleTitle.replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),//.replace(/[^a-zA-Z\s]/g,"").replace(/[\s]/g,""),
                        ProductDescription: $(this).find("ArticleText").text(),
                        ProductImage: $(this).find("ArticleImage").text(),
                        Model: $(this).find("Model").text(),
                        Manufacturer: $(this).find("Manufacturer").text(),
                        Price: $(this).find("SalePrice").text(),
                        Catagory: $(this).find("Catagory").text(),
                        SubCatagory: $(this).find("SubCatagory").text(),
                        Unit: $(this).find("UnitAsText").text(),
                        Color: $(this).find("Color").text(),
                        Weight: $(this).find("Weight").text(),
                        Featured: $(this).find("Featured").text(),
                        PostedOn: $(this).find("PostedOnFormattedDate").text(),
                        Currency: $(this).find("CurrencyCode").text(),
                        WebsiteCategoryID: $(this).find("WebsiteCategoryID").text(),
                        ThemeID: $(this).find("ThemeID").text()
                    });
                });

                if (Data.length > 0) {
                    //alert(JSON.stringify(Data))
                    my.utils.renderExternalTemplate(Template, ContainerID, { Data: Data });

                    setTimeout(function () {
                        jQuery('.home-owl-carousel').each(function () {

                            var owl = $(this);
                            var itemPerLine = owl.data('item');
                            if (!itemPerLine) {
                                itemPerLine = 4;
                            }
                            owl.owlCarousel({
                                items: itemPerLine,
                                itemsTablet: [768, 2],
                                navigation: true,
                                pagination: false,

                                navigationText: ["", ""]
                            });
                        });
                    }, 2000)
                }
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });


    return Data
}

function UpdatePrice4SaleAction(TotalAmount, Action) {
    if ($('#' + TotalAmount).val() == '')
        $('#' + TotalAmount).val('0')

    if (Action == 0)
        $('#' + TotalAmount).val(Math.abs($('#' + TotalAmount).val()) * -1)
    else
        $('#' + TotalAmount).val(Math.abs($('#' + TotalAmount).val()))

    var grossTotal = 0;
    $(".rowTotal").each(function () {
        grossTotal += parseInt(parseInt($(this).val()))
    });

    $('.grdTotal').html(grossTotal)
}

function UpdatePrice(Price, Qty, Discount, Total) {
    var _price
    var _qty
    var _discount

    if ($('#' + Price).val() == '')
        $('#' + Price).val('0')

    if ($('#' + Qty).val() == '')
        $('#' + Qty).val('')

    if ($('#' + Discount).val() == '')
        $('#' + Discount).val('0')
    else if ($('#' + Discount).val().substr(0, 1) == '0' && $('#' + Discount).val().length > 1) {
        $('#' + Discount).val($('#' + Discount).val().substr(1, $('#' + Discount).val().length))
    }

    _price = $('#' + Price).val()
    _qty = parseInt($('#' + Qty).val())
    _discount = $('#' + Discount).val()

    $('#' + Total).val((_price * _qty) - _discount)
    $('#' + Total).val($('#' + Total).val().replace('NaN', ''))


    var grossTotal = 0;
    $(".rowTotal").each(function () {
        grossTotal += parseInt(parseInt($(this).val()))
    });
    
    $('.grdTotal').html(grossTotal)
}

function UpdateCashVoucherPrice(Amount, Tax, Total) {
    var _amount
    var _tax

    if ($('#' + Amount).val() == '')
        $('#' + Amount).val('0')
    else if ($('#' + Amount).val().substr(0, 1) == '0' && $('#' + Amount).val().length > 1) {
        $('#' + Amount).val($('#' + Amount).val().substr(1, $('#' + Amount).val().length))
    }

    if ($('#' + Tax).val() == '')
        $('#' + Tax).val('0')
    else if ($('#' + Tax).val().substr(0, 1) == '0' && $('#' + Tax).val().length > 1) {
        $('#' + Tax).val($('#' + Tax).val().substr(1, $('#' + Tax).val().length))
    }




    _amount = parseFloat($('#' + Amount).val())
    _tax = parseFloat($('#' + Tax).val())
    //alert(_amount +'\n'+_tax+'\n'+_bankcharges)
    $('#' + Total).val(_amount + _tax)
    //$('#' + Total).val($('#' + Total).val().replace('NaN', ''))

    var grossTotal = 0;
    $(".rowTotal").each(function () {
        grossTotal += parseInt(parseInt($(this).val()))
    });

    $('.grdTotal').html(grossTotal)
}

function UpdateBankVoucherPrice(Amount, Tax, BankCharges, Total) {
    var _amount
    var _tax
    var _bankcharges

    if ($('#' + Amount).val() == '')
        $('#' + Amount).val('0')
    else if ($('#' + Amount).val().substr(0, 1) == '0' && $('#' + Amount).val().length > 1) {
        $('#' + Amount).val($('#' + Amount).val().substr(1, $('#' + Amount).val().length))
    }

    if ($('#' + Tax).val() == '')
        $('#' + Tax).val('0')
    else if ($('#' + Tax).val().substr(0, 1) == '0' && $('#' + Tax).val().length > 1) {
        $('#' + Tax).val($('#' + Tax).val().substr(1, $('#' + Tax).val().length))
    }

    if ($('#' + BankCharges).val() == '')
        $('#' + BankCharges).val('0')
    else if ($('#' + BankCharges).val().substr(0, 1) == '0' && $('#' + BankCharges).val().length > 1) {
        $('#' + BankCharges).val($('#' + BankCharges).val().substr(1, $('#' + BankCharges).val().length))
    }



    _amount = parseFloat($('#' + Amount).val())
    _tax = parseFloat($('#' + Tax).val())
    _bankcharges = parseFloat($('#' + BankCharges).val())
    //alert(_amount +'\n'+_tax+'\n'+_bankcharges)
    $('#' + Total).val(_amount + _tax + _bankcharges)
    //$('#' + Total).val($('#' + Total).val().replace('NaN', ''))


    var grossTotal = 0;
    $(".rowTotal").each(function () {
        grossTotal += parseInt(parseInt($(this).val()))
    });

    $('.grdTotal').html(grossTotal)
}

function PlaceAnOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage, ProductIDsList) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: WebsiteID,
        UserID: UserID,
        UserName: UserName,
        UserEmail: UserEmail,
        UserMobileNo: UserMobileNo,
        UserLandlineNo: UserLandlineNo,
        UserCity: UserCity,
        UserAddress: UserAddress,
        OrderMessage: OrderMessage,
        ProductIDsList: ProductIDsList
    };
    
    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/PlaceAnOrder',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res=1;
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res= 0;
        }
    });

    return res;
}

function PlaceOrder() {
    var BID = parseInt(eval(_j24business)[0].WebsiteID);
    if ($('#txtUserName').val().trim().length == 0) {
        alert("Username is required")
        return;
    }
    if ($('#txtUserEmail').val().trim().length == 0) {
        alert("Email is required")
        return;
    }
    else if (verifyEmail($('#txtUserEmail').val())==false) {
        alert("Invalid email address")
        return;
    }

    if ($('#txtUserMobileNo').val().trim().length == 0) {
        alert("Mobile No is required")
        return;
    }
    if ($('#txtUserAddress').val().trim().length == 0) {
        alert("Address is required")
        return;
    }
    if ($('#txtOrderMessage').val().trim().length == 0) {
        alert("Message is required")
        return;
    }

    //  alert(BID + '\n' + -1 + '\n' + $('#txtUserName').val() + '\n' + $('#txtUserEmail').val() + '\n' + $('#txtUserMobileNo').val() + '\n' + $('#UserLandlineNo').val() + '\n' + $('#txtUserCity').val() + '\n' + $('#txtUserAddress').val() + '\n' + $('#txtOrderMessage').val() + '\n' + $('#txtProductID').val())
    if (PlaceAnOrder(BID, -1, $('#txtUserName').val(), $('#txtUserEmail').val(), $('#txtUserMobileNo').val(), $('#txtUserLandlineNo').val(), $('#txtUserCity').val(), $('#txtUserAddress').val(), $('#txtOrderMessage').val(), $('#txtProductID').val()) == 1) {
        alert("Thanks for ordering! \nYour order has been placed, someone in staff will contact you shortly");
        HideDlg('OrderNowDlg');
    }
}

function PlaceAnUserCartOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: WebsiteID,
        UserID: UserID,
        UserName: UserName,
        UserEmail: UserEmail,
        UserMobileNo: UserMobileNo,
        UserLandlineNo: UserLandlineNo,
        UserCity: UserCity,
        UserAddress: UserAddress,
        OrderMessage: OrderMessage
    };

    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/PlaceUserCartOrder',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res = 1;
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res = 0;
        }
    });

    return res;
}


function PlaceUserCartOrder() {
    var BID = parseInt(eval(_j24business)[0].WebsiteID);
    if ($('#txtUserName').val().trim().length == 0) {
        parent.ShowMessage("Username is required", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }
    if ($('#txtUserEmail').val().trim().length == 0) {
        parent.ShowMessage("Email is required", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }
    else if (verifyEmail($('#txtUserEmail').val()) == false) {
        parent.ShowMessage("Invalid email address", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }

    if ($('#txtUserMobileNo').val().trim().length == 0) {
        parent.ShowMessage("Mobile No is required", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }
    if ($('#txtUserAddress').val().trim().length == 0) {
        parent.ShowMessage("Address is required", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }
    if ($('#txtOrderMessage').val().trim().length == 0) {
        parent.ShowMessage("Message is required", '1', $(window).height() * 2 / 100, $(window).width() * 30 / 100)
        return;
    }

    //  alert(BID + '\n' + -1 + '\n' + $('#txtUserName').val() + '\n' + $('#txtUserEmail').val() + '\n' + $('#txtUserMobileNo').val() + '\n' + $('#UserLandlineNo').val() + '\n' + $('#txtUserCity').val() + '\n' + $('#txtUserAddress').val() + '\n' + $('#txtOrderMessage').val() + '\n' + $('#txtProductID').val())
    if (PlaceAnUserCartOrder(BID, -1, $('#txtUserName').val(), $('#txtUserEmail').val(), $('#txtUserMobileNo').val(), $('#txtUserLandlineNo').val(), $('#txtUserCity').val(), $('#txtUserAddress').val(), $('#txtOrderMessage').val()) == 1) {
        //GetUserCartProducts(-1, -1, -1, ".userCartContainer", "/CMS/Shared/Templates/Mall_Shopping_CartProductRows")
        alert("Thanks for ordering! \nYour order has been placed, someone in staff will contact you shortly");
        HideDlg('UserOrderDlg');
        window.location="/Home"
    }
}

function AddToUserCart(WebsiteID, UserID, ProductIDsList) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: -1,
        UserID: -1,
        ProductIDsList: ProductIDsList
    };
    //alert(JSON.stringify(ProductIDsList))
    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/AddToUserCart',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res = xml.d;
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res = 0;
        }
    });

    return res;
}

function RemoveProductFromUserCart(WebsiteID, UserID, ProductID) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: -1,
        UserID: -1,
        ProductID: ProductID
    };

    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/RemoveProductFromUserCart',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res = 1;
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res = 0;
        }
    });

    return res;
}

function UpdateUserCart(WebsiteID, UserID, ProductIDsList) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: -1,
        UserID: -1,
        ProductIDsList: ProductIDsList
    };

    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/UpdateUserCart',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res = 1;
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res = 0;
        }
    });

    return res;
}

function GetUserCartProducts(WebsiteID, UserID, ProductID, ContainerID,Template) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: -1,
        UserID: -1,
        ProductID:ProductID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/GetUserCart',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("UserCart").length;
            var CartTotalAmount = 0, CartTotalItems = 0;
            var Currency = '';

            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("UserCart").each(function () {
                    Currency = $(this).find("ProductCurrency").text()
                    Data.push({
                        ProductID: $(this).find("ProductID").text(),
                        ProductPrice: $(this).find("ProductPrice").text(),
                        ProductQuantity: $(this).find("ProductQuantity").text(),
                        ProductUnit: $(this).find("ProductUnit").text(),
                        ProductTitle: $(this).find("ProductTitle").text(),
                        SubTotal: parseFloat($(this).find("ProductPrice").text()) * parseFloat($(this).find("ProductQuantity").text()),
                        Currency: Currency,
                        ProductImage: $(this).find("ProductImage").text()
                    });
                    CartTotalAmount += (parseFloat($(this).find("ProductPrice").text()) * parseFloat($(this).find("ProductQuantity").text()))
                    CartTotalItems += parseFloat($(this).find("ProductQuantity").text())
                });
            }

            if (Data.length > 0) {
                my.utils.renderExternalTemplate(Template, ContainerID, { Data: Data, CartTotalAmount, CartTotalItems, Currency });
                $(".lblCartTotal").html(Currency + ' ' + CartTotalAmount)
                $("#OrderGrandTotal").html(Currency + ' ' + CartTotalAmount)
            }
        },
        error: function (xhr, status, errord) {
            alert("error: "+xhr.responseText);
            res = 0;
        }
    });

    return Data;
}

var CartProductsIDs = "";

function GetUserCartProductsCount(WebsiteID, UserID,Selector) {
    var Data = [];
    var res = 0;
    var RequestData = {
        WebsiteID: -1,
        UserID: -1
    };

    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/WebsiteArticles.asmx/GetUserCartProductsIDs',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            res = xml.d;
            CartProductsIDs = xml.d.split(',');
            $(Selector).html(CartProductsIDs.length - 1)
            
            
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
            res = 0;
        }
    });

    return res;
}

function UpdateCartProductPrice(ProductID, Price, Qty, Unit, ProductTitle, Currency, ProductImage) {
    //ProductID|ProductPrice|ProductQuantity|ProductUnit|ProductTitle|Currency|Image
    var WebsiteID = -1;
    var UserID = -1;
    var ProductIDsList = ProductID + "|" + Price + "|" + Qty + "|" + Unit + "|" + ProductTitle + "|" + Currency + "|" + ProductImage
    //alert(ProductIDsList)
    UpdateUserCart(WebsiteID, UserID, ProductIDsList)

    var qty = $("." + ProductID + "Qty").val()
    if (qty == '' || qty<0) {
        $("." + ProductID + "Qty").val(0)
        qty=0
    }
    var productSubTotal = qty * Price
    $("." + ProductID + "SubTotal").html(productSubTotal)

    var grandTotal = 0;
    $(".SubTotal").each(function (index) {
        if ($(this).html() != "") {
            if (parseFloat($(this).html()) > 0) {
                grandTotal += parseFloat($(this).html());
            }
        }
    });

    $("#OrderGrandTotal").html(Currency + " " + grandTotal)
    $(".lblCartTotal").html(Currency + " " + grandTotal)
    
}