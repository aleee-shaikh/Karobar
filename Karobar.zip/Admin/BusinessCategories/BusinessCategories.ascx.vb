﻿Public Class BusinessCategories
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then

            LoadData()
        End If
    End Sub

    Sub LoadData()
        GrdBusinessCategorys.DataSource = Website.GetWebsitesCategories()
        GrdBusinessCategorys.DataBind()

    End Sub

    Private Sub GrdBusinessCategorys_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdBusinessCategorys.PageIndexChanging
        GrdBusinessCategorys.PageIndex = e.NewPageIndex
        LoadData()
    End Sub


    Protected Sub GrdBusinessCategorys_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GrdBusinessCategorys.RowCancelingEdit
        GrdBusinessCategorys.EditIndex = -1
        LoadData()
    End Sub

    Private Sub GrdBusinessCategorys_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GrdBusinessCategorys.RowEditing
        GrdBusinessCategorys.EditIndex = e.NewEditIndex
        LoadData()
        GrdBusinessCategorys.ShowFooter = False
    End Sub


    Private Sub GrdBusinessCategorys_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdBusinessCategorys.RowCommand
        If e.CommandName = "EditSection" Then

        ElseIf e.CommandName = "Update" Then
            Dim BusinessCategoryID As String = CType(GrdBusinessCategorys.Rows(GrdBusinessCategorys.EditIndex).FindControl("HdnBusinessCategoryID"), TextBox).Text.Trim
            Dim BusinessCategory As String = CType(GrdBusinessCategorys.Rows(GrdBusinessCategorys.EditIndex).FindControl("txteditBusinessCategory"), TextBox).Text.Trim
            Website.UpdateWebsiteCategory(BusinessCategoryID, BusinessCategory.Trim(), 1, 1)
            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=BusinessCategories")
        ElseIf e.CommandName = "DeleteBusinessCategory" Then
            Website.DeleteWebsiteCategory(e.CommandArgument)
            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=BusinessCategories")
        End If
    End Sub


    Private Sub GrdBusinessCategorys_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdBusinessCategorys.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='whitesmoke';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub BtnAddNewBusinessCategory_Click(sender As Object, e As EventArgs) Handles BtnAddNewBusinessCategory.Click
        PnlAddNewContainer.Visible = True
        PnlBusinessCategorysContainer.Visible = False


    End Sub

    Private Sub BtnSaveNewBusinessCategory_Click(sender As Object, e As EventArgs) Handles BtnSaveNewBusinessCategory.Click
        PnlAddNewContainer.Visible = False
        PnlBusinessCategorysContainer.Visible = True
        Website.AddWebsiteCategory(txtBusinessCategoryName.Text.Trim, 1, 1)

    End Sub
End Class