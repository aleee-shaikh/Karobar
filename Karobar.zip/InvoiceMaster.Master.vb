﻿Public Class InvoiceMaster
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim Ptbl As New DataTable
        'Ptbl = Website.Page.GetPageDetail(Val(Request("P")))
        If (Session("UserID") Is Nothing OrElse Val(Session("UserID")) <= 0) Then ''AndAlso Ptbl.Rows.Count > 0 AndAlso Ptbl.Rows(0)("RequireLoginAuthentication") = True Then
            Response.Redirect("~/EzBusiness.aspx")
        End If
    End Sub

End Class