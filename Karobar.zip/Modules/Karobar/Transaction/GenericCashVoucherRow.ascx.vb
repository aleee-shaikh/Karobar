﻿Public Class GenericCashVoucherRow
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable
    Dim _TotalAmount As Single

    Public Sub AddColumn(ByVal ColumnName As String, Optional ByVal Control As Object = Nothing)

        If Not _tbl.Columns.Contains(ColumnName) Then
            _tbl.Columns.Add(ColumnName)
        End If

        Session(Me.ClientID & "CashVoucher") = _tbl
    End Sub

    Public Function GetTransactionData() As DataTable
        Return _tbl
    End Function

    Public ReadOnly Property TotalAmount
        Get
            Return _TotalAmount
        End Get
    End Property


    Sub BindGrid(Optional ByVal Control As Object = Nothing)
        Dim dr As DataRow
        If _tbl.Rows.Count = 0 Then
            dr = _tbl.NewRow
            _tbl.Rows.Add(dr)
        End If
        GridView1.DataSource = _tbl
        GridView1.DataBind()
        ''AddGridControl()
    End Sub

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Session(Me.ClientID & "CashVoucher") Is Nothing Then
            _tbl = CType(Session(Me.ClientID & "CashVoucher"), DataTable)
            BindGrid()
            GridView1.Columns(2).HeaderText = ReferenceData.Setting("LblCashPaymentVoucherToAccount", "To Account", Session("CurrentBusinessID"))
            GridView1.Columns(3).HeaderText = ReferenceData.Setting("LblCashPaymentVoucherParticular", "Particular", Session("CurrentBusinessID"))
            GridView1.Columns(4).HeaderText = ReferenceData.Setting("LblCashPaymentVoucherTax", "Tax", Session("CurrentBusinessID"))
            GridView1.Columns(5).HeaderText = ReferenceData.Setting("LblCashPaymentVoucherAmount", "Amount", Session("CurrentBusinessID"))
            GridView1.Columns(6).HeaderText = ReferenceData.Setting("LblCashPaymentVoucherTotal", "Total", Session("CurrentBusinessID"))


        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack Then
            For i As Integer = 0 To GridView1.Rows.Count - 1
                Dim ddl As New DropDownList
                ddl = CType(GridView1.Rows(i).FindControl("DDLToAccount"), DropDownList)
                _tbl.Rows(i)("ToAccountHead") = ddl.SelectedItem.Value

                Dim txtParticular As New TextBox
                txtParticular = CType(GridView1.Rows(i).FindControl("txtParticular"), TextBox)
                _tbl.Rows(i)("Particular") = txtParticular.Text

                
                Dim txtTax As New TextBox
                txtTax = CType(GridView1.Rows(i).FindControl("txtTax"), TextBox)
                _tbl.Rows(i)("Tax") = txtTax.Text

                Dim txtTotal As New TextBox
                txtTotal = CType(GridView1.Rows(i).FindControl("txtTotal"), TextBox)
                _tbl.Rows(i)("Total") = txtTotal.Text

                Dim txtAmount As New TextBox
                txtAmount = CType(GridView1.Rows(i).FindControl("txtAmount"), TextBox)
                _tbl.Rows(i)("Amount") = txtAmount.Text

            Next
        Else
            For i As Integer = _tbl.Rows.Count - 1 To 0 Step -1
                _tbl.Rows.RemoveAt(i)
            Next
            Session(Me.ClientID & "CashVoucher") = _tbl
            BindGrid()
        End If
    End Sub

    Private Function ValidateGridRows() As Boolean
        Dim res As Boolean = True
        For i As Integer = 0 To GridView1.Rows.Count - 1

            Dim txtParticular As TextBox = CType(GridView1.Rows(i).FindControl("txtParticular"), TextBox)
            If (txtParticular.Text.Trim().Length <= 0) Then
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "ValidationError", "parent.ShowMessage('Particular is required','1',$(window).height()*2/100,$(window).width()*25/100);", True)
                Return False
            End If
            Dim txtTotal As TextBox = CType(GridView1.Rows(i).FindControl("txtTotal"), TextBox)
            If (Val(txtTotal.Text) <= 0) Then
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "ValidationError", "parent.ShowMessage('Total amount can not be less than 0','1',$(window).height()*2/100,$(window).width()*25/100);", True)
                Return False
            End If
        Next
        Return res
    End Function

    Private Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "AddRow" Then
            If ValidateGridRows() Then
                Dim dr As DataRow
                dr = _tbl.NewRow
                _tbl.Rows.Add(dr)
                ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "success", "$('#" & DataRowsCount.ClientID & "').val(parseInt($('#" & DataRowsCount.ClientID & "').val()) + 1)", True)
            End If
        ElseIf e.CommandName = "DeleteRow" Then
            _tbl.Rows.RemoveAt(Val(e.CommandArgument) - 1)
            ScriptManager.RegisterClientScriptBlock(Me.Page, Me.GetType(), "success", "$('#" & DataRowsCount.ClientID & "').val(parseInt($('#" & DataRowsCount.ClientID & "').val()) - 1)", True)
        End If
        Session(Me.ClientID & "CashVoucher") = _tbl
        BindGrid()
    End Sub



    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim Btn As New Button
            If e.Row.RowIndex = _tbl.Rows.Count - 1 Then
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "+"
                Btn.CommandName = "AddRow"
            Else
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "-"
                Btn.CommandName = "DeleteRow"
            End If

            Dim ddl As New DropDownList
            ddl = CType(e.Row.FindControl("DDLToAccount"), DropDownList)
            Dim tbl As New DataTable
            tbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("AccountHeadID4CashVoucher", "31,32", Session("CurrentBusinessID")))
            If LoggedInUserSession.BusinessCategoryID = 17 Then
                Dim tbl2 As New DataTable
                tbl2 = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("Projects/Tasks", "0", Session("CurrentBusinessID")))
                If tbl2.Rows.Count > 0 Then
                    tbl.Merge(tbl2)
                End If
            End If
            ddl.DataSource = tbl
            ddl.DataTextField = "AccountHeadName"
            ddl.DataValueField = "AccountHeadID"
            ddl.DataBind()
            ddl.Items.Insert(0, New ListItem("Expenses", ReferenceData.Setting("ExpenseHeadID", "", Session("CurrentBusinessID"))))
            ddl.SelectedValue = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("ToAccountHead")), "", _tbl.Rows(e.Row.RowIndex)("ToAccountHead"))
            ''ddl.AutoPostBack = True
            ddl.Attributes.Add("RowIdx", e.Row.RowIndex)
            ''AddHandler ddl.SelectedIndexChanged, AddressOf ProductDDL_SelectedIndexChanged

            Dim txtParticular As New TextBox
            txtParticular = CType(e.Row.FindControl("txtParticular"), TextBox)
            If Not txtParticular Is Nothing Then
                txtParticular.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Particular")), "", _tbl.Rows(e.Row.RowIndex)("Particular"))
            End If

            Dim txtTotal As New TextBox
            txtTotal = CType(e.Row.FindControl("txtTotal"), TextBox)
            If Not txtTotal Is Nothing Then
                txtTotal.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Total")), "", _tbl.Rows(e.Row.RowIndex)("Total"))
                txtTotal.CssClass = "form-control numeric rowTotal"
            End If


            Dim txtAmount As New TextBox
            txtAmount = CType(e.Row.FindControl("txtAmount"), TextBox)
            If Not txtAmount Is Nothing Then
                txtAmount.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Amount")), "", _tbl.Rows(e.Row.RowIndex)("Amount"))
                txtAmount.CssClass = "form-control numeric"
            End If

            Dim txtTax As New TextBox
            txtTax = CType(e.Row.FindControl("txtTax"), TextBox)
            If Not txtTax Is Nothing Then
                txtTax.CssClass = "form-control numeric"
                txtTax.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Tax")), "", _tbl.Rows(e.Row.RowIndex)("Tax"))
                txtTax.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdateCashVoucherPrice('" & txtAmount.ClientID & "','" & txtTax.ClientID & "','" & txtTotal.ClientID & "')")
                txtAmount.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdateCashVoucherPrice('" & txtAmount.ClientID & "','" & txtTax.ClientID & "','" & txtTotal.ClientID & "')")
            End If

            




        End If

        If (e.Row.RowType = DataControlRowType.Footer) Then
            Dim TotalLbl As New Label
            Dim TotalPrice As Single
            For i As Integer = 0 To _tbl.Rows.Count - 1
                TotalPrice += Val(IIf(IsDBNull(_tbl.Rows(i)("Total")), "", _tbl.Rows(i)("Total")))
            Next

            TotalLbl = CType(e.Row.FindControl("AmountTotal"), Label)
            If Not TotalLbl Is Nothing Then
                TotalLbl.Text = TotalPrice
                _TotalAmount = TotalPrice
            End If
        End If
    End Sub


    Protected Sub ProductDDL_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ridx As Integer = sender.Attributes("RowIdx")
        Dim ProductUnit As New TextBox
        Dim ProductPrice As New TextBox
        Dim ProductID As Integer
        ProductUnit = CType(GridView1.Rows(ridx).FindControl("txtUnit"), TextBox)
        ProductPrice = CType(GridView1.Rows(ridx).FindControl("txtPrice"), TextBox)
        ProductID = sender.selecteditem.value

        If Not (ProductUnit Is Nothing) Then
            Dim ds As New DataSet
            ds = Products.GetProductDetails(Session("CurrentBusinessID"), Val(ProductID))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    ProductUnit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UnitAsText")), "", ds.Tables(0).Rows(0)("UnitAsText"))
                    If Not ProductPrice Is Nothing Then
                        ProductPrice.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("SalePrice")), "", ds.Tables(0).Rows(0)("SalePrice"))
                    End If
                End If
            End If
        End If
    End Sub
End Class