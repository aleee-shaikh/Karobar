﻿Public Class SaleSettings
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Sub LoadData()
        txtDefaultDiscount.Text = ReferenceData.Setting("DefaultSaleDiscountPercentage", "0", LoggedInUserSession.BusinessID)
        txtDefaultSaleTax.Text = ReferenceData.Setting("DefaultSaleTaxPercentage", "0", LoggedInUserSession.BusinessID)
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click

        If IsNumeric(txtDefaultDiscount.Text) = False Or IsNumeric(txtDefaultSaleTax.Text) = False Then
            Page.RegisterStartupScript("SettingError", "<script>parent.ShowMessage('Invalid Percentage.','1',$(window).height()*2/100,$(window).width()*30/100);</script>")
        ElseIf Val(txtDefaultDiscount.Text) > 99 Or Val(txtDefaultSaleTax.Text) > 99 Then
            Page.RegisterStartupScript("SettingError", "<script>parent.ShowMessage('Percentage should not be more than 99%','1',$(window).height()*2/100,$(window).width()*50/100);</script>")
        Else
            ReferenceData.UpdateWebsiteSettings("DefaultSaleDiscountPercentage", txtDefaultDiscount.Text, LoggedInUserSession.BusinessID)
            ReferenceData.UpdateWebsiteSettings("DefaultSaleTaxPercentage", txtDefaultSaleTax.Text, LoggedInUserSession.BusinessID)
            Page.RegisterStartupScript("SettingSavedSuccessFully", "<script>parent.ShowMessage('Setting saved successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")

            Log.WriteLog(LoggedInUserSession.BusinessID, LoggedInUserSession.UserID, "Business", "Sale Discount & Tax Updated (" & txtDefaultDiscount.Text & "," & txtDefaultSaleTax.Text & ")", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=0)
        End If

    End Sub
End Class