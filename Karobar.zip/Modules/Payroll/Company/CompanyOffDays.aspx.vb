﻿Public Class CompanyOffDays
    Inherits System.Web.UI.Page

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Try
            OFFDays.Save()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OffdaysAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Off days added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1');setTimeout(function(){parent.window.location='/Working-Days';},2000)</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "OffdaysAddingIssue", "<script>parent.ShowMessage('Unable to add Off days','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub CompanyOffDays_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            OFFDays.LoadData()
        End If
    End Sub
End Class