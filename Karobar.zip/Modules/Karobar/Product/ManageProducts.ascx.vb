﻿Public Class ManageProducts
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
            DDLProductCatagory.DataValueField = "ArticleTypeID"
            DDLProductCatagory.DataTextField = "ArticleType"
            DDLProductCatagory.DataSource = ds.Tables(0)
            DDLProductCatagory.DataBind()
            LoadProductSubCatagories(DDLProductCatagory.SelectedItem.Value)

            GrdProducts.Columns(2).HeaderText = ReferenceData.Setting("LblProductName", "Product", Session("CurrentBusinessID"))
            GrdProducts.Columns(3).HeaderText = ReferenceData.Setting("LblProductCategory", "Category", Session("CurrentBusinessID"))
            GrdProducts.Columns(4).HeaderText = ReferenceData.Setting("LblProductSubCategory", "Sub Category", Session("CurrentBusinessID"))
            GrdProducts.Columns(5).HeaderText = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))
            GrdProducts.Columns(6).HeaderText = ReferenceData.Setting("LblProductPurchasePrice", "Purchase Price", Session("CurrentBusinessID"))
            GrdProducts.Columns(7).HeaderText = ReferenceData.Setting("LblProductSalePrice", "Sale Price", Session("CurrentBusinessID"))
            GrdProducts.Columns(8).HeaderText = ReferenceData.Setting("LblProductOthers", "Others", Session("CurrentBusinessID"))
            GrdProducts.Columns(9).HeaderText = ReferenceData.Setting("LblProductManufacturer", "Manufacturer", Session("CurrentBusinessID"))
            GrdProducts.Columns(10).HeaderText = ReferenceData.Setting("LblGridManageProductsNewLink", "New Product", Session("CurrentBusinessID"))

            LoadData()
        Else

        End If


    End Sub

    Sub LoadProductSubCatagories(ByVal GroupTypeID As Integer)
        DDLProductSubCatagories.Items.Clear()
        Dim ds As New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagories.DataValueField = "ArticleTypeID"
        DDLProductSubCatagories.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If

        DDLProductSubCatagories.Items.Add(New ListItem("All Sub Catagories", "-1"))
        DDLProductSubCatagories.DataSource = tbl
        DDLProductSubCatagories.DataBind()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        If Person.DoesPersonHavePageRights(Session("UserID"), 23) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage products screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If

    End Sub

    Sub LoadData()
        Dim tbl As New DataTable
        tbl = Products.GetProductsList(Session("CurrentBusinessID"), DDLProductCatagory.SelectedItem.Value, DDLProductSubCatagories.SelectedItem.Value, txtFreeText.Text.Trim)
        Dim dv As DataView = tbl.DefaultView
        dv.Sort = SortExpression + " " + If(IsAscendingSort, "ASC", "DESC")
        GrdProducts.DataSource = dv
        GrdProducts.DataBind()
    End Sub


    Private Sub GrdProducts_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdProducts.PageIndexChanging
        GrdProducts.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdProducts_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdProducts.RowCommand
        If e.CommandName = "DeleteProduct" Then
            Products.DeleteProduct(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Deleted Product " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        ElseIf e.CommandName = "ViewProductAccounts" Then

        ElseIf e.CommandName = "DeleteProductAccount" Then

            ''Product.DeleteProductAccount(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Deleted Product Account " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LnkEditProduct As New System.Web.UI.WebControls.LinkButton
            LnkEditProduct = CType(e.Row.FindControl("LnkEditProduct"), LinkButton)
            If Not LnkEditProduct Is Nothing Then
                LnkEditProduct.OnClientClick = "javascript:ShowEditProduct(" & drview("ArticleID") & ");return false"
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub DDLProductCatagory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        LoadProductSubCatagories(DDLProductCatagory.SelectedItem.Value)
    End Sub

    Private Sub GrdProducts_Sorting(sender As Object, e As GridViewSortEventArgs) Handles GrdProducts.Sorting
        Dim columnIndex As Integer = 0
        For Each headerCell In GrdProducts.HeaderRow.Cells
            If (headerCell.ContainingField.SortExpression = e.SortExpression) Then
                columnIndex = GrdProducts.HeaderRow.Cells.GetCellIndex(headerCell)
            End If
        Next

        If e.SortExpression = SortExpression Then
            IsAscendingSort = Not IsAscendingSort

        Else
            IsAscendingSort = False
            SortExpression = e.SortExpression
        End If


        For i As Integer = 0 To GrdProducts.Columns.Count - 1
            GrdProducts.Columns(i).HeaderText = GrdProducts.Columns(i).HeaderText.Replace("▲", "").Replace("▼", "")
        Next

        If (IsAscendingSort) Then
            GrdProducts.Columns(columnIndex).HeaderText = GrdProducts.Columns(columnIndex).HeaderText + "▲"
        Else
            GrdProducts.Columns(columnIndex).HeaderText = GrdProducts.Columns(columnIndex).HeaderText + "▼"
        End If
        LoadData()
    End Sub

    Protected Property IsAscendingSort As Boolean
        Get
            Dim value As Object = ViewState("IsAscendingSort")
            Return If(Not IsNothing(value), CBool(value), False)
        End Get
        Set(value As Boolean)
            ViewState("IsAscendingSort") = value
        End Set
    End Property

    Protected Property SortExpression As String
        Get
            Dim value As Object = ViewState("SortExpression")
            Return If(Not IsNothing(value), CStr(value), "ArticleID")
        End Get
        Set(value As String)
            ViewState("SortExpression") = value
        End Set
    End Property
End Class