﻿Public Class Reminders
    Inherits System.Web.UI.Page

    Function GetDateinMMDDYYYY(dt As String, Seperator As String) As String
        Dim dtTmAry = dt.Split(" ")
        Dim dtAry = dtTmAry(0).Split(Seperator)

        Return dtAry(1) & "/" & dtAry(0) & "/" & dtAry(2).Substring(0, 4) & " " & dtTmAry(1) ' & " " & dtTmAry(2)
    End Function


    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim ApprovedBy As Integer = -1

        Try
            BusinessEvents.AddEvent(Session("CurrentBusinessID"), Session("UserID"), BusinessEvents.EventTypes.Reminders, CDate(GetDateinMMDDYYYY(txtReminderDate.Text, "-")), CDate(GetDateinMMDDYYYY(txtReminderDate.Text, "-")), txtReminderDescription.Text.Trim(), ApprovedBy)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "ReminderAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Reminder added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1');setTimeout(function(){parent.window.location='/Working-Days';},2000)</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "ReminderAddingIssue", "<script>parent.ShowMessage('Unable to add Reminder','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub Reminders_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            txtReminderDate.Text = Now.ToString("dd-MM-yyyy hh:mm:ss tt")
        End If
    End Sub
End Class