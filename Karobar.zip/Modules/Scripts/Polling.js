
function CastVote(PollID, OptionID) {

    var RequestData = {
        PollID: PollID,
        OptionID: OptionID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Poll.asmx/CastVote',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("CastVoteResponse").length;
            alert("Your vote has been casted")
            
            $('#PollOption').attr('checked', false);
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
}
 
function GetPolling(ControlID) {


    var PollData = [];
    var PollOptionsData = [];
    var Polling = [];
    var RequestData = {
        PollID: '-1',
        FreeText:''
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Poll.asmx/GetPolling',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Polling").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("Polling").each(function () {
                    PollData.push({
                        PollingID: $(this).find("PollingID").text(),
                        PollingTypeID: $(this).find("PollingTypeID").text(),
                        PollingDescription: $(this).find("PollingDescription").text(),
                        PollingImage: $(this).find("PollingImage").text(),
                        CreatedBy: $(this).find("CreatedBy").text(),
                        Visible: $(this).find("Visible").text(),
                        Dated: $(this).find("Dated").text()
                    });

                });

                $(xml).find("PollingOptions").each(function () {
                    PollOptionsData.push({
                        PollingOptionID: $(this).find("PollingOptionID").text(),
                        PollID: $(this).find("PollID").text(),
                        PollingOptionDescription: $(this).find("PollingOptionDescription").text(),
                        PollingOptionImage: $(this).find("PollingOptionImage").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    Polling.push({
        Poll: PollData,
        PollOptions: PollOptionsData
    });
    my.utils.renderExternalTemplate("1/Templates/Poll_List", '#'+ControlID+'_PollContainer', Polling);
}

