﻿Public Class RecallTicket
    Inherits System.Web.UI.UserControl

    Sub LoadNewTicket()
        Dim tbl As New DataTable
        Dim ds As New DataSet

        ds = Tickets.GetTickets(Val(Session("CurrentBusinessID")), -1, "", Now.ToString("yyyyMMdd"), Now.ToString("yyyyMMdd"))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    tbl = ds.Tables(0).Select("TicketStatusID=1").CopyToDataTable
                Catch ex As Exception

                End Try
                If tbl.Rows.Count > 0 Then
                    LblTicketType.ForeColor = Drawing.Color.Black
                    HdnTicketID.Value = tbl.Rows(0)("TicketID")
                    Tickets.SaveTicketDetails(Session("CurrentBusinessID"), Val(HdnTicketID.Value), -1, 2, txtTicketDescription.Text.Trim)
                    LblTicketNumber.Text = tbl.Rows(0)("TicketNumber")
                    LblTicketType.Text = tbl.Rows(0)("TicketType")
                    HdnTicketLogID.Value = tbl.Rows(0)("TicketLogID")
                Else
                    LblTicketType.ForeColor = Drawing.Color.Red
                    LblTicketType.Text = "There is no ticket available"
                End If
            End If
        End If

    End Sub

    Private Sub BtnDone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDone.Click
        Tickets.SaveTicketDetails(Session("CurrentBusinessID"), Val(HdnTicketID.Value), Val(HdnTicketLogID.Value), DDLTicketStatus.SelectedItem.Value, txtTicketDescription.Text.Trim)
        Response.Redirect("~/Recall-Ticket")
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
            
        Else
            BtnDone.Enabled = False
            ''BtnRecallTicket.Enabled = True

            DDLTicketStatus.DataSource = Tickets.GetTicketStatuses(Session("CurrentBusinessID"))
            DDLTicketStatus.DataTextField = "TicketStatusName"
            DDLTicketStatus.DataValueField = "TicketStatusID"
            DDLTicketStatus.DataBind()
            DDLTicketStatus.Items.RemoveAt(1)
            DDLTicketStatus.SelectedValue = 2
        End If
    End Sub

    Private Sub BtnRecallTicket_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRecallTicket.Click
        BtnDone.Enabled = True
        ''BtnRecallTicket.Enabled = False
        LoadNewTicket()
    End Sub
End Class