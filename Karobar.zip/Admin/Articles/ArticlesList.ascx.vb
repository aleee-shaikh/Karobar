﻿Public Class ArticlesList
    Inherits System.Web.UI.UserControl

  
    Private Sub BtnAddNewArticles_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAddNewArticle.Click
        Response.Redirect("~/Admin/Admin.aspx?P=Articles&S=1")
    End Sub

    Private Sub GrdArticles_PageIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GrdArticles.PageIndexChanged

    End Sub

    Private Sub GrdArticles_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdArticles.PageIndexChanging
        GrdArticles.PageIndex = e.NewPageIndex
        GrdArticles.DataSource = WebsiteArticles.GetArticlesList(txtSearchArticles.Text.Trim)
        GrdArticles.DataBind()
    End Sub

    Private Sub GrdArticles_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdArticles.RowCommand
        If e.CommandName = "EditArticle" Then
            Session("ArticleID") = e.CommandArgument
            Response.Redirect("~/Admin/Admin.aspx?P=Articles&S=2")
        ElseIf e.CommandName = "DeleteArticle" Then
            WebsiteArticles.DeleteArticle(e.CommandArgument)
            GrdArticles.DataSource = WebsiteArticles.GetArticlesList(txtSearchArticles.Text.Trim)
            GrdArticles.DataBind()
        End If
    End Sub


    Private Sub BtnSearchArticles_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearchArticles.Click
        GrdArticles.DataSource = WebsiteArticles.GetArticlesList(txtSearchArticles.Text.Trim)
        GrdArticles.DataBind()
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            GrdArticles.DataSource = WebsiteArticles.GetArticlesList(txtSearchArticles.Text.Trim)
            GrdArticles.DataBind()
        End If
    End Sub

    Private Sub GrdArticles_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GrdArticles.SelectedIndexChanged

    End Sub

    Private Sub GrdArticles_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles GrdArticles.SelectedIndexChanging

        
    End Sub
End Class