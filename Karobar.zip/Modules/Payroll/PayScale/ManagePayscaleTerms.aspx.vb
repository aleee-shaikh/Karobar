﻿Public Class ManagePayScaleTerms
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If

        If Not Page.IsPostBack Then
            Dim tbl As New DataTable
            tbl = Payroll.GetPayrollGroups(Val(Session("CurrentBusinessID")))
            DDLPayScale.DataValueField = "PayrollGroupID"
            DDLPayScale.DataTextField = "GroupName"
            DDLPayScale.DataSource = tbl
            DDLPayScale.DataBind()
            LoadData()
        End If
        If GrdPayScaleTerm.Rows.Count > 0 Then
            GrdPayScaleTerm.Columns(8).Visible = True
            GrdPayScaleTerm.Columns(9).Visible = True
            GrdPayScaleTerm.Columns(10).Visible = False
        Else
            GrdPayScaleTerm.Columns(8).Visible = False
            GrdPayScaleTerm.Columns(9).Visible = False
            GrdPayScaleTerm.Columns(10).Visible = True
        End If
    End Sub

    Sub LoadData()

        GrdPayScaleTerm.DataSource = Payroll.GetPayrollGroupTerms(Val(Session("CurrentBusinessID")), Val(DDLPayScale.SelectedValue))
        GrdPayScaleTerm.DataBind()
    End Sub

    Private Sub GrdPayScaleTerm_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdPayScaleTerm.RowCommand
        If e.CommandName = "AddNewPayScaleTerm" Then
            Dim Name As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtName"), TextBox).Text
            Dim Description As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtPayScaleTermDescription"), TextBox).Text
            Dim Visible As Boolean = CType(GrdPayScaleTerm.FooterRow.FindControl("ChkVisible"), CheckBox).Checked
            Dim AddDeduct As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtPayScaleTermAddDeduct"), TextBox).Text
            Dim CalculateOnPercentage As Single = Val(CType(GrdPayScaleTerm.FooterRow.FindControl("txtPercentage"), TextBox).Text)
            Dim CalculateOnColumn As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtPercentageColumn"), TextBox).Text
            Dim FixedAmount As Single = CType(GrdPayScaleTerm.FooterRow.FindControl("txtFixedAmount"), TextBox).Text

            Dim SortNo As String = Val(CType(GrdPayScaleTerm.FooterRow.FindControl("txtSortNo"), TextBox).Text)
            Dim ChkVisible As Boolean = CType(GrdPayScaleTerm.FooterRow.FindControl("ChkVisible"), CheckBox).Checked
            Payroll.AddPayrollGroupTerm(DDLPayScale.SelectedValue, Name, Description, CalculateOnPercentage, CalculateOnColumn, FixedAmount, AddDeduct, Visible, Session("UserID"), SortNo)
            GrdPayScaleTerm.ShowFooter = False
        ElseIf e.CommandName = "Insert" Then
            'Dim Key As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtModuleSettingKey"), TextBox).Text
            'Dim Value As String = CType(GrdPayScaleTerm.FooterRow.FindControl("txtModuleSettingValue"), TextBox).Text
            'Website.Modules.AddModuleSettings(HdnModuleID.Value, Key, Value)
            'GrdPayScaleTerm.EditIndex = -1
            'GrdPayScaleTerm.ShowFooter = False
        ElseIf e.CommandName = "Cancel" Then
            GrdPayScaleTerm.ShowFooter = False
            GrdPayScaleTerm.Columns(8).Visible = True
            GrdPayScaleTerm.Columns(9).Visible = True
            GrdPayScaleTerm.Columns(10).Visible = False
            GrdPayScaleTerm.EditIndex = -1
        ElseIf e.CommandName = "Edit" Then
            'Dim txtGroupName As TextBox = CType(GrdPayScaleTerm.FooterRow.FindControl("txtGroupName"), TextBox)
            'Dim GroupDesc As TextBox = CType(GrdPayScaleTerm.FooterRow.FindControl("txtPayScaleTermDescription"), TextBox)
            'Dim ChkVisible As CheckBox = CType(GrdPayScaleTerm.FooterRow.FindControl("ChkVisible"), CheckBox)
            GrdPayScaleTerm.Columns(8).Visible = True
            GrdPayScaleTerm.Columns(9).Visible = True
            GrdPayScaleTerm.Columns(10).Visible = False
        ElseIf e.CommandName = "Update" Then
            Dim Name As String = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txteditName"), TextBox).Text
            Dim Description As String = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditPayScaleTermDescription"), TextBox).Text
            Dim Visible As Boolean = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("ChkEditVisible"), CheckBox).Checked
            Dim AddDeduct As String = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditPayScaleTermAddDeduct"), TextBox).Text
            Dim CalculateOnPercentage As Single = Val(CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditPercentage"), TextBox).Text)
            Dim CalculateOnColumn As String = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditPercentageColumn"), TextBox).Text
            Dim FixedAmount As Single = Val(CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditFixedAmount"), TextBox).Text)

            Dim SortNo As String = Val(CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("txtEditSortNo"), TextBox).Text)
            Dim ChkVisible As Boolean = CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("ChkEditVisible"), CheckBox).Checked
            Dim GroupPolicyID As Integer = Val(CType(GrdPayScaleTerm.Rows(GrdPayScaleTerm.EditIndex).FindControl("HdnGroupPolicyID"), HiddenField).Value)
            Payroll.UpdatePayrollGroupTerm(GroupPolicyID, DDLPayScale.SelectedValue, Name, Description, CalculateOnPercentage, CalculateOnColumn, FixedAmount, AddDeduct, Visible, Session("UserID"), SortNo)
            GrdPayScaleTerm.EditIndex = -1
        ElseIf e.CommandName = "DeletePayScaleTerm" Then
            GrdPayScaleTerm.ShowFooter = False
            Payroll.DeletePayrollGroupTerm(Val(e.CommandArgument))
            GrdPayScaleTerm.EditIndex = -1
        End If
        LoadData()

    End Sub

    Private Sub LnkAddPayScaleTerm_Click(sender As Object, e As EventArgs) Handles LnkAddPayScaleTerm.Click
        GrdPayScaleTerm.ShowFooter = True
        GrdPayScaleTerm.Columns(8).Visible = False
        GrdPayScaleTerm.Columns(9).Visible = False
        GrdPayScaleTerm.Columns(10).Visible = True
        ''If GrdPayScaleTerm.Rows.Count = 0 Then
        Dim dr As DataRow
            Dim tbl As New DataTable
            tbl = Payroll.GetPayrollGroupTerms(Val(Session("CurrentBusinessID")), DDLPayScale.SelectedValue)
            dr = tbl.NewRow
            tbl.Rows.InsertAt(dr, 0)
            GrdPayScaleTerm.DataSource = tbl
            GrdPayScaleTerm.DataBind()
        ''End If

    End Sub

    Private Sub GrdPayScaleTerm_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdPayScaleTerm.RowEditing
        GrdPayScaleTerm.EditIndex = e.NewEditIndex
        GrdPayScaleTerm.DataBind()
    End Sub

    Private Sub DDLPayScale_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLPayScale.SelectedIndexChanged
        LoadData()
    End Sub

    Private Sub GrdPayScaleTerm_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdPayScaleTerm.RowUpdating

    End Sub

    Private Sub GrdPayScaleTerm_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdPayScaleTerm.RowCancelingEdit

    End Sub
End Class