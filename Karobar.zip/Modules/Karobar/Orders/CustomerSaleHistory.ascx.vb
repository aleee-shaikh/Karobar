﻿Public Class CustomerSaleHistory
    Inherits System.Web.UI.UserControl
    Dim _TotalAmount As Single
    Dim _tbl As New DataTable

    Public Property CustomerID() As Integer
        Get
            Return Val(HdnCustomerID.Value)
        End Get
        Set(value As Integer)
            HdnCustomerID.Value = value

        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            HiddenQtyValue.Value = ReferenceData.Setting("HiddenQtyValue", "1", Session("CurrentBusinessID"))
            LoadData()
        End If
    End Sub

    Sub LoadData()
        GrdProducts.DataSource = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", Now.AddYears(-50).ToString("MM/dd/yyyy ") & " 00:00:00 AM", Now.ToString("MM/dd/yyyy ") & " 23:59:59 PM", CustomerID)
        GrdProducts.DataBind()
    End Sub


    Private Sub GrdProducts_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdProducts.PageIndexChanging
        GrdProducts.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdCustomerOrderHistory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdProducts.RowCommand

    End Sub

    Private Sub GrdCustomerOrderHistory_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim LnkEditProduct As New System.Web.UI.WebControls.LinkButton
            LnkEditProduct = CType(e.Row.FindControl("LnkEditProduct"), LinkButton)
            If Not LnkEditProduct Is Nothing Then
                LnkEditProduct.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx?PID=" & drview("ArticleID") & "',$(window).height()*79/100,$(window).width()*72/100);return false"
            End If

            Dim LnkViewSaleInvoice As New System.Web.UI.WebControls.LinkButton
            LnkViewSaleInvoice = CType(e.Row.FindControl("LnkViewSaleInvoice"), LinkButton)
            If Not LnkViewSaleInvoice Is Nothing Then
                ''LnkViewSaleInvoice.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Reports/SaleInvoice.aspx?SaleID=" & drview("SaleID") & "',$(window).height()*95/100,$(window).width()*90/100);return false"
                LnkViewSaleInvoice.OnClientClick = "javascript:ShowDlgForm('/Modules/Karobar/Reports/POSSaleInvoice.aspx?SaleID=" & drview("SaleID") & "',$(window).height()*95/100,$(window).width()*90/100);return false"
            End If


            ''_TotalAmount = _TotalAmount + ((drview("Quantity") * drview("SalePrice")) + drview("Tax") + drview("OtherCharges")) - drview("Discount")
            _TotalAmount = _TotalAmount + ((((drview("Quantity") * drview("Price"))) - drview("Discount")) + drview("Tax"))
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalAmountLbl As New System.Web.UI.WebControls.Label
            TotalAmountLbl = CType(e.Row.FindControl("TotalAmount"), Label)
            If Not TotalAmountLbl Is Nothing Then
                TotalAmountLbl.Text = Math.Round(_TotalAmount, 2)
            End If


        End If
    End Sub

End Class