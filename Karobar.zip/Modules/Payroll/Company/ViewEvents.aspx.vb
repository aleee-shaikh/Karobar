﻿Public Class ViewEvents
    Inherits System.Web.UI.Page

    Private Sub ViewEvents_Load(sender As Object, e As EventArgs) Handles Me.Load
        If (Page.IsPostBack = False) Then
            LoadData()
        End If

    End Sub

    Sub LoadData()
        If Not Request("dt") Is Nothing Then
            Dim tbl As New DataTable
            Dim dt As DateTime
            dt = CDate(Request("dt"))
            LblScreenTitle.Text = dt.ToString("dddd dd-MM-yyyy")
            tbl = BusinessEvents.GetEvents(Val(Session("CurrentBusinessID")), dt.ToString("MM/dd/yyyy 00:00:00 ") & "AM", dt.ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, "", -1)
            GrdEvents.DataSource = tbl
            GrdEvents.DataBind()
        End If
    End Sub

    Private Sub GrdEvents_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdEvents.RowCommand
        If e.CommandName = "DeleteEvent" Then
            BusinessEvents.DeleteEvent(Val(Session("CurrentBusinessID")), e.CommandArgument)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "EventRemovedSuccessFully", "<script>parent.window.location='/Working-Days';</script>")
        End If
    End Sub
End Class