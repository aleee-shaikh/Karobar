﻿Public Class TimePunch
    Inherits System.Web.UI.Page

    Private Sub BtnCheckIn_Click(sender As Object, e As EventArgs) Handles BtnCheckIn.Click
        Dim ds As New DataSet()
        Dim EmpPunchesTbl As New DataTable
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Session("UserID"), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 00:00:00 ") & "AM", General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        If EmpPunchesTbl.Rows.Count > 0 Then
            Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1
            If CDate(EmpPunchesTbl.Rows(LastRowIdx)("EmpPunch")).ToString("yyyyMMdd") = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("yyyyMMdd") Then
                If EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    Page.RegisterStartupScript("CheckInIssue", "<script>parent.HideDlgForm(1);parent.ShowMessage('Employee already have check in punches for this time.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Exit Sub
                End If
            End If
        End If

        Try
            Dim Lat As Single = 0.0, Lng As Single = 0.0
            Dim LocTbl As New DataTable
            LocTbl = Geo.GetLocationFromIP(HttpContext.Current.Request.UserHostAddress)

            If LocTbl.Rows.Count > 0 Then
                If LocTbl.Columns.Contains("Status") AndAlso LocTbl.Columns.Contains("message") Then

                Else
                    If LocTbl.Columns.Contains("lat") Then
                        Lat = LocTbl.Rows(0)("lat")
                    Else
                        Lat = LocTbl.Rows(0)("latitude")
                    End If
                    If LocTbl.Columns.Contains("lon") Then
                        Lng = LocTbl.Rows(0)("lon")
                    Else
                        Lng = LocTbl.Rows(0)("longitude")
                    End If
                End If
            End If

            BusinessTMS.AddEmpPunch(Val(Session("CurrentBusinessID")), Session("UserID"), Val(Session("ShiftID")), BusinessTMS.PunchTypes.PunchIN, BusinessTMS.PunchPurpose.TimePunch, General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone), txtComments.Text, Lat, Lng)
            txtComments.Text = ""
            Page.RegisterStartupScript("CheckInSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Check in punch done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        Catch ex As Exception
            Page.RegisterStartupScript("CheckInIssue", "<script>parent.ShowMessage('Check in could not be added, please try again','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub TimePunch_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LblUserName.Text = Session("UserName")
            CheckEmployeeLastPunches()

        End If
    End Sub

    'Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

    '    lblTime.Text = Now
    'End Sub

    Sub CheckEmployeeLastPunches()
        Dim EmpPunchesTbl As New DataTable
        Dim ds As New DataSet()
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Session("UserID"), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 00:00:00 ") & "AM", General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        If EmpPunchesTbl.Rows.Count > 0 Then
            GrdEmpPunches.DataSource = EmpPunchesTbl
            GrdEmpPunches.DataBind()
            Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1
            If CDate(EmpPunchesTbl.Rows(LastRowIdx)("EmpPunch")).ToString("yyyyMMdd") = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("yyyyMMdd") Then
                If EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    BtnCheckIn.Visible = False
                    BtnCheckOut.Visible = True
                    BtnBreakCheckIn.Visible = True
                    BtnBreakCheckOut.Visible = False
                ElseIf EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                    BtnCheckOut.Visible = False
                    BtnCheckIn.Visible = True
                    BtnBreakCheckIn.Visible = False
                    BtnBreakCheckOut.Visible = False
                ElseIf EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    BtnCheckOut.Visible = False
                    BtnCheckIn.Visible = False
                    BtnBreakCheckIn.Visible = False
                    BtnBreakCheckOut.Visible = True
                ElseIf EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                    BtnCheckOut.Visible = True
                    BtnCheckIn.Visible = False
                    BtnBreakCheckIn.Visible = True
                    BtnBreakCheckOut.Visible = False

                End If
            Else
                BtnCheckOut.Visible = False
                BtnCheckIn.Visible = False
                BtnBreakCheckIn.Visible = True
                BtnBreakCheckOut.Visible = False
            End If
        End If
    End Sub

    Private Sub BtnCheckOut_Click(sender As Object, e As EventArgs) Handles BtnCheckOut.Click
        Dim EmpPunchesTbl As New DataTable
        Dim ds As New DataSet()
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Session("UserID"), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 00:00:00 ") & "AM", General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        If EmpPunchesTbl.Rows.Count > 0 Then
            Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1
            If CDate(EmpPunchesTbl.Rows(LastRowIdx)("EmpPunch")).ToString("yyyyMMdd") = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("yyyyMMdd") Then
                If EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.TimePunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                    Page.RegisterStartupScript("CheckInIssue", "<script>parent.HideDlgForm(1);parent.ShowMessage('Employee already have check out punches for this time.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Exit Sub
                End If
            End If
        End If

        Try
            Dim Lat As Single = 0.0, Lng As Single = 0.0
            Dim LocTbl As New DataTable
            LocTbl = Geo.GetLocationFromIP(HttpContext.Current.Request.UserHostAddress)

            If LocTbl.Rows.Count > 0 Then
                If LocTbl.Columns.Contains("Status") AndAlso LocTbl.Columns.Contains("message") Then

                Else
                    If LocTbl.Columns.Contains("lat") Then
                        Lat = LocTbl.Rows(0)("lat")
                    Else
                        Lat = LocTbl.Rows(0)("latitude")
                    End If
                    If LocTbl.Columns.Contains("lon") Then
                        Lng = LocTbl.Rows(0)("lon")
                    Else
                        Lng = LocTbl.Rows(0)("longitude")
                    End If
                End If
            End If

            BusinessTMS.AddEmpPunch(Val(Session("CurrentBusinessID")), Session("UserID"), Val(Session("ShiftID")), BusinessTMS.PunchTypes.PunchOUT, BusinessTMS.PunchPurpose.TimePunch, General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone), txtComments.Text, Lat, Lng)
            txtComments.Text = ""
            Page.RegisterStartupScript("CheckOutSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Check out punch done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        Catch ex As Exception
            Page.RegisterStartupScript("CheckOutIssue", "<script>parent.ShowMessage('Check out could not be done, please try again','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub BtnBreakCheckIn_Click(sender As Object, e As EventArgs) Handles BtnBreakCheckIn.Click
        Dim EmpPunchesTbl As New DataTable
        Dim ds As New DataSet()
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Session("UserID"), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 00:00:00 ") & "AM", General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        If EmpPunchesTbl.Rows.Count > 0 Then
            Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1
            If CDate(EmpPunchesTbl.Rows(LastRowIdx)("EmpPunch")).ToString("yyyyMMdd") = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("yyyyMMdd") Then
                If EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchIN Then
                    Page.RegisterStartupScript("CheckInIssue", "<script>parent.HideDlgForm(1);parent.ShowMessage('Employee already have break start punches for this time.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Exit Sub
                End If
            End If
        End If

        Try
            Dim Lat As Single = 0.0, Lng As Single = 0.0
            Dim LocTbl As New DataTable
            LocTbl = Geo.GetLocationFromIP(HttpContext.Current.Request.UserHostAddress)

            If LocTbl.Rows.Count > 0 Then
                If LocTbl.Columns.Contains("Status") AndAlso LocTbl.Columns.Contains("message") Then

                Else
                    If LocTbl.Columns.Contains("lat") Then
                        Lat = LocTbl.Rows(0)("lat")
                    Else
                        Lat = LocTbl.Rows(0)("latitude")
                    End If
                    If LocTbl.Columns.Contains("lon") Then
                        Lng = LocTbl.Rows(0)("lon")
                    Else
                        Lng = LocTbl.Rows(0)("longitude")
                    End If
                End If
            End If

            BusinessTMS.AddEmpPunch(Val(Session("CurrentBusinessID")), Session("UserID"), Val(Session("ShiftID")), BusinessTMS.PunchTypes.PunchIN, BusinessTMS.PunchPurpose.BreakPunch, General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone), txtComments.Text, Lat, Lng)
            txtComments.Text = ""
            Page.RegisterStartupScript("CheckInSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Break start punch done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        Catch ex As Exception
            Page.RegisterStartupScript("CheckInIssue", "<script>parent.ShowMessage('Check in could not be added, please try again','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub BtnBreakCheckOut_Click(sender As Object, e As EventArgs) Handles BtnBreakCheckOut.Click
        Dim EmpPunchesTbl As New DataTable
        Dim ds As New DataSet()
        ds = BusinessTMS.GetEmpPunches(Val(Session("CurrentBusinessID")), Session("UserID"), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 00:00:00 ") & "AM", General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("MM/dd/yyyy 23:59:50 ") & "PM", -1, -1)
        EmpPunchesTbl = ds.Tables(0)
        If EmpPunchesTbl.Rows.Count > 0 Then
            Dim LastRowIdx As Integer = EmpPunchesTbl.Rows.Count - 1
            If CDate(EmpPunchesTbl.Rows(LastRowIdx)("EmpPunch")).ToString("yyyyMMdd") = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone).ToString("yyyyMMdd") Then
                If EmpPunchesTbl.Rows(LastRowIdx)("PunchPurposeID") = BusinessTMS.PunchPurpose.BreakPunch And EmpPunchesTbl.Rows(LastRowIdx)("PunchTypeID") = BusinessTMS.PunchTypes.PunchOUT Then
                    Page.RegisterStartupScript("CheckInIssue", "<script>parent.HideDlgForm(1);parent.ShowMessage('Employee already have break end punches for this time.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Exit Sub
                End If
            End If
        End If
        Try
            Dim Lat As Single = 0.0, Lng As Single = 0.0
            Dim LocTbl As New DataTable
            LocTbl = Geo.GetLocationFromIP(HttpContext.Current.Request.UserHostAddress)

            If LocTbl.Rows.Count > 0 Then
                If LocTbl.Columns.Contains("Status") AndAlso LocTbl.Columns.Contains("message") Then

                Else
                    If LocTbl.Columns.Contains("lat") Then
                        Lat = LocTbl.Rows(0)("lat")
                    Else
                        Lat = LocTbl.Rows(0)("latitude")
                    End If
                    If LocTbl.Columns.Contains("lon") Then
                        Lng = LocTbl.Rows(0)("lon")
                    Else
                        Lng = LocTbl.Rows(0)("longitude")
                    End If
                End If
            End If
            BusinessTMS.AddEmpPunch(Val(Session("CurrentBusinessID")), Session("UserID"), Val(Session("ShiftID")), BusinessTMS.PunchTypes.PunchOUT, BusinessTMS.PunchPurpose.BreakPunch, General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone), txtComments.Text, Lat, Lng)
            txtComments.Text = ""
            Page.RegisterStartupScript("CheckOutSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Break end punch done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        Catch ex As Exception
            Page.RegisterStartupScript("CheckOutIssue", "<script>parent.ShowMessage('Check out could not be done, please try again','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub


End Class