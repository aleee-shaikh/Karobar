﻿Public Class TicketDepartments
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            DDLBusinesses.DataTextField = "WebsiteTitle"
            DDLBusinesses.DataValueField = "WebsiteID"
            DDLBusinesses.DataSource = Website.GetWebsites()
            DDLBusinesses.DataBind()
            LoadData()
            MultiView1.ActiveViewIndex = 0
        End If
    End Sub

    Sub LoadData()
        GrdTicketTypes.DataSource = Tickets.GetTicketTypeDepartments(DDLBusinesses.SelectedItem.Value, ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
        GrdTicketTypes.DataBind()
    End Sub

    Private Sub GrdTicketTypes_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdTicketTypes.PageIndexChanging
        GrdTicketTypes.PageIndex = e.NewPageIndex
        LoadData()
    End Sub


    Protected Sub GrdTicketTypes_RowCancelingEdit(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCancelEditEventArgs) Handles GrdTicketTypes.RowCancelingEdit
        GrdTicketTypes.EditIndex = -1
        LoadData()
    End Sub

    Private Sub GrdTicketTypes_RowEditing(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewEditEventArgs) Handles GrdTicketTypes.RowEditing
        GrdTicketTypes.EditIndex = e.NewEditIndex
        LoadData()
        GrdTicketTypes.ShowFooter = False
    End Sub


    Private Sub GrdTicketTypes_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdTicketTypes.RowCommand
        If e.CommandName = "EditSection" Then

        ElseIf e.CommandName = "Update" Then
            Dim TicketTypeID As String = CType(GrdTicketTypes.Rows(GrdTicketTypes.EditIndex).FindControl("DDLeditDepartment"), DropDownList).Text.Trim
            Dim TicketTypeDepartmentID As String = Val(CType(GrdTicketTypes.Rows(GrdTicketTypes.EditIndex).FindControl("DDLeditTicketType"), DropDownList).SelectedItem.Value)
            Tickets.UpdateTicketTypeDepartment(Val(Session("CurrentBusinessID")), e.CommandArgument, ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")), TicketTypeID)

            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=ManageTicketTypeDepartments")
        ElseIf e.CommandName = "DeleteTicketTypeDepartment" Then
            Tickets.DeleteTicketType(e.CommandArgument)
            LoadData()
            Response.Redirect("~/admin/Admin.aspx?P=ManageTicketTypeDepartments")
        End If
    End Sub

    Protected Sub DDLBusinesses_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs) Handles DDLBusinesses.SelectedIndexChanged
        LoadData()
    End Sub

    Private Sub GrdTicketTypes_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdTicketTypes.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim DDLTicketType As New DropDownList
            Dim DDLTicketTypeDepartmentID As New DropDownList

            DDLTicketType = CType(e.Row.FindControl("DDLeditTicketType"), DropDownList)
            DDLTicketTypeDepartmentID = CType(e.Row.FindControl("DDLeditDepartment"), DropDownList)

            If Not DDLTicketType Is Nothing Then
                DDLTicketType.DataSource = Tickets.GetTicketTypes(DDLBusinesses.SelectedItem.Value, ParentTicketTypeID:=drview("ParentTicketTypeID"))
                DDLTicketType.DataTextField = "TicketType"
                DDLTicketType.DataValueField = "TicketTypeID"
                DDLTicketType.DataBind()
                DDLTicketType.SelectedValue = drview("TicketTypeID")
            End If

            If Not DDLTicketTypeDepartmentID Is Nothing Then
                ''DDLTicketTypeDepartmentID.DataSource = Tickets.GetTicketTypeDepartments(DDLBusinesses.SelectedItem.Value, ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
                DDLTicketTypeDepartmentID.DataSource = Tickets.GetTicketTypes(DDLBusinesses.SelectedItem.Value, ParentTicketTypeID:=ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
                DDLTicketTypeDepartmentID.DataTextField = "TicketType"
                DDLTicketTypeDepartmentID.DataValueField = "TicketTypeID"
                DDLTicketTypeDepartmentID.DataBind()
                If IsDBNull(drview("TicketTypeID")) = False Then
                    DDLTicketTypeDepartmentID.SelectedValue = drview("TicketTypeID")
                End If
            End If
        End If
    End Sub
End Class