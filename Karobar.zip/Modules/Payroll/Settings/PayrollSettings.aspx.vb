﻿Public Class PayrollSettings
    Inherits System.Web.UI.Page

    Private Sub LnkDepartments_Click(sender As Object, e As EventArgs) Handles LnkDepartments.Click
        TblDepartments.Visible = True
        TblDesignations.Visible = False
    End Sub

    Private Sub LnkDesignations_Click(sender As Object, e As EventArgs) Handles LnkDesignations.Click
        TblDepartments.Visible = False
        TblDesignations.Visible = True
    End Sub
End Class