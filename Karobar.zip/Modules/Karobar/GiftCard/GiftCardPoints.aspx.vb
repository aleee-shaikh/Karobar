﻿Imports System.Data.SqlClient

Public Class GiftCardPoints
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 142) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open Gift card point screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then
            Dim tbl As New DataTable
            tbl = GiftCard.GetGiftCardPointIncurredEvents(Session("CurrentBusinessID"))
            DDLIncurredEvents.DataValueField = "IncurredEventID"
            DDLIncurredEvents.DataTextField = "EventName"
            DDLIncurredEvents.DataSource = tbl
            DDLIncurredEvents.DataBind()

            tbl = GiftCard.GetGiftCards(Session("CurrentBusinessID"))
            DDLGiftCards.DataValueField = "GiftCardID"
            DDLGiftCards.DataTextField = "GiftCardName"
            DDLGiftCards.DataSource = tbl
            DDLGiftCards.DataBind()
            DDLGiftCards.Items.Insert(0, New ListItem(" -- Select Gift Card -- ", "-1"))
            If Not Request("GID") Is Nothing Then
                HdnGiftCardID.Value = Val(Request("GID"))
                DDLGiftCards.SelectedValue = HdnGiftCardID.Value
            End If
            If Not Request("GPID") Is Nothing Then
                HdnGiftCardPointID.Value = Val(Request("GPID"))
                lblScreenTitle.Text = "Update Gift Card Point"
                tbl = GiftCard.GetGiftCardPoints(Session("CurrentBusinessID"), HdnGiftCardID.Value, HdnGiftCardPointID.Value)
                If tbl.Rows.Count > 0 Then
                    txtPointName.Text = tbl.Rows(0)("PointName")
                    txtMinValue.Text = tbl.Rows(0)("MinValue")
                    txtMaxValue.Text = tbl.Rows(0)("MaxValue")
                    txtPointValue.Text = tbl.Rows(0)("PointValue")
                    txtValidityDays.Text = tbl.Rows(0)("PointsValidityDays")
                    DDLIncurredEvents.SelectedValue = tbl.Rows(0)("IncurredOnEventID")
                End If
            Else
                lblScreenTitle.Text = "Create New Gift Card Point"
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        If Val(HdnGiftCardPointID.Value) > 0 Then
            tbl = GiftCard.UpdateGiftCardPointDetails(Session("CurrentBusinessID"), Val(DDLGiftCards.SelectedValue), Val(HdnGiftCardPointID.Value), txtPointName.Text.Trim, Val(txtMinValue.Text), Val(txtMaxValue.Text), txtPointValue.Text, txtValidityDays.Text, DDLIncurredEvents.SelectedValue)
            If tbl.Columns.Contains("Error") Then
                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAlreadyExist", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                End If
            Else
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Updated Gift Card Point" & txtPointName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=Val(HdnGiftCardPointID.Value))
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardPointUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card point updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
            End If
        Else
            tbl = GiftCard.AddGiftCardPointDetails(Session("CurrentBusinessID"), Val(DDLGiftCards.SelectedValue), txtPointName.Text.Trim, Val(txtMinValue.Text), Val(txtMaxValue.Text), txtPointValue.Text, txtValidityDays.Text, DDLIncurredEvents.SelectedValue)
            If tbl.Columns.Contains("Error") Then
                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAlreadyExist", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card point added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Updated Gift Card Point" & txtPointName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=Val(HdnGiftCardPointID.Value))
                txtPointName.Text = ""
                txtValidityDays.Text = ""
                txtMinValue.Text = "0"
                txtMaxValue.Text = "0"
                txtPointValue.Text = "0"
            End If

        End If
    End Sub
End Class