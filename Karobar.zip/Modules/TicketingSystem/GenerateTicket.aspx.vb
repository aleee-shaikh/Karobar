﻿Public Class GenerateTicket
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Sub LoadData()
        Dim tbl As New DataTable
        GrdTickets.DataSource = Tickets.GetTicketTypes(Session("CurrentBusinessID"), ReferenceData.Setting("TicketSystemTypeID", "6", Session("CurrentBusinessID")))
        GrdTickets.DataBind()

    End Sub

   
    Private Sub GrdTickets_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdTickets.RowCommand
        If e.CommandName = "GenerateTicket" Then

            Tickets.AddTicket(Session("CurrentBusinessID"), Val(e.CommandArgument), _
                              ReferenceData.Setting("FromDepartment4BugComplaint", "6"), _
                              ReferenceData.Setting("FromTeam4BugCompalint", "3"), Session("UserID"), _
                              Session("UserName"), ReferenceData.Setting("ToDepartment4BugComplaint", "4"), _
                              ReferenceData.Setting("ToTeam4BugCompalint", "2"), -1, 1, "", _
                              "", ReferenceData.Setting("DefaultTicketStatusID", "1"), "")
        End If
    End Sub
End Class