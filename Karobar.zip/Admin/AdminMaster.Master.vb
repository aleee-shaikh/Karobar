﻿Public Class AdminMaster
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If ((Session("UserID") Is Nothing OrElse Val(Session("UserID")) <= 0)) Then
            Response.Redirect("~/Admin/Login.aspx")
        Else
            If Person.PersonHasRights(Session("UserID"), ",1,") = False Then
                Response.Redirect("~/WebsiteLayout.aspx")
            End If
        End If
        LblLoggedinUserName.Text = Session("UserName").ToString

    End Sub

    Private Sub LnkLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkLogout.Click
        Session.Abandon()
        ''Session.Clear()
        ''Response.Redirect("~/Admin/Login.aspx")
        Response.Redirect("~/WebsiteLayout.aspx")
    End Sub
End Class