﻿' NOTE: You can use the "Rename" command on the context menu to change the class name "EZKarobar" in code, svc and config file together.
' NOTE: In order to launch WCF Test Client for testing this service, please select EZKarobar.svc or EZKarobar.svc.vb at the Solution Explorer and start debugging.
''Imports CMS
Imports System.ServiceModel
Imports System.ServiceModel.Activation
Imports System.ServiceModel.Web
Imports System.Web.Script.Serialization

<AspNetCompatibilityRequirements(RequirementsMode:=AspNetCompatibilityRequirementsMode.Required)>
Public Class EZKarobar
    Implements IEZKarobar

    '<WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json, UriTemplate:="/WCF/EZKarobar.svc/SearchBusinesses")>
    Public Function SearchBusinesses() As String Implements IEZKarobar.SearchBusinesses
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.GetWebsites()
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"
        ''Return ds.GetXml().ToArray
        Return General.GetDataTableJson(ds.Tables(0))
    End Function
End Class
