﻿Public Class MasterPage
    Inherits System.Web.UI.MasterPage

    Public Function IsMasterUser() As Boolean
        Dim ds As New DataSet
        Dim res As Boolean = False

        If DDLBusinessList.Items.Count <= 1 Then
            If Not Session("UserID") Is Nothing Then
                ds = Person.GetUserDetail(Session("CurrentBusinessID"), Session("UserID"))
                If ds.Tables.Count > 0 Then
                    If ds.Tables(0).Rows.Count > 0 Then
                        If IsDBNull(ds.Tables(0).Rows(0)("CreatedBy")) = False AndAlso Val(ds.Tables(0).Rows(0)("CreatedBy").ToString) > 0 Then
                            res = False
                        Else
                            res = True
                        End If
                    End If
                End If
            End If
        End If
        Return res
    End Function

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Page.ClientScript.RegisterClientScriptInclude("jsRender", "/Scripts/jsRender.js")
        Page.ClientScript.RegisterClientScriptInclude("json2", "/Scripts/json2.js")
        Page.ClientScript.RegisterClientScriptInclude("Templates", "/Scripts/Templates.js")
        Page.ClientScript.RegisterClientScriptInclude("User", "/Modules/Scripts/User.js")
        ''Page.ClientScript.RegisterClientScriptInclude("Menu", "/Modules/Scripts/Menu.js")
        'Page.ClientScript.RegisterClientScriptInclude("Articles", "/Modules/Scripts/Articles.js")
        'Page.ClientScript.RegisterClientScriptInclude("Polling", "/Modules/Scripts/Product.js")
        'Page.ClientScript.RegisterClientScriptInclude("Polling", "/Modules/Scripts/Polling.js")
        Page.ClientScript.RegisterClientScriptInclude("General", "/Modules/Scripts/General.js")
        'Page.ClientScript.RegisterClientScriptInclude("COA", "c")


        If Not Page.IsPostBack Then
            DDLBusinessList.DataSource = Website.GetWebsites(Val(Session("UserID")))
            DDLBusinessList.DataTextField = "WebsiteTitle"
            DDLBusinessList.DataValueField = "WebsiteID"
            DDLBusinessList.DataBind()
            txtCurrentURL.Text = Request.Url.PathAndQuery
        End If
        ''Me.webpagehead.Description = "<meta name='description' content='" & CMS.WebPage.SEODescription() & "'>"
        Dim Ptbl As New DataTable
        Ptbl = Website.Page.GetPageDetail(Val(Request("P")))
        If (Session("UserID") Is Nothing OrElse Val(Session("UserID")) <= 0) AndAlso Ptbl.Rows.Count > 0 AndAlso Ptbl.Rows(0)("RequireLoginAuthentication") = True Then
            Response.Redirect("~/EzBusiness.aspx")
        End If

        Me.webpagehead.Description = CMS.WebPage.PageSEODescription()
        Me.webpagehead.Keywords = CMS.WebPage.PageSEOKeywords

        Dim PIDAry() = Request.RawUrl.Split("/")
        Dim PID As Integer
        If (PIDAry(1).ToLower() = "item" Or PIDAry(1).ToLower() = "detail") And PIDAry.Length > 2 Then
            PID = PIDAry(2)

        End If
        If Not Request("ID") Is Nothing Or PID > 0 Then
            Dim ArticleID As Integer
            Dim MetaTags As String = "" & Environment.NewLine
            Dim ds As New DataSet
            If (PID > 0) Then
                ArticleID = PID
            Else
                ArticleID = Val(Request("ID").ToString)
            End If


            ds = WebsiteArticles.GetArticle(ArticleID)
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0)("ArticleTypeID") >= 8 And ds.Tables(0).Rows(0)("ArticleTypeID") <= 12 Then
                    OGImage.Content = "http://joined24.com/CMS/1/Upload/" & ds.Tables(0).Rows(0)("ArticleImage")
                ElseIf ds.Tables(0).Rows(0)("ArticleTypeID") = 7 Then
                    OGImage.Content = "http://joined24.com/CMS/1/Upload/Jobslogo.jpg"
                Else
                    OGImage.Content = "http://joined24.com/CMS/1/images/Xplorewiki.png"
                End If
                MetaTags = MetaTags & "<meta property='og:title' content='" & ds.Tables(0).Rows(0)("ArticleTitle") & "' />" & Environment.NewLine
                MetaTags = MetaTags & "<meta property='og:description' content='" & IIf(ds.Tables(0).Rows(0)("ArticleText") <> "" AndAlso Len(ds.Tables(0).Rows(0)("ArticleText")) <= 200, ds.Tables(0).Rows(0)("ArticleText"), Left(ds.Tables(0).Rows(0)("ArticleText"), 200) & "...") & "' />" & Environment.NewLine
                Me.webpagehead.Description += " " & ds.Tables(0).Rows(0)("ArticleTitle")
                Page.Title = ds.Tables(0).Rows(0)("ArticleTitle")
            End If
            litMeta.Text = MetaTags
            ''If Session("Visited") Is Nothing Then
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Visit", "Visited at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Session("Visited") = Now
            ''End If
        ElseIf Not Request("OfferID") Is Nothing Then
            Dim ArticleID As Integer
            Dim MetaTags As String = "" & Environment.NewLine
            Dim ds As New DataSet
            ArticleID = Val(Request("OfferID").ToString)

            ds = WebsiteArticles.GetArticle(ArticleID)
            If ds.Tables(0).Rows.Count > 0 Then
                OGImage.Content = "http://joined24.com/CMS/Offers/Images/" & ds.Tables(0).Rows(0)("OfferImage")
                MetaTags = MetaTags & "<meta property='og:title' content='" & ds.Tables(0).Rows(0)("OfferTitle") & "' />" & Environment.NewLine
                MetaTags = MetaTags & "<meta property='og:description' content='" & IIf(ds.Tables(0).Rows(0)("OfferDescription") <> "" AndAlso Len(ds.Tables(0).Rows(0)("OfferDescription")) <= 200, ds.Tables(0).Rows(0)("OfferDescription"), Left(ds.Tables(0).Rows(0)("OfferDescription"), 200) & "...") & "' />" & Environment.NewLine
                Me.webpagehead.Description += " " & ds.Tables(0).Rows(0)("OfferTitle")
                Page.Title = ds.Tables(0).Rows(0)("OfferTitle")
            End If
            litMeta.Text = MetaTags
            ''If Session("Visited") Is Nothing Then
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Visit", "Visited at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Session("Visited") = Now
        End If


        If DDLBusinessList.Items.Count > 2 AndAlso (Session("CurrentBusinessID") Is Nothing OrElse Val(Session("CurrentBusinessID") <= 0)) Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "BusinessAddedSuccessFully", "<script>ShowSelectBusinessDlg()</script>")
        Else
            If (Session("CurrentBusinessID") <= -1 OrElse Session("CurrentBusinessID") Is Nothing) AndAlso DDLBusinessList.Items.Count > 1 Then
                Session("CurrentBusinessID") = Val(DDLBusinessList.Items(1).Value)

                Dim ds As New DataSet

                ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
                If (ds.Tables.Count > 0) Then
                    If ds.Tables(0).Rows.Count > 0 Then
                        'Session("CurrentBusinessCategoryID") = ds.Tables(0).Rows(0)("WebsiteCategoryID")
                        LoggedInUserSession.BusinessID = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")), -1, ds.Tables(0).Rows(0)("WebsiteID"))
                        LoggedInUserSession.BusinessCategoryID = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteCategoryID")), -1, ds.Tables(0).Rows(0)("WebsiteCategoryID"))
                        LoggedInUserSession.BusienssTypeID = IIf(IsDBNull(ds.Tables(0).Rows(0)("BusinessTypeID")), -1, ds.Tables(0).Rows(0)("BusinessTypeID"))

                        LoggedInUserSession.BusinessCountryID = IIf(IsDBNull(ds.Tables(0).Rows(0)("CountryID")), -1, ds.Tables(0).Rows(0)("CountryID"))
                        LoggedInUserSession.BusinessParentID = IIf(IsDBNull(ds.Tables(0).Rows(0)("ParentWebsiteID")), -1, ds.Tables(0).Rows(0)("ParentWebsiteID"))
                        LoggedInUserSession.BusinessThemeID = IIf(IsDBNull(ds.Tables(0).Rows(0)("ThemeID")), -1, ds.Tables(0).Rows(0)("ThemeID"))
                        LoggedInUserSession.BusinessTitle = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))

                        LoggedInUserSession.BusinessCurrencyCode = IIf(IsDBNull(ds.Tables(0).Rows(0)("CurrencyCode")), "", ds.Tables(0).Rows(0)("CurrencyCode"))
                        LoggedInUserSession.BusinessLogo = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteLogo")), "", ds.Tables(0).Rows(0)("WebsiteLogo"))
                        LoggedInUserSession.BusinessCreated = IIf(IsDBNull(ds.Tables(0).Rows(0)("DateCreated")), "", ds.Tables(0).Rows(0)("DateCreated"))

                        LoggedInUserSession.BusinessLat = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lat")), 0, ds.Tables(0).Rows(0)("Lat"))
                        LoggedInUserSession.BusinessLng = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lng")), 0, ds.Tables(0).Rows(0)("Lng"))

                        LoggedInUserSession.TimeZone = IIf(IsDBNull(ds.Tables(0).Rows(0)("UTCOffset")), 0, ds.Tables(0).Rows(0)("UTCOffset").ToString().Trim())
                    End If
                End If
            End If
        End If


    End Sub

    Private Sub DDLBusinessList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLBusinessList.SelectedIndexChanged
        Session("CurrentBusinessID") = DDLBusinessList.SelectedItem.Value

        Dim ds As New DataSet
        ds = Website.GetWebsiteDetails(Val(DDLBusinessList.SelectedItem.Value))
        If (ds.Tables.Count > 0) Then
            If ds.Tables(0).Rows.Count > 0 Then
                'Session("CurrentBusinessCategoryID") = ds.Tables(0).Rows(0)("WebsiteCategoryID")
                LoggedInUserSession.BusinessID = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")), -1, ds.Tables(0).Rows(0)("WebsiteID"))
                LoggedInUserSession.BusinessTitle = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))
                LoggedInUserSession.BusinessCategoryID = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteCategoryID")), -1, ds.Tables(0).Rows(0)("WebsiteCategoryID"))
                LoggedInUserSession.BusienssTypeID = IIf(IsDBNull(ds.Tables(0).Rows(0)("BusinessTypeID")), -1, ds.Tables(0).Rows(0)("BusinessTypeID"))

                LoggedInUserSession.BusinessCountryID = IIf(IsDBNull(ds.Tables(0).Rows(0)("CountryID")), -1, ds.Tables(0).Rows(0)("CountryID"))
                LoggedInUserSession.BusinessParentID = IIf(IsDBNull(ds.Tables(0).Rows(0)("ParentWebsiteID")), -1, ds.Tables(0).Rows(0)("ParentWebsiteID"))
                LoggedInUserSession.BusinessThemeID = IIf(IsDBNull(ds.Tables(0).Rows(0)("ThemeID")), -1, ds.Tables(0).Rows(0)("ThemeID"))
                LoggedInUserSession.BusinessTitle = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))

                LoggedInUserSession.BusinessCurrencyCode = IIf(IsDBNull(ds.Tables(0).Rows(0)("CurrencyCode")), "", ds.Tables(0).Rows(0)("CurrencyCode"))
                LoggedInUserSession.BusinessLogo = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteLogo")), "", ds.Tables(0).Rows(0)("WebsiteLogo"))
                LoggedInUserSession.BusinessCreated = IIf(IsDBNull(ds.Tables(0).Rows(0)("DateCreated")), "", ds.Tables(0).Rows(0)("DateCreated"))

                LoggedInUserSession.BusinessLat = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lat")), 0, ds.Tables(0).Rows(0)("Lat"))
                LoggedInUserSession.BusinessLng = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lng")), 0, ds.Tables(0).Rows(0)("Lng"))

                LoggedInUserSession.TimeZone = IIf(IsDBNull(ds.Tables(0).Rows(0)("UTCOffset")), 0, ds.Tables(0).Rows(0)("UTCOffset").ToString().Trim())
            End If
        End If
        ds = Menu.GetMenus(UserID:=LoggedInUserSession.UserID)
        Session("LoadLoggedinUserMenu") = ds
        Response.Redirect("~/Business")
    End Sub

    Public Function WebsiteThemeID() As Integer
        Dim ThemeID As Integer = 0
        Dim BID As Integer = 0
        If Not Request.RawUrl Is Nothing Then
            If (Request.RawUrl.ToLower.IndexOf("kid=") >= 0) Then
                BID = Val(Request.RawUrl.ToLower.Substring(Request.RawUrl.ToLower.IndexOf("kid=") + 4))
            End If
        End If

        If BID > 0 Then
            Dim ds As New DataSet
            ds = Website.GetWebsiteDetails(BID)
            If (ds.Tables.Count > 0) Then
                If ds.Tables(0).Rows.Count > 0 Then
                    If ds.Tables(0).Rows(0)("WebsiteCategoryID") > 0 Then
                        ThemeID = IIf(IsDBNull(ds.Tables(0).Rows(0)("ThemeID")), 0, ds.Tables(0).Rows(0)("ThemeID"))
                    End If
                End If
            End If
        End If

        Return ThemeID
    End Function
End Class