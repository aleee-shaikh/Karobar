﻿Public Class ManageBusinessses
    Inherits System.Web.UI.UserControl


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 1) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout(window.location='/Transaction','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage business screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub

    Sub LoadData()
        GrdBusinesses.DataSource = Website.GetWebsites(HttpContext.Current.Session("UserID"))
        GrdBusinesses.DataBind()
    End Sub


    Private Sub GrdBusinesses_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdBusinesses.PageIndexChanging
        GrdBusinesses.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdBusinesses_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdBusinesses.RowCommand
        If e.CommandName = "DeleteBusiness" Then
            Website.DeleteWebsite(Val(e.CommandArgument))
            LoadData()
        ElseIf e.CommandName = "EditBusiness" Then
            Session("BID") = Val(e.CommandArgument)
            Response.Redirect("/Edit-Business")
        End If
    End Sub

    Private Sub GrdBusinesses_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdBusinesses.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            'Dim LnkEdtBus As New LinkButton
            'LnkEdtBus = CType(e.Row.FindControl("LnkEditBusiness"), LinkButton)
            'If Not LnkEdtBus Is Nothing Then
            '    Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            '    LnkEdtBus.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Business/EditBusiness.aspx?BID=" & drview("WebsiteID") & "',$(window).height()*75/100,$(window).width()*57/100);return false")
            'End If

            Dim BusinessLogoImage As New System.Web.UI.WebControls.Image
            BusinessLogoImage = CType(e.Row.FindControl("BusinessLogo"), System.Web.UI.WebControls.Image)
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            If Not BusinessLogoImage Is Nothing Then
                If IsDBNull(drview("WebsiteLogo")) OrElse drview("WebsiteLogo") = "" Then
                    BusinessLogoImage.ImageUrl = "~/Images/No-Image.png"
                Else
                    BusinessLogoImage.ImageUrl = "~/CMS/" & Website.WebsiteID & "/Businesses/" & drview("WebsiteID") & "/Images" & "/" & drview("WebsiteLogo")
                End If
            End If

            Dim BusinessWebLink As New HyperLink()
            BusinessWebLink = CType(e.Row.FindControl("BusinessWebLink"), HyperLink)

            If Not BusinessWebLink Is Nothing Then
                Dim url As String = ""
                If IsDBNull(drview("WebsiteURL")) OrElse drview("WebsiteURL") = "" Then
                    If (drview("CategoryTitle").ToString().ToLower().IndexOf("job") >= 0) Then
                        url = "/job?" & drview("WebsiteTitle").Replace(" ", "") & "&KID=" & drview("WebsiteID")
                    ElseIf (drview("CategoryTitle").ToString().ToLower().IndexOf("ecommerce") >= 0) Then
                        url = "/mall?" & drview("WebsiteTitle").Replace(" ", "") & "&KID=" & drview("WebsiteID")
                    Else
                        url = "/mall?" & drview("WebsiteTitle").Replace(" ", "") & "&KID=" & drview("WebsiteID")

                    End If
                Else
                    url = drview("WebsiteURL") & ""
                End If
                BusinessWebLink.NavigateUrl = url
                BusinessWebLink.Text = url
                BusinessWebLink.Target = "_blank"
            End If
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")

        End If
    End Sub
End Class