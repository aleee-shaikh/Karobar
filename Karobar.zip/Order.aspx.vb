﻿Public Class Order
    Inherits System.Web.UI.Page

    Dim _TotalAmount As Single
    Dim _TotalQuantity As Single
    Dim _Tax As Single
    Dim _Discount As Single
    Dim _RedeemPoints As Single
    Dim _RedeemPointsAmount As Single
    Dim _DeliverCharges As Single
    Dim _BusinessDetail As New DataTable
    Dim _OrderDtl As New DataTable

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open sale invoice", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If Not Page.IsPostBack Then
            If (Not Request("OID") Is Nothing) Then
                HdnSaleID.Value = Cryptography.Decrypt(Request("OID"))
                'HdnSaleID.Value = Request("OID")
                Page.Title = "Order Detail (" & HdnSaleID.Value & ")"
            End If
            If (Not Request("BID") Is Nothing) Then
                HdnBID.Value = Cryptography.Decrypt(Request("BID"))
                'HdnBID.Value = Request("BID")
            End If

            If LoggedInUserSession.BusinessCategoryID = 4 Then
                LblOrderNo.Text = "Booking # :"
                LblOrderDate.Text = "Booking Date :"
            End If
        End If

        If Val(HdnSaleID.Value) > 0 Then
            Dim tbl As New DataTable, tbl1 As New DataTable
            Dim ds As New DataSet
            ds = Products.GetOrderDetails(Val(HdnBID.Value), Val(HdnSaleID.Value))
            tbl = ds.Tables(0)
            tbl1 = ds.Tables(1)

            _OrderDtl = tbl
            If tbl.Rows.Count > 0 Then
                lblCustomer.Text = IIf(IsDBNull(tbl.Rows(0)("UserName")), "", tbl.Rows(0)("UserName"))
                If LoggedInUserSession.BusinessCategoryID = 4 Then
                    LblInvDate.Text = IIf(IsDBNull(tbl.Rows(0)("Dated")), "", tbl.Rows(0)("Dated")) & IIf(IsDBNull(tbl.Rows(0)("OrderToDate")), "", " - " & tbl.Rows(0)("OrderToDate"))
                Else
                    LblInvDate.Text = IIf(IsDBNull(tbl.Rows(0)("Dated")), "", tbl.Rows(0)("Dated"))
                End If

                lblInvNo.Text = IIf(IsDBNull(tbl.Rows(0)("OrderID")), "", tbl.Rows(0)("OrderID"))
                HdnCustomerEmail.Value = IIf(IsDBNull(tbl.Rows(0)("UserEmail")) OrElse tbl.Rows(0)("UserEmail").ToString = "", "", tbl.Rows(0)("UserEmail"))
            End If
            GrdProducts.DataSource = tbl1
            GrdProducts.DataBind()

            LoadBusinessDetails()

            'If (Not Request("Action") Is Nothing) Then
            'If Request("Action") = "SendInvoiceEmail" Then
            'SendInvoiceEmail()
            'End If
            'End If
        End If
    End Sub

    Sub LoadBusinessDetails()
        Dim ds As New DataSet
        ds = Website.GetWebsiteDetails(Val(HdnBID.Value))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                _BusinessDetail = ds.Tables(0)
                lblInvoiceTitle.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
                lblBusinessTelephone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
                lblBusinessAddres.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
                lblBusinessCityPostCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")) OrElse ds.Tables(0).Rows(0)("City").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("City") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")) OrElse ds.Tables(0).Rows(0)("Town").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("Town") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")) OrElse ds.Tables(0).Rows(0)("ZipCode").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("ZipCode") & ",")

            End If
        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then

            'e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            'e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
            _TotalQuantity += (drview("ProductQuantity"))
            _TotalAmount += (drview("ProductPrice") * drview("ProductQuantity"))

        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim lblTotalItems As New System.Web.UI.WebControls.Label
            Dim lblTotal As New System.Web.UI.WebControls.Label
            lblTotalItems = CType(e.Row.FindControl("lblTotalItems"), Label)
            lblTotal = CType(e.Row.FindControl("lblTotal"), Label)

            If Not lblTotal Is Nothing Then
                lblTotalItems.Text = _TotalQuantity
                lblTotal.Text = _TotalAmount
            End If


        End If
    End Sub

    'Private Sub lnkSendInvoiceEmail_Click(sender As Object, e As EventArgs) Handles lnkSendInvoiceEmail.Click
    '    SendInvoiceEmail()
    '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InvoiceSentSuccessfully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale Invoice sent successfully to " & HdnCustomerEmail.Value & "','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
    'End Sub

    'Sub SendInvoiceEmail()
    '    Dim FromUserEmail As String = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
    '    Dim EmailSubject As String = "Sale Invoice #" & lblInvNo.Text
    '    Dim ToUserEmail As String = HdnCustomerEmail.Value
    '    Dim emailBody As String = HdnInvoice.Value
    '    Dim fileName As String = "~/Modules/Karobar/Reports/PDF/" & lblInvNo.Text & ".pdf"
    '    ''WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, "", "", "", emailBody)

    '    If (System.IO.File.Exists(fileName) = False) Then
    '        GenerateFile.Generate(GenerateFile.ExportFormat.PDF, HdnInvoice.Value, fileName)
    '    End If

    '    Dim EmailTemplateFile As String = ReferenceData.Setting("SaleInvoiceTemplate", "SaleInvoiceTemplate")
    '    Dim ReplacingWords As String = ""

    '    ReplacingWords = ReplacingWords & "[CustomerName]♦" & _OrderDtl.Rows(0)("CustomerName") & "¤"
    '    ReplacingWords = ReplacingWords & "[UserEmail]♦" & _OrderDtl.Rows(0)("CustomerEmail") & "¤"
    '    ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
    '    'ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
    '    'ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
    '    'ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
    '    'ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
    '    'ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
    '    'ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
    '    'ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessID]♦" & _BusinessDetail.Rows(0)("WebsiteID") & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & _BusinessDetail.Rows(0)("WebsiteLogo").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & _BusinessDetail.Rows(0)("CurrencyCode").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & _BusinessDetail.Rows(0)("Email").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & _BusinessDetail.Rows(0)("Phone").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessFax]♦" & _BusinessDetail.Rows(0)("Fax").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessCity]♦" & _BusinessDetail.Rows(0)("City").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessTown]♦" & _BusinessDetail.Rows(0)("Town").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & _BusinessDetail.Rows(0)("CategoryTitle").ToString() & "¤"
    '    ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & _BusinessDetail.Rows(0)("Address").ToString() & "¤"

    '    WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, EmailTemplateFile, fileName, ReplacingWords, "")

    'End Sub
End Class