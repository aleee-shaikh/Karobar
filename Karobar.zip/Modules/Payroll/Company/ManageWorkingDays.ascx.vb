﻿Public Class ManageWorkingDays
    Inherits System.Web.UI.UserControl

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init




    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage products screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If (Not Page.IsPostBack) Then
            For i As Integer = 1 To 12
                DDLMonths.Items.Add(New ListItem(MonthName(i), i))
            Next
            For i As Integer = 0 To 50
                DDLYear.Items.Add(New ListItem(2000 + i, 2000 + i))
            Next


            Dim M As Integer = Now.Month
            Dim Y As Integer = Now.Year
            DDLMonths.SelectedValue = M
            DDLYear.SelectedValue = Y
            LoadData(M, Y)
        End If

    End Sub

    Sub LoadData(Month As Integer, Year As Integer)
        Dim TotalDaysInMonth As Integer
        Dim dt As DateTime = Month & "/01/" & Year ' Now.ToString("MM/01/yyyy")
        Dim tbl As New DataTable
        Dim companyOffDaystbl As New DataTable
        tbl.Columns.Add("Index")
        tbl.Columns.Add("MonthDate")
        tbl.Columns.Add("WeekDayName")
        tbl.Columns.Add("IsCompanyOffDay")
        tbl.Columns.Add("IsHoliday")
        tbl.Columns.Add("DayNotes")
        tbl.Columns.Add("DayNotesCount")
        tbl.Columns.Add("DateMMDDYYYY")
        tbl.Columns.Add("EventTypeID")

        Dim EventsTbl As New DataTable
        EventsTbl = BusinessEvents.GetEvents(Val(Session("CurrentBusinessID")), CDate(Month & "/01/" & Year), CDate(Month & "/" & DateTime.DaysInMonth(Year, Month) & "/" & Year), BusinessEvents.EventTypes.Holidays, "", -1)

        companyOffDaystbl = Payroll.GetCompanyOFFDays(Val(Session("CurrentBusinessID")))
        TotalDaysInMonth = DateTime.DaysInMonth(Year, Month)
        For i As Integer = 0 To TotalDaysInMonth - 1
            Dim dr As DataRow
            dr = tbl.NewRow
            dr("Index") = i + 1
            dr("MonthDate") = dt.AddDays(i).ToString("dd/MM/yyyy")
            dr("DateMMDDYYYY") = dt.AddDays(i).ToString("MM/dd/yyyy")
            dr("WeekDayName") = WeekdayName(Weekday(dt.AddDays(i)))
            dr("IsCompanyOffDay") = 0
            dr("IsHoliday") = 0
            dr("EventTypeID") = 0
#Region "Check for weekly off days"
            If companyOffDaystbl.Rows.Count > 0 Then
                If companyOffDaystbl.Rows(0)("Monday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "monday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Tuesday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "tuesday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Wednesday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "wednesday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Thursday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "thursday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Friday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "friday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Saturday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "saturday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
                If companyOffDaystbl.Rows(0)("Sunday") Then
                    If dr("WeekDayName").ToString().ToLower().Trim() = "sunday" Then
                        dr("IsCompanyOffDay") = 1
                    End If
                End If
            End If
#End Region

            Dim dayNotesCount As Integer = 0
            For j As Integer = 0 To EventsTbl.Rows.Count - 1
                If dt.AddDays(i).ToString("yyyyMMdd") = CDate(EventsTbl.Rows(j)("EventDate")).ToString("yyyyMMdd") Then
                    Dim DayNotes As String = ""
                    If (EventsTbl.Rows(j)("Reason").ToString().Length > 20) Then
                        DayNotes = EventsTbl.Rows(j)("Reason").ToString().Substring(0, 20) & "...<br/>"
                    Else
                        DayNotes = EventsTbl.Rows(j)("Reason") & "<br/>"
                    End If
                    dr("DayNotes") = dr("DayNotes") & DayNotes

                    If (EventsTbl.Rows(j)("EventTypeID") = BusinessEvents.EventTypes.Holidays) Then
                        dr("IsHoliday") = 1
                        ''dr("EventType") = BusinessEvents.EventTypes.Reminders
                    End If
                    If (EventsTbl.Rows(j)("EventTypeID") = BusinessEvents.EventTypes.Reminders) Then
                        'dr("EventType") = BusinessEvents.EventTypes.Reminders
                        dr("EventTypeID") = EventsTbl.Rows(j)("EventTypeID")
                    End If


                    dayNotesCount += 1
                End If
            Next
            dr("DayNotesCount") = dayNotesCount
            tbl.Rows.Add(dr)
        Next
        Repeater1.DataSource = tbl
        Repeater1.DataBind()
    End Sub

    Protected Sub BtnLoadCalendar_Click1(sender As Object, e As EventArgs)
        LoadData(DDLMonths.SelectedValue, DDLYear.SelectedValue)
    End Sub
End Class