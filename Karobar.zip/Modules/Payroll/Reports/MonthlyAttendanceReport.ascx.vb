﻿Public Class MonthlyAttendanceReport
    Inherits System.Web.UI.UserControl
    Public PersonHaveSupplierRights As Boolean

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            txtFromDate.Text = Now.ToString("01-MM-yyyy")
            txtToDate.Text = Now.ToString("dd-MM-yyyy")
            DDLDepartments.DataValueField = "DepartmentID"
            DDLDepartments.DataTextField = "DepartmentName"
            DDLDepartments.DataSource = Payroll.GetDepartments(Val(Session("CurrentBusinessID")))
            DDLDepartments.DataBind()
            DDLDepartments.Items.Insert(0, New ListItem(" -- All Departments -- ", "-1"))

            DDLShifts.DataValueField = "ShiftID"
            DDLShifts.DataTextField = "ShiftName"
            DDLShifts.DataSource = Payroll.GetWokringShifts(Val(Session("CurrentBusinessID")))
            DDLShifts.DataBind()
            DDLShifts.Items.Insert(0, New ListItem(" -- All Shifts -- ", "-1"))

            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "goBack", "history.go(-1);", True)
        'End If
        PersonHaveSupplierRights = Person.DoesPersonHavePageRights(Session("UserID"), 49) 'Person.PersonHasRights(Session("UserID"), ",49,")
        If PersonHaveSupplierRights = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage people screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        Else


        End If
    End Sub

    Sub LoadData()
        LblReportDate.Text = CDate(General.GetDateinMMDDYYYY(txtFromDate.Text, "-")).ToString("dddd, dd-MMM-yyyy") & " To " & CDate(General.GetDateinMMDDYYYY(txtToDate.Text, "-")).ToString("dddd, dd-MMM-yyyy")
        LblReportDepartment.Text = DDLDepartments.SelectedItem.Text
        LblReportShift.Text = DDLShifts.SelectedItem.Text
        GrdEmpAttendance.DataSource = Payroll.GetStaffMonthlyReport(Session("CurrentBusinessID"), General.GetDateinMMDDYYYY(txtFromDate.Text, "-"), General.GetDateinMMDDYYYY(txtToDate.Text, "-"), DDLDepartments.SelectedValue, DDLShifts.SelectedValue)
        GrdEmpAttendance.DataBind()
    End Sub


    Private Sub GrdEmpAttendance_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdEmpAttendance.PageIndexChanging
        GrdEmpAttendance.PageIndex = e.NewPageIndex
        LoadData()
    End Sub


    Private Sub GrdEmpAttendance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdEmpAttendance.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

End Class