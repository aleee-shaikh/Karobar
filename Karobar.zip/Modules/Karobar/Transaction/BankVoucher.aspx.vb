﻿Imports System.Data.SqlClient

Public Class BankVoucher
    Inherits System.Web.UI.Page


    Private Sub PaymentsPayReceived_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 42) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then
            If Not Page.IsPostBack Then
                DDLCreditAccount.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("ParentAccountHeadID4BankvoucherPaymentPayReceived", "10", Session("CurrentBusinessID")))
                DDLCreditAccount.DataTextField = "AccountHeadName"
                DDLCreditAccount.DataValueField = "AccountHeadID"
                DDLCreditAccount.DataBind()


                GenericBankVoucherRow1.AddColumn("ToAccountHead", New DropDownList)
                GenericBankVoucherRow1.AddColumn("Particular", New TextBox)
                GenericBankVoucherRow1.AddColumn("ChequeNo", New TextBox)
                GenericBankVoucherRow1.AddColumn("BankCharges", New TextBox)
                GenericBankVoucherRow1.AddColumn("Tax", New TextBox)
                GenericBankVoucherRow1.AddColumn("Amount", New TextBox)
                GenericBankVoucherRow1.AddColumn("Total", New TextBox)

                txtDate.Text = Now.ToString("dd-MM-yyyy")
            End If
        End If
    End Sub


    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim BankPaymentTbl = New DataTable
        Dim BankPaymentTotal As Single
        Dim CreditHeadBalance As Single
        Dim CreditHeadtbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(DDLCreditAccount.SelectedValue & ",")
        If (CreditHeadtbl.Rows.Count > 0) Then
            CreditHeadBalance = CreditHeadtbl.Rows(0)("Balance")
        End If

        BankPaymentTbl = GenericBankVoucherRow1.GetTransactionData
        For i As Integer = 0 To BankPaymentTbl.Rows.Count - 1
            BankPaymentTotal += Val(BankPaymentTbl.Rows(i)("Total"))
        Next
        If BankPaymentTotal > CreditHeadBalance Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankBankExceeding", "<script>parent.ShowMessage('Total payment amount is exceeding the current balance of selected bank balance.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            Return
        End If

        Dim tbl As New DataTable
        Dim TID As Integer = -1
        Dim BankID As Integer = -1

        If DDLCreditAccount.Items.Count > 0 Then
            BankID = DDLCreditAccount.SelectedItem.Value
        End If

        Dim DatedAry() = txtDate.Text.Replace("/", "-").Split("-")

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try

            connection.Open()
            trans = connection.BeginTransaction()

            tbl = Transactions.AddTransaction(Session("CurrentBusinessID"), txtReference.Text.Trim, "BPV", txtParticular.Text, "Active", True, CDate(DatedAry(1) & "-" & DatedAry(0) & "-" & DatedAry(2)), trans:=trans)
            If tbl.Rows.Count > 0 Then
                TID = tbl.Rows(0)("TransactionID")
                Transactions.AddTransactionDetails(TID, DDLCreditAccount.SelectedItem.Value, True, txtParticular.Text, 0, GenericBankVoucherRow1.TotalAmount, 0, 0, "", trans:=trans)
                tbl = New DataTable
                tbl = GenericBankVoucherRow1.GetTransactionData
                For i As Integer = 0 To tbl.Rows.Count - 2
                    Transactions.AddTransactionDetails(TID, tbl.Rows(i)("ToAccountHead"), False, tbl.Rows(i)("Particular"), tbl.Rows(i)("Total"), 0, tbl.Rows(i)("BankCharges"), tbl.Rows(i)("Tax"), tbl.Rows(i)("ChequeNo"), trans:=trans)
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Bank payment done successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
                ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Transaction done", "Transaction ID :" & TID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                Log.Notifications_Add("Bank Payment " & GenericBankVoucherRow1.TotalAmount, TID, "Bank Payment", GenericBankVoucherRow1.TotalAmount)


            End If

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionAddingIssue", "<script>parent.ShowMessage('Unable to process transaction','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try



    End Sub
End Class