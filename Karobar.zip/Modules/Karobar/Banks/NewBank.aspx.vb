﻿Public Class NewBank
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 52) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then

            If Not Request("BID") Is Nothing Then
                HdnBID.Value = Val(Request("BID"))

                If (Val(HdnBID.Value) > 0) Then
                    lblScreenTitle.Text = "Update Bank"
                    Dim dr() As DataRow
                    dr = Bank.GetBanksList(Session("CurrentBusinessID"), "").Select(" BankID=" & Val(HdnBID.Value))
                    Dim found As Boolean = False
                    Dim BID As Integer = Session("CurrentBusinessID")

                    For Each row In dr
                        txtBankName.Text = row("BankName")
                        txtBankDescription.Text = row("BankDescription")
                        found = True
                        BID = Val(row("WebsiteID"))
                    Next

                    If found = False OrElse BID <> Session("CurrentBusinessID") Then
                        BtnSave.Visible = False
                        BtnSave.Enabled = False
                    End If
                Else
                    BtnSave.Visible = False
                    BtnSave.Enabled = False
                End If
            Else
                    lblScreenTitle.Text = "Add New Bank"
            End If

        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        If Val(HdnBID.Value) > 0 Then
            tbl = Bank.UpdateBank(Session("CurrentBusinessID"), Val(HdnBID.Value), HttpContext.Current.Session("UserID"), txtBankName.Text.Trim, txtBankDescription.Text.Trim)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "AccountHeadUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Bank updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
            Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "Bank", "Updated Bank " & txtBankName.Text.Trim, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=HdnBID.Value)
        Else
            tbl = Bank.AddBank(Session("CurrentBusinessID"), HttpContext.Current.Session("UserID"), txtBankName.Text.Trim, txtBankDescription.Text.Trim)
            If tbl.Rows.Count = 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankAlreadyExist", "<script>parent.ShowMessage('Bank already exist!','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Bank added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")

                Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "Bank", "Added New Bank " & txtBankName.Text.Trim, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=tbl.Rows(0)("BankID"))
                txtBankDescription.Text = ""
                txtBankName.Text = ""
            End If
        End If
    End Sub
End Class