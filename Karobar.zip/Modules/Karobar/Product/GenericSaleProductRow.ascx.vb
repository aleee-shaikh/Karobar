﻿Public Class GenericSaleProductRow
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable
    Dim _TotalAmount As Single
    Dim PlacingWebsiteOrder As Boolean = False
    Dim _Ordertbl As New DataTable

    Public Sub AddColumn(ByVal ColumnName As String, Optional ByVal Control As Object = Nothing)

        If Not _tbl.Columns.Contains(ColumnName) Then
            _tbl.Columns.Add(ColumnName)
        End If

        Session(Me.ClientID & "SaleOrder") = _tbl
    End Sub

    Public Function GetSaleData() As DataTable
        Return _tbl
    End Function

    Public ReadOnly Property TotalAmount
        Get
            Return _TotalAmount
        End Get
    End Property

    Sub BindGrid(Optional ByVal Control As Object = Nothing)
        Dim dr As DataRow
        If _tbl.Rows.Count = 0 Then
            dr = _tbl.NewRow
            _tbl.Rows.Add(dr)
        End If
        GridView1.DataSource = _tbl
        GridView1.DataBind()



        ''AddGridControl()
    End Sub


    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Session(Me.ClientID & "SaleOrder") Is Nothing Then
            _tbl = CType(Session(Me.ClientID & "SaleOrder"), DataTable)
            BindGrid()
        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack Then
            UpdateRows
        Else
            GridView1.Columns(2).HeaderText = ReferenceData.Setting("LblProductName", "Product", Session("CurrentBusinessID"))
            GridView1.Columns(3).HeaderText = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))
            GridView1.Columns(4).HeaderText = ReferenceData.Setting("LblProductSalePrice", "Price", Session("CurrentBusinessID"))

            GridView1.Columns(5).HeaderText = ReferenceData.Setting("LblGridProductStockQuantity", "Stock Qty", Session("CurrentBusinessID"))
            ''GridView1.Columns(5).Visible = False
            GridView1.Columns(6).HeaderText = ReferenceData.Setting("LblGridProductQuantity", "Quantity", Session("CurrentBusinessID"))
            GridView1.Columns(7).HeaderText = ReferenceData.Setting("LblProductDiscount", "Discount", Session("CurrentBusinessID"))

            GridView1.Columns(8).HeaderText = ReferenceData.Setting("LblGridSaleProductTotal", "Total", Session("CurrentBusinessID"))

            For i As Integer = _tbl.Rows.Count - 1 To 0 Step -1
                _tbl.Rows.RemoveAt(i)
            Next
            Session(Me.ClientID & "SaleOrder") = _tbl
            BindGrid()

        End If


    End Sub

    Private Sub GridView1_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridView1.RowCommand
        If e.CommandName = "AddRow" Then
            Dim dr As DataRow
            dr = _tbl.NewRow
            _tbl.Rows.Add(dr)
        ElseIf e.CommandName = "DeleteRow" Then
            _tbl.Rows.RemoveAt(Val(e.CommandArgument) - 1)
        End If
        Session(Me.ClientID & "SaleOrder") = _tbl
        BindGrid()

    End Sub

    Public Sub AddRow()
        Dim dr As DataRow
        dr = _tbl.NewRow
        _tbl.Rows.Add(dr)

    End Sub

    Public Sub UpdateRows()
        For i As Integer = 0 To GridView1.Rows.Count - 1
            'For j As Integer = 0 To _tbl.Columns.Count - 1 '' GridView1.Rows(i).Cells.Count - 1
            '    If GridView1.Rows(i).Cells(j + 1).Controls.Count > 0 Then
            '        If TypeOf GridView1.Rows(i).Cells(j + 1).Controls(1) Is TextBox Then
            '            Dim txt As New TextBox
            '            txt = CType(GridView1.Rows(i).Cells(j + 1).Controls(1), TextBox)
            '            _tbl.Rows(i)(j) = txt.Text
            '        Else
            '            Dim ddl As New DropDownList
            '            ddl = CType(GridView1.Rows(i).Cells(j + 1).Controls(1), DropDownList)
            '            _tbl.Rows(i)(j) = ddl.SelectedItem.Value
            '        End If

            '    End If


            'Next


            Dim ddl As New DropDownList
            ddl = CType(GridView1.Rows(i).FindControl("DDLProducts"), DropDownList)
            _tbl.Rows(i)("Product") = ddl.SelectedItem.Value

            Dim txtQty As New TextBox
            txtQty = CType(GridView1.Rows(i).FindControl("txtQuantity"), TextBox)
            _tbl.Rows(i)("Quantity") = txtQty.Text

            Dim txtStockQty As New TextBox
            txtStockQty = CType(GridView1.Rows(i).FindControl("txtStockQty"), TextBox)
            _tbl.Rows(i)("StockQuantity") = txtStockQty.Text

            Dim txtUnit As New TextBox
            txtUnit = CType(GridView1.Rows(i).FindControl("txtUnit"), TextBox)
            _tbl.Rows(i)("Unit") = txtUnit.Text

            Dim txtPrice As New TextBox
            txtPrice = CType(GridView1.Rows(i).FindControl("txtPrice"), TextBox)
            _tbl.Rows(i)("Price") = txtPrice.Text

            Dim txtDiscount As New TextBox
            txtDiscount = CType(GridView1.Rows(i).FindControl("txtDiscount"), TextBox)
            _tbl.Rows(i)("Discount") = txtDiscount.Text

            Dim txtTotal As New TextBox
            txtTotal = CType(GridView1.Rows(i).FindControl("txtTotal"), TextBox)
            _tbl.Rows(i)("Total") = txtTotal.Text

        Next
    End Sub

    Public Sub AddOrderDetails(OrderDetails As DataTable)
        ''_tbl.Rows.RemoveAt(0)
        Dim dr As DataRow
        For i As Integer = 0 To OrderDetails.Rows.Count - 1
            dr = _tbl.NewRow
            dr("Product") = OrderDetails.Rows(i)("ProductID")
            dr("Unit") = OrderDetails.Rows(i)("Unit")
            dr("Quantity") = OrderDetails.Rows(i)("Quantity")
            dr("Discount") = OrderDetails.Rows(i)("Discount")
            dr("Price") = OrderDetails.Rows(i)("Price")
            dr("Total") = (OrderDetails.Rows(i)("Price") * OrderDetails.Rows(i)("Quantity")) - OrderDetails.Rows(i)("Discount")
            _tbl.Rows.Add(dr)
        Next
        dr = _tbl.NewRow
        _tbl.Rows.Add(dr)
        _Ordertbl = _tbl
        Session(Me.ClientID & "SaleOrder") = _tbl
        BindGrid()
        PlacingWebsiteOrder = True
    End Sub

    Private Sub GridView1_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridView1.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim Btn As New Button
            If e.Row.RowIndex = _tbl.Rows.Count - 1 Then
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "+"
                Btn.CommandName = "AddRow"
            Else
                Btn.Width = "25"
                Btn = CType(e.Row.Cells(0).FindControl("Btn"), Button)
                Btn.Text = "-"
                Btn.CommandName = "DeleteRow"
            End If


            Dim ddl As New DropDownList
            ddl = CType(e.Row.FindControl("DDLProducts"), DropDownList)
            ddl.DataTextField = "ArticleTitle"
            ddl.DataValueField = "ArticleID"
            ddl.DataSource = Products.GetProductsList(Session("CurrentBusinessID"))
            ddl.DataBind()
            If _tbl.Columns.Contains("Product") Then
                ddl.SelectedValue = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Product")), "", _tbl.Rows(e.Row.RowIndex)("Product"))
            End If

            ddl.AutoPostBack = True
            ddl.Attributes.Add("RowIdx", e.Row.RowIndex)
            AddHandler ddl.SelectedIndexChanged, AddressOf ProductDDL_SelectedIndexChanged

            Dim txtPrice As New TextBox
            txtPrice = CType(e.Row.FindControl("txtPrice"), TextBox)
            If Not txtPrice Is Nothing Then
                txtPrice.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("Price") Then
                    txtPrice.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Price")), "", _tbl.Rows(e.Row.RowIndex)("Price"))
                End If

            End If


            Dim txtDiscount As New TextBox
            txtDiscount = CType(e.Row.FindControl("txtDiscount"), TextBox)
            If Not txtDiscount Is Nothing Then
                txtDiscount.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("Discount") Then
                    txtDiscount.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Discount")), "", _tbl.Rows(e.Row.RowIndex)("Discount"))
                End If

            End If

            Dim txtTotal As New TextBox
            txtTotal = CType(e.Row.FindControl("txtTotal"), TextBox)
            If Not txtTotal Is Nothing Then
                txtTotal.CssClass = "form-control numeric rowTotal"
                If _tbl.Columns.Contains("Total") Then
                    txtTotal.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Total")), "", _tbl.Rows(e.Row.RowIndex)("Total"))
                End If

            End If
            txtTotal.Enabled = False

            Dim txtStockQty As New TextBox
            txtStockQty = CType(e.Row.FindControl("txtStockQty"), TextBox)
            If Not txtTotal Is Nothing Then
                txtStockQty.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("StockQuantity") Then
                    txtStockQty.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("StockQuantity")), "", _tbl.Rows(e.Row.RowIndex)("StockQuantity"))
                End If

            End If

            Dim txtQty As New TextBox
            txtQty = CType(e.Row.FindControl("txtQuantity"), TextBox)
            If Not txtQty Is Nothing Then
                txtQty.CssClass = "form-control numeric"
                If _tbl.Columns.Contains("Quantity") Then
                    txtQty.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Quantity")), "", _tbl.Rows(e.Row.RowIndex)("Quantity"))
                End If

                ''txtQty.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Quantity")), "", _tbl.Rows(e.Row.RowIndex)("Quantity"))
                txtQty.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "');")
                txtDiscount.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "');")
                txtPrice.Attributes.Add("onkeyup", "ApplyNumericValidation();UpdatePrice('" & txtPrice.ClientID & "','" & txtQty.ClientID & "','" & txtDiscount.ClientID & "','" & txtTotal.ClientID & "');")
            End If

            Dim txtUnit As New TextBox
            txtUnit = CType(e.Row.FindControl("txtUnit"), TextBox)
            If Not txtUnit Is Nothing Then
                If _tbl.Columns.Contains("Unit") Then
                    txtUnit.Text = IIf(IsDBNull(_tbl.Rows(e.Row.RowIndex)("Unit")), "", _tbl.Rows(e.Row.RowIndex)("Unit"))
                End If

            End If




        End If

        If (e.Row.RowType = DataControlRowType.Footer) Then
            Dim TotalLbl As New Label
            Dim TotalPrice As Single
            For i As Integer = 0 To _tbl.Rows.Count - 1
                If _tbl.Columns.Contains("Total") Then
                    TotalPrice += Val(IIf(IsDBNull(_tbl.Rows(i)("Total")), "", _tbl.Rows(i)("Total")))
                End If

            Next

            TotalLbl = CType(e.Row.FindControl("AmountTotal"), Label)
            If Not TotalLbl Is Nothing Then
                TotalLbl.Text = TotalPrice
                _TotalAmount = TotalPrice
            End If
        End If
    End Sub

    Protected Sub ProductDDL_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ridx As Integer = sender.Attributes("RowIdx")
        Dim ProductUnit As New TextBox
        Dim ProductPrice As New TextBox
        Dim txtStockQty As New TextBox
        Dim ProductID As Integer
        ProductUnit = CType(GridView1.Rows(ridx).FindControl("txtUnit"), TextBox)
        ProductPrice = CType(GridView1.Rows(ridx).FindControl("txtPrice"), TextBox)
        txtStockQty = CType(GridView1.Rows(ridx).FindControl("txtStockQty"), TextBox)
        ProductID = sender.selecteditem.value

        If Not (ProductUnit Is Nothing) Then
            Dim ds As New DataSet
            ds = Products.GetProductDetails(Session("CurrentBusinessID"), Val(ProductID))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    ProductUnit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UnitAsText")), "", ds.Tables(0).Rows(0)("UnitAsText"))
                    If Not ProductPrice Is Nothing Then
                        ProductPrice.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("SalePrice")), "", ds.Tables(0).Rows(0)("SalePrice"))
                    End If
                    If Not txtStockQty Is Nothing Then
                        txtStockQty.Text = ds.Tables(0).Rows(0)("Purchased") - ds.Tables(0).Rows(0)("Sold")
                    End If
                End If
            End If
        End If
    End Sub

End Class