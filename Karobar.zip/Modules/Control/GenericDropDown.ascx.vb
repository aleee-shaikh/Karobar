﻿Public Class GenericDropDown
    Inherits System.Web.UI.UserControl
    Dim _Width As String
    Dim _DataTable As DataTable
    Dim _Lst As New List(Of ListItem)

    Public Property Width() As String
        Get
            Return _Width
        End Get
        Set(ByVal value As String)
            _Width = value
        End Set
    End Property


    Public Property SelectedValue() As String
        Get
            Return HdnSelectedItemValue.Value
        End Get
        Set(ByVal value As String)
            HdnSelectedItemValue.Value = value
            For Each itm In _Lst
                If itm.Value = value Then
                    HdnSelectedItemText.Value = itm.Text
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "key", "<script>SetSelectedValue('" & itm.Text & "','" & itm.Value & "')</script>", False)
                    Exit For
                End If
            Next

        End Set
    End Property

    Public ReadOnly Property SelectedText() As String
        Get
            Return HdnSelectedItemText.Value
        End Get
    End Property

    Public ReadOnly Property Items() As List(Of ListItem)
        Get
            Return _Lst
        End Get
    End Property

    Public Sub AddNewItem(ByVal Text As String, ByVal Value As String, Optional ByVal Style As String = "")
        DDLItems.Controls.Add(New LiteralControl("<li><a style='" & Style & "' href='javascript:SetSelectedValue(""" & Text & """,""" & Value & """)'>" & Text & "</a></li>"))
        _Lst.Add(New ListItem(Text, Value))
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            HdnSelectedItemText.Value = "--Select--"
            HdnSelectedItemValue.Value = "-1"
        End If
    End Sub

End Class
