﻿Public Class WebsiteContactUs
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            


            DDLBusinesses.DataTextField = "WebsiteTitle"
            DDLBusinesses.DataValueField = "WebsiteID"
            DDLBusinesses.DataSource = Website.GetWebsites()
            DDLBusinesses.DataBind()


            DDLTicketTypes.DataSource = Tickets.GetTicketTypes(DDLBusinesses.SelectedItem.Value)
            DDLTicketTypes.DataTextField = "TicketType"
            DDLTicketTypes.DataValueField = "TicketTypeID"
            DDLTicketTypes.DataBind()
            
        End If
    End Sub

    Sub LoadData()
        GrdWebsiteUsersContactUs.DataSource = Tickets.GetTickets(DDLBusinesses.SelectedItem.Value, DDLTicketTypes.SelectedItem.Value, txtSearchText.Text.Trim)
        GrdWebsiteUsersContactUs.DataBind()
    End Sub

    Private Sub GrdWebsiteUsersContactUs_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdWebsiteUsersContactUs.PageIndexChanging
        GrdWebsiteUsersContactUs.PageIndex = e.NewPageIndex
        LoadData()
    End Sub




    Private Sub GrdWebsiteUsersContactUs_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdWebsiteUsersContactUs.RowCommand
        'If e.CommandName = "EditUser" Then
        '    Session("EditUserID") = e.CommandArgument
        '    Response.Redirect("~/Admin/Admin.aspx?P=Users&S=2")
        'ElseIf e.CommandName = "EnableDisableWebAccess" Then
        '    Website.User.EnableDisableWebAccess(e.CommandArgument, (e.CommandSource.text.IndexOf("Disable") >= 0))
        '    GrdWebsiteUsersContactUs.DataSource = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")),SearchText:= txtFilter.Text.Trim, IsAdmin)
        '    GrdWebsiteUsersContactUs.DataBind()
        'ElseIf e.CommandName = "DeleteUser" Then
        '    Website.User.DeleteUser(e.CommandArgument)
        '    GrdWebsiteUsersContactUs.DataSource = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")),SearchText:= txtFilter.Text.Trim)
        '    GrdWebsiteUsersContactUs.DataBind()
        'End If
    End Sub

    Private Sub BtnSearchUser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearchUser.Click
        LoadData()
    End Sub
End Class