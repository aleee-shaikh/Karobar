﻿Public Class Upload
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            Dim tbl As New DataTable
            tbl = WebsiteArticles.GetArticleTypes().Tables(1)
            If tbl.Rows.Count > 0 Then
                DDLArticleType.DataSource = tbl
                DDLArticleType.DataTextField = "ArticleType"
                DDLArticleType.DataValueField = "ArticleTypeID"
                DDLArticleType.DataBind()
                ClearForm()
            End If
        End If

    End Sub

    Private Sub BtnUpload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpload.Click
        
        Dim ArticleID As Integer
        ArticleID = WebsiteArticles.AddArticles(DDLArticleType.SelectedItem.Value, txtArticleTitle.Text.Trim, txtArticleDesc.Text.Trim, UploadFile1.FileName, True, 0, "", HttpContext.Current.Session("UserID"))
        SaveArticleImage(ArticleID, UploadFile1)
        SaveArticleImage(ArticleID, UploadFile2)
        SaveArticleImage(ArticleID, UploadFile3)
        SaveArticleImage(ArticleID, UploadFile4)
        SaveArticleImage(ArticleID, UploadFile5)
        SaveArticleImage(ArticleID, UploadFile6)
        SaveArticleImage(ArticleID, UploadFile7)
        SaveArticleImage(ArticleID, UploadFile8)
        SaveArticleImage(ArticleID, UploadFile9)
        SaveArticleImage(ArticleID, UploadFile10)
        ClearForm()
        MultiView1.ActiveViewIndex = 1
    End Sub

    Sub SaveArticleImage(ByVal ArticleID As Integer, ByRef Fileupload As FileUpload)
        If Fileupload.FileName <> "" Then
            Dim File As String = Server.MapPath(ReferenceData.Setting("UploadPath4Articles", "/CMS/" & Website.WebsiteID & "/Upload/") & Fileupload.FileName)
            Fileupload.SaveAs(File)
            WebsiteArticles.AddArticleImage(ArticleID, Fileupload.FileName, "", HttpContext.Current.Session("UserID"))
        End If
    End Sub

    Sub ClearForm()
        txtArticleDesc.Text = ""
        txtArticleTitle.Text = ""
        txtWebURL.Text = ""
        DDLArticleType.SelectedIndex = 0
        MultiView1.ActiveViewIndex = 0

    End Sub

    Private Sub LnkUploadMore_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkUploadMore.Click
        ClearForm()
    End Sub
End Class