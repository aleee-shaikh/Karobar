﻿Public Class ManagePO
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtPOFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtPOToDate.Text = Now.ToString("dd-MM-yyyy")
            LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))

            Dim tbl As New DataTable
            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Supplier)
            DDLSupplier.DataValueField = "UserID"
            DDLSupplier.DataTextField = "FirstName"
            DDLSupplier.DataSource = tbl
            DDLSupplier.DataBind()

            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim ds As New DataSet
        Dim FDate As String = ""
        Dim FdateAry() = txtPOFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtPOToDate.Text.Replace("/", "-").Split("-")
        Dim VID As Integer = -1

        If DDLSupplier.Items.Count > 0 Then
            VID = Val(DDLSupplier.SelectedItem.Value)
        End If
        _tbl = POBLL.GetPOs(Session("CurrentBusinessID"), FdateAry(2) & FdateAry(1) & FdateAry(0), TdateAry(2) & TdateAry(1) & TdateAry(0), VID, -1, txtSearchText.Text, 999999, 1)


        Session("POs-" & Session("UserID")) = _tbl
        GrdPOs.DataSource = _tbl
        GrdPOs.DataBind()
    End Sub

    Private Sub GrdPOs_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdPOs.RowCommand

    End Sub

    Private Sub GrdPOs_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdPOs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim LnkViewPO As New System.Web.UI.WebControls.LinkButton
            LnkViewPO = CType(e.Row.FindControl("LnkViewPO"), LinkButton)
            If Not LnkViewPO Is Nothing Then
                LnkViewPO.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Transaction/PO/PO_Print.aspx?POID=" & drview("POID") & "',$(window).height()*95/100,$(window).width()*85/100);return false"
            End If

        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalDebitLbl As New System.Web.UI.WebControls.Label
            Dim TotalCreditLbl As New System.Web.UI.WebControls.Label

            TotalDebitLbl = CType(e.Row.FindControl("LblTotalDebit"), Label)
            TotalCreditLbl = CType(e.Row.FindControl("LblTotalCredit"), Label)

            If Not TotalDebitLbl Is Nothing Then
                TotalDebitLbl.Text = _TotalDebit
            End If

            If Not TotalCreditLbl Is Nothing Then
                TotalCreditLbl.Text = _TotalCredit
            End If
        End If

    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim attachment As String = ""
        If Not Session("POs-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("POs-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            attachment = "attachment; filename=NoDataFound.csv"
        Else
            attachment = "attachment; filename=POs" & Now.ToString("yyyyMMddhhmm") & ".csv"

            For i As Integer = 0 To _tbl.Columns.Count - 1
                Data = Data & _tbl.Columns(i).ColumnName & ","
            Next
            Data = Data & Environment.NewLine
            For i As Integer = 0 To _tbl.Rows.Count - 1
                For j As Integer = 0 To _tbl.Columns.Count - 1
                    Data = Data & _tbl.Rows(i)(j) & ","
                Next
                Data = Data & Environment.NewLine
            Next
        End If

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", attachment)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class