﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class ReportingService
    Inherits System.Web.Services.WebService

#Region "Banking"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function GetBusinessBankAccountsDetails(BusinessID As Integer, SearchText As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        'tbl = Bank.GetBusinessBankAccountsDetails(BusinessID, SearchText)
        'ds.Tables.Add(tbl)
        'ds.Tables(0).TableName = "Banks"
        'ds.Namespace = "Banking"

        Return ds.GetXml
    End Function
#End Region

#Region "Transactions"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetAccountHeadLedger(BusinessID As Integer, AccountHeadID As String, FromDate As DateTime, ToDate As DateTime) As String
        ''Dim FromDate As String = DateTime.Now.AddYears(-10).ToString("dd-MM-yyyy") & " 00:00:00 AM"
        ''Dim ToDate As String = DateTime.Now.AddYears(0).ToString("dd-MM-yyyy") & " 23:59:59 PM"
        Dim _tbl As New DataTable
        Dim AccountHeadIDs As String = ReferenceData.Setting("AccountsPayableID", "", Session("CurrentBusinessID"))
        AccountHeadIDs = AccountHeadIDs & "," & ReferenceData.Setting("AccountsReceiveableID", "", Session("CurrentBusinessID"))
        AccountHeadIDs = AccountHeadIDs & "," & ReferenceData.Setting("BankAccountHeadID", "", Session("CurrentBusinessID"))
        AccountHeadIDs = AccountHeadIDs & "," & ReferenceData.Setting("ExpenseHeadID", "", Session("CurrentBusinessID"))
        AccountHeadIDs = AccountHeadIDs & "," & ReferenceData.Setting("CashInHandAccountHeadID", "", Session("CurrentBusinessID"))
        If AccountHeadID > 0 Then
            AccountHeadIDs = AccountHeadID & ","
        End If
        Dim tbl As New DataTable
        Dim COATbl As New DataTable
        Dim HeadIDsAry() = AccountHeadIDs.Split(",")
        Dim HeadIds As String = ""
        Dim ds As New DataSet


        COATbl = ChartOfAccount.GetCOA(HttpContext.Current.Session("CurrentBusinessID"))
        For Each itm In HeadIDsAry
            If itm <> "" Then
                HeadIds = HeadIds & ChartOfAccount.GetAccountHeadTree(COATbl, itm) & ","
                HeadIds = HeadIds.Replace(",,", ",")
            End If
        Next
        HeadIds = HeadIds.Replace(",,", ",")

        ds = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, CDate(FromDate), CDate(ToDate))
        _tbl = ds.Tables(0)

        Dim _OldLedgerTbl As New DataTable()
        _OldLedgerTbl = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, DateTime.Now.AddYears(-10), CDate(FromDate).AddDays(-1)).Tables(0)

        Dim Bal As Single
        Dim cr As Single
        Dim dr As Single

        If (ds.Tables.Count > 1 AndAlso ds.Tables(1).Rows.Count > 0) Then 'InitialOpeningBalance
            Bal = ds.Tables(1).Rows(0)("InitialOpeningBalance")
        End If

        For i As Integer = 0 To _OldLedgerTbl.Rows.Count - 1
            dr = IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Debit")), 0, _OldLedgerTbl.Rows(i)("Debit"))
            cr = IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Credit")), 0, _OldLedgerTbl.Rows(i)("Credit"))


            If IsDBNull(_OldLedgerTbl.Rows(i)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(i)("TransactionCode") = "CashSale" And cr > 0 Then
                dr = cr
            End If
            Bal = Bal + (dr - cr)
        Next
        'Bal = Bal + (dr - cr)
        Dim LgrTbl As New DataTable()
        LgrTbl = _tbl.Copy()
        LgrTbl.Clear()

        Dim Drow As DataRow
        Drow = LgrTbl.NewRow

        Drow("Particular") = "Opening Balance"
        Drow("Debit") = Bal
        Drow("Credit") = 0
        Drow("TransactionDate") = Now
        LgrTbl.Rows.Add(Drow)
        LgrTbl.Merge(_tbl)
        _tbl.Merge(_OldLedgerTbl)

        _tbl = LgrTbl
        Dim _Balance As Single
        _tbl.Columns.Add("Balance")
        For i As Integer = 0 To _tbl.Rows.Count - 1
            dr = IIf(IsDBNull(_tbl.Rows(i)("Debit")), 0, _tbl.Rows(i)("Debit"))
            cr = IIf(IsDBNull(_tbl.Rows(i)("Credit")), 0, _tbl.Rows(i)("Credit"))
            If IsDBNull(_tbl.Rows(i)("TransactionCode")) = False AndAlso _tbl.Rows(i)("TransactionCode") = "CashSale" And cr > 0 Then
                dr = cr
            End If
            _Balance = _Balance + (dr - cr)
            _tbl.Rows(i)("Balance") = _Balance
        Next

        ds = New DataSet()
        ds.Tables.Add(_tbl)
        ds.Tables(0).TableName = "AccountHead"
        ds.Namespace = "Ledger"

        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetMonthWiseAccountHeadLedger(BusinessID As Integer, AccountHeadID As String, FromDate As DateTime, ToDate As DateTime) As String
        Dim _tbl As New DataTable
        Dim AccountHeadIDs As String = ""
        If AccountHeadID > 0 Then
            AccountHeadIDs = AccountHeadID & ","
        End If
        Dim tbl As New DataTable
        Dim COATbl As New DataTable
        Dim HeadIDsAry() = AccountHeadIDs.Split(",")
        Dim HeadIds As String = ""
        Dim ds As New DataSet
        Dim MonthlyLedgerTbl As New DataTable
        MonthlyLedgerTbl.Columns.Add("Month")
        MonthlyLedgerTbl.Columns.Add("AccountHeadID")
        MonthlyLedgerTbl.Columns.Add("AccountHeadName")
        MonthlyLedgerTbl.Columns.Add("Balance")
        MonthlyLedgerTbl.Columns.Add("Currency")

        COATbl = ChartOfAccount.GetCOA(HttpContext.Current.Session("CurrentBusinessID"))
        For Each itm In HeadIDsAry
            If itm <> "" Then
                HeadIds = HeadIds & ChartOfAccount.GetAccountHeadTree(COATbl, itm) & ","
                HeadIds = HeadIds.Replace(",,", ",")
            End If
        Next
        HeadIds = HeadIds.Replace(",,", ",")

        Dim dt As New DateTime()
        For i As Integer = 1 To 11
            Dim Fdate As String
            Dim TDate As String
            If (i = 1) Then
                dt = ToDate.AddMonths(0)
            Else
                dt = ToDate.AddMonths((i - 1) * -1)
            End If

            Dim LastDayOfMonth As String = DateTime.DaysInMonth(dt.Year, dt.Month)
            Fdate = dt.ToString("MM-" & LastDayOfMonth & "-yyyy 00:00:00 ") & "AM"
            TDate = dt.ToString("MM-" & LastDayOfMonth & "-yyyy 23:59:59 ") & "PM"

            ds = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, CDate(Fdate), CDate(TDate))
            _tbl = ds.Tables(0)

            Dim _OldLedgerTbl As New DataTable()
            _OldLedgerTbl = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, DateTime.Now.AddYears(-10), CDate(Fdate).AddDays(-1)).Tables(0)

            Dim Bal As Single
            Dim cr As Single
            Dim dr As Single

            If (ds.Tables.Count > 1 AndAlso ds.Tables(1).Rows.Count > 0) Then 'InitialOpeningBalance
                Bal = ds.Tables(1).Rows(0)("InitialOpeningBalance")
            End If

            For j As Integer = 0 To _OldLedgerTbl.Rows.Count - 1
                dr = IIf(IsDBNull(_OldLedgerTbl.Rows(j)("Debit")), 0, _OldLedgerTbl.Rows(j)("Debit"))
                cr = IIf(IsDBNull(_OldLedgerTbl.Rows(j)("Credit")), 0, _OldLedgerTbl.Rows(j)("Credit"))

                If IsDBNull(_OldLedgerTbl.Rows(j)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(j)("TransactionCode") = "CashSale" And cr > 0 Then
                    dr = cr
                End If
                Bal = Bal + (dr - cr)
            Next
            Dim LgrTbl As New DataTable()
            LgrTbl = _tbl.Copy()
            LgrTbl.Clear()

            Dim Drow As DataRow
            Drow = LgrTbl.NewRow

            Drow("Particular") = "Opening Balance"
            Drow("Debit") = Bal
            Drow("Credit") = 0
            Drow("TransactionDate") = Now
            LgrTbl.Rows.Add(Drow)
            LgrTbl.Merge(_tbl)
            _tbl.Merge(_OldLedgerTbl)

            _tbl = LgrTbl
            Dim _Balance As Single
            _tbl.Columns.Add("Balance")
            For j As Integer = 0 To _tbl.Rows.Count - 1
                dr = IIf(IsDBNull(_tbl.Rows(j)("Debit")), 0, _tbl.Rows(j)("Debit"))
                cr = IIf(IsDBNull(_tbl.Rows(j)("Credit")), 0, _tbl.Rows(j)("Credit"))
                If IsDBNull(_tbl.Rows(j)("TransactionCode")) = False AndAlso _tbl.Rows(j)("TransactionCode") = "CashSale" And cr > 0 Then
                    dr = cr
                End If
                _Balance = _Balance + (dr - cr)
                _tbl.Rows(j)("Balance") = _Balance
            Next


            Drow = MonthlyLedgerTbl.NewRow
            Drow("Month") = MonthName(dt.Month).Substring(0, 3) & "-" & dt.Year
            Drow("AccountHeadID") = AccountHeadID
            Drow("Currency") = LoggedInUserSession.BusinessCurrencyCode
            If (COATbl.Select("AccountHeadID=" & AccountHeadID).Length > 0) Then
                Drow("AccountHeadName") = COATbl.Select("AccountHeadID=" & AccountHeadID).CopyToDataTable().Rows(0)("AccountHeadName")
            Else
                Drow("AccountHeadName") = ""
            End If

            Drow("Balance") = _tbl.Rows(0)("Balance")
            MonthlyLedgerTbl.Rows.Add(Drow)
        Next

        Dim id = ReferenceData.Setting("AccountsReceiveableID", "-1", Session("CurrentBusinessID"))
        ds = New DataSet()
        ds.Tables.Add(MonthlyLedgerTbl)
        ds.Tables(0).TableName = "MonthlyLedger"
        ds.Namespace = "AccountMonthlyLedger"
        Return ds.GetXml
    End Function
#End Region


End Class