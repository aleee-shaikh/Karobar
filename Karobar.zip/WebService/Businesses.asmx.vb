﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class Businesses
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SearchBusinesses() As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.GetWebsites()
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"



        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function SearchBusinesses4VirtualMarket(BusinessID As Integer, CategoryID As Integer, UserID As Integer, SearchText As String, PageNo As Integer, PageSize As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.GetWebsites4VirtualMarket(BusinessID, CategoryID, UserID, SearchText, PageNo, PageSize)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"



        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function SearchBusinesses(BusinessID As Integer, CategoryID As Integer, UserID As Integer, SearchText As String, PageNo As Integer, PageSize As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.SearchBusinesses(BusinessID, CategoryID, UserID, SearchText, PageNo, PageSize)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"

        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetBusinessBankAccounts() As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Bank.GetBanksAccountsList(Val(LoggedInUserSession.BusinessID), -1)

        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Banks"
        ds.Namespace = "Business"

        Return ds.GetXml
    End Function
End Class