﻿Imports System.Data.SqlClient
Imports Newtonsoft.Json

Public Class POSSale
    Inherits System.Web.UI.UserControl
    Dim _BusinessDetail As New DataTable
    Dim _CustomerDtl As New DataTable
    Public ProductMappedOffers As String
    Public ProductMappedOffersProducts As String
    Dim RequiredProductSaleMapping As String = ""

    Private Sub DDLUserCards_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLUserCards.SelectedIndexChanged
        If ddlCustomer.SelectedValue > 0 Then
            Dim tbl As New DataTable
            tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), ddlCustomer.SelectedValue, DDLUserCards.SelectedValue)
            lblPoints.Text = "0"
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("CardStatusID") = 2 Then 'Cancelled
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardCancelled", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been cancelled.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                ElseIf DateDiff(DateInterval.Day, Now, tbl.Rows(0)("ExpiryDate")) < 0 Then
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardExpired", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been expired.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                Else
                    lblPoints.Text = tbl.Rows(0)("Points")
                    LoadUserGiftCardDetails()
                End If
            End If
        End If
    End Sub

    Private Sub POSSale_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            txtSalePercentage.Text = CMS.ReferenceData.Setting("DefaultSaleDiscountPercentage", "0", CMS.LoggedInUserSession.BusinessID)
            txtSaleTax.Text = CMS.ReferenceData.Setting("DefaultSaleTaxPercentage", "0", CMS.LoggedInUserSession.BusinessID)
            If Not Request("OID") Is Nothing Then
                HdnOrderID.Value = Cryptography.Decrypt(Request("OID"))
                Dim ds As New DataSet()
                ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(HdnOrderID.Value))

                If (ds.Tables.Count > 0) Then
                    If (ds.Tables(0).Rows.Count > 0) Then
                        If (IsDBNull(ds.Tables(0).Rows(0)("IsCompleted")) = False AndAlso Val(ds.Tables(0).Rows(0)("IsCompleted")) = 1) Then
                            Page.RegisterStartupScript("OrderAlreadyCompleted", "<script>parent.HideDlgForm(1);parent.ShowMessage('Order has already been completed.','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                        Else
                            txtCartData.Text = General.GetDataTableJson(ds.Tables(1))
                            LoadPurchasedProducts()
                            Try
                                If Not IsDBNull(ds.Tables(0).Rows(0)("UserID")) AndAlso Val(ds.Tables(0).Rows(0)("UserID")) > 0 Then
                                    ddlCustomer.SelectedValue = ds.Tables(0).Rows(0)("UserID")
                                End If
                            Catch ex As Exception

                            End Try
                        End If

                    End If
                End If

            End If

            InitializeData()

            If (ddlCustomer.Items.Count > 0) Then
                LoadCustomerCreditLimitAndBalance()
            End If

            HiddenQtyValue.Value = ReferenceData.Setting("HiddenQtyValue", "1", Session("CurrentBusinessID"))
            LblTax.Text = ReferenceData.Setting("LblSalesTax", "Tax", Session("CurrentBusinessID"))

            If LoggedInUserSession.BusinessCategoryID = 13 Or LoggedInUserSession.BusinessCategoryID = 15 Then
                pnlGiftCard.Visible = False
            Else
                pnlGiftCard.Visible = True
            End If

            '' txtProducts.Text = "{""AllBusinessProducts"":" & General.GetDataTableJson(Products.GetProductsList(Session("CurrentBusinessID"))) & "}"
        Else

        End If

        'Dim offerds As New DataSet
        'offerds = Products.GetProductsMappedOffer(LoggedInUserSession.BusinessID)
        'If (offerds.Tables.Count > 1) Then
        '    ProductMappedOffers = General.GetDataTableJson(offerds.Tables(0))
        '    ProductMappedOffersProducts = General.GetDataTableJson(offerds.Tables(1))
        'End If
    End Sub


    Sub InitializeData()
        Dim ds As New DataSet

        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
        DDLProductCatagory.DataValueField = "ArticleTypeID"
        DDLProductCatagory.DataTextField = "ArticleType"
        DDLProductCatagory.DataSource = ds.Tables(0)
        DDLProductCatagory.DataBind()

        Dim custmerInfoTbl As DataTable
        custmerInfoTbl = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Customer)
        ddlCustomer.DataSource = custmerInfoTbl
        ddlCustomer.DataValueField = "UserID"
        ddlCustomer.DataTextField = "FirstName"
        ddlCustomer.DataBind()


        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SaleType * -1)
        ddlSaleType.DataValueField = "ArticleTypeID"
        ddlSaleType.DataTextField = "ArticleType"
        ddlSaleType.DataSource = ds.Tables(0)
        ddlSaleType.DataBind()
        If (LoggedInUserSession.BusinessCategoryID = 16) Then
            pnlReturantOptions.Visible = True

            lblDeliveryPerson.Text = ReferenceData.Setting("LblDeliveryPerson", "Delivery Person:", Session("CurrentBusinessID"))
            lblTableNo.Text = ReferenceData.Setting("LblTableNo", "Table #:", Session("CurrentBusinessID"))


            DDLDeliveryPerson.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Staff)
            DDLDeliveryPerson.DataValueField = "UserID"
            DDLDeliveryPerson.DataTextField = "FirstName"
            DDLDeliveryPerson.DataBind()

            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.TableNos * -1)
            DDLTableNo.DataValueField = "ArticleTypeID"
            DDLTableNo.DataTextField = "ArticleType"
            DDLTableNo.DataSource = ds.Tables(0)
            DDLTableNo.DataBind()

        Else
            pnlReturantOptions.Visible = False
        End If

        LoadData()
    End Sub

    Sub LoadData()
        rptProducts.DataSource = Products.GetProductsList(Session("CurrentBusinessID"), DDLProductCatagory.SelectedValue, DDLProductSubCatagories.SelectedValue, txtFreeText.Text.Trim)
        rptProducts.DataBind()

    End Sub

    Private Sub DDLProductCatagory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        LoadProductSubCatagories(DDLProductCatagory.SelectedValue)
        LoadData()
    End Sub

    Sub LoadProductSubCatagories(ByVal GroupTypeID As Integer)
        DDLProductSubCatagories.Items.Clear()
        Dim ds As New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagories.DataValueField = "ArticleTypeID"
        DDLProductSubCatagories.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If

        DDLProductSubCatagories.Items.Add(New ListItem("All Sub Catagories", "-1"))
        DDLProductSubCatagories.DataSource = tbl
        DDLProductSubCatagories.DataBind()

    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnProceed_Click(sender As Object, e As EventArgs) Handles BtnProceed.Click
        txtCartTotal.Text = (CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text)) + CSng(txtCartTax.Text) + CSng(txtDeliveryCharges.Text)
        DivPayment.Visible = True
        DivCart.Visible = False
        DivInvoice.Visible = False
        txtPurchasedPayableAmount.Text = txtCartTotal.Text
        txtGrossAmount.Text = txtCartTotal.Text
        HdnGrossAmount.Value = txtCartTotal.Text
        txtPurchasedTotalItems.Text = txtCartItemsCount.Text
        HdnTotalRedeemPointsAmount.Value = "0"

        ''If Menu.GetBusinessCategoryID() = 13 Then
        If LoggedInUserSession.BusinessCategoryID = 13 Or LoggedInUserSession.BusinessCategoryID = 15 Then
            pnlGiftCard.Visible = False
        Else
            pnlGiftCard.Visible = True
        End If
    End Sub

    Sub LoadPurchasedProducts()
        Dim tblCartProducts As New DataTable
        tblCartProducts = General.ConvertJSONToDataTable(txtCartData.Text)
        If (tblCartProducts.Rows.Count > 0) Then
            tblCartProducts.Rows.RemoveAt(tblCartProducts.Rows.Count - 1)
        End If

        GrdProducts.DataSource = tblCartProducts
        GrdProducts.DataBind()
    End Sub

    Sub LoadBusinessDetails()
        Dim ds As New DataSet
        ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                _BusinessDetail = ds.Tables(0)
                lblInvoiceTitle.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
                lblBusinessTelephone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
                lblBusinessAddres.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
                lblBusinessCityPostCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")) OrElse ds.Tables(0).Rows(0)("City").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("City") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")) OrElse ds.Tables(0).Rows(0)("Town").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("Town") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")) OrElse ds.Tables(0).Rows(0)("ZipCode").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("ZipCode") & ",")

            End If
        End If
    End Sub

    Private Sub ddlCustomer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlCustomer.SelectedIndexChanged
        LoadCustomerCreditLimitAndBalance()

        Dim tbl As New DataTable

        HdnGiftCardValidityDays.Value = "0"
        txtRedeemPoints.Text = "0"
        HdnPointValue.Value = 0
        HdnGiftCardID.Value = "-1"
        lblPoints.Text = "0"
        DDLUserCards.Items.Clear()
        tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), ddlCustomer.SelectedValue)
        DDLUserCards.DataTextField = "UserCardName"
        DDLUserCards.DataValueField = "UserCardID"
        DDLUserCards.DataSource = tbl
        DDLUserCards.DataBind()
        DDLUserCards.Items.Insert(0, New ListItem("-- Select Gift Card --", "-1"))
        If tbl.Rows.Count > 0 Then
            HdnGiftCardValidityDays.Value = tbl.Rows(0)("ValidityDays")
            HdnGiftCardID.Value = tbl.Rows(0)("GiftCardID")
        End If
    End Sub

    Sub LoadUserGiftCardDetails()
        Dim tbl As New DataTable
        txtRedeemPoints.Text = "0"
        txtRedeemPointsAmount.Text = "0"

        tbl = GiftCard.GetGiftCardPoints(Session("CurrentBusinessID"), HdnGiftCardID.Value,, 4, "")
        If tbl.Rows.Count > 0 Then
            If tbl.Rows.Count = 1 Then
                If tbl.Rows(0)("MinValue") <= 0 And tbl.Rows(0)("MaxValue") <= 0 Then
                    HdnPointValue.Value = tbl.Rows(0)("PointValue")
                Else
                    If lblPoints.Text >= tbl.Rows(0)("MinValue") And lblPoints.Text <= tbl.Rows(0)("MaxValue") Then
                        HdnPointValue.Value = tbl.Rows(0)("PointValue")
                    End If
                End If
            Else
                For i As Integer = 0 To tbl.Rows.Count - 1
                    If lblPoints.Text >= tbl.Rows(i)("MinValue") And lblPoints.Text <= tbl.Rows(i)("MaxValue") Then
                        HdnPointValue.Value = tbl.Rows(i)("PointValue")
                    End If
                Next
            End If

        End If

    End Sub

    Sub LoadCustomerCreditLimitAndBalance()
        Dim ds As DataSet = New DataSet
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), ddlCustomer.SelectedValue)
        txtCustomerBalance.Text = "0"
        txtCreditLimit.Text = "0"
        If (ds.Tables.Count > 0) Then
            _CustomerDtl = ds.Tables(0)
            If (ds.Tables(0).Rows.Count > 0) Then
                txtCreditLimit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("CreditLimit")), 0, ds.Tables(0).Rows(0)("CreditLimit"))
                HdnCustomerEmail.Value = IIf(IsDBNull(ds.Tables(0).Rows(0)("loginid")), "", ds.Tables(0).Rows(0)("loginid"))
                Dim HeadIds As String = ""
                Dim tbl As New DataTable
                HeadIds = ddlCustomer.SelectedValue & ","
                tbl = ChartOfAccount.COA_GetAccountReceiveableSummary(HeadIds)
                If (tbl.Rows.Count > 0) Then
                    txtCustomerBalance.Text = tbl.Rows(0)("Balance")
                End If
            End If
        End If
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click

    End Sub

    Private Sub BtnCancelPayment_Click(sender As Object, e As EventArgs) Handles BtnCancelPayment.Click

    End Sub

    Private Sub BtnSubmit_Click(sender As Object, e As EventArgs) Handles BtnSubmit.Click
        Dim Orderds As New DataSet
        If Val(HdnOrderID.Value) > 0 Then
            Orderds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(HdnOrderID.Value))
            If (Orderds.Tables.Count > 0) Then
                If (Orderds.Tables(0).Rows.Count > 0) Then
                    If (IsDBNull(Orderds.Tables(0).Rows(0)("IsCompleted")) = False AndAlso Val(Orderds.Tables(0).Rows(0)("IsCompleted")) = 1) Then
                        Page.RegisterStartupScript("OrderAlreadyCompleted", "<script>parent.HideDlgForm(1);parent.ShowMessage('Order has already been completed.','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                        Exit Sub
                    End If
                End If
            End If
        End If


        Dim tblCart As New DataTable
        tblCart = General.ConvertJSONToDataTable(txtCartData.Text)

        If ddlSaleType.SelectedIndex = 0 AndAlso CSng(HdnGrossAmount.Value) + CSng(HdnTotalRedeemPointsAmount.Value) + CSng(txtCustomerBalance.Text) > CSng(txtCreditLimit.Text) Then
            'ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Customer credit limit exceeding','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            Page.RegisterStartupScript("CreditLimitExceed", "<script>parent.ShowMessage('Customer credit limit exceeding','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            Return
        Else
            'Dim Saletbl = New DataTable
            'Saletbl = SaleOrderDetails.GetSaleData
            'For i As Integer = 0 To Saletbl.Rows.Count - 1
            '    If Val(Saletbl.Rows(i)("Quantity")) > Val(Saletbl.Rows(i)("StockQuantity")) Then
            '        ClientScript.RegisterClientScriptBlock(Me.GetType(), "QtyExceedtoStock", "<script>parent.ShowMessage('Product quantity should be less than stock quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            '        Return
            '    End If
            'Next
        End If




        Dim tbl As New DataTable
        Dim SID As Integer
        Dim CusID As Integer = -1
        Dim SaleTypeID As Integer = -1
        Dim SalePersonID As Integer = -1
        Dim StockLocation As Integer = -1

        StockLocation = -1

        If ddlCustomer.Items.Count > 0 Then
            CusID = ddlCustomer.SelectedItem.Value
        End If
        If ddlSaleType.Items.Count > 0 Then
            SaleTypeID = ddlSaleType.SelectedItem.Value
        End If
        SalePersonID = Session("UserID")
        RequiredProductSaleMapping = ReferenceData.Setting("RequiredProductSaleMapping", "No", Session("CurrentBusinessID"))
        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try

            connection.Open()
            trans = connection.BeginTransaction()

            Dim transtbl As New DataTable
            Dim TID As Integer
            transtbl = Transactions.AddTransaction(Session("CurrentBusinessID"), "", IIf(ddlSaleType.SelectedIndex = 0, "Sale", "CashSale"), ddlSaleType.SelectedItem.Text & " Sale", "Active", True, General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone), trans)

            tbl = Products.SaleProductMaster(Session("CurrentBusinessID"), "", SaleTypeID, CusID, CSng(txtCartTax.Text), txtDeliveryCharges.Text, SalePersonID, "", "", 1, StockLocation, trans, Val(DDLTableNo.SelectedValue), Val(DDLDeliveryPerson.SelectedValue), General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone))
            If tbl.Rows.Count > 0 Then
                SID = tbl.Rows(0)("SaleID")
                TID = transtbl.Rows(0)("TransactionID")

                If ddlSaleType.SelectedIndex = 0 Then 'Credit
                    'Tax is zero abd added with amount
                    'Transactions.AddTransactionDetails(TID, CusID, True, "Product Sale", CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text), 0, 0, CSng(txtCartTax.Text), "", SID, trans:=trans)
                    Transactions.AddTransactionDetails(TID, CusID, True, "Product Sale", (CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text)) + CSng(txtCartTax.Text), 0, 0, 0, "", SID, trans:=trans)
                Else
                    'Tax is zero abd added with amount
                    'Transactions.AddTransactionDetails(TID, CusID, True, "Product Sale", 0, CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text), 0, CSng(txtCartTax.Text), "", SID, trans:=trans)
                    Transactions.AddTransactionDetails(TID, CusID, True, "Product Sale", 0, (CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text)) + CSng(txtCartTax.Text), 0, 0, "", SID, trans:=trans)
                    ''''Transactions.AddTransactionDetails(TID, ReferenceData.Setting("CustomerAccountHeadID", "-1", Session("CurrentBusinessID")), True, "Product Sale", 0, SaleOrderDetails.TotalAmount, Val(txtDeliveryCharges.Text), Val(txtTax.Text), "", SID)
                End If
                Dim productsTbl As New DataTable
                productsTbl = Products.GetProductsList(Session("CurrentBusinessID"))

                tbl = New DataTable
                tbl = tblCart
                Dim SoldProductCount As Integer = 0
                For i As Integer = 0 To tbl.Rows.Count - 2
                    If tbl.Rows(i)("ProductID") > 0 Then
                        Dim ds As New DataSet
                        Dim ptbl As New DataTable
                        Try
                            ptbl = productsTbl.Select("articleid=" & tbl.Rows(i)("ProductID")).CopyToDataTable()
                        Catch ex As Exception

                        End Try
                        ds.Tables.Add(ptbl)
                        Dim discount As Single = 0.0
                        Dim redeemDiscountAmount As Single = 0.0
                        Dim redeemPoints As Single = 0.0

                        If (i = 0) Then
                            redeemPoints = CSng(txtRedeemPoints.Text)
                            redeemDiscountAmount = CSng(HdnTotalRedeemPointsAmount.Value)
                            discount = CSng(txtCartDiscount.Text) ''Val(tbl.Rows(i)("Discount"))

                            LblInvDate.Text = Now
                            lblCustomer.Text = ddlCustomer.SelectedItem.Text

                            lblInvNo.Text = SID
                        End If
                        Products.SaleProductDetails(SID, tbl.Rows(i)("ProductID"), tbl.Rows(i)("ProductUnit"), CSng(tbl.Rows(i)("ProductQuantity")), CSng(tbl.Rows(i)("ProductPrice")), discount, CSng(tbl.Rows(i)("ProductQuantity")) * CSng(tbl.Rows(i)("ProductPrice")), trans, redeemPoints, redeemDiscountAmount, tbl.Rows(i)("ProductTitle"))
                        Dim SalePercentage As Single = ReferenceData.Setting("DefaultSaleDiscountPercentage", "0", CMS.LoggedInUserSession.BusinessID)


                        Dim SaleAmt As Single
                        If (SalePercentage > 0) Then
                            SaleAmt = (SalePercentage * CSng(tbl.Rows(i)("ProductQuantity")) * CSng(tbl.Rows(i)("ProductPrice"))) / 100
                        Else
                            SaleAmt = CSng(tbl.Rows(i)("ProductQuantity")) * CSng(tbl.Rows(i)("ProductPrice"))
                        End If
                        SaleAmt = SaleAmt + (SaleAmt * ReferenceData.Setting("DefaultSaleTaxPercentage", "0", CMS.LoggedInUserSession.BusinessID)) / 100

                        If ddlSaleType.SelectedIndex = 0 Then
                            ''new
                            If HiddenQtyValue.Value = "1" Then
                                Transactions.AddTransactionDetails(TID, ReferenceData.Setting("AccountsReceiveableID", "-1", Session("CurrentBusinessID")), False, "Product Sale :" & ds.Tables(0).Rows(0)("ArticleTitle"), 0, SaleAmt, 0, 0, "", SID, trans:=trans)
                            Else
                                Transactions.AddTransactionDetails(TID, ReferenceData.Setting("AccountsReceiveableID", "-1", Session("CurrentBusinessID")), False, "Product Sale :" & ds.Tables(0).Rows(0)("ArticleTitle"), 0, SaleAmt * HiddenQtyValue.Value, 0, 0, "", SID, trans:=trans)
                            End If

                        Else

                            If HiddenQtyValue.Value = "1" Then

                                Transactions.AddTransactionDetails(TID, ReferenceData.Setting("CashInHandAccountHeadID", "-1", Session("CurrentBusinessID")), False, "Product Sale :" & ds.Tables(0).Rows(0)("ArticleTitle"), SaleAmt, 0, 0, 0, "", SID, trans:=trans)
                            Else
                                Transactions.AddTransactionDetails(TID, ReferenceData.Setting("CashInHandAccountHeadID", "-1", Session("CurrentBusinessID")), False, "Product Sale :" & ds.Tables(0).Rows(0)("ArticleTitle"), SaleAmt * HiddenQtyValue.Value, 0, 0, 0, "", SID, trans:=trans)
                            End If

                        End If

                        If (RequiredProductSaleMapping = "Yes") Then
                            Dim productMappingds As New DataSet
                            productMappingds = Products.GetProductsMapping(LoggedInUserSession.BusinessID, tbl.Rows(i)("ProductID"))
                            If productMappingds.Tables.Count >= 3 Then
                                For a As Integer = 0 To productMappingds.Tables(1).Rows.Count - 1
                                    Products.SaleProductDetails(SID, productMappingds.Tables(1).Rows(a)("ProductID"), productMappingds.Tables(1).Rows(a)("ProductUnit"), CSng(productMappingds.Tables(1).Rows(a)("ProductQuantity")), 0, 0, 0, trans, 0, 0, "") ' tbl.Rows(i)("ProductTitle"))
                                Next
                                For a As Integer = 0 To productMappingds.Tables(2).Rows.Count - 1
                                    Products.SaleProductDetails(SID, productMappingds.Tables(2).Rows(a)("ProductID"), productMappingds.Tables(2).Rows(a)("ProductUnit"), CSng(productMappingds.Tables(2).Rows(a)("ProductQuantity")), 0, 0, 0, trans, 0, 0, "") ' tbl.Rows(i)("ProductTitle"))
                                Next
                            End If

                        End If

                        SoldProductCount += 1
                    End If
                Next

                If Val(DDLUserCards.SelectedValue) > 0 Then
                    tbl = GiftCard.RedeemUserGiftCard(Session("CurrentBusinessID"), ddlCustomer.SelectedValue, Val(HdnGiftCardID.Value), DDLUserCards.SelectedValue, txtRedeemPoints.Text, HttpContext.Current.Session("UserID"))
                End If

                If Val(HdnOrderID.Value) > 0 Then
                    Products.UpdateOrderStatus(Session("CurrentBusinessID"), HdnOrderID.Value, SID)
                End If
                Page.RegisterStartupScript("SaleDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product Sale", "Product Sale :" & SID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=SID)
                Log.Notifications_Add(IIf(ddlSaleType.SelectedIndex = 0, "Credit Sale", "Cash Sale") & " " & SoldProductCount & " item(s) :" & CSng(HdnGrossAmount.Value), SID, IIf(ddlSaleType.SelectedIndex = 0, "POS Credit Sale", "POS Cash Sale"), SoldProductCount)


            End If

            trans.Commit()
            Page.RegisterStartupScript("SaleAddingIssue", "<script>$('#" & DivCart.ClientID & "').hide();$('#" & DivInvoice.ClientID & "').show();</script>")
            'DivCart.Visible = False
            'DivPayment.Visible = False
            'DivInvoice.Visible = True


            InitializeData()
            LoadPurchasedProducts()
            txtCartData.Text = ""
            txtCartTax.Text = 0
            txtCartDiscount.Text = 0
            txtCartTotal.Text = 0
            txtCartProductAmountTotal.Text = 0
            txtCartItemsCount.Text = 0
            LoadCustomerCreditLimitAndBalance()
        Catch ex As Exception
            trans.Rollback()
            Page.RegisterStartupScript("SaleAddingIssue", "<script>parent.ShowMessage('Unable to process sale','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try

    End Sub

    Private Sub btnBackToPOS_Click(sender As Object, e As EventArgs) Handles btnBackToPOS.Click

        DivCart.Visible = True
        DivPayment.Visible = False
        DivInvoice.Visible = False

        txtCartData.Text = ""
        txtCartTax.Text = 0
        txtCartDiscount.Text = 0
        txtCartTotal.Text = 0
        txtCartProductAmountTotal.Text = 0
        txtCartItemsCount.Text = 0
        LoadData()


    End Sub

    Private Sub GrdProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim lblDiscount As Label = CType(e.Row.FindControl("lblDiscount"), Label)
            Dim lblTax As Label = CType(e.Row.FindControl("lblTax"), Label)
            Dim lblTotal As Label = CType(e.Row.FindControl("lblTotal"), Label)
            Dim lblTotalItems As Label = CType(e.Row.FindControl("lblTotalItems"), Label)
            Dim lblGrandTotal As Label = CType(e.Row.FindControl("lblGrandTotal"), Label)
            Dim lblRedeemPointsDiscountAmount As Label = CType(e.Row.FindControl("lblRedeemPointsDiscountAmount"), Label)
            Dim lblRedeemPoints As Label = CType(e.Row.FindControl("lblRedeemPoints"), Label)
            Dim lblDeliveryCharges As Label = CType(e.Row.FindControl("lblDeliveryCharges"), Label)

            lblTotalItems.Text = txtCartItemsCount.Text
            lblTotal.Text = txtCartProductAmountTotal.Text
            lblTax.Text = txtCartTax.Text
            lblDiscount.Text = txtCartDiscount.Text
            lblGrandTotal.Text = HdnGrossAmount.Value  'txtCartTotal.Text
            lblRedeemPointsDiscountAmount.Text = HdnTotalRedeemPointsAmount.Value
            lblRedeemPoints.Text = txtRedeemPoints.Text
            lblDeliveryCharges.Text = txtDeliveryCharges.Text

            Dim ds As New DataSet
            ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    lblInvoiceTitle.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
                    lblBusinessTelephone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
                    lblBusinessAddres.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
                    lblBusinessCityPostCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")) OrElse ds.Tables(0).Rows(0)("City").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("City") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")) OrElse ds.Tables(0).Rows(0)("Town").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("Town") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")) OrElse ds.Tables(0).Rows(0)("ZipCode").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("ZipCode") & ",")

                End If
            End If



        End If
    End Sub

    Private Sub BtnSubmit_Command(sender As Object, e As CommandEventArgs) Handles BtnSubmit.Command

    End Sub

    Private Sub rptProducts_ItemDataBound(sender As Object, e As RepeaterItemEventArgs) Handles rptProducts.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim HdnProductID As New HiddenField
            Dim HdnParentArticleID As New HiddenField
            Dim GrdChildProducts As New GridView
            HdnProductID = CType(e.Item.FindControl("HdnProductID"), HiddenField)
            HdnParentArticleID = CType(e.Item.FindControl("HdnParentArticleID"), HiddenField)
            GrdChildProducts = CType(e.Item.FindControl("grdChildProducts"), GridView)

            Dim ds As New DataSet
            ds = Products.GetParentProducts(Session("CurrentBusinessID"), Val(HdnProductID.Value), Val(HdnProductID.Value))
            GrdChildProducts.DataSource = ds
            GrdChildProducts.DataBind()

        End If
    End Sub

    Private Sub btnSendEmail_Click(sender As Object, e As EventArgs) Handles btnSendEmail.Click
        _CustomerDtl = Person.GetUserDetail(Session("CurrentBusinessID"), ddlCustomer.SelectedValue).Tables(0)
        LoadBusinessDetails()
        SendInvoiceEmail()
        Page.RegisterStartupScript("SaleDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale Invoice sent successfully to " & HdnCustomerEmail.Value & "','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
    End Sub

    Sub SendInvoiceEmail()
        Dim FromUserEmail As String = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
        Dim EmailSubject As String = "Sale Invoice #" & lblInvNo.Text
        Dim ToUserEmail As String = HdnCustomerEmail.Value
        Dim emailBody As String = HdnInvoice.Value
        Dim fileName As String = "~/Modules/Karobar/Reports/PDF/" & lblInvNo.Text & ".pdf"
        ''WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, "", "", "", emailBody)

        If (System.IO.File.Exists(fileName) = False) Then
            GenerateFile.Generate(GenerateFile.ExportFormat.PDF, HdnInvoice.Value, fileName)
        End If

        Dim EmailTemplateFile As String = ReferenceData.Setting("SaleInvoiceTemplate", "SaleInvoiceTemplate")
        Dim ReplacingWords As String = ""

        ReplacingWords = ReplacingWords & "[CustomerName]♦" & _CustomerDtl.Rows(0)("FirstName") & "¤"
        ReplacingWords = ReplacingWords & "[UserEmail]♦" & _CustomerDtl.Rows(0)("loginID") & "¤"
        ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
        'ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
        'ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
        'ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
        'ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
        'ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
        'ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
        'ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
        ReplacingWords = ReplacingWords & "[BusinessID]♦" & _BusinessDetail.Rows(0)("WebsiteID") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & _BusinessDetail.Rows(0)("WebsiteLogo").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & _BusinessDetail.Rows(0)("CurrencyCode").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & _BusinessDetail.Rows(0)("Email").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & _BusinessDetail.Rows(0)("Phone").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessFax]♦" & _BusinessDetail.Rows(0)("Fax").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCity]♦" & _BusinessDetail.Rows(0)("City").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTown]♦" & _BusinessDetail.Rows(0)("Town").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & _BusinessDetail.Rows(0)("CategoryTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & _BusinessDetail.Rows(0)("Address").ToString() & "¤"

        WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, EmailTemplateFile, fileName, ReplacingWords, "")

    End Sub
End Class