﻿Public Class Admin
    Inherits System.Web.UI.Page

    Private Sub Admin_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Dim P As String = IIf(Request("P") Is Nothing, "", Request("P"))
        Select Case P.ToLower
            Case "layouts"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Layout/LayoutManager.ascx"))
            Case "pages"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Pages/PagesManager.ascx"))
            Case "modules"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Modules/ModulesManager.ascx"))
            Case "websitesettings"
                PnlContainer.Controls.Add(LoadControl("~/Admin/WebsiteSettings/WebsiteSettingsManager.ascx"))
            Case "log"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Log/WebsiteLogManager.ascx"))
            Case "users"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Users/WebsiteUsersManager.ascx"))
            Case "filemanager"
                PnlContainer.Controls.Add(LoadControl("~/Admin/FileManager/FileManager.ascx"))
            Case "articles"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Articles/ArticlesManager.ascx"))
            Case "dashboard"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Dashboard/Dashboard.ascx"))
            Case "shareddata"
                PnlContainer.Controls.Add(LoadControl("~/Admin/SharedData/SharedDataManager.ascx"))
            Case "statistics"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Statistics/WebsiteStatisticManager.ascx"))
            Case "sendmarketingemails"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Emails/WebsiteEmailsManager.ascx"))
            Case "polling"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Polling/PollingManager.ascx"))
            Case "tickets"
                PnlContainer.Controls.Add(LoadControl("~/Admin/ContactUS/WebsiteContactUsManager.ascx"))
            Case "managetickettypes"
                PnlContainer.Controls.Add(LoadControl("~/Admin/ContactUS/TicketTypes.ascx"))
            Case "manageticketstatus"
                PnlContainer.Controls.Add(LoadControl("~/Admin/ContactUS/WebsiteContactUsManager.ascx"))
            Case "usersubscriptions"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Log/WebsiteLogManager.ascx"))
            Case "roles"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Roles/RoleTypes.ascx"))
            Case "managetickettypedepartments"
                PnlContainer.Controls.Add(LoadControl("~/Admin/ContactUS/TicketDepartments.ascx"))
            Case "businesscategories"
                PnlContainer.Controls.Add(LoadControl("~/Admin/BusinessCategories/BusinessCategories.ascx"))
            Case "notifications"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Notification/NotificationManager.ascx"))
            Case "businesses"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Business/AdminBusinesses.ascx"))
            Case "mobile"
                PnlContainer.Controls.Add(LoadControl("~/Admin/Mobile/Templates/MobileAppTemplatesManager.ascx"))
        End Select
    End Sub
End Class