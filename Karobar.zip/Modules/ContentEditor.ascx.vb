﻿Public Class ContentEditor
    Inherits System.Web.UI.UserControl
    Dim _ModuleID As Integer
    
    Public Property ModuleID() As Integer
        Get
            Return _ModuleID
        End Get
        Set(ByVal value As Integer)
            _ModuleID = value
        End Set
    End Property

    


    Public Property Text() As String
        Get
            Return wysiwyg.Value
        End Get
        Set(ByVal value As String)
            wysiwyg.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        

    End Sub


End Class