﻿Public Class KarobarSettings
    Inherits System.Web.UI.Page



    Private Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 44) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
        If Not Page.IsPostBack Then
            Settings.ParentTypeID = Website.DataTypes.ProductCatagories * -1
            Settings.Title = "Product Catagories"
            SetUnbold()
            LnkProductCatagories.Font.Bold = True
            Settings.Visible = True
        End If

        LnkDepartments.Text = ReferenceData.Setting("LblDepartment", "Department", LoggedInUserSession.BusinessID)
        If LoggedInUserSession.BusinessCategoryID = 5 Then 'school
            pnlSaleSettings.Visible = False
            pnlProductUnits.Visible = False
        End If
        'Dim ds As New DataSet
        'Dim BusinessCategory As String
        'Dim BusinessCategoryID As Integer = 0
        'ds = Website.GetWebsiteDetails(Session("CurrentBusinessID"))
        'If (ds.Tables.Count > 0) Then
        '    If ds.Tables(0).Rows.Count > 0 Then
        '        BusinessCategory = ds.Tables(0).Rows(0)("CategoryTitle")
        '        BusinessCategoryID = ds.Tables(0).Rows(0)("WebsiteCategoryID")
        '    End If
        'End If

        LnkTableNos.Visible = False
        pnlTableNos.Visible = False
        If Session("CurrentBusinessCategoryID") = 16 Then 'Resturant
            LnkTableNos.Visible = True
            pnlTableNos.Visible = True
        ElseIf Session("CurrentBusinessCategoryID") = 14 Then 'Blogs/Jobs
            LnkBankAccountType.Visible = False
            LnkCustomerType.Visible = False
            LnkDepartments.Visible = False
            LnkLabels.Visible = False
            LnkProductSubCatagories.Visible = True
            LnkProductUnits.Visible = True
            LnkSaleType.Visible = False
            LnkStockLocations.Visible = False
            LnkSupplierStatus.Visible = False
            LnkSupplierType.Visible = False

            pnlBankAccountType.Visible = False
            pnlCustomerType.Visible = False
            pnlDepartments.Visible = False
            pnlLabels.Visible = False
            pnlProductSubCatagories.Visible = true
            pnlProductUnits.Visible = True
            pnlSaleType.Visible = False
            pnlStockLocations.Visible = False
            pnlSupplierStatus.Visible = False
            pnlSupplierType.Visible = False
        End If
    End Sub

    Private Sub LnkProductCatagories_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductCatagories.Click
        Settings.ParentTypeID = Website.DataTypes.ProductCatagories * -1
        Settings.Title = "Product Catagories"
        SetUnbold()
        LnkProductCatagories.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkProductSubCatagories_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductSubCatagories.Click
        Settings.ParentTypeID = Website.DataTypes.ProductSubCatagories * -1
        Settings.Title = "Product Sub Catagories"
        SetUnbold()
        LnkProductSubCatagories.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkProductUnits_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkProductUnits.Click
        Settings.ParentTypeID = Website.DataTypes.ProductUnits * -1
        Settings.Title = "Product Units"
        SetUnbold()
        LnkProductUnits.Font.Bold = True
        Settings.Visible = True
    End Sub

    Sub SetUnbold()
        LnkProductCatagories.Font.Bold = False
        LnkProductSubCatagories.Font.Bold = False
        LnkProductUnits.Font.Bold = False
        LnkPersonTitles.Font.Bold = False
        LnkMaritalStatus.Font.Bold = False
        LnkStockLocations.Font.Bold = False
        LnkSupplierType.Font.Bold = False
        LnkCustomerType.Font.Bold = False
        LnkBankAccountType.Font.Bold = False
        LnkSupplierStatus.Font.Bold = False
        LnkCustomerStatus.Font.Bold = False
        LnkWeeklyOffDays.Font.Bold = False
        LnkDesignations.Font.Bold = False
        LnkDepartments.Font.Bold = False
        LnkTableNos.Font.Bold = False
        lnkSaleSettings.Font.Bold = False
        LabelSettings.Visible = False
        Settings.Visible = False
        OFFDays.Visible = False
        DesignationSettings.Visible = False
        DepartmentsSettings.Visible = False
        WorkingShifts.Visible = False
        SaleSettings.Visible = False
    End Sub

    Private Sub LnkPersonTitles_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkPersonTitles.Click
        Settings.ParentTypeID = Website.DataTypes.PersonTitles * -1
        Settings.Title = "Person Titles"
        SetUnbold()
        LnkPersonTitles.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkMaritalStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkMaritalStatus.Click
        Settings.ParentTypeID = Website.DataTypes.MaritalStatus * -1
        Settings.Title = "Person Marital Status"
        SetUnbold()
        LnkMaritalStatus.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkStockLocations_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkStockLocations.Click
        Settings.ParentTypeID = Website.DataTypes.StockLocations * -1
        Settings.Title = "Product Stock Location"
        SetUnbold()
        LnkStockLocations.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkSupplierType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSupplierType.Click
        Settings.ParentTypeID = Website.DataTypes.SupplierType * -1
        Settings.Title = "Supplier Type"
        SetUnbold()
        LnkSupplierType.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkCustomerType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkCustomerType.Click
        Settings.ParentTypeID = Website.DataTypes.CustomerType * -1
        Settings.Title = "Customer Type"
        SetUnbold()
        LnkCustomerType.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkBankAccountType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkBankAccountType.Click
        Settings.ParentTypeID = Website.DataTypes.BankAccountType * -1
        Settings.Title = "Bank Account Type"
        SetUnbold()
        LnkBankAccountType.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkCustomerStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkCustomerStatus.Click
        Settings.ParentTypeID = Website.DataTypes.CustomerStatus * -1
        Settings.Title = "Customer Status"
        SetUnbold()
        LnkCustomerStatus.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkSupplierStatus_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSupplierStatus.Click
        Settings.ParentTypeID = Website.DataTypes.SupplierStatus * -1
        Settings.Title = "Supplier Status"
        SetUnbold()
        LnkSupplierStatus.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkSaleType_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkSaleType.Click
        Settings.ParentTypeID = Website.DataTypes.SaleType * -1
        Settings.Title = "Sale Type"
        SetUnbold()
        LnkSaleType.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub LnkLabels_Click(sender As Object, e As EventArgs) Handles LnkLabels.Click
        LabelSettings.Visible = True
        Settings.Visible = False
        DesignationSettings.Visible = False
        DepartmentsSettings.Visible = False
        WorkingShifts.Visible = False
        OFFDays.Visible = False
    End Sub

    Private Sub LnkDesignations_Click(sender As Object, e As EventArgs) Handles LnkDesignations.Click
        SetUnbold()
        LnkDesignations.Font.Bold = True
        DesignationSettings.Visible = True
    End Sub

    Private Sub LnkDepartments_Click(sender As Object, e As EventArgs) Handles LnkDepartments.Click
        SetUnbold()
        LnkDepartments.Font.Bold = True
        DepartmentsSettings.Visible = True
    End Sub

    Private Sub LnkWeeklyOffDays_Click(sender As Object, e As EventArgs) Handles LnkWeeklyOffDays.Click
        SetUnbold()
        LnkWeeklyOffDays.Font.Bold = True
        OFFDays.Visible = True
    End Sub

    Private Sub LnkWorkingShifts_Click(sender As Object, e As EventArgs) Handles LnkWorkingShifts.Click
        SetUnbold()
        LnkWorkingShifts.Font.Bold = True
        WorkingShifts.Visible = True
    End Sub

    Private Sub LnkTableNos_Click(sender As Object, e As EventArgs) Handles LnkTableNos.Click
        Settings.ParentTypeID = Website.DataTypes.TableNos * -1
        Settings.Title = "Table Nos"
        SetUnbold()
        LnkTableNos.Font.Bold = True
        Settings.Visible = True
    End Sub

    Private Sub lnkSaleSettings_Click(sender As Object, e As EventArgs) Handles lnkSaleSettings.Click
        SetUnbold()
        lnkSaleSettings.Font.Bold = True
        SaleSettings.Visible = True
    End Sub

End Class