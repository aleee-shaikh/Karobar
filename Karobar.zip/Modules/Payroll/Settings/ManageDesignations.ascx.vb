﻿Public Class ManageDesignations
    Inherits System.Web.UI.UserControl


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
            If GrdDesignations.Rows.Count > 0 Then
                GrdDesignations.Columns(2).Visible = True
                GrdDesignations.Columns(3).Visible = True
                GrdDesignations.Columns(4).Visible = False
            Else
                GrdDesignations.Columns(2).Visible = False
                GrdDesignations.Columns(3).Visible = False
                GrdDesignations.Columns(4).Visible = True
            End If
        End If

    End Sub


    Sub LoadData()
        GrdDesignations.DataSource = Payroll.GetDesignations(Session("CurrentBusinessID"))
        GrdDesignations.DataBind()
    End Sub

    Private Sub GrdDesignations_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdDesignations.RowCommand
        If e.CommandName = "AddNewDesignation" Then
            GrdDesignations.ShowFooter = True
            GrdDesignations.Columns(2).Visible = False
            GrdDesignations.Columns(3).Visible = False
            GrdDesignations.Columns(4).Visible = True
        ElseIf e.CommandName = "SaveNewDesignation" Then
            Dim DesignationName As String = CType(GrdDesignations.FooterRow.FindControl("txtDesignationName"), TextBox).Text
            Dim Visible As Boolean = CType(GrdDesignations.FooterRow.FindControl("chkVisible"), CheckBox).Checked
            Payroll.AddDesignation(Session("CurrentBusinessID"), DesignationName, Visible)
            GrdDesignations.Columns(2).Visible = True
            GrdDesignations.Columns(3).Visible = True
            GrdDesignations.Columns(4).Visible = False
        ElseIf e.CommandName = "Insert" Then

        ElseIf e.CommandName = "Cancel" Then
            GrdDesignations.ShowFooter = False
            GrdDesignations.EditIndex = -1
            GrdDesignations.Columns(2).Visible = True
            GrdDesignations.Columns(3).Visible = True
            GrdDesignations.Columns(4).Visible = False
        ElseIf e.CommandName = "DeleteDesignation" Then
            Dim ID As Integer = Val(e.CommandArgument)
            Payroll.DeleteDesignation(ID)
        ElseIf e.CommandName = "Edit" Then
            GrdDesignations.Columns(2).Visible = True
            GrdDesignations.Columns(3).Visible = True
            GrdDesignations.Columns(4).Visible = False
            GrdDesignations.ShowFooter = False
        ElseIf e.CommandName = "Update" Then
            Dim ID As Integer = Val(CType(GrdDesignations.Rows(GrdDesignations.EditIndex).FindControl("HdnDesignationID"), HiddenField).Value)
            Dim DesignationName As String = CType(GrdDesignations.Rows(GrdDesignations.EditIndex).FindControl("txteditDesignationName"), TextBox).Text
            Dim Visible As Boolean = CType(GrdDesignations.Rows(GrdDesignations.EditIndex).FindControl("chkEditVisible"), CheckBox).Checked

            Payroll.UpdateDesignation(ID, DesignationName, Visible)
            GrdDesignations.EditIndex = -1
            GrdDesignations.Columns(2).Visible = True
            GrdDesignations.Columns(3).Visible = True
            GrdDesignations.Columns(4).Visible = False
        End If
        LoadData()

    End Sub

    Private Sub GrdDesignations_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdDesignations.RowEditing
        GrdDesignations.EditIndex = e.NewEditIndex
        GrdDesignations.DataBind()
    End Sub

    Private Sub GrdDesignations_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdDesignations.RowCancelingEdit
        GrdDesignations.EditIndex = -1
        GrdDesignations.DataBind()
    End Sub

    Protected Sub LnkAddDesignation_Click(sender As Object, e As EventArgs) Handles LnkAddDesignation.Click
        GrdDesignations.ShowFooter = True
        GrdDesignations.Columns(2).Visible = False
        GrdDesignations.Columns(3).Visible = False
        GrdDesignations.Columns(4).Visible = True
        GrdDesignations.EditIndex = -1
        Dim dr As DataRow
        Dim tbl As New DataTable
        tbl = Payroll.GetDesignations(Session("CurrentBusinessID"))
        dr = tbl.NewRow
        tbl.Rows.InsertAt(dr, 0)
        GrdDesignations.DataSource = tbl
        GrdDesignations.DataBind()
    End Sub
End Class