﻿Public Class ManageLicenses
    Inherits System.Web.UI.UserControl


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHavePageRights(Session("UserID"), 1) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout(window.location='/Transaction','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage business screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If Not Me.IsPostBack Then
            LoadData()
            DDLLicense.DataTextField = "LicenseTitle"
            DDLLicense.DataValueField = "LicenseID"
            DDLLicense.DataSource = PortalLicense.GetLicenses(Val(Session("CurrentBusinessID")))
            DDLLicense.DataBind()
            DDLLicense.Items.Insert(0, New ListItem("Select License", "-1"))
        Else

        End If
    End Sub

    Sub LoadData()
        GrdBusinesses.DataSource = PortalLicense.GetChildWebsites(Val(Session("CurrentBusinessID")))
        GrdBusinesses.DataBind()
    End Sub


    Private Sub GrdBusinesses_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdBusinesses.PageIndexChanging
        GrdBusinesses.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdBusinesses_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdBusinesses.RowCommand
        If e.CommandName = "IssueLicense" Then
            DivIssueLicense.Visible = True
            pnlGrid.Visible = False
            HdnBID.Value = e.CommandArgument
        ElseIf e.CommandName = "RenewLicense" Then
            Dim tmpAry() = e.CommandArgument.ToString().Split("|")
            Dim BID As Integer = tmpAry(0)
            Dim LID As Integer = tmpAry(1)
            PortalLicense.IssueLicense(BID, LID, Session("UserID"))
            LoadData()
            HdnBID.Value = "0"
        ElseIf e.CommandName = "CancelLicense" Then
            Dim tmpAry() = e.CommandArgument.ToString().Split("|")
            Dim BID As Integer = tmpAry(0)
            Dim LID As Integer = tmpAry(1)

            PortalLicense.CancelLicense(BID, LID, Session("UserID"), "")
            LoadData()
        End If
    End Sub

    Private Sub GrdBusinesses_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdBusinesses.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim BusinessLogoImage As New System.Web.UI.WebControls.Image
            BusinessLogoImage = CType(e.Row.FindControl("BusinessLogo"), System.Web.UI.WebControls.Image)
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            If Not BusinessLogoImage Is Nothing Then
                If IsDBNull(drview("WebsiteLogo")) OrElse drview("WebsiteLogo") = "" Then
                    BusinessLogoImage.ImageUrl = "~/Images/No-Image.png"
                Else
                    BusinessLogoImage.ImageUrl = "~/CMS/" & Website.WebsiteID & "/Businesses/" & drview("WebsiteID") & "/Images" & "/" & drview("WebsiteLogo")
                End If
            End If
            Dim pnlLnkIssueLicense As New Panel
            Dim pnlLnkRenewLicense As New Panel
            Dim pnlLnkCancelLicense As New Panel
            pnlLnkIssueLicense = CType(e.Row.FindControl("pnlLnkIssueLicense"), Panel)
            pnlLnkRenewLicense = CType(e.Row.FindControl("pnlLnkRenewLicense"), Panel)
            pnlLnkCancelLicense = CType(e.Row.FindControl("pnlLnkCancelLicense"), Panel)
            Dim pnlIssue As New Panel
            pnlIssue = CType(e.Row.FindControl("pnlIssue"), Panel)
            Dim pnlCancel As New Panel
            pnlCancel = CType(e.Row.FindControl("pnlCancel"), Panel)

            If IsDBNull(drview("IssueDate")) = False Then

                pnlIssue.Visible = True
                pnlLnkIssueLicense.Visible = False

                Dim lblLicenseIssueDate As New Label
                Dim lbLicenselExpiryDate As New Label
                lblLicenseIssueDate = CType(e.Row.FindControl("lblLicenseIssueDate"), Label)
                lbLicenselExpiryDate = CType(e.Row.FindControl("lbLicenselExpiryDate"), Label)
                lblLicenseIssueDate.Text = drview("IssueDate")
                lbLicenselExpiryDate.Text = drview("ExpiryDate")
            Else
                pnlIssue.Visible = False
                pnlLnkIssueLicense.Visible = True
            End If

            If IsDBNull(drview("CancelDate")) = False AndAlso drview("IsCancelled") = True Then
                pnlCancel.Visible = True
                pnlLnkIssueLicense.Visible = True
                pnlLnkRenewLicense.Visible = False
                pnlLnkCancelLicense.Visible = False
                Dim lblLicenseCancelDate As New Label
                Dim lblLicenseCancelRemarks As New Label
                lblLicenseCancelDate = CType(e.Row.FindControl("lblLicenseCancelDate"), Label)
                lblLicenseCancelRemarks = CType(e.Row.FindControl("lblLicenseCancelRemarks"), Label)
                lblLicenseCancelDate.Text = drview("CancelDate")
                lblLicenseCancelRemarks.Text = drview("CancelRemarks")
            ElseIf IsDBNull(drview("IssueDate")) = True AndAlso IsDBNull(drview("CancelDate")) = True Then
                pnlCancel.Visible = False
                pnlLnkIssueLicense.Visible = True
                pnlLnkRenewLicense.Visible = False
                pnlLnkCancelLicense.Visible = False
            End If
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")

        End If
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        PortalLicense.IssueLicense(hdnBID.Value, DDLLicense.SelectedValue, Session("UserID"))
        LoadData()
        HdnBID.Value = "0"
        pnlGrid.Visible = True
        DivIssueLicense.Visible = False
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click
        LoadData()
        HdnBID.Value = "0"
        pnlGrid.Visible = True
        DivIssueLicense.Visible = False
    End Sub
End Class