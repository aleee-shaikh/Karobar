﻿Public Class CounterDisplay
    Inherits System.Web.UI.UserControl

    Sub LoadData()
        Dim tbl As New DataTable
        Dim ds As New DataSet

        ds = Tickets.GetTickets(Val(Session("CurrentBusinessID")), -1, "", Now.ToString("yyyyMMdd"), Now.ToString("yyyyMMdd"))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    tbl = ds.Tables(0).Select("TicketStatusID=1").CopyToDataTable
                Catch ex As Exception

                End Try

            End If
        End If
        GrdTickets.DataSource = tbl
        GrdTickets.DataBind()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack Then
        Else
            LoadData()
        End If
    End Sub

End Class