﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
 Public Class Person1
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function SubsCribeUserforNewsLetter(ByVal ArticleTypeID As Integer, ByVal UserEmailAddress As String) As String
        Dim NewUserID As Integer = -1
        Dim PList As New List(Of DBDAL.SP_Parameter)
        Dim ds As New DataSet
        Dim LoginID As String = UserEmailAddress
        Dim tbl As New DataTable
        tbl = Person.GetUserDetailByLoginID(LoginID)

        If tbl.Rows.Count > 0 Then
            tbl = New DataTable
            Dim dr As DataRow = tbl.NewRow
            tbl.Columns.Add("UserID")
            dr(0) = "-1"
            tbl.Rows.Add(dr)
            ds.Tables.Add(tbl)
        Else


            ds = Person.SubsCribeUserforNewsLetter(ArticleTypeID, UserEmailAddress)

            ''Log.WriteLog(HttpContext.Current.Session("UserID"), "User Registered", "User Registered at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform,HttpContext.Current.Request.RawUrl )
        End If


        ds.Tables(0).TableName = "SubscribeUsers"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function RegisterUser(ByVal P As String, ByVal Parameters As String) As String
        Dim NewUserID As Integer = -1
        Dim PList As New List(Of DBDAL.SP_Parameter)
        Dim ds As New DataSet
        Dim LoginID As String = ""
        PList = DBDAL.GetSPParametersList(Parameters)
        For i As Integer = 0 To PList.Count - 1
            If PList(i).ParameterName.ToLower.IndexOf("loginid") >= 0 Then
                LoginID = PList(i).ParameterValue
            End If
        Next
        Dim tbl As New DataTable
        tbl = Person.GetUserDetailByLoginID(LoginID)
        If tbl.Rows.Count > 0 Then
            tbl = New DataTable
            Dim dr As DataRow = tbl.NewRow
            tbl.Columns.Add("UserID")
            dr(0) = "-1"
            tbl.Rows.Add(dr)
            ds.Tables.Add(tbl)
        Else


            ds = Person.RegisterPerson("User_Register", PList)

            tbl = New DataTable
            tbl = Person.GetUserDetailByLoginID(LoginID)
            HttpContext.Current.Session("UserID") = tbl.Rows(0)("UserID")
            HttpContext.Current.Session("UserEmail") = tbl.Rows(0)("LoginID")
            HttpContext.Current.Session("UserName") = tbl.Rows(0)("FirstName")
            HttpContext.Current.Session("UserImage") = tbl.Rows(0)("Imagefilename")
            If ReferenceData.Setting("SendWelcomeEmail", "") = "Yes" Then
                WebsiteEmail.SendEmail(ReferenceData.Setting("FromEmailAddress", "info@explorewiki.com"), LoginID, "Forgot Password Request", "WelcomeEmail", "", "[UserName]♦" & tbl.Rows(0)("FirstName") & "¤[Password]♦" & tbl.Rows(0)("Password") & "¤")
            End If
            Log.WriteLog(Website.WebsiteID, HttpContext.Current.Session("UserID"), "User Registered", "User Registered at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=HttpContext.Current.Session("UserID"))
        End If
        ds.Tables(0).TableName = "Users"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function UpdateUserDetails(ByVal P As String, ByVal Parameters As String) As String
        Dim NewUserID As Integer = -1
        Dim PList As New List(Of DBDAL.SP_Parameter)
        Dim ds As New DataSet
        Dim LoginID As String = ""
        PList = DBDAL.GetSPParametersList(Parameters)
        For i As Integer = 0 To PList.Count - 1
            If PList(i).ParameterName.ToLower.IndexOf("loginid") >= 0 Then
                LoginID = PList(i).ParameterValue
            End If
        Next


        ds = Person.UpdateDetails(PList)


        Log.WriteLog(Website.WebsiteID, HttpContext.Current.Session("UserID"), "User Details Update", "User Updated at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)

        ds.Tables(0).TableName = "Users"
        Return ds.GetXml
    End Function

    ''<ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function ForgotPasswordRequest(ByVal LoginID As String, ByVal SecretQuestion As String, ByVal SecretQuestionAnswer As String) As String
        Dim UID As Integer
        UID = Person.ForgotPasswordRequest(LoginID)
        If UID > 0 Then
            ''Person.UserID = UID
            Log.WriteLog(Website.WebsiteID, UID, "Reset Password Request", "Reset Password " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
        Return UID.ToString
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function LoginOut(ByVal LoginID As String, ByVal UserID As String) As String

        HttpContext.Current.Session("UserID") = -1
        HttpContext.Current.Session("CurrentBusinessID") = -1
        HttpContext.Current.Session.Abandon()
        Return -1
    End Function

    ''<ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function LoginUser(ByVal LoginID As String, ByVal Password As String, ByVal RememberMe As String) As String
        Dim UID As Integer
        Dim PersonLogin As New Person
        UID = PersonLogin.Login(LoginID, Password)
        If UID > 0 Then
            HttpContext.Current.Session("UserID") = UID
            Log.WriteLog(Val(Session("CurrentBusinessID")), UID, "User Login", "User Login at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=UID)
        End If
        Return UID.ToString
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function AuthenticateUser(ByVal LoginID As String, ByVal Passoword As String) As String
        Return "Hello World"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetUserDetails(ByVal UserID As String) As String
        Dim ds As New DataSet
        If (Val(UserID) < 0 And Not (Session("UserID") Is Nothing)) Then
            UserID = HttpContext.Current.Session("UserID")
        End If

        ds = Website.User.GetPersonDetail(UserID)
        If ds.Tables.Count > 0 Then
            ds.Tables(0).TableName = "UserDetails"
            ds.Tables(1).TableName = "UserEducation"
            ds.Tables(2).TableName = "UserAdditionalDetails"
            ds.Tables(3).TableName = "UserDesignations"
            ds.Tables(4).TableName = "WebAccess"
        End If

        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetUserSpecificInfo(ByVal UserID As String, Key As String) As String
        Dim ds As New DataSet

        If (Key.ToLower().Trim().IndexOf("pass") >= 0) Then
            ds.Tables.Add(New DataTable())
        Else
            Dim value As String = ""
            Dim tbl As New DataTable()
            tbl.Columns.Add(Key)
            ''UserID = HttpContext.Current.Session("UserID")
            ds = Website.User.GetPersonDetail(UserID)
            If (ds.Tables.Count > 0) Then
                If (ds.Tables(0).Rows.Count > 0) Then
                    value = (IIf(IsDBNull(ds.Tables(0).Rows(0)(Key)), "", ds.Tables(0).Rows(0)(Key)))
                    Dim dr As DataRow
                    dr = tbl.NewRow
                    dr(Key) = value
                    tbl.Rows.Add(dr)
                End If
            End If
        End If

        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "UserDetails"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetCustomerOutstandingBalance(ByVal UserID As String) As String
        Dim ds As New DataSet
        Dim tbl As New DataTable()
        Dim HeadIds As String = ""
        HeadIds = UserID & ","
        tbl = ChartOfAccount.COA_GetAccountReceiveableSummary(HeadIds)

        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "CustomerOutstandingBalance"
        Return ds.GetXml
    End Function
End Class