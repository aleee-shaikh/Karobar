﻿Public Class ExchangeProduct
    Inherits System.Web.UI.Page

    Private Sub PurchaseProduct_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        LblProductReference.Text = ReferenceData.Setting("LblSaleProductReference", "Reference", Session("CurrentBusinessID"))
        LblProductSaleType.Text = ReferenceData.Setting("LblProductSaleType", "Sale Type", Session("CurrentBusinessID"))
        LblProductOrderDate.Text = ReferenceData.Setting("LblProductOrderDate", "Order Date", Session("CurrentBusinessID"))
        LblDueDate.Text = ReferenceData.Setting("LblDueDate", "Due Date", Session("CurrentBusinessID"))
        LblCustomer.Text = ReferenceData.Setting("LblCustomer", "Customer", Session("CurrentBusinessID"))
        LblTax.Text = ReferenceData.Setting("LblSalesTax", "Tax", Session("CurrentBusinessID"))

        LblDeliveryCharges.Text = ReferenceData.Setting("LblDeliveryCharges", "Delivery Charges", Session("CurrentBusinessID"))
        LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
        LblStockLocation.Text = ReferenceData.Setting("LblStockLocation", "Stock Location", Session("CurrentBusinessID"))
        LblScreenTitle.Text = ReferenceData.Setting("LblExchangeProductScreenTitle", "Exchange Product", Session("CurrentBusinessID"))


        ExchangeSaleOrderDetails.AddColumn("Product", New DropDownList)
        ExchangeSaleOrderDetails.AddColumn("Quantity", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("StockQuantity", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("Unit", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("Price", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("Discount", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("Total", New TextBox)
        ExchangeSaleOrderDetails.AddColumn("SaleAction", New TextBox)

        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SaleType * -1)
            DDLSaletype.DataValueField = "ArticleTypeID"
            DDLSaletype.DataTextField = "ArticleType"
            DDLSaletype.DataSource = ds.Tables(0)
            DDLSaletype.DataBind()

            DDLCustomer.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Customer)
            DDLCustomer.DataValueField = "UserID"
            DDLCustomer.DataTextField = "FirstName"
            DDLCustomer.DataBind()

            DDLSalesPerson.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Staff)
            DDLSalesPerson.DataValueField = "UserID"
            DDLSalesPerson.DataTextField = "FirstName"
            DDLSalesPerson.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.StockLocations * -1)
            DDLStockLocation.DataValueField = "ArticleTypeID"
            DDLStockLocation.DataTextField = "ArticleType"
            DDLStockLocation.DataSource = ds.Tables(0)
            DDLStockLocation.DataBind()
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim SID As Integer
        Dim CusID As Integer = -1
        Dim SaleTypeID As Integer = -1
        Dim SalePersonID As Integer = -1
        Dim StockLocation As Integer = -1

        If DDLStockLocation.Items.Count > 0 Then
            StockLocation = DDLStockLocation.SelectedItem.Value
        End If

        If DDLCustomer.Items.Count > 0 Then
            CusID = DDLCustomer.SelectedItem.Value
        End If
        If DDLSaletype.Items.Count > 0 Then
            SaleTypeID = DDLSaletype.SelectedItem.Value
        End If
        If DDLSalesPerson.Items.Count > 0 Then
            SalePersonID = DDLSalesPerson.SelectedItem.Value
        End If

        tbl = Products.SaleProductMaster(Session("CurrentBusinessID"), txtReference.Text.Trim, SaleTypeID, CusID, Val(txtTax.Text), Val(txtDeliveryCharges.Text), SalePersonID, txtOrderDate.Text, txtDueDate.Text, 1, StockLocation)
        Dim ptbl As New DataTable
        ''Dim PID As Integer
        ''ptbl = Products.PurchaseProductMaster(Session("CurrentBusinessID"), "ProductExchange", -1, DDLStockLocation.SelectedItem.Value, 0, "Product Exchange", Now)
        If tbl.Rows.Count > 0 Then
            SID = tbl.Rows(0)("SaleID")

            tbl = New DataTable
            tbl = ExchangeSaleOrderDetails.GetExchangeData

            'If ptbl.Rows.Count > 0 Then
            '    PID = ptbl.Rows(0)("PurchaseID")
            'End If
            Try
                For i As Integer = 0 To tbl.Rows.Count - 2
                    If Val(tbl.Rows(i)("Total")) < 0 Then
                        ''Products.PurchaseProductDetails(PID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), Val(tbl.Rows(i)("Quantity")), Val(tbl.Rows(i)("Price")), Val(tbl.Rows(i)("Discount")), Val(tbl.Rows(i)("Total")), Now, Now)
                        Products.SaleProductDetails(SID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), Val(tbl.Rows(i)("Quantity")) * -1, Val(tbl.Rows(i)("Price")), Val(tbl.Rows(i)("Discount")), Val(tbl.Rows(i)("Total")))
                    Else
                        Products.SaleProductDetails(SID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), Val(tbl.Rows(i)("Quantity")), Val(tbl.Rows(i)("Price")), Val(tbl.Rows(i)("Discount")), Val(tbl.Rows(i)("Total")))
                    End If
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "SaleDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product Sale", "Product Sale :" & SID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=SID)
            Catch ex As Exception
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "SaleAddingIssue", "<script>parent.ShowMessage('Unable to process sale','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End Try

        End If

    End Sub
End Class