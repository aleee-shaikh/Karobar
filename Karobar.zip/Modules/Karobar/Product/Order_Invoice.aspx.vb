﻿Public Class Order_Invoice
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblOrderReference.Text = ReferenceData.Setting("LblCashPaymentReference", "Reference", Session("CurrentBusinessID"))
            'LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
            LblOrderParticular.Text = ReferenceData.Setting("LblOrderParticular", "Remarks", Session("CurrentBusinessID"))
            'LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
            LblOrderDate.Text = ReferenceData.Setting("LblOrderDate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Purchase Order", Session("CurrentBusinessID"))
            If Not Request("OrderID") Is Nothing Then
                hdnOrderID.Value = Val(Request("OrderID"))
                LoadData()
            Else
                hdnOrderID.Value = "0"
            End If
        End If
    End Sub

    Sub LoadData()
        If Val(hdnOrderID.Value) > 0 Then
            Dim ds As New DataSet
            ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(hdnOrderID.Value))
            If ds.Tables.Count > 1 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    lblOrderNo.Text = ds.Tables(0).Rows(0)("OrderID")
                    If IsDBNull(ds.Tables(0).Rows(0)("ReferenceNo")) = False Then
                        lblOrderReference.Text = ds.Tables(0).Rows(0)("ReferenceNo")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("Remarks")) = False Then
                        LblOrderParticular.Text = ds.Tables(0).Rows(0)("Remarks")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("Dated")) = False Then
                        LblOrderDate.Text = ds.Tables(0).Rows(0)("Dated")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierID")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierID")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierName")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierAddress")) = False Then
                        lblSupplierAddress.Text = ds.Tables(0).Rows(0)("SupplierAddress")
                    End If


                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyName")) = False Then
                        lblCompanyName.Text = ds.Tables(0).Rows(0)("CompanyName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyAddress")) = False Then
                        lblCompanyAddress.Text = ds.Tables(0).Rows(0)("CompanyAddress")
                    End If
                    GrdOrderDetails.DataSource = ds.Tables(1)
                    GrdOrderDetails.DataBind()
                End If
            End If
        End If
    End Sub
End Class