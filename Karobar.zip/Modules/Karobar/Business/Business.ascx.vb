﻿Public Class Business
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then

            DDLBusinessCategory.DataSource = Website.GetWebsitesCategories
            DDLBusinessCategory.DataTextField = "CategoryTitle"
            DDLBusinessCategory.DataValueField = "WebsiteCategoryID"
            DDLBusinessCategory.DataBind()


            DDLCountry.DataSource = Website.GetCountries()
            DDLCountry.DataTextField = "CountryName"
            DDLCountry.DataValueField = "CountryID"
            DDLCountry.DataBind()

            DDLCurrency.DataSource = Website.GetCurrencies(Website.WebsiteID, HttpContext.Current.Session("UserID"))
            DDLCurrency.DataTextField = "CurrencyName"
            DDLCurrency.DataValueField = "CurrencyCode"
            DDLCurrency.DataBind()
            DDLCurrency.SelectedValue = ReferenceData.Setting("DefaultCurrency", "PKR", Session("CurrentBusinessID"))

            DDLBusinessTypes.DataSource = Website.GetBusinessTypes()
            DDLBusinessTypes.DataTextField = "TypeName"
            DDLBusinessTypes.DataValueField = "BusinessTypeID"
            DDLBusinessTypes.DataBind()

            'If (Not Session("BID") Is Nothing) AndAlso Session("BID") > 0 Then
            '    HdnBID.Value = Val(Session("BID"))
            'ElseIf (Session("BID") Is Nothing) AndAlso Val(Session("BID")) <= 0 Then
            '    Session("BID") = Session("CurrentBusinessID")
            '    HdnBID.Value = Val(Session("BID"))

            'End If

            HdnBID.Value = LoggedInUserSession.BusinessID
            LoadData(Val(HdnBID.Value))
        End If
    End Sub

    Sub LoadData(ByVal BID As Integer)
        Dim ds As New DataSet
        ds = Website.GetWebsiteDetails(LoggedInUserSession.BusinessID)
        If ds.Tables.Count > 0 Then
            txtBusinessName.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))
            txtBusinessDescription.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteDescription")), "", ds.Tables(0).Rows(0)("WebsiteDescription"))
            txtPhone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
            txtBusinessFax.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Fax")), "", ds.Tables(0).Rows(0)("Fax"))
            txtEmail.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Email")), "", ds.Tables(0).Rows(0)("Email"))
            txtBusinessAddress.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
            hdnWebsiteThemeID.Value = IIf(IsDBNull(ds.Tables(0).Rows(0)("ThemeID")), "-1", ds.Tables(0).Rows(0)("ThemeID"))
            trBusinessThemes.Visible = False

            If (IsDBNull(ds.Tables(0).Rows(0)("WebsiteCategoryID")) = False AndAlso ds.Tables(0).Rows(0)("WebsiteCategoryID") > 0) Then
                DDLBusinessCategory.SelectedValue = ds.Tables(0).Rows(0)("WebsiteCategoryID")
                lblBusinessCategory.Text = DDLBusinessCategory.SelectedItem.Text
                If ds.Tables(0).Rows(0)("WebsiteCategoryID") >= 13 And ds.Tables(0).Rows(0)("WebsiteCategoryID") <= 15 Then
                    trBusinessThemes.Visible = True
                End If
            Else
                DDLBusinessCategory.SelectedValue = "-1"
            End If

            If (IsDBNull(ds.Tables(0).Rows(0)("BusinessTypeID")) = False AndAlso ds.Tables(0).Rows(0)("BusinessTypeID") > 0) Then
                DDLBusinessTypes.SelectedValue = ds.Tables(0).Rows(0)("BusinessTypeID")
                LblBusinessType.Text = DDLBusinessTypes.SelectedItem.Text
            Else
                DDLBusinessTypes.SelectedValue = "-1"
            End If

            If (IsDBNull(ds.Tables(0).Rows(0)("CurrencyCode")) = False) Then
                DDLCurrency.SelectedValue = ds.Tables(0).Rows(0)("CurrencyCode")
            Else
                DDLCurrency.SelectedValue = ReferenceData.Setting("DefaultCurrency", "PKR", Session("CurrentBusinessID"))
            End If

            txtCity.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")), "", ds.Tables(0).Rows(0)("City"))
            txtTown.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")), "", ds.Tables(0).Rows(0)("Town"))
            txtZipCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")), "", ds.Tables(0).Rows(0)("ZipCode"))

            txtLng.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lng")), "0", ds.Tables(0).Rows(0)("Lng"))
            txtLat.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Lat")), "0", ds.Tables(0).Rows(0)("Lat"))

            txtFacebook.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("FacebookLink")), "", ds.Tables(0).Rows(0)("FacebookLink"))
            txtLinkedin.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("LinkedLink")), "", ds.Tables(0).Rows(0)("LinkedLink"))
            txtTwitter.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("TwitterLink")), "", ds.Tables(0).Rows(0)("TwitterLink"))

            If (IsDBNull(ds.Tables(0).Rows(0)("CountryID")) = False AndAlso ds.Tables(0).Rows(0)("CountryID") > 0) Then
                DDLCountry.SelectedValue = ds.Tables(0).Rows(0)("CountryID")
                lblTimeZone.Text = ds.Tables(0).Rows(0)("TimeZone") & " " & ds.Tables(0).Rows(0)("UTCOffset")
                LoggedInUserSession.TimeZone = IIf(IsDBNull(ds.Tables(0).Rows(0)("UTCOffset")), 0, ds.Tables(0).Rows(0)("UTCOffset").ToString().Trim())
            Else
                DDLCountry.SelectedValue = "-1"
            End If


            'If (IsDBNull(ds.Tables(0).Rows(0)("WebsiteLogo")) = False AndAlso ds.Tables(0).Rows(0)("WebsiteLogo") <> "") Then
            '    ''Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Website.WebsiteID & "/Businesses/") & BID & "\Images"
            '    Dim BusinessDirectory As String = "~/CMS/" & Website.WebsiteID & "/Businesses/" & BID & "/Images"
            '    HdnBusinessLogoFilename.Value = ds.Tables(0).Rows(0)("WebsiteLogo")
            '    BusinessLogo.ImageUrl = BusinessDirectory & "/" & ds.Tables(0).Rows(0)("WebsiteLogo")
            '    BusinessLogo.AlternateText = txtBusinessName.Text
            'End If



            If (IsDBNull(ds.Tables(0).Rows(0)("WebsiteLogo")) = False AndAlso ds.Tables(0).Rows(0)("WebsiteLogo") <> "") Then
                HdnBusinessLogoFilename.Value = ds.Tables(0).Rows(0)("WebsiteLogo")
                BusinessLogo.ImageUrl = "~/CMS/" & Website.WebsiteID & "/Businesses/" & Session("CurrentBusinessID") & "/Images" & "/" & ds.Tables(0).Rows(0)("WebsiteLogo")
                BusinessLogo.AlternateText = txtBusinessName.Text
            Else
                BusinessLogo.ImageUrl = "~/Images/No-Image.png"
            End If


            'If (DDLBusinessCategory.SelectedValue > 0 AndAlso DDLBusinessCategory.SelectedItem.Text.ToLower().IndexOf("ecommerce") >= 0) Then
            '    LnkWebsiteUrl.Text = "/mall?" & txtBusinessName.Text.Replace(" ", "") & "&KID=" & BID
            'Else
            '    LnkWebsiteUrl.Text = "/wikispot?" & txtBusinessName.Text.Replace(" ", "") & "&KID=" & BID
            'End If

            Dim url As String = ""
            If IsDBNull(ds.Tables(0).Rows(0)("WebsiteURL")) OrElse ds.Tables(0).Rows(0)("WebsiteURL") = "" Then
                If (DDLBusinessCategory.SelectedItem.Text.ToLower().IndexOf("job") >= 0) Then
                    url = "/job?" & txtBusinessName.Text.Replace(" ", "") & "&KID=" & BID
                ElseIf (DDLBusinessCategory.SelectedItem.Text.ToLower().ToLower().IndexOf("ecommerce") >= 0) Then
                    url = "/mall?" & txtBusinessName.Text.Replace(" ", "") & "&KID=" & BID
                    ''trBusinessThemes.Visible = True
                Else
                    url = "/mall?" & txtBusinessName.Text.Replace(" ", "") & "&KID=" & BID

                End If
            Else
                url = ds.Tables(0).Rows(0)("WebsiteURL") '& "/Home"
            End If
            ''LnkWebsiteUrl.Text = "/wikispot/" & txtBusinessName.Text.Replace(" ", "") & "?q=&KID=" & BID & "&CID=-1"
            ''"http://joined24.com/" & BID & "/" & txtBusinessName.Text.Trim.Replace(" ", "_")
            LnkWebsiteUrl.NavigateUrl = url
            LnkWebsiteUrl.Text = url
            LnkWebsiteUrl.Target = "_blank"
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click

        Dim BusinessLogoFilename As String = HdnBusinessLogoFilename.Value
        If FileUploadBusinessLogo.PostedFile.FileName <> "" And FileUploadBusinessLogo.PostedFile.FileName <> BusinessLogoFilename Then
            BusinessLogoFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadBusinessLogo.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Website.WebsiteID & "/Businesses/") & HdnBID.Value & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If

            FileUploadBusinessLogo.SaveAs(BusinessDirectory & "/" & BusinessLogoFilename)
        End If
        Dim tbl As New DataTable
        tbl = Website.UpdateWebsiteDetails(Val(HdnBID.Value), HttpContext.Current.Session("UserID"), txtBusinessName.Text.Trim, txtBusinessDescription.Text.Trim, DDLBusinessCategory.SelectedItem.Value, DDLCurrency.SelectedItem.Value, BusinessLogoFilename, txtPhone.Text.Trim, txtBusinessFax.Text.Trim, txtEmail.Text.Trim, DDLCountry.SelectedItem.Value, txtCity.Text.Trim, txtTown.Text.Trim, txtZipCode.Text.Trim, txtBusinessAddress.Text.Trim, Val(hdnWebsiteThemeID.Value), CSng(txtLat.Text), CSng(txtLng.Text), txtFacebook.Text.Trim, txtLinkedin.Text.Trim, txtTwitter.Text.Trim)
        LoadData(HdnBID.Value)
        Log.WriteLog(LoggedInUserSession.BusinessID, LoggedInUserSession.UserID, "Business", "Business Details Updated ", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, LoggedInUserSession.UserID)
        ''ClientScript.RegisterClientScriptBlock(Me.GetType(), "BusinessAddedSuccessFully", "<script>parent.HideDlgForm();parent.ShowMessage('Business added successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
    End Sub
End Class