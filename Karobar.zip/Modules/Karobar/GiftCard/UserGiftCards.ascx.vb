﻿Public Class UserGiftCards
    Inherits System.Web.UI.UserControl

    Public Property CustomerID() As Integer
        Get
            Return Val(HdnCustomerID.Value)
        End Get
        Set(value As Integer)
            HdnCustomerID.Value = value

        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Sub LoadData()
        GrdGiftCards.DataSource = GiftCard.GetUserCards(Session("CurrentBusinessID"), CustomerID)
        GrdGiftCards.DataBind()
    End Sub


    Private Sub GrdGiftCards_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdGiftCards.PageIndexChanging
        GrdGiftCards.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdGiftCards_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdGiftCards.RowCommand
        If e.CommandName = "RenewCard" Then
            Dim tmpAry = e.CommandArgument.ToString.Split("|")
            Dim GiftCardID As Integer = tmpAry(0)
            Dim UserCardID As Integer = tmpAry(1)
            GiftCard.RenewUserGiftCard(Session("CurrentBusinessID"), CustomerID, GiftCardID, UserCardID, Session("UserID"))
            LoadData()
        ElseIf e.CommandName = "CancelCard" Then
            Dim tmpAry = e.CommandArgument.ToString.Split("|")
            Dim GiftCardID As Integer = tmpAry(0)
            Dim UserCardID As Integer = tmpAry(1)
            GiftCard.CancelUserGiftCard(Session("CurrentBusinessID"), CustomerID, GiftCardID, UserCardID, Session("UserID"))
            LoadData()
        End If
    End Sub

    Private Sub GrdGiftCards_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdGiftCards.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim pnlRenewCard As New Panel
            pnlRenewCard = CType(e.Row.FindControl("pnlRenewCard"), Panel)
            Dim pnlCancelLnk As New Panel
            pnlCancelLnk = CType(e.Row.FindControl("pnlCancelLnk"), Panel)

            If (drview("CardStatusID") = 2) Then
                pnlCancelLnk.Visible = False
                pnlRenewCard.Visible = False
            ElseIf DateDiff(DateInterval.Day, Now, drview("ExpiryDate")) < 0 Then
                pnlRenewCard.Visible = True
                pnlCancelLnk.Visible = False
            End If

            Dim LnkPrintCard As New LinkButton
            LnkPrintCard = CType(e.Row.FindControl("LnkPrint"), LinkButton)
            LnkPrintCard.Attributes.Add("onclick", "return PrintGiftCard('" & drview("UserCardID") & "','" & drview("GiftCardName") & "','" & drview("UserName") & "','" & drview("IssueDate") & "','" & drview("ExpiryDate") & "','" & drview("Points") & "')")
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

End Class