﻿Public Class WorkingShifts
    Inherits System.Web.UI.Page

    Private Sub TimePunch_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

        End If
    End Sub

End Class