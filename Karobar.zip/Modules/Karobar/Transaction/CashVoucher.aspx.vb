﻿Imports System.Data.SqlClient

Public Class CashVoucher
    Inherits System.Web.UI.Page


    Private Sub PaymentsPayReceived_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 41) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then

            LblCashPaymentReference.Text = ReferenceData.Setting("LblCashPaymentReference", "Reference", Session("CurrentBusinessID"))
            LblCashPaymentFromHeadCreditAccount.Text = ReferenceData.Setting("LblCashPaymentFromHeadCreditAccount", "From Head (Credit Account)", Session("CurrentBusinessID"))
            LblCashPaymentParticular.Text = ReferenceData.Setting("LblCashPaymentParticular", "Particular", Session("CurrentBusinessID"))
            LblCashPaymentDate.Text = ReferenceData.Setting("LblCashPaymentDate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Cash Payment Voucher", Session("CurrentBusinessID"))



            DDLCreditAccount.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), AccountHeadID:=ReferenceData.Setting("AccountHeadID4CashvoucherPaymentPayReceived", "24", Session("CurrentBusinessID")))
            DDLCreditAccount.DataTextField = "AccountHeadName"
            DDLCreditAccount.DataValueField = "AccountHeadID"
            DDLCreditAccount.DataBind()


            GenericCashVoucherRow1.AddColumn("ToAccountHead", New DropDownList)
            GenericCashVoucherRow1.AddColumn("Particular", New TextBox)
            GenericCashVoucherRow1.AddColumn("ChequeNo", New TextBox)
            GenericCashVoucherRow1.AddColumn("BankCharges", New TextBox)
            GenericCashVoucherRow1.AddColumn("Tax", New TextBox)
            GenericCashVoucherRow1.AddColumn("Amount", New TextBox)
            GenericCashVoucherRow1.AddColumn("Total", New TextBox)

            txtDate.Text = Now.ToString("dd-MM-yyyy")
        End If
    End Sub


    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim CashPaymentTbl = New DataTable
        Dim CashPaymentTotal As Single
        Dim CreditHeadBalance As Single
        Dim CreditHeadtbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(DDLCreditAccount.SelectedValue & ",")
        If (CreditHeadtbl.Rows.Count > 0) Then
            CreditHeadBalance = CreditHeadtbl.Rows(0)("Balance")
        End If

        CashPaymentTbl = GenericCashVoucherRow1.GetTransactionData
        For i As Integer = 0 To CashPaymentTbl.Rows.Count - 1
            CashPaymentTotal += Val(CashPaymentTbl.Rows(i)("Total"))
        Next
        If CashPaymentTotal > CreditHeadBalance Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "CashExceeding", "<script>parent.ShowMessage('Total cash payment amount is exceeding the current balance of selected credit head.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            Return
        End If

        Dim tbl As New DataTable
        Dim TID As Integer = -1
        Dim CashAccountID As Integer = -1

        If DDLCreditAccount.Items.Count > 0 Then
            CashAccountID = DDLCreditAccount.SelectedItem.Value
        End If

        Dim DatedAry() = txtDate.Text.Replace("/", "-").Split("-")

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try

            connection.Open()
            trans = connection.BeginTransaction()


            tbl = Transactions.AddTransaction(Session("CurrentBusinessID"), txtReference.Text.Trim, "CPV", txtParticular.Text, "Active", True, CDate(DatedAry(1) & "-" & DatedAry(0) & "-" & DatedAry(2)), trans:=trans)
            If tbl.Rows.Count > 0 Then
                TID = tbl.Rows(0)("TransactionID")
                Transactions.AddTransactionDetails(TID, CashAccountID, True, txtParticular.Text, 0, GenericCashVoucherRow1.TotalAmount, 0, 0, "", trans:=trans)
                tbl = New DataTable
                tbl = GenericCashVoucherRow1.GetTransactionData

                For i As Integer = 0 To tbl.Rows.Count - 2
                    Transactions.AddTransactionDetails(TID, tbl.Rows(i)("ToAccountHead"), False, tbl.Rows(i)("Particular"), tbl.Rows(i)("Total"), 0, 0, tbl.Rows(i)("Tax"), "", trans:=trans)
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Cash payment done successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
                ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Transaction done", "Transaction ID :" & TID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=TID)
                Log.Notifications_Add("Cash Payment " & GenericCashVoucherRow1.TotalAmount, TID, "Cash Payment", GenericCashVoucherRow1.TotalAmount)

            End If

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionAddingIssue", "<script>parent.ShowMessage('Unable to process transaction','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try

    End Sub
End Class