﻿Public Class GiftCardForm
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 142) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open Gift card screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then

            If Not Request("GID") Is Nothing Then
                HdnGiftCardID.Value = Val(Request("GID"))
                lblScreenTitle.Text = "Update Gift Card"
                Dim tbl As New DataTable
                tbl = GiftCard.GetGiftCards(Val(Session("CurrentBusinessID")), Val(HdnGiftCardID.Value), "")
                If tbl.Rows.Count > 0 Then
                    txtGiftCardName.Text = tbl.Rows(0)("GiftCardName")
                    txtGiftCardValidityDays.Text = tbl.Rows(0)("ValidityDays")
                End If
            Else
                lblScreenTitle.Text = "Create New Gift Card"
            End If

        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        If Val(HdnGiftCardID.Value) > 0 Then
            tbl = GiftCard.UpdateGiftCard(Session("CurrentBusinessID"), Val(HdnGiftCardTypeID.Value), Val(HdnGiftCardID.Value), txtGiftCardName.Text.Trim, Val(txtGiftCardValidityDays.Text), HttpContext.Current.Session("UserID"))
            If tbl.Columns.Contains("Error") Then
                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAlreadyExist", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                End If
            Else
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Updated Gift Card" & txtGiftCardName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=Val(HdnGiftCardID.Value))
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
            End If
        Else
            tbl = GiftCard.AddGiftCard(Session("CurrentBusinessID"), 1, txtGiftCardName.Text.Trim, Val(txtGiftCardValidityDays.Text), HttpContext.Current.Session("UserID"))
            If tbl.Columns.Contains("Error") Then
                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAlreadyExist", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Added Gift Card" & txtGiftCardName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                txtGiftCardName.Text = ""
                txtGiftCardValidityDays.Text = ""

            End If

        End If
    End Sub
End Class