﻿Public Class GRN_Print
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblGRNReference.Text = ReferenceData.Setting("LblCashPaymentReference", "Reference", Session("CurrentBusinessID"))
            'LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
            LblGRNParticular.Text = ReferenceData.Setting("LblGRNParticular", "Remarks", Session("CurrentBusinessID"))
            'LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
            LblGRNDate.Text = ReferenceData.Setting("LblGRNDate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Goods Receive Note", Session("CurrentBusinessID"))
            If Not Request("GRNID") Is Nothing Then
                hdnGRNID.Value = Val(Request("GRNID"))
                LoadData()
            Else
                hdnGRNID.Value = "0"
            End If
        End If
    End Sub

    Sub LoadData()
        If Val(hdnGRNID.Value) > 0 Then
            Dim ds As New DataSet
            ds = GRNBLL.GetGRNDetailByID(Session("CurrentBusinessID"), hdnGRNID.Value)
            If ds.Tables.Count > 1 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    lblOrderNo.Text = ds.Tables(0).Rows(0)("GRNID")
                    If IsDBNull(ds.Tables(0).Rows(0)("ReferenceNo")) = False Then
                        lblGRNReference.Text = ds.Tables(0).Rows(0)("ReferenceNo")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("Remarks")) = False Then
                        LblGRNParticular.Text = ds.Tables(0).Rows(0)("Remarks")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("Dated")) = False Then
                        LblGRNDate.Text = CMS.General.GetLocalDateTimeByTimeZone(ds.Tables(0).Rows(0)("Dated"), CMS.LoggedInUserSession.TimeZone)
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierID")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierID")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierName")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierAddress")) = False Then
                        lblSupplierAddress.Text = ds.Tables(0).Rows(0)("SupplierAddress")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("ReceiverName")) = False Then
                        lblReceivedBy.Text = ds.Tables(0).Rows(0)("ReceiverName")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyName")) = False Then
                        lblCompanyName.Text = ds.Tables(0).Rows(0)("CompanyName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyAddress")) = False Then
                        lblCompanyAddress.Text = ds.Tables(0).Rows(0)("CompanyAddress")
                    End If
                    GrdGRNDetails.DataSource = ds.Tables(1)
                    GrdGRNDetails.DataBind()
                End If
            End If
        End If
    End Sub
End Class