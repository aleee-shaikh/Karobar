﻿Public Class FBShareProduct
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            If Not Request("OfferID") Is Nothing Then
                HdnProductID.Value = Val(Request("OfferID"))
                LoadOffer(Val(HdnProductID.Value))
            Else
                If Not Request("PID") Is Nothing Then
                    HdnProductID.Value = Val(Request("PID"))
                End If
                LoadData(Val(HdnProductID.Value))
            End If

        End If

    End Sub

    Sub LoadOffer(ByVal OfferID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = OffersAndDeals.Offer_GetOffers(-1, OfferID)

        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
        End If
        If tbl.Rows.Count > 0 Then

            txtProductName.Text = IIf(IsDBNull(tbl.Rows(0)("OfferTitle")), "", tbl.Rows(0)("OfferTitle"))
            txtDescription.Text = IIf(IsDBNull(tbl.Rows(0)("OfferDescription")), "", tbl.Rows(0)("OfferDescription"))
            If (txtDescription.Text.ToLower().IndexOf("<iframe")) >= 0 Then

                Dim Desc As String = ""
                Desc = txtDescription.Text.Substring(txtDescription.Text.ToLower().IndexOf("src=") + 5)
                Desc = Desc.Substring(0, Desc.ToLower().IndexOf(" frameborder=") - 1)
                txtDescription.Text = Desc & "<br>" & txtDescription.Text


            End If
            Dim tmpTbl As New DataTable
            tmpTbl = ChartOfAccount.GetBusinessDetails(Val(tbl.Rows(0)("WebsiteID")))

            If (IsDBNull(tbl.Rows(0)("OfferImage")) = False AndAlso tbl.Rows(0)("OfferImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Offers/Images"
                ProductImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("OfferImage")
                ProductImage.AlternateText = txtProductName.Text
                If tbl.Rows(0)("OfferImage").ToString().Trim() <> "" Then
                    ProductImage.Visible = False

                End If
            Else

                If tbl.Rows.Count > 0 Then
                    If (IsDBNull(tmpTbl.Rows(0)("websiteLogo")) = False AndAlso tmpTbl.Rows(0)("websiteLogo") <> "") Then
                        ProductImage.ImageUrl = "/CMS/1/Businesses/" & tmpTbl.Rows(0)("WebsiteID") & "/Images/" & tmpTbl.Rows(0)("websiteLogo")
                        ProductImage.AlternateText = txtProductName.Text
                    End If
                End If

            End If

            ''Response.Redirect("http://joined24.com/Detail/" & PID & "/" & tbl.Rows(0)("ArticleTitle").ToString().Replace(" ", "") & "?KID=" & tbl.Rows(0)("WebsiteID"))
            If (tmpTbl.Rows.Count > 0 AndAlso IsDBNull(tmpTbl.Rows(0)("WebsiteUrl")) = False AndAlso tmpTbl.Rows(0)("WebsiteUrl").ToString() <> "") Then
                Page.RegisterStartupScript("redirectScript", "<script>window.location='" & tmpTbl.Rows(0)("WebsiteUrl") & "/offer-detail.html?O=" & OfferID & "'</script>")
            Else
                Page.RegisterStartupScript("redirectScript", "<script>window.location='" & "http://joined24.com/Offer-Deals?KID=" & tbl.Rows(0)("WebsiteID") & "&O=" & OfferID & "'</script>")
            End If

            'If (ProductImage Is Nothing Or ProductImage.ImageUrl Is Nothing Or ProductImage.ImageUrl.ToString().Length <= 0) Then
            '    Response.Redirect("http://joined24.com/Item/" & PID & "/" & tbl.Rows(0)("ArticleTitle").ToString().Replace(" ", "") & "?KID=" & tbl.Rows(0)("WebsiteID"))
            'End If
        End If

    End Sub

    Sub LoadData(ByVal PID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Products.GetProductDetails(-1, PID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
        End If
        If tbl.Rows.Count > 0 Then

            txtProductName.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleTitle")), "", tbl.Rows(0)("ArticleTitle"))
            txtDescription.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleText")), "", tbl.Rows(0)("ArticleText"))
            Page.Title = txtProductName.Text
            If (txtDescription.Text.ToLower().IndexOf("<iframe")) >= 0 Then

                Dim Desc As String = ""
                Desc = txtDescription.Text.Substring(txtDescription.Text.ToLower().IndexOf("src=") + 5)
                Desc = Desc.Substring(0, Desc.ToLower().IndexOf(" frameborder=") - 1)
                txtDescription.Text = Desc & "<br>" & txtDescription.Text


            End If

            Dim tmpTbl As New DataTable
            tmpTbl = ChartOfAccount.GetBusinessDetails(Val(tbl.Rows(0)("WebsiteID")))
            If (IsDBNull(tbl.Rows(0)("ArticleImage")) = False AndAlso tbl.Rows(0)("ArticleImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Product/Images"
                ProductImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ArticleImage")
                ProductImage.AlternateText = txtProductName.Text
                If tbl.Rows(0)("ArticleImage").ToString().Trim() <> "" Then
                    ProductImage.Visible = False

                End If
            Else

                If tbl.Rows.Count > 0 Then
                    If (IsDBNull(tmpTbl.Rows(0)("websiteLogo")) = False AndAlso tmpTbl.Rows(0)("websiteLogo") <> "") Then
                        ProductImage.ImageUrl = "/CMS/1/Businesses/" & tmpTbl.Rows(0)("WebsiteID") & "/Images/" & tmpTbl.Rows(0)("websiteLogo")
                        ProductImage.AlternateText = txtProductName.Text

                    End If
                End If

            End If

            If (tmpTbl.Rows.Count > 0 AndAlso IsDBNull(tmpTbl.Rows(0)("WebsiteUrl")) = False AndAlso tmpTbl.Rows(0)("WebsiteUrl").ToString() <> "" AndAlso tmpTbl.Rows(0)("WebsiteCategoryID") = "14") Then 'For portal blog detail
                Page.RegisterStartupScript("redirectScript", "<script>window.location='" & tmpTbl.Rows(0)("WebsiteUrl") & "/Blog-Detail/" & PID & "/" & txtProductName.Text.Replace(" ", "-").Replace(":", "-").Replace("[", "").Replace("]", "") & "'</script>")
            ElseIf (tmpTbl.Rows.Count > 0 AndAlso IsDBNull(tmpTbl.Rows(0)("WebsiteUrl")) = False AndAlso tmpTbl.Rows(0)("WebsiteUrl").ToString() <> "") Then
                Page.RegisterStartupScript("redirectScript", "<script>window.location='" & tmpTbl.Rows(0)("WebsiteUrl") & "/product-detail.html?PID=" & PID & "'</script>")
            Else
                Page.RegisterStartupScript("redirectScript", "<script>window.location='" & "http://joined24.com/Detail/" & PID & "/" & tbl.Rows(0)("ArticleTitle").ToString().Replace(" ", "") & "?KID=" & tbl.Rows(0)("WebsiteID") & "'</script>")
            End If
            ''Response.Redirect("http://joined24.com/Detail/" & PID & "/" & tbl.Rows(0)("ArticleTitle").ToString().Replace(" ", "") & "?KID=" & tbl.Rows(0)("WebsiteID"))

            'If (ProductImage Is Nothing Or ProductImage.ImageUrl Is Nothing Or ProductImage.ImageUrl.ToString().Length <= 0) Then
            '    Response.Redirect("http://joined24.com/Item/" & PID & "/" & tbl.Rows(0)("ArticleTitle").ToString().Replace(" ", "") & "?KID=" & tbl.Rows(0)("WebsiteID"))
            'End If
        End If

    End Sub

    
End Class