﻿Public Class ManageOrder
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtOrderFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtOrderToDate.Text = Now.ToString("dd-MM-yyyy")
            ddlOrderStatus.DataSource = Products.GetOrderStatus(Val(Session("CurrentBusinessID")))
            ddlOrderStatus.DataTextField = "StatusName"
            ddlOrderStatus.DataValueField = "OrderStatusID"
            ddlOrderStatus.DataBind()
            ddlOrderStatus.Items.Insert(0, New ListItem(" -- All Orders -- ", "-1"))
            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim ds As New DataSet
        Dim FDate As String = ""
        Dim FdateAry() = txtOrderFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtOrderToDate.Text.Replace("/", "-").Split("-")

        ds = Products.GetOrderDetails(Session("CurrentBusinessID"), -1, FdateAry(2) & FdateAry(1) & FdateAry(0), TdateAry(2) & TdateAry(1) & TdateAry(0), ddlOrderStatus.SelectedValue)
        _tbl = New DataTable
        If ds.Tables.Count > 0 Then
            _tbl = ds.Tables(0)
        End If

        Session("Orders-" & Session("UserID")) = _tbl

        Dim dv As DataView = _tbl.DefaultView
        dv.Sort = SortExpression + " " + If(IsAscendingSort, "ASC", "DESC")
        GrdOrders.DataSource = dv
        GrdOrders.DataBind()
    End Sub

    Private Sub GrdOrders_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdOrders.RowCommand
        'If e.CommandName = "VoidOrder" Then
        '    Orders.VoidOrder(Session("CurrentBusinessID"), Val(e.CommandArgument), "Void")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Void Order", "Void Order :" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        '    LoadData()
        'ElseIf e.CommandName = "UnvoidOrder" Then
        '    Orders.VoidOrder(Session("CurrentBusinessID"), Val(e.CommandArgument), "Active")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "UnVoid Order", "UnVoid Order :" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        '    LoadData()
        'End If
    End Sub

    Private Sub GrdOrders_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdOrders.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LnkViewOrder As New System.Web.UI.WebControls.LinkButton
            LnkViewOrder = CType(e.Row.FindControl("LnkViewOrder"), LinkButton)
            If Not LnkViewOrder Is Nothing Then
                LnkViewOrder.OnClientClick = " ShowOrderDetails(" + Val(drview("OrderID")).ToString() + ");return false"
            End If

            'Dim LnkViewOrderInvoice As New System.Web.UI.WebControls.LinkButton
            'LnkViewOrderInvoice = CType(e.Row.FindControl("LnkViewOrderInvoice"), LinkButton)
            'If Not LnkViewOrder Is Nothing Then
            '    LnkViewOrderInvoice.OnClientClick = " ShowOrderInvoice(" + Val(drview("OrderID")).ToString() + ");return false"
            'End If
            'e.Row.Attributes.Add("onclick", "ShowOrderDetails(" + Val(drview("OrderID")).ToString() + ")")


            'If drview("OrderStatus") = "1" Then
            '    e.Row.Cells(5).Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            '    e.Row.Cells(5).Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
            'Else
            '    e.Row.Cells(5).Attributes.Add("style", "background:red;color:white")
            '    e.Row.Cells(5).Attributes.Add("onMouseOver", "this.style.backgroundColor='pink';this.style.cursor='pointer';")
            '    e.Row.Cells(5).Attributes.Add("OnMouseOut", "this.style.backgroundColor='Red';this.style.cursor='pointer';")
            'End If

            'If (IsDBNull(drview("StatusName")) OrElse drview("StatusName") = "") Then
            '    If (DateDiff(DateInterval.Hour, CDate(drview("Dated")), Now)) >= 24 Then
            '        e.Row.Cells(5).Attributes.Add("style", "background:Orange;color:white")
            '    Else
            '        e.Row.Cells(5).Attributes.Add("style", "background:Blue;color:white")
            '    End If
            'ElseIf (drview("StatusName") = "Contacted") Then
            '    e.Row.Cells(5).Attributes.Add("style", "background:pink;color:blue")
            'ElseIf (drview("StatusName") = "Cancelled") Then
            '    e.Row.Cells(5).Attributes.Add("style", "background:red;color:white")
            'ElseIf (drview("StatusName") = "Confirmed") Then
            '    e.Row.Cells(5).Attributes.Add("style", "background:yellow;color:blue")
            'ElseIf (drview("StatusName") = "Completed") Then
            '    e.Row.Cells(5).Attributes.Add("style", "background:YellowGreen;color:white")
            'End If
        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) ' Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim attachment As String = ""
        If Not Session("Orders-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("Orders-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            attachment = "attachment; filename=NoDataFound.csv"
        Else
            attachment = "attachment; filename=Orders" & Now.ToString("yyyyMMddhhmm") & ".csv"

            For i As Integer = 0 To _tbl.Columns.Count - 1
                Data = Data & _tbl.Columns(i).ColumnName & ","
            Next
            Data = Data & Environment.NewLine
            For i As Integer = 0 To _tbl.Rows.Count - 1
                For j As Integer = 0 To _tbl.Columns.Count - 1
                    Data = Data & _tbl.Rows(i)(j) & ","
                Next
                Data = Data & Environment.NewLine
            Next
        End If

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", attachment)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub GrdOrders_Sorting(sender As Object, e As GridViewSortEventArgs) Handles GrdOrders.Sorting

        Dim columnIndex As Integer = 0
        For Each headerCell In GrdOrders.HeaderRow.Cells
            If (headerCell.ContainingField.SortExpression = e.SortExpression) Then
                columnIndex = GrdOrders.HeaderRow.Cells.GetCellIndex(headerCell)
            End If
        Next

        If e.SortExpression = SortExpression Then
            IsAscendingSort = Not IsAscendingSort

        Else
            IsAscendingSort = False
            SortExpression = e.SortExpression
        End If


        For i As Integer = 0 To GrdOrders.Columns.Count - 1
            GrdOrders.Columns(i).HeaderText = GrdOrders.Columns(i).HeaderText.Replace("▲", "").Replace("▼", "")
        Next

        If (IsAscendingSort) Then
            GrdOrders.Columns(columnIndex).HeaderText = GrdOrders.Columns(columnIndex).HeaderText + "▲"
        Else
            GrdOrders.Columns(columnIndex).HeaderText = GrdOrders.Columns(columnIndex).HeaderText + "▼"
        End If
        LoadData()
    End Sub


    Protected Property IsAscendingSort As Boolean
        Get
            Dim value As Object = ViewState("IsAscendingSort")
            Return If(Not IsNothing(value), CBool(value), False)
        End Get
        Set(value As Boolean)
            ViewState("IsAscendingSort") = value
        End Set
    End Property

    Protected Property SortExpression As String
        Get
            Dim value As Object = ViewState("SortExpression")
            Return If(Not IsNothing(value), CStr(value), "UserID")
        End Get
        Set(value As String)
            ViewState("SortExpression") = value
        End Set
    End Property

End Class