﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="Joined24POS", Name:="Joined24DeviceService")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class Joined24POS
    Inherits System.Web.Services.WebService
    Dim WebKey As String = "W3bChat!2345"

#Region "Device POS"

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Sale(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim SaleDetailsParameters = Data.Split("~")(1) 'SaleDetails
        Dim MasterParametersTbl As New DataTable
        Dim SaleDetailsParametersTbl As New DataTable()


        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)
            SaleDetailsParametersTbl = General.ConvertJSONToDataTable(SaleDetailsParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If
            If SaleDetailsParametersTbl.Rows.Count > 0 Then
                SaleDetailsParametersTbl.Rows.RemoveAt(SaleDetailsParametersTbl.Rows.Count - 1)
            End If
            ds.Tables.Add(DevicePOS.Sale(MasterParametersTbl, SaleDetailsParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSSale"
        ds.Namespace = "POSSale"
        jsonData = "{""POSSale"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Purchase(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim PurchaseDetailsParameters = Data.Split("~")(1) 'PurchaseDetails
        Dim MasterParametersTbl As New DataTable
        Dim PurchaseDetailsParametersTbl As New DataTable()


        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)
            PurchaseDetailsParametersTbl = General.ConvertJSONToDataTable(PurchaseDetailsParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If
            If PurchaseDetailsParametersTbl.Rows.Count > 0 Then
                PurchaseDetailsParametersTbl.Rows.RemoveAt(PurchaseDetailsParametersTbl.Rows.Count - 1)
            End If
            ds.Tables.Add(DevicePOS.Purchase(MasterParametersTbl, PurchaseDetailsParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSPurchase"
        ds.Namespace = "POSPurchase"
        jsonData = "{""POSPurchase"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Pay(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim PayDetailsParameters = Data.Split("~")(1) 'PaymentDetails
        Dim MasterParametersTbl As New DataTable
        Dim PayDetailsParametersTbl As New DataTable()


        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)
            PayDetailsParametersTbl = General.ConvertJSONToDataTable(PayDetailsParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If
            If PayDetailsParametersTbl.Rows.Count > 0 Then
                PayDetailsParametersTbl.Rows.RemoveAt(PayDetailsParametersTbl.Rows.Count - 1)
            End If
            ds.Tables.Add(DevicePOS.Pay(MasterParametersTbl, PayDetailsParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSPay"
        ds.Namespace = "POSPay"
        jsonData = "{""POSPay"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetSaleReport(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim MasterParametersTbl As New DataTable

        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If

            ds.Tables.Add(DevicePOS.GetSaleReport(MasterParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSSaleReport"
        ds.Namespace = "POSSaleReport"
        jsonData = "{""POSSaleReport"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetPurchaseReport(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim MasterParametersTbl As New DataTable

        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If

            ds.Tables.Add(DevicePOS.GetPurchaseReport(MasterParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSPurchaseReport"
        ds.Namespace = "POSPurchaseReport"
        jsonData = "{""POSPurchaseReport"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetExpenseReport(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim MasterParametersTbl As New DataTable

        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If

            ds.Tables.Add(DevicePOS.GetExpenseReport(MasterParametersTbl))
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "POSExpenseReport"
        ds.Namespace = "POSExpenseReport"
        jsonData = "{""POSExpenseReport"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetDashboardSummary(Key As String, Data As String) As String
        Dim ds As New DataSet
        Dim jsonData As String
        Dim MasterParameters = Data.Split("~")(0) 'Master Parameters
        Dim MasterParametersTbl As New DataTable

        If Key = ConfigurationManager.AppSettings("WebServicePOSTokenKey") Then
            MasterParametersTbl = General.ConvertJSONToDataTable(MasterParameters)

            If MasterParametersTbl.Rows.Count > 0 Then
                MasterParametersTbl.Rows.RemoveAt(MasterParametersTbl.Rows.Count - 1)
            End If

            ds.Tables.Add(DevicePOS.GetSaleSummary(MasterParametersTbl))
            ds.Tables(0).TableName = "DashboardSaleSummary"
            ds.Tables.Add(DevicePOS.GetPurchaseSummary(MasterParametersTbl))
            ds.Tables(1).TableName = "DashboardPurchaseSummary"
            ds.Tables.Add(DevicePOS.GetExpenseSummary(MasterParametersTbl))
            ds.Tables(2).TableName = "DashboardExpenseSummary"
        Else
            ds.Tables.Add(New DataTable())
        End If
        'ds.Tables(0).TableName = "DashboardSummary"
        ds.Namespace = "DashboardSummary"
        jsonData = "{""SaleSummary"":" & General.GetDataTableJson(ds.Tables(0)) & ",""PurchaseSummary"":" & General.GetDataTableJson(ds.Tables(1)) & ",""ExpenseSummary"":" & General.GetDataTableJson(ds.Tables(2)) & "}"

        Return jsonData
    End Function
#End Region




End Class