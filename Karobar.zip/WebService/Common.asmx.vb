﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
 Public Class Common
    Inherits System.Web.Services.WebService


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function GetNewTickets(ByVal TicketTypeID As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim xds As New DataSet

        ds = Tickets.GetTickets(Val(Session("CurrentBusinessID")), -1, "", Now.ToString("yyyyMMdd"), Now.ToString("yyyyMMdd"))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                Try
                    tbl = ds.Tables(0).Select("TicketStatusID=1").CopyToDataTable
                Catch ex As Exception

                End Try
            End If
        End If

        xds.Tables.Add(tbl)
        xds.Tables(0).TableName = "Tickets"
        Return xds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Products_GetProducts(ByVal BID As String, Catagory As String, SubCatagory As String, SearchText As String, PageNo As Integer, PageSize As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Products.GetProductsList(Val(BID), Catagory:=Catagory, SubCatagory:=SubCatagory, SearchText:=SearchText, PageNo:=Val(PageNo), PageSize:=Val(PageSize))
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "ProductsList"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Products_GetProductsWithSortOrders(ByVal BID As String, Catagory As String, SubCatagory As String,
                                                   SearchText As String, PageNo As Integer, PageSize As Integer,
                                                   SortField As String, SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Products.GetProductsList(Val(BID), Catagory:=Catagory, SubCatagory:=SubCatagory, SearchText:=SearchText, PageNo:=Val(PageNo), PageSize:=Val(PageSize), SortField:=SortField, SortOrder:=SortOrder)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "ProductsList"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Products_GetProductDetails(BID As String, ByVal PID As String) As String
        Dim ds As New DataSet
        ds = Products.GetProductDetails(BID, PID)

        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "ProductDetail"
        If ds.Tables.Count > 1 Then ds.Tables(1).TableName = "ProductImages"

        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetBusinessDetails(ByVal BID As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = ChartOfAccount.GetBusinessDetails(BID)
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "BusinessDetails"
        Return ds.GetXml().ToString()
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function COA_GetLast12MonthConsolidatedSummary(KID As Integer, ByVal StartDate As DateTime, EndDate As DateTime) As String
        Dim tbl As New DataTable
        Dim Sale(12) As Single
        Dim Purchase(12) As Single
        Dim Expenses(12) As Single
        Dim Months(12) As String
        Dim TotalSale As Single
        Dim TotalPurchase As Single
        Dim TotalExpenses As Single
        Dim ExpenseHeadID As Integer

        Dim ds As New DataSet
        KID = Val(LoggedInUserSession.BusinessID)
        ExpenseHeadID = Val(ReferenceData.Setting("ExpenseHeadID", "", KID))

        'Dim TotalMonths As Integer = DateDiff(DateInterval.Month, StartDate, EndDate)

        For i As Integer = 1 To 12 'TotalMonths - 1

            Months(i - 1) = MonthName(StartDate.AddMonths((i - 1) * -1).Month).Substring(0, 3) & "-" & StartDate.AddMonths((i - 1) * -1).Year
            tbl = New DataTable
            tbl = Products.SaleReport(KID, -1, -1, "", StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                Sale(i - 1) = Sale(i - 1) + (((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount")) + tbl.Rows(j)("Tax"))
            Next
            TotalSale = TotalSale + Sale(i - 1)

            tbl = New DataTable
            tbl = Products.PurchaseReport(KID, -1, -1, "", StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                Purchase(i - 1) = Purchase(i - 1) + ((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount"))
            Next
            TotalPurchase = TotalPurchase + Purchase(i - 1)


            tbl = New DataTable
            tbl = ChartOfAccount.GetExpensesSummary(KID, ExpenseHeadID, StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                Expenses(i - 1) = Expenses(i - 1) + tbl.Rows(j)("Debit")
            Next
            TotalExpenses = TotalExpenses + Expenses(i - 1)
        Next

        Dim dr As DataRow
        Dim Saletbl As New DataTable
        For i As Integer = 1 To 12
            Saletbl.Columns.Add(Months(i - 1))
        Next
        Saletbl.Columns.Add("TotalSale")
        dr = Saletbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = Math.Round(Sale(i - 1), 2)
        Next
        dr(Saletbl.Columns.Count - 1) = Math.Round(TotalSale, 2)
        Saletbl.Rows.Add(dr)

        Dim Purcshasetbl As New DataTable
        For i As Integer = 1 To 12
            Purcshasetbl.Columns.Add(Months(i - 1))
        Next
        Purcshasetbl.Columns.Add("TotalPurchase")

        dr = Purcshasetbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = Purchase(i - 1)
        Next
        dr(Purcshasetbl.Columns.Count - 1) = TotalPurchase
        Purcshasetbl.Rows.Add(dr)

        Dim Expensestbl As New DataTable
        For i As Integer = 1 To 12
            Expensestbl.Columns.Add(Months(i - 1))
        Next
        Expensestbl.Columns.Add("TotalExpenses")

        dr = Expensestbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = Expenses(i - 1)
        Next
        dr(Expensestbl.Columns.Count - 1) = TotalExpenses
        Expensestbl.Rows.Add(dr)

        Dim Monthstbl As New DataTable
        Monthstbl.Columns.Add("Months")
        For i As Integer = 0 To 11
            dr = Monthstbl.NewRow
            dr(0) = Months(i)
            Monthstbl.Rows.Add(dr)
        Next

        ds.Tables.Add(Purcshasetbl)
        ds.Tables.Add(Saletbl)
        ds.Tables.Add(Expensestbl)
        ds.Tables.Add(Monthstbl)
        ds.Tables(0).TableName = "Purchase"
        ds.Tables(1).TableName = "Sale"
        ds.Tables(2).TableName = "Expenses"
        ds.Tables(3).TableName = "Last12Months"

        Return ds.GetXml()
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function COA_GetMonthWiseAccountSummary(BID As Integer, AccountHeadID As Integer, ByVal StartDate As DateTime, EndDate As DateTime) As String
        Dim tbl As New DataTable
        Dim SummaryData(12) As Single
        Dim Months(12) As String
        Dim Total As Single

        Dim ds As New DataSet
        BID = Val(LoggedInUserSession.BusinessID)

        For i As Integer = 1 To 12 'TotalMonths - 1
            tbl = New DataTable
            tbl = ChartOfAccount.GetExpensesSummary(BID, AccountHeadID, StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                SummaryData(i - 1) = SummaryData(i - 1) + tbl.Rows(j)("Debit")
            Next
            Total = Total + SummaryData(i - 1)
        Next

        Dim dr As DataRow
        Dim SummaryDatatbl As New DataTable
        For i As Integer = 1 To 12
            SummaryDatatbl.Columns.Add(Months(i - 1))
        Next
        SummaryDatatbl.Columns.Add("Total")

        dr = SummaryDatatbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = SummaryData(i - 1)
        Next
        dr(SummaryDatatbl.Columns.Count - 1) = Total
        SummaryDatatbl.Rows.Add(dr)

        Dim Monthstbl As New DataTable
        Monthstbl.Columns.Add("Months")
        For i As Integer = 0 To 11
            dr = Monthstbl.NewRow
            dr(0) = Months(i)
            Monthstbl.Rows.Add(dr)
        Next

        ds.Tables.Add(SummaryDatatbl)
        ds.Tables.Add(Monthstbl)
        ds.Tables(0).TableName = "MonthsWiseAccountHeadSummary"
        ds.Tables(1).TableName = "MonthLabels"
        Return ds.GetXml()
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetAccountHeadsBalanceSummary(ByVal AccountHeadIDs As String) As String
        Dim Cr As Single = 0
        Dim Dr As Single = 0
        Dim Balance As Single = 0
        Dim AmountReceiveable As Single = 0
        Dim tbl As New DataTable
        Dim COATbl As New DataTable
        Dim HeadIDsAry() = AccountHeadIDs.Split(",")
        Dim HeadIds As String = ""
        Dim ds As New DataSet

        COATbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"))
        For Each itm In HeadIDsAry
            If itm <> "" Then HeadIds = ChartOfAccount.GetAccountHeadTree(COATbl, itm) & ","
            HeadIds = HeadIds.Replace(",,", ",")
        Next
        HeadIds = HeadIds.Replace(",,", ",")
        tbl = ChartOfAccount.GetCOAAccountHeadsBalance(HttpContext.Current.Session("CurrentBusinessID"), HeadIds)

        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "AccountHeadsBalanceSummary"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
           <WebMethod(EnableSession:=True)> _
    Public Function COA_GetRecentTransactions(ByVal AccountHeadIDs As String) As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""

        AccountHeadIDs = ReferenceData.Setting("AccountHeadIDs4Log", "", Session("CurrentBusinessID"))
        ds = Transactions.GetTransactions(Session("CurrentBusinessID"), AccountHeadIDs, Now.AddDays(-30), Now, "")

        ds.Tables(0).TableName = "RecentTransactions"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetAccountsHeadLog(ByVal AccountHeadIDs As String, ByVal LogIDs As String) As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""
        Dim LogTbl As New DataTable

        AccountHeadIDs = ReferenceData.Setting("AccountHeadIDs4Log", "", Session("CurrentBusinessID"))
        ''LogTbl = Log.GetAccountHeadsLog(HttpContext.Current.Session("UserID"), AccountHeadIDs, "", Now.AddDays(-30).ToString("dd-MM-yyyy"), Now.ToString("dd-MM-yyyy"), LogIDs)
        LogTbl = Log.GetAccountHeadsLog(HttpContext.Current.Session("UserID"), AccountHeadIDs, "", CDate(Now.AddDays(-30)), CDate(Now), LogIDs)

        ds.Tables.Add(LogTbl)
        ds.Tables(0).TableName = "AccountsHeadLog"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetAccountsHeadSummary(ByVal AccountHeadIDs As String) As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""
        Dim COATbl As New DataTable
        Dim Summarytbl As New DataTable
        Summarytbl.Columns.Add("ParentAccountHeadID")
        Summarytbl.Columns.Add("AccountHeadID")
        Summarytbl.Columns.Add("AccountHeadName")
        Summarytbl.Columns.Add("Debit")
        Summarytbl.Columns.Add("Credit")
        Summarytbl.Columns.Add("Balance")

        ''Account Receiveable
        Dim tbl As New DataTable
        Dim HeadIds As String = ""
        Dim Cr As Single = 0
        Dim Dr As Single = 0
        Dim Balance As Single = 0
        Dim SummaryDataRow As DataRow
        ''HeadIds = ReferenceData.Setting("CustomerAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("SupplierAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("StaffAccountHeadID", "", Session("CurrentBusinessID"))
        ''tbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(HeadIds)
        ''HeadIds = ReferenceData.Setting("CustomerAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("SupplierAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("StaffAccountHeadID", "", Session("CurrentBusinessID") )
        HeadIds = ReferenceData.Setting("CustomerAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("StaffAccountHeadID", "", Session("CurrentBusinessID"))
        tbl = ChartOfAccount.COA_GetAccountReceiveableSummary(HeadIds)
        ''tbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(HeadIds)
        'Try
        '    tbl = tbl.Select("Balance<0").CopyToDataTable()
        'Catch ex As Exception

        'End Try
        For i As Integer = 0 To tbl.Rows.Count - 1
            ''If tbl.Rows(i)("Balance") < 0 Then Balance = Balance + Math.Abs(tbl.Rows(i)("Balance"))
            Balance = Balance + tbl.Rows(i)("Balance")
        Next
        If tbl.Rows.Count > 0 Then
            SummaryDataRow = Summarytbl.NewRow
            SummaryDataRow("ParentAccountHeadID") = tbl.Rows(0)("ParentAccountHeadID")
            SummaryDataRow("AccountHeadID") = tbl.Rows(0)("AccountHeadID")
            SummaryDataRow("AccountHeadName") = "AccountReceiveable"
            SummaryDataRow("Debit") = Dr
            SummaryDataRow("Credit") = Cr
            SummaryDataRow("Balance") = Math.Abs(Balance)
            Summarytbl.Rows.Add(SummaryDataRow)
        End If


        ''Account Payable
        tbl = New DataTable
        Cr = 0
        Dr = 0
        Balance = 0

        HeadIds = ReferenceData.Setting("CustomerAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("SupplierAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("StaffAccountHeadID", "", Session("CurrentBusinessID"))

        ''tbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(HeadIds)
        tbl = ChartOfAccount.COA_GetAccountPayableSummary(HeadIds)
        'Try
        '    tbl = tbl.Select("Balance>0").CopyToDataTable()
        'Catch ex As Exception

        'End Try
        For i As Integer = 0 To tbl.Rows.Count - 1
            ''If tbl.Rows(i)("Balance") > 0 Then
            ''Balance = Balance + Math.Abs(tbl.Rows(i)("Balance"))
            Balance = Balance + IIf(IsDBNull(tbl.Rows(i)("Balance")), 0, tbl.Rows(i)("Balance")) ''+ tbl.Rows(i)("DueAmount")
            ''End If
        Next
        If tbl.Rows.Count > 0 Then
            SummaryDataRow = Summarytbl.NewRow
            SummaryDataRow("ParentAccountHeadID") = tbl.Rows(0)("ParentAccountHeadID")
            SummaryDataRow("AccountHeadID") = tbl.Rows(0)("AccountHeadID")
            SummaryDataRow("AccountHeadName") = "AccountsPayable"
            SummaryDataRow("Debit") = Dr
            SummaryDataRow("Credit") = Cr
            SummaryDataRow("Balance") = Math.Abs(Balance)
            Summarytbl.Rows.Add(SummaryDataRow)
        End If

        ''Cash in Hand
        tbl = New DataTable
        Cr = 0
        Dr = 0
        Balance = 0

        HeadIds = ReferenceData.Setting("CashInHandAccountHeadID", "", Session("CurrentBusinessID")) & ","

        tbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(HeadIds)
        Dim CashInHandTbl As New DataTable
        Try
            CashInHandTbl = tbl.Select("Balance>0").CopyToDataTable()
        Catch ex As Exception

        End Try

        tbl = CashInHandTbl

        For i As Integer = 0 To tbl.Rows.Count - 1
            Balance = Balance + Math.Abs(tbl.Rows(i)("Balance"))
        Next
        If tbl.Rows.Count > 0 Then
            SummaryDataRow = Summarytbl.NewRow
            SummaryDataRow("ParentAccountHeadID") = tbl.Rows(0)("ParentAccountHeadID")
            SummaryDataRow("AccountHeadID") = tbl.Rows(0)("AccountHeadID")
            SummaryDataRow("AccountHeadName") = "CashinHand"
            SummaryDataRow("Debit") = Dr
            SummaryDataRow("Credit") = Cr
            SummaryDataRow("Balance") = Balance
            Summarytbl.Rows.Add(SummaryDataRow)
        End If


        ''Banks
        tbl = New DataTable
        Cr = 0
        Dr = 0
        Balance = 0

        HeadIds = ReferenceData.Setting("BankAccountHeadID", "", Session("CurrentBusinessID")) & ","

        tbl = ChartOfAccount.COA_GetAccountHeadsBalanceSummary(HeadIds)
        Try
            tbl = tbl.Select("Balance>0").CopyToDataTable()
        Catch ex As Exception

        End Try
        For i As Integer = 0 To tbl.Rows.Count - 1
            Balance = Balance + Math.Abs(IIf(IsDBNull(tbl.Rows(i)("Balance")), 0, tbl.Rows(i)("Balance")))
        Next
        If tbl.Rows.Count > 0 Then
            SummaryDataRow = Summarytbl.NewRow
            SummaryDataRow("ParentAccountHeadID") = tbl.Rows(0)("ParentAccountHeadID")
            SummaryDataRow("AccountHeadID") = tbl.Rows(0)("AccountHeadID")
            SummaryDataRow("AccountHeadName") = "Banks"
            SummaryDataRow("Debit") = Dr
            SummaryDataRow("Credit") = Cr
            SummaryDataRow("Balance") = Balance
            Summarytbl.Rows.Add(SummaryDataRow)
        End If

        ''Sale on Cash
        tbl = New DataTable
        Cr = 0
        Dr = 0
        Balance = 0
        Dim TypeID As Integer
        HeadIds = ""
        TypeID = Val(ReferenceData.Setting("CashTypeID4Sale", "", Session("CurrentBusinessID")))

        tbl = ChartOfAccount.GetCOASaleOnCash(Session("CurrentBusinessID"), TypeID)

        For i As Integer = 0 To tbl.Rows.Count - 1
            Balance = Balance + Math.Abs(tbl.Rows(i)("TotalAmount"))
        Next
        If tbl.Rows.Count > 0 Then
            SummaryDataRow = Summarytbl.NewRow
            SummaryDataRow("ParentAccountHeadID") = -1 '' tbl.Rows(0)("ParentAccountHeadID")
            SummaryDataRow("AccountHeadID") = -1 ''tbl.Rows(0)("AccountHeadID")
            SummaryDataRow("AccountHeadName") = "SaleOnCash"
            SummaryDataRow("Debit") = Dr
            SummaryDataRow("Credit") = Cr
            SummaryDataRow("Balance") = Balance
            Summarytbl.Rows.Add(SummaryDataRow)
        End If


        ds.Tables.Add(Summarytbl)
        ds.Tables(0).TableName = "AccountsHeadSummary"
        Return ds.GetXml
    End Function



    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetPurchaseSummary(ByVal ProductIDs As String) As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""
        Dim COATbl As New DataTable
        Dim tbl As New DataTable
        Dim drow As DataRow
        Dim Summarytbl As New DataTable
        Dim TodaysPurchaseAmount As Single = 0
        Dim YesterdayPurchaseAmount As Single = 0
        Dim ThisMonthPurchaseAmount As Single = 0
        Dim Last6MonthsPurchaseAmount As Single = 0
        Dim Last12MonthsPurchaseAmount As Single = 0

        Summarytbl.Columns.Add("TodaysPurchaseAmount")
        Summarytbl.Columns.Add("YesterdayPurchaseAmount")
        Summarytbl.Columns.Add("ThisMonthPurchaseAmount")
        Summarytbl.Columns.Add("Last6MonthsPurchaseAmount")
        Summarytbl.Columns.Add("Last12MonthsPurchaseAmount")
        drow = Summarytbl.NewRow

        tbl = New DataTable
        tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", Now.ToString("MM-dd-yyyy") & " 00:00:00 AM", Now.ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            TodaysPurchaseAmount = TodaysPurchaseAmount + ((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount"))
        Next
        drow("TodaysPurchaseAmount") = TodaysPurchaseAmount

        tbl = New DataTable
        tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", Now.AddDays(-1).ToString("MM-dd-yyyy") & " 00:00:00 AM", Now.AddDays(-1).ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            YesterdayPurchaseAmount = YesterdayPurchaseAmount + ((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount"))
        Next
        drow("YesterdayPurchaseAmount") = YesterdayPurchaseAmount

        tbl = New DataTable
        tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", CDate(Now.ToString("MM") & "-01-" & Now.ToString("yyyy")).ToString("MM-dd-yyyy") & " 00:00:00 AM", CDate(Now.ToString("MM") & "-" & Now.DaysInMonth(Now.Year, Now.Month) & "-" & Now.ToString("yyyy")).ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            ThisMonthPurchaseAmount = ThisMonthPurchaseAmount + ((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount"))
        Next
        drow("ThisMonthPurchaseAmount") = ThisMonthPurchaseAmount

        tbl = New DataTable
        tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", Now.AddMonths(-6).ToString("MM-dd-yyyy"), Now.ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last6MonthsPurchaseAmount = Last6MonthsPurchaseAmount + ((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount"))
        Next
        drow("Last6MonthsPurchaseAmount") = Last6MonthsPurchaseAmount

        tbl = New DataTable
        tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", Now.AddMonths(-12).ToString("MM-dd-yyyy") & " 00:00:00 AM", Now.ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last12MonthsPurchaseAmount = Last12MonthsPurchaseAmount + ((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount"))
        Next
        drow("Last12MonthsPurchaseAmount") = Last12MonthsPurchaseAmount

        Summarytbl.Rows.Add(drow)
        ds.Tables.Add(Summarytbl)
        ds.Tables(0).TableName = "PurchaseSummary"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetExpenseSummary() As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""
        Dim COATbl As New DataTable
        Dim tbl As New DataTable
        Dim drow As DataRow
        Dim Summarytbl As New DataTable
        Dim TodaysExpenseAmount As Single = 0
        Dim YesterdayExpenseAmount As Single = 0
        Dim ThisMonthExpenseAmount As Single = 0
        Dim Last6MonthsExpenseAmount As Single = 0
        Dim Last12MonthsExpenseAmount As Single = 0
        Dim ExpenseHeadID As Integer
        ExpenseHeadID = Val(ReferenceData.Setting("ExpenseHeadID", "", LoggedInUserSession.BusinessID))

        Summarytbl.Columns.Add("TodaysExpenseAmount")
        Summarytbl.Columns.Add("YesterdayExpenseAmount")
        Summarytbl.Columns.Add("ThisMonthExpenseAmount")
        Summarytbl.Columns.Add("Last6MonthsExpenseAmount")
        Summarytbl.Columns.Add("Last12MonthsExpenseAmount")
        drow = Summarytbl.NewRow

        ''tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, Now.ToString("MM-dd-yyyy"), Now.ToString("MM-dd-yyyy"))
        tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, Now.ToString("MM-dd-yyyy"), Now.ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            TodaysExpenseAmount = TodaysExpenseAmount + tbl.Rows(i)("Debit")
        Next
        drow("TodaysExpenseAmount") = TodaysExpenseAmount

        tbl = New DataTable

        tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, Now.AddDays(-1).ToString("MM-dd-yyyy"), Now.AddDays(-1).ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            YesterdayExpenseAmount = YesterdayExpenseAmount + tbl.Rows(i)("Debit")
        Next
        drow("YesterdayExpenseAmount") = YesterdayExpenseAmount

        tbl = New DataTable
        tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, CDate(Now.ToString("MM") & "-01-" & Now.ToString("yyyy")).ToString("MM-dd-yyyy"), CDate(Now.ToString("MM") & "-" & Now.DaysInMonth(Now.Year, Now.Month) & "-" & Now.ToString("yyyy")).ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            ThisMonthExpenseAmount = ThisMonthExpenseAmount + tbl.Rows(i)("Debit")
        Next
        drow("ThisMonthExpenseAmount") = ThisMonthExpenseAmount

        tbl = New DataTable
        tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, Now.AddMonths(-6).ToString("MM-dd-yyyy"), Now.ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last6MonthsExpenseAmount = Last6MonthsExpenseAmount + tbl.Rows(i)("Debit")
        Next
        drow("Last6MonthsExpenseAmount") = Last6MonthsExpenseAmount

        tbl = New DataTable
        tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, Now.AddMonths(-12).ToString("MM-dd-yyyy"), Now.ToString("MM-dd-yyyy"))
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last12MonthsExpenseAmount = Last12MonthsExpenseAmount + tbl.Rows(i)("Debit")
        Next
        drow("Last12MonthsExpenseAmount") = Last12MonthsExpenseAmount

        Summarytbl.Rows.Add(drow)
        ds.Tables.Add(Summarytbl)
        ds.Tables(0).TableName = "ExpenseSummary"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod(EnableSession:=True)> _
    Public Function COA_GetSaleSummary(ByVal ProductIDs As String) As String
        Dim ds As New DataSet
        Dim COAHeadIDS As String = ""
        Dim COATbl As New DataTable
        Dim tbl As New DataTable
        Dim drow As DataRow
        Dim Summarytbl As New DataTable
        Dim TodaysSaleAmount As Single = 0
        Dim YesterdaySaleAmount As Single = 0
        Dim ThisMonthSaleAmount As Single = 0
        Dim Last6MonthsSaleAmount As Single = 0
        Dim Last12MonthsSaleAmount As Single = 0
        Dim UserDateTime As DateTime = General.GetLocalDateTimeByTimeZone(Now.ToUniversalTime(), LoggedInUserSession.TimeZone)

        Summarytbl.Columns.Add("TodaysSaleAmount")
        Summarytbl.Columns.Add("YesterdaySaleAmount")
        Summarytbl.Columns.Add("ThisMonthSaleAmount")
        Summarytbl.Columns.Add("Last6MonthsSaleAmount")
        Summarytbl.Columns.Add("Last12MonthsSaleAmount")
        drow = Summarytbl.NewRow

        tbl = New DataTable
        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", UserDateTime.ToString("MM-dd-yyyy") & " 00:00:00 AM", UserDateTime.ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            TodaysSaleAmount = TodaysSaleAmount + (((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount")) + tbl.Rows(i)("Tax"))
        Next
        drow("TodaysSaleAmount") = Math.Round(TodaysSaleAmount, 2)

        tbl = New DataTable
        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", UserDateTime.AddDays(-1).ToString("MM-dd-yyyy") & " 00:00:00 AM", UserDateTime.AddDays(-1).ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            YesterdaySaleAmount = YesterdaySaleAmount + (((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount")) + tbl.Rows(i)("Tax"))
        Next
        drow("YesterdaySaleAmount") = Math.Round(YesterdaySaleAmount, 2)

        tbl = New DataTable
        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", CDate(UserDateTime.ToString("MM") & "-01-" & UserDateTime.ToString("yyyy")).ToString("MM-dd-yyyy") & " 00:00:00 AM", CDate(UserDateTime.ToString("MM") & "-" & UserDateTime.DaysInMonth(UserDateTime.Year, UserDateTime.Month) & "-" & UserDateTime.ToString("yyyy")).ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            ThisMonthSaleAmount = ThisMonthSaleAmount + (((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount")) + tbl.Rows(i)("Tax"))
        Next
        drow("ThisMonthSaleAmount") = Math.Round(ThisMonthSaleAmount, 2)

        tbl = New DataTable
        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", UserDateTime.AddMonths(-6).ToString("MM-dd-yyyy") & " 00:00:00 AM", UserDateTime.ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last6MonthsSaleAmount = Last6MonthsSaleAmount + (((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount")) + tbl.Rows(i)("Tax"))
        Next
        drow("Last6MonthsSaleAmount") = Math.Round(Last6MonthsSaleAmount, 2)

        tbl = New DataTable
        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", UserDateTime.AddMonths(-12).ToString("MM-dd-yyyy") & " 00:00:00 AM", UserDateTime.ToString("MM-dd-yyyy") & " 23:59:59 PM")
        For i As Integer = 0 To tbl.Rows.Count - 1
            Last12MonthsSaleAmount = Last12MonthsSaleAmount + (((tbl.Rows(i)("Price") * tbl.Rows(i)("Quantity")) - tbl.Rows(i)("Discount")) + tbl.Rows(i)("Tax"))
        Next
        drow("Last12MonthsSaleAmount") = Math.Round(Last12MonthsSaleAmount, 2)

        Summarytbl.Rows.Add(drow)
        ds.Tables.Add(Summarytbl)
        ds.Tables(0).TableName = "SaleSummary"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function GetContactUsData(ByVal UserID As String) As String
        Dim ds As New DataSet
        Dim DBObj As New DBDAL
        Dim tbl As New DataTable
        Dim dr As DataRow

        Dim FromDepartmentID As String = ReferenceData.Setting("WebsiteContactUsFromDepartmentID", "5") 'Website Users
        Dim FromDepartmentName As String = DBObj.GetValuesFromTable("Departments", FromDepartmentID, "DepartmentID", "DepartmentName")
        Dim FromTeamID As String = ReferenceData.Setting("WebsiteContactUsFromTeamID", "1") ''Website Users
        Dim FromTeamName As String = DBObj.GetValuesFromTable("Team", FromTeamID, "TeamID", "TeamName")
        Dim FromPersonID As String = ReferenceData.Setting("WebsiteContactUsFromPersonID", HttpContext.Current.Session("UserID"))
        Dim FromPersonName As String = HttpContext.Current.Session("UserName")
        Dim ToTeamID As String = ReferenceData.Setting("WebsiteContactUsToTeamID", "2") ''Website Support
        Dim ToTeamName As String = DBObj.GetValuesFromTable("Team", ToTeamID, "TeamID", "TeamName")
        Dim ToPersonID As String = ReferenceData.Setting("WebsiteContactUsToPersonID", "1")
        Dim ToPersonName As String = DBObj.GetValuesFromTable("Users", ToPersonID, "UserID", "FirstName")
        Dim ToDepartmentID As String = ReferenceData.Setting("WebsiteContactUsToDepartmentID", "4") ''Website Support
        Dim ToDepartmentName As String = DBObj.GetValuesFromTable("Departments", ToDepartmentID, "DepartmentID", "DepartmentName")
        Dim TicketTypeID As String = ReferenceData.Setting("WebsiteContactUsTicketTypeID", "2") ''Contact us
        Dim TicketTypeName As String = DBObj.GetValuesFromTable("TicketTypes", TicketTypeID, "TicketTypeID", "TicketType")
        Dim TicketPriorityID As String = ReferenceData.Setting("WebsiteContactUsTicketPriorityID", "3") ''Normal
        Dim TicketStatusID As String = ReferenceData.Setting("WebsiteContactUsTicketStatusID", "1") ''Normal

        tbl.Columns.Add("FromDepartmentID")
        tbl.Columns.Add("FromDepartmentName")
        tbl.Columns.Add("FromTeamID")
        tbl.Columns.Add("FromTeamName")
        tbl.Columns.Add("FromPersonID")
        tbl.Columns.Add("FromPersonName")
        tbl.Columns.Add("ToTeamID")
        tbl.Columns.Add("ToTeamName")
        tbl.Columns.Add("ToPersonID")
        tbl.Columns.Add("ToPersonName")
        tbl.Columns.Add("ToDepartmentID")
        tbl.Columns.Add("ToDepartmentName")
        tbl.Columns.Add("TicketTypeID")
        tbl.Columns.Add("TicketTypeName")
        tbl.Columns.Add("TicketPriorityID")
        tbl.Columns.Add("TicketStatusID")
        dr = tbl.NewRow
        dr("FromDepartmentID") = FromDepartmentID
        dr("FromDepartmentName") = FromDepartmentName
        dr("FromTeamID") = FromTeamID
        dr("FromTeamName") = FromTeamName
        dr("FromPersonID") = FromPersonID
        dr("FromPersonName") = FromPersonName
        dr("ToTeamID") = ToTeamID
        dr("ToTeamName") = ToTeamName
        dr("ToPersonID") = ToPersonID
        dr("ToPersonName") = ToPersonName
        dr("ToDepartmentID") = ToDepartmentID
        dr("ToDepartmentName") = ToDepartmentName
        dr("TicketTypeID") = TicketTypeID
        dr("TicketPriorityID") = TicketPriorityID
        dr("TicketStatusID") = TicketStatusID
        tbl.Rows.Add(dr)
        ds.Tables.Add(tbl)

        ds.Tables(0).TableName = "ContactUsData"

        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function SendContactUsEmail(ByVal P As String, ByVal Parameters As String) As String
        Dim PList As New List(Of DBDAL.SP_Parameter)
        Dim Param As New DBDAL.SP_Parameter
        Dim FromUserName As String = ""
        Dim FromUserEmail As String = ""
        Dim PhoneNo As String = ""
        Dim Subject As String = ""
        Dim Message As String = ""
        Dim Department As String = ""
        Dim Country As String = ""
        Dim City As String = ""
        Dim PostCode As String = ""
        Dim ToUserEmail As String = ""
        Dim FromDepartmentName As String = ""
        Dim FromDepartmentID As String = ""
        Dim FromTeamID As String = ""
        Dim FromTeamName As String = ""
        Dim FromPersonID As String = ""
        Dim ToTeamID As String = ""
        Dim ToTeamName As String = ""
        Dim ToPersonID As String = ""
        Dim ToPersonName As String = ""
        Dim ToDepartmentID As String = ""
        Dim ToDepartmentName As String = ""
        Dim TicketTypeID As String = ""
        Dim TicketTypeName As String = ""
        Dim TicketPriorityID As String = ""
        Dim TicketStatusID As String = ""
        Dim EmailTemplateFile As String = ""
        Dim ReplacingWords As String = ""
        ToUserEmail = ReferenceData.Setting("ContactUsToEmail", "aleee_shaikh@yahoo.com")
        EmailTemplateFile = ReferenceData.Setting("ContactUsEmailTemplateFile", "ContactUSEmail.tmpl.htm")
        PList = DBDAL.GetSPParametersList(Parameters)


        For Each Param In PList
            If Param.ParameterName = "UserName" Then
                FromUserName = Param.ParameterValue
            ElseIf Param.ParameterName = "UserEmail" Then
                FromUserEmail = Param.ParameterValue
            ElseIf Param.ParameterName = "PhoneNo" Then
                PhoneNo = Param.ParameterValue
            ElseIf Param.ParameterName = "Subject" Then
                Subject = Param.ParameterValue
            ElseIf Param.ParameterName = "Message" Then
                Message = Param.ParameterValue
            ElseIf Param.ParameterName = "Country" Then
                Country = Param.ParameterValue
            ElseIf Param.ParameterName = "City" Then
                City = Param.ParameterValue
            ElseIf Param.ParameterName = "Postcode" Then
                PostCode = Param.ParameterValue
            ElseIf Param.ParameterName = "FromDepartmentID" Then
                FromDepartmentID = Param.ParameterValue
            ElseIf Param.ParameterName = "FromDepartmentName" Then
                FromDepartmentName = Param.ParameterValue
            ElseIf Param.ParameterName = "FromTeamID" Then
                FromTeamID = Param.ParameterValue
            ElseIf Param.ParameterName = "FromTeamName" Then
                FromTeamName = Param.ParameterValue
            ElseIf Param.ParameterName = "FromPersonID" Then
                FromPersonID = Param.ParameterValue
            ElseIf Param.ParameterName = "ToTeamID" Then
                ToTeamID = Param.ParameterValue
            ElseIf Param.ParameterName = "ToTeamName" Then
                ToTeamName = Param.ParameterValue
            ElseIf Param.ParameterName = "ToPersonID" Then
                ToPersonID = Param.ParameterValue
            ElseIf Param.ParameterName = "ToPersonName" Then
                ToPersonName = Param.ParameterValue
            ElseIf Param.ParameterName = "ToDepartmentID" Then
                ToDepartmentID = Param.ParameterValue
            ElseIf Param.ParameterName = "ToDepartmentName" Then
                ToDepartmentName = Param.ParameterValue
            ElseIf Param.ParameterName = "TicketTypeID" Then
                TicketTypeID = Param.ParameterValue
            ElseIf Param.ParameterName = "TicketPriorityID" Then
                TicketPriorityID = Param.ParameterValue
            ElseIf Param.ParameterName = "TicketTypeName" Then
                TicketTypeName = Param.ParameterValue
            ElseIf Param.ParameterName = "TicketStatusID" Then
                TicketStatusID = Param.ParameterValue
            End If
        Next
        If FromUserName <> "" And HttpContext.Current.Session("UserID") <= 0 Then
            FromPersonID = -1
        End If
        Dim Ticket As New Tickets
        Ticket.AddTicket(Website.WebsiteID, TicketTypeID, FromDepartmentID, FromTeamID, FromPersonID, FromUserName, ToDepartmentID, ToTeamID, ToPersonID, TicketPriorityID, Subject, Message, TicketStatusID)

        ReplacingWords = ReplacingWords & "[UserName]♦" & FromUserName & "¤"
        ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
        ReplacingWords = ReplacingWords & "[PhoneNo]♦" & PhoneNo & "¤"
        ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
        ReplacingWords = ReplacingWords & "[Message]♦" & Message & "¤"
        ReplacingWords = ReplacingWords & "[Department]♦" & Department & "¤"
        ReplacingWords = ReplacingWords & "[Country]♦" & Country & "¤"
        ReplacingWords = ReplacingWords & "[City]♦" & City & "¤"
        ReplacingWords = ReplacingWords & "[PostCode]♦" & PostCode & "¤"
        ReplacingWords = ReplacingWords & "[FromDepartmentID]♦" & FromDepartmentID & "¤"
        ReplacingWords = ReplacingWords & "[FromDepartmentName]♦" & FromDepartmentName & "¤"
        ReplacingWords = ReplacingWords & "[FromTeamID]♦" & FromTeamID & "¤"
        ReplacingWords = ReplacingWords & "[FromTeamName]♦" & FromTeamName & "¤"
        ReplacingWords = ReplacingWords & "[FromPersonID]♦" & FromPersonID & "¤"
        ReplacingWords = ReplacingWords & "[ToTeamID]♦" & ToTeamID & "¤"
        ReplacingWords = ReplacingWords & "[ToTeamName]♦" & ToTeamName & "¤"
        ReplacingWords = ReplacingWords & "[ToPersonID]♦" & ToPersonID & "¤"
        ReplacingWords = ReplacingWords & "[ToPersonName]♦" & ToPersonName & "¤"
        ReplacingWords = ReplacingWords & "[ToDepartmentID]♦" & ToDepartmentID & "¤"
        ReplacingWords = ReplacingWords & "[ToDepartmentName]♦" & ToDepartmentName & "¤"
        ReplacingWords = ReplacingWords & "[TicketPriorityID]♦" & TicketPriorityID & "¤"
        ReplacingWords = ReplacingWords & "[TicketStatusID]♦" & TicketStatusID & "¤"

        ''WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, Subject, EmailTemplateFile, "", ReplacingWords)

        Return ""
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Events_GetTodaysEvents() As String
        Dim ds As New DataSet
        ds = BusinessEvents.GetTodaysEvents(HttpContext.Current.Session("CurrentBusinessID"), Now.ToString("MM/dd/yyyy") & " 00:00:00 AM", Now.ToString("MM/dd/yyyy") & " 23:59:50 PM", Session("UserID"), 2)
        If ds.Tables.Count > 0 Then
            ds.Tables(0).TableName = "DateTime"
            ds.Tables(1).TableName = "Events"
        End If

        Return ds.GetXml()
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Events_EventsViewed(EventIDs As String) As String
        Dim ds As New DataSet

        BusinessEvents.EventViewed(HttpContext.Current.Session("CurrentBusinessID"), Session("UserID"), EventIDs)

        Return ds.GetXml()
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function Get_WebsiteSetting(Key As String) As String
        Dim ds As New DataSet
        Dim BID As Integer
        BID = Val(LoggedInUserSession.BusinessID)
        Return LoggedInUserSession.BusinessID & ":" & ReferenceData.Setting(Key, "", BID)
    End Function

End Class