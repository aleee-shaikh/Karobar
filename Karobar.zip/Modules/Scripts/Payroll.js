function GetAttendanceStatistics(ControlID) {
    var RequestData = {
        ID: -1
    };

    var AttendanceStatistics = [];

    $.ajax({
        type: "POST",
        dataType: 'xml',
        //data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/PayrollService.asmx/GetAttendanceStatistics',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("EmployeesAttendance").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("EmployeesAttendance").each(function () {

                    AttendanceStatistics.push({
                        TotalPresent: $(this).find("TotalPresent").text(),
                        TotalAbsent: $(this).find("TotalAbsent").text(),
                        TotalOnLeave: $(this).find("TotalOnLeave").text()
                    });

                });

            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return AttendanceStatistics;
}


function GetTotalPeopleCount(ControlID) {
    var RequestData = {
        ID: -1
    };

    var TotalPeople = [];

    $.ajax({
        type: "POST",
        dataType: 'xml',
        //data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/PayrollService.asmx/GetTotalPeopleCount',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("TotalPeopleCount").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("TotalPeopleCount").each(function () {

                    TotalPeople.push({
                        TotalStaff: $(this).find("TotalStaff").text(),
                        TotalVendors: $(this).find("TotalVendors").text(),
                        TotalCustomers: $(this).find("TotalCustomers").text()
                    });

                });

            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return TotalPeople;
}
