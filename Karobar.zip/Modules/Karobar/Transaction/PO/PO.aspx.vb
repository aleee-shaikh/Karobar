﻿Public Class PO
    Inherits System.Web.UI.Page


    Private Sub PaymentsPayReceived_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 123) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then

            LblPOReference.Text = ReferenceData.Setting("LblCashPaymentReference", "Reference", Session("CurrentBusinessID"))
            LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
            LblPOParticular.Text = ReferenceData.Setting("LblPOParticular", "Remarks", Session("CurrentBusinessID"))
            LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
            LblPODate.Text = ReferenceData.Setting("LblPODate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Purchase Order", Session("CurrentBusinessID"))



            Dim tbl As New DataTable


            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Supplier)
            DDLSupplier.DataValueField = "UserID"
            DDLSupplier.DataTextField = "FirstName"
            DDLSupplier.DataSource = tbl
            DDLSupplier.DataBind()

            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Staff)
            DDLSalesPerson.DataValueField = "UserID"
            DDLSalesPerson.DataTextField = "FirstName"
            DDLSalesPerson.DataSource = tbl
            DDLSalesPerson.DataBind()

            GenericPORow1.AddColumn("Product", New DropDownList)
            GenericPORow1.AddColumn("Quantity", New TextBox)
            GenericPORow1.AddColumn("Unit", New TextBox)
            GenericPORow1.AddColumn("Price", New TextBox)
            GenericPORow1.AddColumn("Discount", New TextBox)
            GenericPORow1.AddColumn("Total", New TextBox)
            ''GenericPORow1.AddColumn("ManufacturingDate", New TextBox)
            ''GenericPORow1.AddColumn("ExpiryDate", New TextBox)

            txtDate.Text = Now.ToString("dd-MM-yyyy")
        End If
    End Sub


    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        If GenericPORow1.DataRowsCount.Value > 0 Then
            GenericPORow1.AddRow()
            GenericPORow1.UpdateRows()
        End If
        Dim tbl As New DataTable
        Dim POID As Integer = -1
        Dim SupplierID As Integer = -1
        Dim SalesPersonID As Integer = -1

        If DDLSalesPerson.Items.Count > 0 Then
            SalesPersonID = DDLSalesPerson.SelectedValue
        End If
        If (DDLSupplier.Items.Count > 0) Then
            SupplierID = DDLSupplier.SelectedValue
        End If

        Dim DatedAry() = txtDate.Text.Replace("/", "-").Split("-")
        tbl = POBLL.AddPOMaster(Session("CurrentBusinessID"), txtReference.Text.Trim, SupplierID, SalesPersonID, txtParticular.Text.Trim())
        If tbl.Rows.Count > 0 Then

            POID = tbl.Rows(0)("POid")
                tbl = New DataTable
                tbl = GenericPORow1.GetPOData()
                Try
                For i As Integer = 0 To tbl.Rows.Count - 2
                    If tbl.Rows(i)("Product") > 0 Then
                        POBLL.AddPODetails(POID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), tbl.Rows(i)("Quantity"), tbl.Rows(i)("Price"), tbl.Rows(i)("Discount"), tbl.Rows(i)("Total"))
                    End If
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "PODoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('PO has been saved successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
                    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "PO done", "PO ID :" & POID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=POID)
                Catch ex As Exception
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "POAddingIssue", "<script>parent.ShowMessage('Unable to process PO','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End Try

        End If
    End Sub
End Class