﻿Public Class ManagePeople
    Inherits System.Web.UI.UserControl

    Public PersonHaveSupplierRights As Boolean
    Public ShowStudentLnk As Boolean
    Public PersonHaveStaffRights As Boolean
    Public PersonHaveCustomerRights As Boolean

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "goBack", "history.go(-1);", True)
        'End If
        Dim PersonHaveAdminRights As Boolean
        PersonHaveAdminRights = Person.DoesPersonHaveManagerialRoles(Session("UserID"))

        PersonHaveStaffRights = (PersonHaveAdminRights Or Person.DoesPersonHavePageRights(Session("UserID"), 50))
        PersonHaveCustomerRights = (PersonHaveAdminRights Or Person.DoesPersonHavePageRights(Session("UserID"), 48))
        PersonHaveSupplierRights = (PersonHaveAdminRights Or Person.DoesPersonHavePageRights(Session("UserID"), 49)) 'Person.PersonHasRights(Session("UserID"), ",49,")

        'If PersonHaveSupplierRights = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage people screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'Else

        If (Not Page.IsPostBack) Then
            If PersonHaveSupplierRights = False Then
                DDLUserType.Items.RemoveAt(2)
            End If
        End If
        'End If

        If (Not Session("CurrentBusinessCategoryID") Is Nothing) AndAlso Val(Session("CurrentBusinessCategoryID")) = 5 Then
            DDLUserType.Items.Add(New ListItem("Student", "7"))
            ShowStudentLnk = True
        Else
            ShowStudentLnk = False
        End If
    End Sub

    Sub LoadData()
        Dim tbl As New DataTable
        tbl = Person.GetUsersList(Session("CurrentBusinessID"), txtFreeText.Text.Trim, DDLUserType.SelectedItem.Value)
        Dim dv As DataView = tbl.DefaultView
        dv.Sort = SortExpression + " " + If(IsAscendingSort, "ASC", "DESC")
        GrdPeoples.DataSource = dv
        GrdPeoples.DataBind()
    End Sub


    Private Sub GrdPeoples_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdPeoples.PageIndexChanging
        GrdPeoples.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdPeoples_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdPeoples.RowCommand
        If e.CommandName = "DeletePeople" Then

            If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
                Page.RegisterStartupScript("StaffUpdatingIssue", "<script>parent.ShowMessage('Update/Delete is disabled on demo business','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                Exit Sub
            End If

            ''People.DeletePeople(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(HttpContext.Current.Session("UserID"), "People", "Deleted People " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, e.CommandArgument)
        ElseIf e.CommandName = "ViewPeopleAccounts" Then

        ElseIf e.CommandName = "DeleteUser" Then

            If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
                Page.RegisterStartupScript("StaffUpdatingIssue", "<script>parent.ShowMessage('Update/Delete is disabled on demo business','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                Exit Sub
            End If
            Person.DeleteUser(e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "People", "Deleted People Account " & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub

    Private Sub GrdPeoples_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdPeoples.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim PeopleEditLnkBtn As New System.Web.UI.WebControls.LinkButton
            PeopleEditLnkBtn = CType(e.Row.FindControl("LnkEditUser"), LinkButton)
            If Not PeopleEditLnkBtn Is Nothing Then
                Select Case IIf(IsDBNull(drview("AccountTypeID")), "-1", drview("AccountTypeID"))
                    Case Person.UserTypes.Customer
                        PeopleEditLnkBtn.OnClientClick = "javascript:AddCustomer(" & drview("UserID") & ");return false;"
                    Case Person.UserTypes.Supplier
                        PeopleEditLnkBtn.OnClientClick = "javascript:AddSupplier(" & drview("UserID") & ");return false;"
                    Case Person.UserTypes.Staff
                        PeopleEditLnkBtn.OnClientClick = "javascript:ShowAddStaff(" & drview("UserID") & ");return false;"
                    Case Person.UserTypes.Student
                        PeopleEditLnkBtn.OnClientClick = "javascript:ShowAddStudent(" & drview("UserID") & ");return false;"
                    Case Person.UserTypes.ServiceProvider
                        PeopleEditLnkBtn.OnClientClick = "javascript:AddSupplier(" & drview("UserID") & ");return false;"
                    Case Person.UserTypes.DMSDeliveryBoy
                        PeopleEditLnkBtn.OnClientClick = "javascript:ShowAddStaff(" & drview("UserID") & ");return false;"
                End Select
            End If

            'Dim GrdPeopleAccounts As New System.Web.UI.WebControls.GridView
            'GrdPeopleAccounts = CType(e.Row.FindControl("GrdPeopleAccounts"), GridView)

            'If Not GrdPeopleAccounts Is Nothing Then
            '    GrdPeopleAccounts.DataSource = People.GetPeoplesAccountsList(Session("CurrentBusinessID"), drview("PeopleID"), "")
            '    GrdPeopleAccounts.DataBind()
            'End If


            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub GrdPeoples_Sorting(sender As Object, e As GridViewSortEventArgs) Handles GrdPeoples.Sorting

        Dim columnIndex As Integer = 0
        For Each headerCell In GrdPeoples.HeaderRow.Cells
            If (headerCell.ContainingField.SortExpression = e.SortExpression) Then
                columnIndex = GrdPeoples.HeaderRow.Cells.GetCellIndex(headerCell)
            End If
        Next

        If e.SortExpression = SortExpression Then
            IsAscendingSort = Not IsAscendingSort

        Else
            IsAscendingSort = False
            SortExpression = e.SortExpression
        End If


        For i As Integer = 0 To GrdPeoples.Columns.Count - 1
            GrdPeoples.Columns(i).HeaderText = GrdPeoples.Columns(i).HeaderText.Replace("▲", "").Replace("▼", "")
        Next

        If (IsAscendingSort) Then
            GrdPeoples.Columns(columnIndex).HeaderText = GrdPeoples.Columns(columnIndex).HeaderText + "▲"
        Else
            GrdPeoples.Columns(columnIndex).HeaderText = GrdPeoples.Columns(columnIndex).HeaderText + "▼"
        End If
        LoadData()
    End Sub

    Protected Property IsAscendingSort As Boolean
        Get
            Dim value As Object = ViewState("IsAscendingSort")
            Return If(Not IsNothing(value), CBool(value), False)
        End Get
        Set(value As Boolean)
            ViewState("IsAscendingSort") = value
        End Set
    End Property

    Protected Property SortExpression As String
        Get
            Dim value As Object = ViewState("SortExpression")
            Return If(Not IsNothing(value), CStr(value), "UserID")
        End Get
        Set(value As String)
            ViewState("SortExpression") = value
        End Set
    End Property


End Class