﻿Public Class ManageMarketingEmails
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            LoadEmailTemplates()
            LoadData(-1)

        End If
    End Sub

    Sub LoadData(EmailTemplateID As Integer)
        Dim tbl As New DataTable
        tbl = WebsiteEmail.GetEmailSendQueueStatus(EmailTemplateID)
        GrdWebsiteEmailQueue.DataSource = tbl
        GrdWebsiteEmailQueue.DataBind()
        BtnDelete.Enabled = (tbl.Rows.Count > 0)
        BtnSendAllEmails.Enabled = (tbl.Rows.Count > 0)

    End Sub

    Sub LoadEmailTemplates()
        DDLEmails.DataValueField = "EmailTemplateID"
        DDLEmails.DataTextField = "EmailSubject"
        DDLEmails.DataSource = WebsiteEmail.GetExistingEmails()
        DDLEmails.DataBind()
        If Page.IsPostBack Then DDLEmails.SelectedIndex = DDLEmails.Items.Count - 1
    End Sub


    Private Sub DDLEmails_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLEmails.SelectedIndexChanged
        LoadData(DDLEmails.SelectedItem.Value)
    End Sub

    Private Sub BtnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnDelete.Click
        Dim SelectedID As String = ""

        For i As Integer = 0 To GrdWebsiteEmailQueue.Rows.Count - 1
            Dim row As GridViewRow = GrdWebsiteEmailQueue.Rows(i)
            Dim Chkbox As New CheckBox
            Chkbox = GrdWebsiteEmailQueue.Rows(i).FindControl("ChkEmailQueueID")
            If Not Chkbox Is Nothing AndAlso Chkbox.Checked = True Then
                Dim HdnID As New HiddenField
                HdnID = GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailQueueID")
                SelectedID = SelectedID & HdnID.Value & ","
            End If



        Next
        If SelectedID.Length > 1 Then
            SelectedID = SelectedID.Substring(0, SelectedID.Length - 1)
        End If
        WebsiteEmail.DeleteEmailQueue(SelectedID)
        GrdWebsiteEmailQueue.DataSource = WebsiteEmail.GetEmailSendQueueStatus(DDLEmails.SelectedItem.Value)
        GrdWebsiteEmailQueue.DataBind()

    End Sub

    Private Sub BtnSendAllEmails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSendAllEmails.Click
        'Dim tbl As New DataTable
        'Dim ToEmail As String = ""
        'Dim ToUserID As String = ""
        'Dim EmailQueueID As Integer = 0
        'Dim FromEmail As String = ReferenceData.Setting("FromEmailAddress", "info@explorewiki.com")
        'For i As Integer = 0 To GrdWebsiteEmailQueue.Rows.Count - 1
        '    Dim chk As New CheckBox
        '    chk = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("ChkEmailQueueID"), CheckBox)
        '    If chk.Checked Then
        '        Dim EmailAddress As String
        '        Dim hdnToEmailAddress As New HiddenField
        '        Dim hdnCCEmailAddress As New HiddenField
        '        Dim hdnToUserID As New HiddenField
        '        Dim hdnToEmailSubject As New HiddenField
        '        Dim hdnToEmailMessage As New HiddenField
        '        Dim HdnToEmails As New HiddenField
        '        Dim HdnEmailQueueID As New HiddenField

        '        hdnToEmailAddress = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnToEmailAddress"), HiddenField)
        '        hdnToEmailSubject = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailSubject"), HiddenField)
        '        hdnToEmailMessage = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailMessage"), HiddenField)
        '        HdnToEmails = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnToEmails"), HiddenField)
        '        hdnCCEmailAddress = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("hdnCCEmailAddress"), HiddenField)
        '        HdnEmailQueueID = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailQueueID"), HiddenField)

        '        EmailAddress = HdnToEmails.Value


        '        ToEmail = ToEmail & EmailAddress & ";"

        '        WebsiteEmail.SendEmail(FromEmail, ToEmail, hdnCCEmailAddress.Value, hdnToEmailSubject.Value, "", "", "", hdnToEmailMessage.Value)
        '        WebsiteEmail.UpdateEmailQueue(Val(HdnEmailQueueID.Value))

        '    End If
        'Next


        'LoadData(DDLEmails.SelectedValue)
        'Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", "parent.HideDlgForm(1);parent.ShowMessage('Email has been sent successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')", True)
    End Sub

    Private Sub GrdWebsiteEmailQueue_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GrdWebsiteEmailQueue.PageIndexChanging
        GrdWebsiteEmailQueue.PageIndex = e.NewPageIndex
        LoadData(DDLEmails.SelectedValue)
    End Sub

    Private Sub BtnAddEmail_Click(sender As Object, e As EventArgs) Handles BtnAddEmail.Click
        Dim tbl As New DataTable
        Dim ToEmail As String = ""
        Dim ToUserID As String = ""
        Dim EmailQueueID As Integer = 0
        Dim FromEmail As String = ReferenceData.Setting("FromEmailAddress", "info@explorewiki.com")
        For i As Integer = 0 To GrdWebsiteEmailQueue.Rows.Count - 1
            Dim chk As New CheckBox
            chk = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("ChkEmailQueueID"), CheckBox)
            If chk.Checked Then
                Dim EmailAddress As String
                Dim hdnToEmailAddress As New HiddenField
                Dim hdnCCEmailAddress As New HiddenField
                Dim hdnToUserID As New HiddenField
                Dim hdnToEmailSubject As New HiddenField
                Dim hdnToEmailMessage As New HiddenField
                Dim HdnToEmails As New HiddenField
                Dim HdnEmailQueueID As New HiddenField

                hdnToEmailAddress = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnToEmailAddress"), HiddenField)
                hdnToEmailSubject = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailSubject"), HiddenField)
                hdnToEmailMessage = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailMessage"), HiddenField)
                HdnToEmails = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnToEmails"), HiddenField)
                hdnCCEmailAddress = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("hdnCCEmailAddress"), HiddenField)
                HdnEmailQueueID = CType(GrdWebsiteEmailQueue.Rows(i).FindControl("HdnEmailQueueID"), HiddenField)

                EmailAddress = HdnToEmails.Value


                ToEmail = ToEmail & EmailAddress & ";"

                WebsiteEmail.SendEmail(FromEmail, ToEmail, hdnCCEmailAddress.Value, hdnToEmailSubject.Value, "", "", "", hdnToEmailMessage.Value)
                WebsiteEmail.UpdateEmailQueue(Val(HdnEmailQueueID.Value))

            End If
        Next


        LoadData(DDLEmails.SelectedValue)
        Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", "parent.HideDlgForm(1);parent.ShowMessage('Email has been sent successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')", True)
    End Sub
End Class