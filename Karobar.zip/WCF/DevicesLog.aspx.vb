﻿Public Class DevicesLog
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim Model As String = ""
        Dim CordovaVersion As String = ""
        Dim DeviceID As String = ""
        Dim DeviceVersion As String = ""
        Dim AppID As String = ""
        Dim Platform As String = ""

        If Not Request("AppID") Is Nothing Then AppID = Request("AppID")
        If Not Request("MD") Is Nothing Then Model = Request("MD")
        If Not Request("P") Is Nothing Then Platform = Request("P")
        If Not Request("CV") Is Nothing Then CordovaVersion = Request("CV")
        If Not Request("ID") Is Nothing Then DeviceID = Request("ID")
        If Not Request("DV") Is Nothing Then DeviceVersion = Request("DV")


        If DeviceID <> "" And AppID <> "" Then
            Dim Success As Boolean = True
            Dim DBObj As New DBDAL
            Dim Cmd As New SqlClient.SqlCommand
            Dim da As New SqlClient.SqlDataAdapter
            Dim Sql As String = ""
            Dim ds As New DataSet

            Try

                Cmd.CommandType = CommandType.StoredProcedure
                Cmd.CommandText = "WriteDeviceLog"
                Cmd.Parameters.AddWithValue("@AppName", AppID)
                Cmd.Parameters.AddWithValue("@Model", Model)
                Cmd.Parameters.AddWithValue("@Platform", Platform)
                Cmd.Parameters.AddWithValue("@CordovaVersion", CordovaVersion)
                Cmd.Parameters.AddWithValue("@DeviceID", DeviceID)
                Cmd.Parameters.AddWithValue("@DeviceVersion", DeviceVersion)
                DBObj.RunSQL(Cmd)
            Catch ex As Exception
                Success = False


            End Try
        End If


    End Sub

End Class