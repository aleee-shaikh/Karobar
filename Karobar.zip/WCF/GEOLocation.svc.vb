﻿Imports System.ServiceModel
Imports System.ServiceModel.Activation
Imports System.ServiceModel.Web

<ServiceContract(Namespace:="")>
<AspNetCompatibilityRequirements(RequirementsMode:=AspNetCompatibilityRequirementsMode.Allowed)>
Public Class GEOLocation

    ' To use HTTP GET, add <WebGet()> attribute. (Default ResponseFormat is WebMessageFormat.Json)
    ' To create an operation that returns XML,
    '     add <WebGet(ResponseFormat:=WebMessageFormat.Xml)>,
    '     and include the following line in the operation body:
    '         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml"
    <OperationContract()>
    <WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json)>
    Public Function SearchBusinesses() As String ''Implements IEZKarobar.SearchBusinesses
        Dim tbl As New DataTable
        Dim ds As New DataSet

        tbl = Website.GetWebsites()
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"
        ''Return ds.GetXml().ToArray
        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <OperationContract()>
    <WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json)>
    Public Function IsDeviceRegistered(DeviceID As String) As String
        Dim ds As New DataSet

        ds = DeviceGeoLocation.IsDeviceRegistered(DeviceID)
        ds.Tables(0).TableName = "DeviceRegistered"
        ds.Namespace = "DeviceRegistered"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <OperationContract()>
    <WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json)>
    Public Function GetDeviceGeoLocation(DeviceID As String, DateFrom As String, DateTo As String, FreeText As String) As String
        Dim ds As New DataSet

        ds = DeviceGeoLocation.GetDeviceGEOLocation(DeviceID, DateFrom, DateTo, FreeText)
        ds.Tables(0).TableName = "DeviceGeoLocation"
        ds.Namespace = "DeviceGeoLocation"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <OperationContract()>
    <WebInvoke(Method:="GET")>
    Public Function SaveDeviceGeoLocation(AppName As String, DeviceID As String, Lat As String, Lng As String, Speed As String,
                                  Heading As String, Altitude As String, Accuracy As String, AltitudeAccuracy As String,
                                  TimeStamp As String) As Boolean
        Dim res As Boolean = DeviceGeoLocation.SaveDeviceGEOLocation(AppName, DeviceID, Lat, Lng, Speed, Heading, Altitude, Accuracy, AltitudeAccuracy, TimeStamp)


        Return res
    End Function


    <OperationContract()>
    <WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json)>'', ResponseFormat:=WebMessageFormat.Json)>
    Public Function RegisterDevice(AppName As String, Model As String, CordovaVersion As String, DeviceID As String,
         Platform As String, DeviceVersion As String, UserName As String, LoginID As String, Password As String) As String

        Dim ds As New DataSet
        ds = DeviceGeoLocation.RegisterDevice(AppName, Model, CordovaVersion, DeviceID, Platform, DeviceVersion, UserName, LoginID, Password)
        ds.Tables(0).TableName = "DeviceRegister"
        ds.Namespace = "DeviceRegister"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <OperationContract()>
    <WebInvoke(Method:="GET", RequestFormat:=WebMessageFormat.Json)>
    Public Function GetDeviceLocationPathPoints(DeviceID As String, Dated As String) As String

        Dim ds As New DataSet
        Dim dary() = Dated.Split("/")
        Dated = dary(2) & IIf(dary(0) <= 9, "0" & Val(dary(0)), Val(dary(0))) & IIf(dary(1) <= 9, "0" & Val(dary(1)), Val(dary(1)))
        ds = DeviceGeoLocation.GetDeviceLocationPathPoints(DeviceID, Dated)
        ds.Tables(0).TableName = "DeviceLocationPoints"
        ds.Namespace = "DeviceLocationPoints"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

End Class
