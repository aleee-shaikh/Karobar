﻿Imports System.Web.SessionState

Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started
        ''RegistarRoutes(System.Web.Routing.RouteTable.Routes)
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        '' Fires at the beginning of each request
        HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "*")
        HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Accept")
        Response.AddHeader("Access-Control-Allow-Credentials", "true")

        'If HttpContext.Current.Request.HttpMethod = "OPTIONS" Then

        '    HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache")
        '    HttpContext.Current.Response.AddHeader("Access-Control-Max-Age", "1728000")
        '    HttpContext.Current.Response.End()
        'End If

        'Response.AddHeader("Access-Control-Allow-Origin", "*")

    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs

        Dim Context = HttpContext.Current
            If (Context IsNot Nothing) Then


            End If

            Try
                Log.WriteLog(Val(HttpContext.Current.Session("CurrentBusinessID")), Val(HttpContext.Current.Session("UserID")), "Error", Server.GetLastError.InnerException.Message.ToString.Replace("'", "''") & "<" & Server.GetLastError.StackTrace.Replace("'", "''") & ">", Request.Browser.Browser & "[" & Request.Browser.Version & "]", Request.UserHostAddress, Request.Browser.Platform, Request.RawUrl)
            Catch ex As Exception

            End Try

        If Server.GetLastError.HResult.ToString <> -2147467259 Then
            Response.Clear()
            Server.ClearError()
            Response.Redirect("~/Error.aspx", False)
            HttpContext.Current.ApplicationInstance.CompleteRequest()
        End If


    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

    Sub RegistarRoutes(ByVal Routes As System.Web.Routing.RouteCollection)
        ''Routes.MapPageRoute("r1", "r1/{Id}", "~/WebsiteLayout.aspx")
    End Sub

End Class