﻿Public Class UserCardBalanceReport
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Me.IsPostBack Then
            'LoadData()
        Else

        End If
    End Sub

    Sub LoadData()
        GrdUserCardBalance.DataSource = GiftCard.GetUserCards(-1, -1, Val(txtCardNo.Text))
        GrdUserCardBalance.DataBind()
    End Sub

    Private Sub GrdUserCardBalance_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdUserCardBalance.PageIndexChanging
        GrdUserCardBalance.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdUserCardBalance_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdUserCardBalance.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

        End If

    End Sub


    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim ExportFileName As String = ""
        If Not Session("BankBalanceReport-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("BankBalanceReport-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            ExportFileName = "filename=NoDataFound.csv"
        Else
            ExportFileName = "BankBalanceReport" & Now.ToString("yyyyMMddhhmm") & ".csv"
        End If

        General.ExportGridToCSV(_tbl, ExportFileName, "AccountHeadID,AccountHeadName,Balance")

    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open bank balance report", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
    End Sub


    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub
End Class