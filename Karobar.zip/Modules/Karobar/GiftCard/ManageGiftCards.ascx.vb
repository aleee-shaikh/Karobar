﻿Public Class ManageGiftCards
    Inherits System.Web.UI.UserControl

    Public PersonHaveSupplierRights As Boolean

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            LoadData()
        Else

        End If
    End Sub


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        'PersonHaveSupplierRights = Person.DoesPersonHavePageRights(Session("UserID"), 49) 'Person.PersonHasRights(Session("UserID"), ",49,")
        'If PersonHaveSupplierRights = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open manage people screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'Else
        '    txtDate.Text = Now.ToString("dd-MM-yyyy")

        'End If
    End Sub

    Sub LoadData()
        GrdGiftCards.DataSource = GiftCard.GetGiftCards(Session("CurrentBusinessID"), -1, txtFreeText.Text)
        GrdGiftCards.DataBind()
    End Sub


    Private Sub GrdGiftCards_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdGiftCards.PageIndexChanging
        GrdGiftCards.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdGiftCards_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdGiftCards.RowCommand
        If e.CommandName = "DeleteGiftCard" Then
            GiftCard.DeleteGiftCard(Session("CurrentBusinessID"), e.CommandArgument)
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Deleted Gift Card" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
            LoadData()
        ElseIf e.CommandName = "DeleteGiftCardPoint" Then
            GiftCard.DeleteGiftCardPoint(Session("CurrentBusinessID"), e.CommandArgument)
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Gift Card", "Deleted Gift Card Point" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
            LoadData()
        End If
    End Sub

    Private Sub GrdGiftCards_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdGiftCards.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LnkEditGiftCard As New System.Web.UI.WebControls.LinkButton
            LnkEditGiftCard = CType(e.Row.FindControl("LnkEditGiftCard"), LinkButton)
            If Not LnkEditGiftCard Is Nothing Then
                LnkEditGiftCard.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/GiftCard/GiftCardForm.aspx?GID=" & drview("GiftCardID") & "',$(window).height()*52/100,$(window).width()*47/100);return false"
            End If

            Dim GrdGiftCardPoints As New System.Web.UI.WebControls.GridView
            GrdGiftCardPoints = CType(e.Row.FindControl("GrdGiftCardPoints"), GridView)
            AddHandler GrdGiftCardPoints.RowDataBound, AddressOf GrdGiftCardPoints_RowDataBound
            If Not GrdGiftCardPoints Is Nothing Then
                GrdGiftCardPoints.DataSource = GiftCard.GetGiftCardPoints(Session("CurrentBusinessID"), drview("GiftCardID"))
                GrdGiftCardPoints.DataBind()
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub GrdGiftCardPoints_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)


            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='silver';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub
End Class