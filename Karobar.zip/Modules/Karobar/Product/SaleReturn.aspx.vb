﻿Imports System.Data.SqlClient

Public Class SaleReturn
    Inherits System.Web.UI.Page


    Private Sub PurchaseProduct_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 131) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If
        SaleReturnDetails.AddColumn("Product", New DropDownList)
        SaleReturnDetails.AddColumn("Quantity", New TextBox)
        SaleReturnDetails.AddColumn("ReturnQty", New TextBox)
        SaleReturnDetails.AddColumn("Unit", New TextBox)
        SaleReturnDetails.AddColumn("Price", New TextBox)
        SaleReturnDetails.AddColumn("Discount", New TextBox)
        SaleReturnDetails.AddColumn("Total", New TextBox)
        SaleReturnDetails.AddColumn("Selected", New CheckBox)
        LblProductReference.Text = ReferenceData.Setting("LblSaleProductReference", "Reference", Session("CurrentBusinessID"))
        LblProductSaleType.Text = ReferenceData.Setting("LblProductSaleType", "Sale Type", Session("CurrentBusinessID"))
        LblProductOrderDate.Text = ReferenceData.Setting("LblProductOrderDate", "Order Date", Session("CurrentBusinessID"))
        LblDueDate.Text = ReferenceData.Setting("LblDueDate", "Due Date", Session("CurrentBusinessID"))
        LblCustomer.Text = ReferenceData.Setting("LblCustomer", "Customer", Session("CurrentBusinessID"))
        LblTax.Text = ReferenceData.Setting("LblSalesTax", "Tax", Session("CurrentBusinessID"))

        LblDeliveryCharges.Text = ReferenceData.Setting("LblDeliveryCharges", "Delivery Charges", Session("CurrentBusinessID"))
        LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
        LblStockLocation.Text = ReferenceData.Setting("LblStockLocation", "Stock Location", Session("CurrentBusinessID"))

        'If (Not Request.QueryString("TID") Is Nothing) Then
        '    hdnTID.Value = Request.QueryString("TID")
        '    txtReference.Text = hdnTID.Value

        '    Dim ds As New DataSet
        '    ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(hdnTID.Value))
        '    If ds.Tables.Count > 0 Then
        '        SaleReturnDetails.AddOrderDetails(ds.Tables(0))
        '    End If
        'End If

        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SaleType * -1)
            DDLSaletype.DataValueField = "ArticleTypeID"
            DDLSaletype.DataTextField = "ArticleType"
            DDLSaletype.DataSource = ds.Tables(0)
            DDLSaletype.DataBind()

            Dim custmerInfoTbl As DataTable
            custmerInfoTbl = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Customer)
            DDLCustomer.DataSource = custmerInfoTbl
            DDLCustomer.DataValueField = "UserID"
            DDLCustomer.DataTextField = "FirstName"
            DDLCustomer.DataBind()

            DDLCustomer4Search.DataSource = custmerInfoTbl
            DDLCustomer4Search.DataValueField = "UserID"
            DDLCustomer4Search.DataTextField = "FirstName"
            DDLCustomer4Search.DataBind()

            If (DDLCustomer.Items.Count > 0) Then
                LoadCustomerCreditLimitAndBalance()
            End If
            'Dim script As String = "var customerData=[];"
            'For i As Integer = 0 To custmerInfoTbl.Rows.Count - 1
            '    script += "customerData.push({customerID:" & custmerInfoTbl.Rows(i)("UserID") & ", CreditLimit:'" & IIf(IsDBNull(custmerInfoTbl.Rows(i)("CreditLimit")), 0, custmerInfoTbl.Rows(i)("CreditLimit")) & "'});"
            'Next
            'ClientScript.RegisterClientScriptBlock(Me.GetType(), "InitData", "<script>" & script & "</script>")

            DDLSalesPerson.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Staff)
            DDLSalesPerson.DataValueField = "UserID"
            DDLSalesPerson.DataTextField = "FirstName"
            DDLSalesPerson.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.StockLocations * -1)
            DDLStockLocation.DataValueField = "ArticleTypeID"
            DDLStockLocation.DataTextField = "ArticleType"
            DDLStockLocation.DataSource = ds.Tables(0)
            DDLStockLocation.DataBind()
        End If
        txtFreeText.Focus()
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim SaleReturntbl = New DataTable
        Dim SoldQty As Single
        Dim ReturnQty As Single

        SaleReturntbl = SaleReturnDetails.GetSaleData
        'For i As Integer = 0 To SaleReturntbl.Rows.Count - 1
        '    If IsDBNull(SaleReturntbl.Rows(i)("ReturnQty")) = False Then
        '        If (SaleReturntbl.Rows(i)("ReturnQty").ToString() <> "") Then
        '            ReturnQty += Math.Abs(CSng(SaleReturntbl.Rows(i)("ReturnQty")))
        '        End If
        '    End If
        '    If IsDBNull(SaleReturntbl.Rows(i)("Quantity")) = False Then
        '        If (SaleReturntbl.Rows(i)("Quantity").ToString() <> "") Then
        '            SoldQty += CSng(SaleReturntbl.Rows(i)("Quantity"))
        '        End If
        '    End If

        'Next
        'If ReturnQty > SoldQty Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "QtyExceedtoStock", "<script>parent.ShowMessage('Product return quantity should be less than purchase quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        '    Return
        'End If


        'Validate reqturn qty
        For i As Integer = 0 To SaleReturntbl.Rows.Count - 2
            If SaleReturntbl.Rows(i)("Product") > 0 AndAlso IsDBNull(SaleReturntbl.Rows(i)("Selected")) = False AndAlso SaleReturntbl.Rows(i)("Selected") = "1" AndAlso SaleReturntbl.Rows(i)("ReturnQty") <> "" Then
                If CSng(SaleReturntbl.Rows(i)("ReturnQty")) > CSng(SaleReturntbl.Rows(i)("Quantity")) Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Return quantity can not be more than sold quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Return
                End If
            Else
                Dim TotalQty As Single
                Dim TotalRetQty As Single
                For j As Integer = 0 To SaleReturntbl.Rows.Count - 2
                    If (SaleReturntbl.Rows(j)("Product") = SaleReturntbl.Rows(i)("Product")) Then
                        If CSng(SaleReturntbl.Rows(j)("Quantity")) > 0 Then
                            TotalQty += CSng(SaleReturntbl.Rows(j)("Quantity"))
                        Else
                            TotalRetQty += Math.Abs(CSng(SaleReturntbl.Rows(j)("Quantity")))
                        End If
                        If (IsDBNull(SaleReturntbl.Rows(j)("ReturnQty")) = False) AndAlso SaleReturntbl.Rows(j)("ReturnQty").ToString() <> "" Then
                            TotalRetQty += Math.Abs(CSng(SaleReturntbl.Rows(j)("ReturnQty").ToString()))
                        End If

                    End If
                Next

                If (TotalRetQty > TotalQty) Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Return quantity can not be more than sold quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                    Return
                End If
            End If
        Next


        Dim tbl As New DataTable
        tbl = SaleReturnDetails.GetSaleData
        Dim TotalAmount As Single
        For i As Integer = 0 To tbl.Rows.Count - 1
            If (IsDBNull(tbl.Rows(i)("Selected")) = False AndAlso tbl.Rows(i)("Selected") = "1") Then
                TotalAmount += tbl.Rows(i)("Total")
            End If
        Next
        'If DDLSaletype.SelectedIndex = 0 AndAlso Val(TotalAmount) + Val(txtCustomerBalance.Text) > Val(txtCustomerBalance.Text) Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Customer credit limit exceeding','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        '    Return
        'End If

        ''tbl = New DataTable
        Dim SID As Integer
        Dim CusID As Integer = -1
        Dim SaleTypeID As Integer = -1
        Dim SalePersonID As Integer = -1
        Dim StockLocation As Integer = -1

        If SaleReturnDetails.DataRowsCount.Value > 0 Then
            SaleReturnDetails.AddRow()
            SaleReturnDetails.UpdateRows()
        End If

        If DDLStockLocation.Items.Count > 0 Then
            StockLocation = DDLStockLocation.SelectedItem.Value
        End If
        If DDLCustomer.Items.Count > 0 Then
            CusID = DDLCustomer.SelectedItem.Value
        End If
        If DDLSaletype.Items.Count > 0 Then
            SaleTypeID = DDLSaletype.SelectedItem.Value
        End If
        If DDLSalesPerson.Items.Count > 0 Then
            SalePersonID = DDLSalesPerson.SelectedItem.Value
        End If



        Dim TID As Integer

        SID = Val(hdnSaleID.Value)
        TID = Val(hdnTID.Value)

        'If DDLSaletype.SelectedIndex = 0 Then
        '    Transactions.AddTransactionDetails(TID, CusID, True, "Sale Return", TotalAmount, 0, Val(txtDeliveryCharges.Text), Val(txtTax.Text), "", SID)
        'Else
        '    Transactions.AddTransactionDetails(TID, CusID, True, "Sale Return", 0, TotalAmount, Val(txtDeliveryCharges.Text), Val(txtTax.Text), "", SID)
        'End If


        'For i As Integer = 0 To tbl.Rows.Count - 2
        '    If tbl.Rows(i)("Product") > 0 AndAlso IsDBNull(tbl.Rows(i)("Selected")) = False AndAlso tbl.Rows(i)("Selected") = "1" Then
        '        If CSng(tbl.Rows(i)("ReturnQty")) > CSng(tbl.Rows(i)("Quantity")) Then
        '            ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Return quantity can not be more than sold quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        '            Return
        '        End If
        '    End If
        'Next
        Dim SaleReturnCount As Integer = 0

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try

            connection.Open()
            trans = connection.BeginTransaction()
            Dim productsTbl As New DataTable
            productsTbl = Products.GetProductsList(Session("CurrentBusinessID"))

            For i As Integer = 0 To tbl.Rows.Count - 2
                If tbl.Rows(i)("Product") > 0 AndAlso IsDBNull(tbl.Rows(i)("Selected")) = False AndAlso tbl.Rows(i)("Selected") = "1" Then
                    If CSng(tbl.Rows(i)("ReturnQty")) > CSng(tbl.Rows(i)("Quantity")) Then
                        ClientScript.RegisterClientScriptBlock(Me.GetType(), "CreditLimitExceed", "<script>parent.ShowMessage('Return quantity can not be more than sold quantity.','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                        Return
                    End If
                    Dim ds As New DataSet
                    ''ds = Products.GetProductDetails(Session("CurrentBusinessID"), tbl.Rows(i)("Product"))

                    Dim ptbl As New DataTable
                    Try
                        ptbl = productsTbl.Select("articleid=" & tbl.Rows(i)("Product")).CopyToDataTable()
                    Catch ex As Exception

                    End Try
                    ds.Tables.Add(ptbl)
                    ReturnQty = IIf(CSng(tbl.Rows(i)("ReturnQty")) <= 0, CSng(tbl.Rows(i)("ReturnQty")), CSng(tbl.Rows(i)("ReturnQty")) * -1)


                    Products.SaleProductDetails(SID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), ReturnQty, Val(tbl.Rows(i)("Price")), CSng(tbl.Rows(i)("Discount")), (ReturnQty * CSng(tbl.Rows(i)("Price")) - CSng(tbl.Rows(i)("Discount"))), trans)
                    If DDLSaletype.SelectedIndex = 0 Then
                        ''new
                        Transactions.AddTransactionDetails(TID, ReferenceData.Setting("AccountsReceiveableID", "-1", Session("CurrentBusinessID")), False, "Sale Return :" & ds.Tables(0).Rows(0)("ArticleTitle"), 0, (ReturnQty * CSng(tbl.Rows(i)("Price")) - CSng(tbl.Rows(i)("Discount"))), 0, 0, "", SID, trans:=trans)
                    Else
                        Transactions.AddTransactionDetails(TID, ReferenceData.Setting("CashInHandAccountHeadID", "-1", Session("CurrentBusinessID")), False, "Sale Return :" & ds.Tables(0).Rows(0)("ArticleTitle"), (ReturnQty * CSng(tbl.Rows(i)("Price")) - CSng(tbl.Rows(i)("Discount"))), 0, 0, 0, "", SID, trans:=trans)
                    End If
                    SaleReturnCount += 1
                End If
            Next

            ClientScript.RegisterClientScriptBlock(Me.GetType(), "SaleReturnDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale return done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
            ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product Sale", "Product Sale :" & SID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=SID)
            Log.Notifications_Add("Sale Return " & SaleReturnCount & " item(s) ", SID, "Sale Return", SaleReturnCount)

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "SaleReturnAddingIssue", "<script>parent.ShowMessage('Unable to process sale','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try

    End Sub

    Private Sub DDLCustomer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLCustomer.SelectedIndexChanged
        LoadCustomerCreditLimitAndBalance()
    End Sub

    Sub LoadCustomerCreditLimitAndBalance()
        Dim ds As DataSet = New DataSet
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), DDLCustomer.SelectedValue)
        txtCustomerBalance.Text = "0"
        txtCreditLimit.Text = "0"
        If (ds.Tables.Count > 0) Then
            If (ds.Tables(0).Rows.Count > 0) Then
                txtCreditLimit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("CreditLimit")), 0, ds.Tables(0).Rows(0)("CreditLimit"))
                Dim HeadIds As String = ""
                Dim tbl As New DataTable
                HeadIds = DDLCustomer.SelectedValue & ","
                tbl = ChartOfAccount.COA_GetAccountReceiveableSummary(HeadIds)
                If (tbl.Rows.Count > 0) Then
                    txtCustomerBalance.Text = tbl.Rows(0)("Balance")
                End If
            End If
        End If
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click

        SearchInvoice()
        pnlSaleReturn.Visible = False
        pnlSearchSaleInvoice.Visible = True
        hdnTID.Value = "0"
        hdnSaleID.Value = "0"

    End Sub

    Private Sub GrdProducts_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GrdProducts.PageIndexChanging
        GrdProducts.PageIndex = e.NewPageIndex
        SearchInvoice()
    End Sub

    Sub SearchInvoice()
        Dim tbl As New DataTable
        Dim CustIDs As String = ""
        If Val(DDLCustomer4Search.SelectedValue) > 0 Then
            CustIDs = DDLCustomer4Search.SelectedValue
        End If

        tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, txtFreeText.Text.Trim, Now.AddYears(-10), Now, CustIDs)


        GrdProducts.DataSource = tbl
        GrdProducts.DataBind()
    End Sub

    Private Sub GrdProducts_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdProducts.RowCommand
        If e.CommandName = "ViewSaleInvoice" Then
            pnlSaleReturn.Visible = True
            pnlSearchSaleInvoice.Visible = False

            Dim tbl As New DataTable
            tbl = Products.GetSaleDetails(Session("CurrentBusinessID"), e.CommandArgument)
            If tbl.Rows.Count > 0 Then
                txtReference.Text = IIf(IsDBNull(tbl.Rows(0)("Reference")), "", tbl.Rows(0)("Reference"))
                If Not DDLSaletype.Items.FindByValue(IIf(IsDBNull(tbl.Rows(0)("SaleType")), "", tbl.Rows(0)("SaleType"))) Is Nothing Then
                    DDLSaletype.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("SaleType")), "", tbl.Rows(0)("SaleType"))
                End If

                txtDueDate.Text = IIf(IsDBNull(tbl.Rows(0)("DueDate")), "", tbl.Rows(0)("DueDate"))
                txtOrderDate.Text = IIf(IsDBNull(tbl.Rows(0)("OrderDate")), "", tbl.Rows(0)("OrderDate"))

                DDLCustomer.Text = IIf(IsDBNull(tbl.Rows(0)("Customer")), "", tbl.Rows(0)("Customer"))
                txtDeliveryCharges.Text = IIf(IsDBNull(tbl.Rows(0)("OtherCharges")), "", Math.Round(tbl.Rows(0)("OtherCharges"), 3))
                If Not DDLStockLocation.Items.FindByValue(tbl.Rows(0)("StockLocationID")) Is Nothing Then
                    DDLStockLocation.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("StockLocationID")), "", tbl.Rows(0)("StockLocationID"))
                End If

                txtTax.Text = IIf(IsDBNull(tbl.Rows(0)("Tax")), "", Math.Round(tbl.Rows(0)("Tax"), 3))
                If Not DDLSalesPerson.Items.FindByValue(tbl.Rows(0)("SalesPerson")) Is Nothing Then
                    DDLSalesPerson.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("SalesPerson")), "", tbl.Rows(0)("SalesPerson"))
                End If


                LoadCustomerCreditLimitAndBalance()
            End If
            SaleReturnDetails.AddReturnSaleDataRows(tbl)

            Dim TotalAmount As Single = 0.0
            For i As Integer = 0 To tbl.Rows.Count - 1
                If (IsDBNull(tbl.Rows(i)("TotalAmount")) = False AndAlso tbl.Rows(i)("TotalAmount").ToString() <> "") Then
                    TotalAmount += tbl.Rows(i)("TotalAmount")
                End If
            Next
            hdnSaleID.Value = tbl.Rows(0)("SaleID")
            tbl = New DataTable
            tbl = Transactions.GetTransactionDetailsBySaleID(Session("CurrentBusinessID"), hdnSaleID.Value & ",")
            If tbl.Rows.Count > 0 Then
                hdnTID.Value = tbl.Rows(0)("TransactionID")
            End If
            If TotalAmount <= 0 Then
                BtnSave.Visible = False

            End If
        End If
    End Sub
End Class