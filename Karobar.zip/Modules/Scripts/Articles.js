function GetPopularProducts(ControlID, TypeID) {
    var Data = [];
    var RequestData = {
        TypeID: TypeID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetPopularProducts',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("PopularProducts").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("PopularProducts").each(function () {
                    Data.push({
                        ProductID: $(this).find("ArticleID").text(),
                        ProductName: $(this).find("ArticleTitle").text(),
                        ProductDescription: $(this).find("ArticleText").text(),
                        ProductImage: $(this).find("ArticleImage").text(),
                        Price: $(this).find("SalePrice").text(),
                        SoldCount: $(this).find("Sale").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}


function GetMostPurchasedProducts(ControlID, TypeID) {
    var Data = [];
    var RequestData = {
        TypeID: TypeID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetMostPurchasedProduct',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("MostPurchasedProducts").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("MostPurchasedProducts").each(function () {
                    Data.push({
                        ProductID: $(this).find("ArticleID").text(),
                        ProductName: $(this).find("ArticleTitle").text(),
                        PurchaseCount: $(this).find("PurchaseCount").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}

function GetMostSoldProducts(ControlID,TypeID) {
    var Data = [];
    var RequestData = {
        TypeID: TypeID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetMostSoldProduct',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("MostSoldProducts").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("MostSoldProducts").each(function () {
                    Data.push({
                        ProductID: $(this).find("ArticleID").text(),
                        ProductName: $(this).find("ArticleTitle").text(),
                        SoldCount: $(this).find("SaleCount").text()
                    });
                });

                var ProductsRows = ''
                for (var i = 0; i < Data.length; i++) {
                    ProductsRows = ProductsRows + '<tr>'
                    ProductsRows = ProductsRows + '<td>' + Data[i].ProductName + '</td>'
                    ProductsRows = ProductsRows + '<td align="center">' + Data[i].SoldCount + '</td>'
                    ProductsRows = ProductsRows + '</tr>'
                }
                //$('#TblMostSoldProducts tr:gt(0)').remove();
                //$('#MostSoldProductsRowsBody').html($('#MostSoldProductsRowsBody').html() + ProductsRows)
                $('#MostSoldProductsRowsBody').html(ProductsRows)
                setTimeout("LoadDashboardMostSoldProducts('" + ControlID + "','" + TypeID + "')", 60000)
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}

function GetPopularProducts4Web(BID, TypeID, ContainerID, Template) {
    var Data = [];
    var RequestData = {
        BID:BID,
        TypeID: TypeID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetPopularProducts',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("MostSoldProducts").length;
            if (Count == 0) {
                ;
            }
            else {
                
                $(xml).find("MostSoldProducts").each(function () {
                    Data.push({
                        BusinessID:BID,
                        ProductID: $(this).find("ArticleID").text(),
                        ProductTitle: $(this).find("ArticleTitle").text(),
                        ProductName: $(this).find("ArticleTitle").text(),
                        ProductTitle4URL: $(this).find("ArticleTitle").text().replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),
                        ProductImage: $(this).find("ArticleImage").text(),
                        SoldCount: $(this).find("SaleCount").text(),
                        Price: $(this).find("SalePrice").text(),
                        Currency: $(this).find("CurrencyCode").text()
                    });
                });

                if (Data.length > 0) {
                    my.utils.renderExternalTemplate(Template, ContainerID, { Data: Data });

                    setTimeout(function () {
                        jQuery('.home-owl-carousel').each(function () {

                            var owl = $(this);
                            var itemPerLine = owl.data('item');
                            if (!itemPerLine) {
                                itemPerLine = 4;
                            }
                            owl.owlCarousel({
                                items: itemPerLine,
                                itemsTablet: [768, 2],
                                navigation: true,
                                pagination: false,

                                navigationText: ["", ""]
                            });
                        });
                    },500)
                }
                else
                    $(ContainerID).html('')
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}

function LoadSubCatagories(TypeID) {
    var Data = [];
    var BID = -1//parseInt(gup("KID"));
    //if (!(BID > 0))
    //    BID = parseInt(eval(_j24business)[0].WebsiteID);

    var RequestData = {
        BusinessID: BID,
        TypeID: TypeID

    };
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetProductTypes',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ProductTypes").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ProductTypes").each(function () {
                    Data.push({
                        WebsiteID:BID,
                        ArticleTypeID: $(this).find("ArticleTypeID").text(),
                        ParentArticleTypeID: $(this).find("ParentArticleTypeID").text(),
                        GroupTypeID: $(this).find("GroupTypeID").text(),
                        ArticleType: $(this).find("ArticleType").text(),
                        ArticleType4URL: ReplaceWith($(this).find("ArticleType").text(), '+=)(\]{}{}/\.,><":;?~`!@#$%,*^ &', '_')
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}



function LoadSubCatagories4Website(TypeID, CtrlID, Template) {
    var Data = [];
    var BID = parseInt(gup("KID"));
    if (!(BID > 0))
        BID = parseInt(eval(_j24business)[0].WebsiteID);

    var RequestData = {
        BusinessID: BID,
        TypeID: TypeID

    };
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetProductTypes',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ProductTypes").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ProductTypes").each(function () {
                    Data.push({
                        WebsiteID: BID,
                        ArticleTypeID: $(this).find("ArticleTypeID").text(),
                        ParentArticleTypeID: $(this).find("ParentArticleTypeID").text(),
                        GroupTypeID: $(this).find("GroupTypeID").text(),
                        ArticleType: $(this).find("ArticleType").text(),
                        ArticleType4URL: ReplaceWith($(this).find("ArticleType").text(), '+=)(\]{}{}/\.,><":;?~`!@#$%,*^ &', '_')
                    });
                });
            }

            if (CtrlID) {
                my.utils.renderExternalTemplate(Template, CtrlID, Data);
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}

function AddArticles(ControlID) {
    var file = document.getElementById("UploadFile");
    var filename = $("#UploadFile").val();
    var formData = new FormData();
    var _ArticleTypeID = "1"// $('#'+ControlID+'TypeID').val()
    var _ArticleTitle = $('#' + ControlID + 'ArticleTitle').val()
    var _ArticleDesc = $('#' + ControlID + 'ArticleDesc').val()
    var _ArticleImageWebURL = $('#' + ControlID + 'ArticleImageWebURL').val()
    var _ArticleImageLocalPath = $("#UploadFile").val()
    var Data = [];
    
//    formData.append("UploadFile", file.files[0]);
//    _ArticleImageLocalPath.append("UploadFile", file.files[0]);

    var RequestData = {
        ArticleTypeID   :_ArticleTypeID,
        ArticleTitle    : _ArticleTitle,
        ArticleDesc     : _ArticleDesc,
        ArticleImageWebURL: _ArticleImageWebURL,
        ArticleImageLocalPath: _ArticleImageLocalPath
        ,File            : file.files[0]
            
    };
    

    var data = new FormData();
    data.append("file", file.files[0]);
    alert(JSON.stringify(data))
//    alert(JSON.stringify(RequestData))
            $.ajax({
                type: "POST",
                url: '/Webservice/WebsiteArticles.asmx/Articles_Add',
                //enctype: 'multipart/form-data',
                
                
                cache: false,
                dataType: 'json',
                processData: false,
                contentType: "application/json; charset=utf-8",
                async: false,


                data: data,//JSON.stringify(RequestData), // { file: filename },
                success: function () {
                    alert("Data Uploaded: ");
                }
            });

}

function AddArticlesOld(ControlID) {
    var file = document.getElementById("UploadFile");
    var formData = new FormData();
    var _ArticleTypeID = "1"// $('#'+ControlID+'TypeID').val()
    var _ArticleTitle = $('#' + ControlID + 'ArticleTitle').val()
    var _ArticleDesc = $('#' + ControlID + 'ArticleDesc').val()
    var _ArticleImageWebURL = $('#' + ControlID + 'ArticleImageWebURL').val()
    var _ArticleImageLocalPath= new FormData();
    
    formData.append("UploadFile", file.files[0]);
    _ArticleImageLocalPath.append("UploadFile", file.files[0]);

    var RequestData = {
        ArticleTypeID: _ArticleTypeID,
        ArticleTitle: _ArticleTitle,
        ArticleDesc: _ArticleDesc,
        ArticleImageWebURL: _ArticleImageWebURL,
        ArticleImageLocalPath: _ArticleImageLocalPath
    };
    alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        cache: false,
        dataType: 'json',
        processData: false, 
        contentType: false,
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Articles_Add',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            //            HideDlg('UploadDlg')
            //            $('#txtTitle').val('');
            //            $('#txtDescription').val('');
            //            $('#txtUploadURL').val('')
            $(location).attr('href', '/Home')
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data;
}

function SearchArticle(FreeText) {
    FreeText = FreeText.replace(/\./g, '')
    if (FreeText == 'Search')
        FreeText = ''
    window.location = '/Search/' + FreeText
}

function GetArticleTypes() {
    var Data = [];
    var RequestData = {
        PrimaryTypeID: -1
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetArticleTypes',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ArticlePrimaryTypes").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ArticlePrimaryTypes").each(function () {
                    Data.push({
                        ArticleTypeID: $(this).find("ArticleTypeID").text(),
                        ParentArticleTypeID: $(this).find("ParentArticleTypeID").text(),
                        ArticleType: $(this).find("ArticleType").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    return Data
}

function LoadArticleTypes() {


    var Data = [];
    var RequestData = {
        PrimaryTypeID: -1
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetArticleTypes',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ArticlePrimaryTypes").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ArticlePrimaryTypes").each(function () {
                    Data.push({
                        ArticleTypeID: $(this).find("ArticleTypeID").text(),
                        ParentArticleTypeID: $(this).find("ParentArticleTypeID").text(),
                        ArticleType: $(this).find("ArticleType").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    
    my.utils.renderExternalTemplate("1/Templates/ArticleTypesList", "#ArticleTypesContainer", Data);
}


function GetArticleDetail(ID) {

    var RequestData = {
        ArticleID: ID
    };
    var Data = [];
    var ArticleImages=[]
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/WebsiteArticles.asmx/Article_GetDetail',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ArticleDetail").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ArticleImages").each(function () {
                    ArticleImages.push({
                        ArtileImageVideoURL: $(this).find("ImageVideoURL").text(),
                        ArtileDescription: $(this).find("Description").text(),
                        PostedOn: $(this).find("DateCreated").text()
                     })
                });
                $(xml).find("ArticleDetail").each(function () {
                
                    Data.push({
                        ArticleID: $(this).find("ArticleID").text(),
                        TypeID: $(this).find("ArticleTypeID").text(),
                        ArticleTypeName: $(this).find("ArticleType").text(),
                        Title: $(this).find("ArticleTitle").text(),
                        Title4URL: ReplaceWith($(this).find("ArticleTitle").text(), '+=)(\]{}{}/\.,><":;?~`!@#$%,*^ ', '_'),
                        Description: $(this).find("ArticleText").text(),
                        ArticleImage: $(this).find("ArticleImage").text(),
                        ArticleImages: ArticleImages,
                        ArticleImagesCount: $(xml).find("ArticleImages").length,
                        PostedByUserID: $(this).find("PostedBy").text(),
                        PostedByUserName: $(this).find("FirstName").text() + ' ' + $(this).find("LastName").text(),
                        Visible: $(this).find("Visible").text(),
                        Views: $(this).find("ViewsCount").text(),
                        Dated: $(this).find("PostedOn").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Data;
}

function GetSimilarArticles(ControlID) {
    var Data = []
    var ID = gup('ID')
    var PageSize = $('#' + ControlID + '_PageSize').val()
    Data = GetArticleDetail(ID)
    $('#'+ControlID+'ArticleTypeName').html(Data[0].ArticleTypeName)
    //(ControlID, TypeID, Template, Container, PageSize)
    GetArticleCategoryWise(ControlID, Data[0].TypeID, 'SimilarArticleRow', 'SimilarArticles', PageSize);
}

function LoadArticleDetailTemplate() {
    var Data = []
    var ID = gup('ID')
    Data = GetArticleDetail(ID)
    my.utils.renderExternalTemplate("1/Templates/" + Data[0].ArticleTypeName.replace(' ','') + "Detail", "#ArticleDetail", Data);
}

function GetArticles(ControlID) {
    if (ControlID != '') {

        var SearchText = $('#txtFreeSearchText').val()
        var PageSize = $('#' + ControlID + '_PageSize').val()
        var SortBy = (document.getElementById(ControlID + '_SortBy')) ? $('#' + ControlID + '_SortBy').val() : ''
        var SortOrder = (document.getElementById(ControlID + '_SortBy')) ? $('#' + ControlID + '_SortOrder').val() : ''
        var PageNumber = $('#' + ControlID + '_PageNo').val()
        var Template = $('#' + ControlID + '_WebsiteID').val() + '/Templates/ArticleRow'// + $('#' + ControlID + '_Template').val()
        var ContainerID = ControlID + '_ArticlesListContainer'
        var Count = 0;
        var FreeText = gup('Text')
        var TypeID = gup('Category')


        if (FreeText != '') {
            SearchText = FreeText
            $('#txtFreeSearchText').val(FreeText)
        }
        if (SearchText.indexOf('Search...') >= 0)
            SearchText = ''
        if (TypeID == '')
            TypeID = 0

        var RequestData = {
            TypeID: TypeID,
            SearchText:SearchText,
            PageNumber:PageNumber,
            PageSize:PageSize,
            SortBy:SortBy,
            SortOrder: SortOrder,
            JSFunction4Paging:'Loading'
        };
        var Data = [];

        //alert(JSON.stringify(RequestData))
        $.ajax({
            type: "POST",
            dataType: 'xml',
            data: JSON.stringify(RequestData),
            async: false,
            url: '/Webservice/WebsiteArticles.asmx/Articles_Search',
            contentType: "application/json; charset=utf-8",
            success: function (xml) {
                Count = $(xml).find("ArticlesSearchResults").length;
                if (Count == 0) {
                    ;
                }
                else {
                    $(xml).find("ArticlesSearchResults").each(function () {
                        Data.push({
                            ArticleID: $(this).find("ArticleID").text(),
                            TypeID: $(this).find("ArticleTypeID").text(),
                            ArticleTypeName: $(this).find("ArticleType").text(),
                            Title: $(this).find("ArticleTitle").text(),
                            Title4URL: ReplaceWith($(this).find("ArticleTitle").text(), '+=)(\]{}{}/\.,><":;?~`!@#$%,*^ ', '_'),
                            Description: $(this).find("ArticleText").text(),
                            ArticleImage: $(this).find("ArticleImage").text(),
                            PostedByUserID: $(this).find("PostedBy").text() ,
                            PostedByUserName: $(this).find("FirstName").text() + ' ' + $(this).find("LastName").text(),
                            Visible: $(this).find("Visible").text(),
                            Views: $(this).find("ViewsCount").text(),
                            Dated: $(this).find("PostedOn").text(),
                            RecordCount: $(this).find("RecordCount").text(),
                            ControlID: ControlID
                        });

                        //$('#' + ControlID + 'ArticleTitle').html($(this).find("ArticleType").text())
                    });
                }
            },
            error: function (xhr, status, errord) {
                alert(xhr.responseText);
            }
        });
        //  alert(Count +'     ----  ' + JSON.stringify(Data))
        //alert(Template)
        if (Count > 0) {
            my.utils.renderExternalTemplate(Template, "#" + ContainerID, Data);
        }
        return Data;
    }

}





function GetArticleCategoryWise(ControlID, TypeID,Template,Container,PageSize) {

    var RequestData = {
        TypeID: TypeID,
        SearchText: '',
        PageNumber: $('#'+ControlID+'_PageNo').val(),
        PageSize: (PageSize==undefined || PageSize==null ||  PageSize=='')?'15':PageSize,
        SortBy: '',
        SortOrder: '',
        JSFunction4Paging: 'Loading'
    };
    
    $.ajax({
        type: "POST",
        dataType: 'xml',
        url: '/Webservice/WebsiteArticles.asmx/Articles_Search',
        data: JSON.stringify(RequestData),
        contentType: "application/json; charset=utf-8",
        success: function (msg) {
            OnGetArticleCategoryWiseSuccess(ControlID, msg, Template,Container);
        },
        error: function (xhr, desc, exceptionobj) {
            alert(xhr.responseText);
        }
    });
}

function OnGetArticleCategoryWiseSuccess(ControlID, Articles, Template, Container) {
    var Data = [];
    var WebsiteID = $('#' + ControlID + '_WebsiteID').val()

    $(Articles).find("ArticlesSearchResults").each(function () {
    
        Data.push({
            ArticleID: $(this).find("ArticleID").text(),
            TypeID: $(this).find("ArticleTypeID").text(),
            ArticleTypeName: $(this).find("ArticleType").text(),
            Title: $(this).find("ArticleTitle").text(),
            Title4URL: ReplaceWith($(this).find("ArticleTitle").text(), '+=)(\]{}{}/\.,><":;?~`!@#$%,*^ ', '_'),
            Description: $(this).find("ArticleText").text(),
            ArticleImage: $(this).find("ArticleImage").text(),
            PostedByUserID: $(this).find("PostedBy").text(),
            PostedByUserName: $(this).find("FirstName").text() + ' ' + $(this).find("LastName").text(),
            Visible: $(this).find("Visible").text(),
            Views: $(this).find("ViewsCount").text(),
            RecordCount: $(this).find("RecordCount").text(),
            Dated: $(this).find("PostedOn").text(),
            ControlID:ControlID
        });

    });

    my.utils.renderExternalTemplate(WebsiteID + "/Templates/" + Template, "#" + ControlID + Container, Data);
}

