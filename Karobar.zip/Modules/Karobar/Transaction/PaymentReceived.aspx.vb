﻿Imports System.Data.SqlClient

Public Class PaymentReceived
    Inherits System.Web.UI.Page


    Private Sub PaymentsPayReceived_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 20) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then
            DDLCreditAccountHead.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("CreditAccountHeads4PaymentReceived", "30,31,32", Session("CurrentBusinessID")))
            DDLCreditAccountHead.DataTextField = "AccountHeadName"
            DDLCreditAccountHead.DataValueField = "AccountHeadID"
            DDLCreditAccountHead.DataBind()

            LblPaymentReceiveDate.Text = ReferenceData.Setting("LblPaymentReceiveDate", "Date", Session("CurrentBusinessID"))
            LblPaymentReceivedParticular.Text = ReferenceData.Setting("LblPaymentReceivedParticular", "Particular", Session("CurrentBusinessID"))
            LblReceivedPaymentAmount.Text = ReferenceData.Setting("LblReceivedPaymentAmount", "Amount", Session("CurrentBusinessID"))
            LblReceivedPaymentCreditAccount.Text = ReferenceData.Setting("LblReceivedPaymentCreditAccount", "Payment (Credit Account)", Session("CurrentBusinessID"))
            LblReceivedPaymentDebitAccount.Text = ReferenceData.Setting("LblReceivedPaymentDebitAccount", "Payment (Debit Account)", Session("CurrentBusinessID"))
            LblReceivedPaymentOtherCharges.Text = ReferenceData.Setting("LblReceivedPaymentOtherCharges", "Other Charges", Session("CurrentBusinessID"))

            LblReceivedPaymentReference.Text = ReferenceData.Setting("LblReceivedPaymentReference", "Reference", Session("CurrentBusinessID"))
            LblReceivedPaymentTax.Text = ReferenceData.Setting("LblReceivedPaymentTax", "Tax", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblReceivedPaymentScreenTitle", "Received Payment", Session("CurrentBusinessID"))

            DDLDebitAccountHead.DataSource = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("DebitAccountHeadsPaymentReceived", "24,10", Session("CurrentBusinessID")))
            DDLDebitAccountHead.DataTextField = "AccountHeadName"
            DDLDebitAccountHead.DataValueField = "AccountHeadID"
            DDLDebitAccountHead.DataBind()

            Dim tbl As New DataTable
            tbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), AccountHeadID:=ReferenceData.Setting("OthersDebitAccountHeads4PaymentReceived", "24", Session("CurrentBusinessID")))
            For i As Integer = 0 To tbl.Rows.Count - 1
                DDLDebitAccountHead.Items.Insert(0, New ListItem(tbl.Rows(i)("AccountHeadName"), tbl.Rows(i)("AccountHeadID")))
            Next
            txtDate.Text = Now.ToString("dd-MM-yyyy")
        End If
    End Sub


    Protected Sub BtnSave_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim TID As Integer = -1
        Dim _creditaccountheadid As Integer = -1
        Dim _debitaccountheadid As Integer = -1

        If DDLCreditAccountHead.Items.Count > 0 Then
            _creditaccountheadid = DDLCreditAccountHead.SelectedItem.Value
        End If

        If DDLDebitAccountHead.Items.Count > 0 Then
            _debitaccountheadid = DDLDebitAccountHead.SelectedItem.Value
        End If


        Dim DatedAry() = txtDate.Text.Replace("/", "-").Split("-")

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try
            connection.Open()
            trans = connection.BeginTransaction()

            tbl = Transactions.AddTransaction(Session("CurrentBusinessID"), txtReference.Text.Trim, "PRV", txtParticular.Text, "Active", True, CDate(DatedAry(1) & "-" & DatedAry(0) & "-" & DatedAry(2)), trans:=trans)
            If tbl.Rows.Count > 0 Then
                TID = tbl.Rows(0)("TransactionID")
                Transactions.AddTransactionDetails(TID, _creditaccountheadid, True, txtParticular.Text, 0, Val(txtAmount.Text), 0, 0, "", trans:=trans)
                tbl = New DataTable

                Transactions.AddTransactionDetails(TID, _debitaccountheadid, False, "Received payment from " & DDLCreditAccountHead.SelectedItem.Text, Val(txtAmount.Text), 0, Val(txtOtherCharges.Text), Val(txtTax.Text), "", trans:=trans)
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Payment received successfully!','0',$(window).height()*2/100,$(window).width()*45/100)</script>")
                ''Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Transaction done", "Transaction ID :" & TID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                Log.Notifications_Add("Payment Received " & Val(txtAmount.Text), TID, "Payment Received", Val(txtAmount.Text))


            End If

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "TransactionAddingIssue", "<script>parent.ShowMessage('Unable to process transaction','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Finally
            connection.Close()
        End Try


    End Sub
End Class