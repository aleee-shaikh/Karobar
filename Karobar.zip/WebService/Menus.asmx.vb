﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
Public Class Menus
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function LoadWelcomeMenu(ByVal UserID As Integer) As String
        Dim ds As New DataSet

        If Session("PortalMenu") Is Nothing Then
            ds = Menu.GetMenus(ReferenceData.Setting("WelcomeMenuID", "29"))
            Session("PortalMenu") = ds
        Else
            ds = CType(Session("PortalMenu"), DataSet)
        End If
        If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count = 0) Then
            ds = Menu.GetMenus(ReferenceData.Setting("WelcomeMenuID", "29"))
            Session("PortalMenu") = ds
        End If
        ds.Tables(0).TableName = "Menus"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function LoadLoggedinUserMenu(ByVal UserID As Integer) As String
        Dim ds As New DataSet

        If Session("LoadLoggedinUserMenu") Is Nothing Then
            ds = Menu.GetMenus(UserID:=UserID)
            Session("LoadLoggedinUserMenu") = ds
        Else
            ds = CType(Session("LoadLoggedinUserMenu"), DataSet)
        End If

        If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count = 0) Then
            ds = Menu.GetMenus(UserID:=UserID)
            Session("LoadLoggedinUserMenu") = ds
        End If
        ds.Tables(0).TableName = "Menus"
        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetWebSectionDetail(ByVal WebsiteID As Integer, SectionID As Integer) As String
        Dim ds As New DataSet

        ds = WebSectionsBLL.GetSectionDetail(WebsiteID, SectionID)
        ds.Tables(0).TableName = "WebSection"
        ds.Namespace = "WebSection"
        Return ds.GetXml().ToString

    End Function
End Class