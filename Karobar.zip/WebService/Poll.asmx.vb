﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
 Public Class Poll
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
        <WebMethod()> _
    Public Function GetPolling(ByVal PollID As String, ByVal FreeText As String) As String
        Dim ds As New DataSet

        ds = Polling.GetPolling(PollID, FreeText)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "Polling"
        If ds.Tables.Count > 1 Then ds.Tables(1).TableName = "PollingOptions"

        Return ds.GetXml
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
        <WebMethod(True)> _
    Public Function CastVote(ByVal PollID As String, ByVal OptionID As String) As String
        Dim ds As New DataSet
        ds = Polling.CastVote(PollID, OptionID, HttpContext.Current.Session("UserID"))

        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "CastVoteResponse"


        Return ds.GetXml
    End Function

End Class