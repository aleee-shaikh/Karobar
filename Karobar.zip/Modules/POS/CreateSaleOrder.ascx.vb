﻿Imports System.Data.SqlClient
Imports Newtonsoft.Json

Public Class CreateSaleOrder
    Inherits System.Web.UI.UserControl
    Dim _BusinessDetail As New DataTable
    Dim _CustomerDtl As New DataTable

    Private Sub POSSale_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Me.IsPostBack Then
            If LoggedInUserSession.BusinessCategoryID = 4 Then 'Showroom
                'pnlBookingForm.Visible = True
                LblBookingFromDate.Text = ReferenceData.Setting("LblBookingFromDate", "Bkng From", Session("CurrentBusinessID"))
                LblBookingToDate.Text = ReferenceData.Setting("LblBookingToDate", "Bkng To", Session("CurrentBusinessID"))
            End If


            If Not Request("OID") Is Nothing Then
                HdnOrderID.Value = Cryptography.Decrypt(Request("OID"))
                Dim ds As New DataSet()
                ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(HdnOrderID.Value))

                If (ds.Tables.Count > 0) Then
                    If (ds.Tables(0).Rows.Count > 0) Then
                        If (IsDBNull(ds.Tables(0).Rows(0)("IsCompleted")) = False AndAlso Val(ds.Tables(0).Rows(0)("IsCompleted")) = 1) Then
                            Page.RegisterStartupScript("OrderAlreadyCompleted", "<script>parent.HideDlgForm(1);parent.ShowMessage('Order has already been completed.','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
                        Else
                            txtCartData.Text = General.GetDataTableJson(ds.Tables(1))
                            LoadPurchasedProducts()
                        End If

                    End If
                End If

            End If

            InitializeData()

            If (ddlCustomer.Items.Count > 0) Then
                LoadCustomerCreditLimitAndBalance()
            End If

            HiddenQtyValue.Value = ReferenceData.Setting("HiddenQtyValue", "1", Session("CurrentBusinessID"))
            LblTax.Text = ReferenceData.Setting("LblSalesTax", "Tax", Session("CurrentBusinessID"))
            txtOrderDateFrom.Text = Now.ToString("dd-MM-yyyy 00:00")
            txtOrderToDate.Text = Now.ToString("dd-MM-yyyy 00:00")
            '' txtProducts.Text = "{""AllBusinessProducts"":" & General.GetDataTableJson(Products.GetProductsList(Session("CurrentBusinessID"))) & "}"
        Else

        End If

    End Sub

    Sub InitializeData()
        Dim ds As New DataSet

        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
        DDLProductCatagory.DataValueField = "ArticleTypeID"
        DDLProductCatagory.DataTextField = "ArticleType"
        DDLProductCatagory.DataSource = ds.Tables(0)
        DDLProductCatagory.DataBind()

        Dim custmerInfoTbl As DataTable
        custmerInfoTbl = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Customer)
        ddlCustomer.DataSource = custmerInfoTbl
        ddlCustomer.DataValueField = "UserID"
        ddlCustomer.DataTextField = "FirstName"
        ddlCustomer.DataBind()

        ddlCustomer.Items.Insert(0, New ListItem("--Select Customer--", "-1"))

        'ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SaleType * -1)
        'ddlSaleType.DataValueField = "ArticleTypeID"
        'ddlSaleType.DataTextField = "ArticleType"
        'ddlSaleType.DataSource = ds.Tables(0)
        'ddlSaleType.DataBind()
        If (LoggedInUserSession.BusinessCategoryID = 16 Or LoggedInUserSession.BusinessCategoryID = 4 Or LoggedInUserSession.BusinessCategoryID = 9) Then
            pnlReturantOptions.Visible = True

            lblDeliveryPerson.Text = ReferenceData.Setting("LblDeliveryPerson", "Salesman:", Session("CurrentBusinessID"))
            lblTableNo.Text = ReferenceData.Setting("LblTableNo", "Table #:", Session("CurrentBusinessID"))

            If LoggedInUserSession.BusinessCategoryID = 9 And LoggedInUserSession.BusinessID = 64 Then'DMS
                DDLDeliveryPerson.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.DMSDeliveryBoy)
            Else
                DDLDeliveryPerson.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Staff)
            End If

            DDLDeliveryPerson.DataValueField = "UserID"
            DDLDeliveryPerson.DataTextField = "FirstName"
            DDLDeliveryPerson.DataBind()

            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.TableNos * -1)
            DDLTableNo.DataValueField = "ArticleTypeID"
            DDLTableNo.DataTextField = "ArticleType"
            DDLTableNo.DataSource = ds.Tables(0)
            DDLTableNo.DataBind()

        Else
            pnlReturantOptions.Visible = False
        End If

        LoadData()

        ddlOrderStatus.DataSource = Products.GetOrderStatus(Val(Session("CurrentBusinessID")))
        ddlOrderStatus.DataTextField = "StatusName"
        ddlOrderStatus.DataValueField = "OrderStatusID"
        ddlOrderStatus.DataBind()
    End Sub

    Sub LoadData()
        rptProducts.DataSource = Products.GetProductsList(Session("CurrentBusinessID"), DDLProductCatagory.SelectedValue, DDLProductSubCatagories.SelectedValue, txtFreeText.Text.Trim)
        rptProducts.DataBind()
    End Sub

    Private Sub DDLProductCatagory_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        LoadProductSubCatagories(DDLProductCatagory.SelectedValue)
        LoadData()
    End Sub

    Sub LoadProductSubCatagories(ByVal GroupTypeID As Integer)
        DDLProductSubCatagories.Items.Clear()
        Dim ds As New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagories.DataValueField = "ArticleTypeID"
        DDLProductSubCatagories.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If

        DDLProductSubCatagories.Items.Add(New ListItem("All Sub Catagories", "-1"))
        DDLProductSubCatagories.DataSource = tbl
        DDLProductSubCatagories.DataBind()

    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnProceed_Click(sender As Object, e As EventArgs) Handles BtnProceed.Click
        txtCartTotal.Text = (CSng(txtCartProductAmountTotal.Text) - CSng(txtCartDiscount.Text)) + CSng(txtCartTax.Text) + CSng(txtDeliveryCharges.Text)
        DivPayment.Visible = True
        DivCart.Visible = False
        DivInvoice.Visible = False
        'txtPurchasedPayableAmount.Text = txtCartTotal.Text
        'txtGrossAmount.Text = txtCartTotal.Text
        'HdnGrossAmount.Value = txtCartTotal.Text
        'txtPurchasedTotalItems.Text = txtCartItemsCount.Text
        'HdnTotalRedeemPointsAmount.Value = "0"

        'If Menu.GetBusinessCategoryID() = 13 Then
        '    pnlGiftCard.Visible = False
        'Else
        '    pnlGiftCard.Visible = True
        'End If
    End Sub

    Sub LoadPurchasedProducts()
        Dim tblCartProducts As New DataTable
        tblCartProducts = General.ConvertJSONToDataTable(txtCartData.Text)
        If (tblCartProducts.Rows.Count > 0) Then
            tblCartProducts.Rows.RemoveAt(tblCartProducts.Rows.Count - 1)
        End If

        GrdProducts.DataSource = tblCartProducts
        GrdProducts.DataBind()
    End Sub

    Sub LoadBusinessDetails()
        Dim ds As New DataSet
        ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then
                _BusinessDetail = ds.Tables(0)
                lblInvoiceTitle.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
                lblBusinessTelephone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
                lblBusinessAddres.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
                lblBusinessCityPostCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")) OrElse ds.Tables(0).Rows(0)("City").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("City") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")) OrElse ds.Tables(0).Rows(0)("Town").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("Town") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")) OrElse ds.Tables(0).Rows(0)("ZipCode").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("ZipCode") & ",")

            End If
        End If
    End Sub

    Private Sub ddlCustomer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlCustomer.SelectedIndexChanged
        LoadCustomerCreditLimitAndBalance()

        Dim tbl As New DataTable

        'HdnGiftCardValidityDays.Value = "0"
        'txtRedeemPoints.Text = "0"
        'HdnPointValue.Value = 0
        'HdnGiftCardID.Value = "-1"
        'lblPoints.Text = "0"
        'DDLUserCards.Items.Clear()
        'tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), ddlCustomer.SelectedValue)
        'DDLUserCards.DataTextField = "UserCardName"
        'DDLUserCards.DataValueField = "UserCardID"
        'DDLUserCards.DataSource = tbl
        'DDLUserCards.DataBind()
        'DDLUserCards.Items.Insert(0, New ListItem("-- Select Gift Card --", "-1"))
        'If tbl.Rows.Count > 0 Then
        '    HdnGiftCardValidityDays.Value = tbl.Rows(0)("ValidityDays")
        '    HdnGiftCardID.Value = tbl.Rows(0)("GiftCardID")
        'End If
    End Sub

    Sub LoadCustomerCreditLimitAndBalance()
        Dim ds As DataSet = New DataSet
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), ddlCustomer.SelectedValue)
        txtCustomerBalance.Text = "0"
        txtCreditLimit.Text = "0"
        If (ds.Tables.Count > 0) Then
            _CustomerDtl = ds.Tables(0)
            If (ds.Tables(0).Rows.Count > 0) Then
                txtCreditLimit.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("CreditLimit")), 0, ds.Tables(0).Rows(0)("CreditLimit"))
                HdnCustomerEmail.Value = IIf(IsDBNull(ds.Tables(0).Rows(0)("loginid")), "", ds.Tables(0).Rows(0)("loginid"))
                Dim HeadIds As String = ""
                Dim tbl As New DataTable
                HeadIds = ddlCustomer.SelectedValue & ","
                tbl = ChartOfAccount.COA_GetAccountReceiveableSummary(HeadIds)
                If (tbl.Rows.Count > 0) Then
                    txtCustomerBalance.Text = tbl.Rows(0)("Balance")
                End If
            End If
        End If
    End Sub

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles BtnCancel.Click

    End Sub

    Private Sub btnBackToPOS_Click(sender As Object, e As EventArgs) Handles btnBackToPOS.Click

        DivCart.Visible = True
        DivPayment.Visible = False
        DivInvoice.Visible = False

        txtCartData.Text = ""
        txtCartTax.Text = 0
        txtCartDiscount.Text = 0
        txtCartTotal.Text = 0
        txtCartProductAmountTotal.Text = 0
        txtCartItemsCount.Text = 0
        LoadData()


    End Sub

    Private Sub GrdProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim lblDiscount As Label = CType(e.Row.FindControl("lblDiscount"), Label)
            Dim lblTax As Label = CType(e.Row.FindControl("lblTax"), Label)
            Dim lblTotal As Label = CType(e.Row.FindControl("lblTotal"), Label)
            Dim lblTotalItems As Label = CType(e.Row.FindControl("lblTotalItems"), Label)
            Dim lblGrandTotal As Label = CType(e.Row.FindControl("lblGrandTotal"), Label)
            Dim lblRedeemPointsDiscountAmount As Label = CType(e.Row.FindControl("lblRedeemPointsDiscountAmount"), Label)
            Dim lblRedeemPoints As Label = CType(e.Row.FindControl("lblRedeemPoints"), Label)
            Dim lblDeliveryCharges As Label = CType(e.Row.FindControl("lblDeliveryCharges"), Label)

            lblTotalItems.Text = txtCartItemsCount.Text
            lblTotal.Text = txtCartProductAmountTotal.Text
            lblTax.Text = txtCartTax.Text
            lblDiscount.Text = txtCartDiscount.Text
            'lblGrandTotal.Text = HdnGrossAmount.Value  'txtCartTotal.Text
            'lblRedeemPointsDiscountAmount.Text = HdnTotalRedeemPointsAmount.Value
            'lblRedeemPoints.Text = txtRedeemPoints.Text
            lblDeliveryCharges.Text = txtDeliveryCharges.Text

            Dim ds As New DataSet
            ds = Website.GetWebsiteDetails(Val(Session("CurrentBusinessID")))
            If ds.Tables.Count > 0 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    lblInvoiceTitle.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
                    lblBusinessTelephone.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Phone")), "", ds.Tables(0).Rows(0)("Phone"))
                    lblBusinessAddres.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("Address")), "", ds.Tables(0).Rows(0)("Address"))
                    lblBusinessCityPostCode.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("City")) OrElse ds.Tables(0).Rows(0)("City").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("City") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("Town")) OrElse ds.Tables(0).Rows(0)("Town").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("Town") & ",") & IIf(IsDBNull(ds.Tables(0).Rows(0)("ZipCode")) OrElse ds.Tables(0).Rows(0)("ZipCode").ToString().Trim() = "", "", ds.Tables(0).Rows(0)("ZipCode") & ",")

                End If
            End If



        End If
    End Sub

    Private Sub rptProducts_ItemDataBound(sender As Object, e As RepeaterItemEventArgs) Handles rptProducts.ItemDataBound
        If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
            Dim HdnProductID As New HiddenField
            Dim HdnParentArticleID As New HiddenField
            Dim GrdChildProducts As New GridView
            HdnProductID = CType(e.Item.FindControl("HdnProductID"), HiddenField)
            HdnParentArticleID = CType(e.Item.FindControl("HdnParentArticleID"), HiddenField)
            GrdChildProducts = CType(e.Item.FindControl("grdChildProducts"), GridView)

            Dim ds As New DataSet
            ds = Products.GetParentProducts(Session("CurrentBusinessID"), Val(HdnProductID.Value), Val(HdnProductID.Value))
            GrdChildProducts.DataSource = ds
            GrdChildProducts.DataBind()

        End If
    End Sub

    Private Sub btnSendEmail_Click(sender As Object, e As EventArgs) Handles btnSendEmail.Click
        _CustomerDtl = Person.GetUserDetail(Session("CurrentBusinessID"), ddlCustomer.SelectedValue).Tables(0)
        LoadBusinessDetails()
        SendInvoiceEmail()
        Page.RegisterStartupScript("SaleDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Sale Invoice sent successfully to " & HdnCustomerEmail.Value & "','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
    End Sub

    Sub SendInvoiceEmail()
        Dim FromUserEmail As String = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
        Dim EmailSubject As String = "Sale Invoice #" & lblInvNo.Text
        Dim ToUserEmail As String = HdnCustomerEmail.Value
        Dim emailBody As String = HdnInvoice.Value
        Dim fileName As String = "~/Modules/Karobar/Reports/PDF/" & lblInvNo.Text & ".pdf"
        ''WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, "", "", "", emailBody)

        If (System.IO.File.Exists(fileName) = False) Then
            GenerateFile.Generate(GenerateFile.ExportFormat.PDF, HdnInvoice.Value, fileName)
        End If

        Dim EmailTemplateFile As String = ReferenceData.Setting("SaleInvoiceTemplate", "SaleInvoiceTemplate")
        Dim ReplacingWords As String = ""

        ReplacingWords = ReplacingWords & "[CustomerName]♦" & _CustomerDtl.Rows(0)("FirstName") & "¤"
        ReplacingWords = ReplacingWords & "[UserEmail]♦" & _CustomerDtl.Rows(0)("loginID") & "¤"
        ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
        'ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
        'ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
        'ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
        'ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
        'ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
        'ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
        'ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
        ReplacingWords = ReplacingWords & "[BusinessID]♦" & _BusinessDetail.Rows(0)("WebsiteID") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & _BusinessDetail.Rows(0)("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & _BusinessDetail.Rows(0)("WebsiteLogo").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & _BusinessDetail.Rows(0)("CurrencyCode").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & _BusinessDetail.Rows(0)("Email").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & _BusinessDetail.Rows(0)("Phone").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessFax]♦" & _BusinessDetail.Rows(0)("Fax").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCity]♦" & _BusinessDetail.Rows(0)("City").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTown]♦" & _BusinessDetail.Rows(0)("Town").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & _BusinessDetail.Rows(0)("CategoryTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & _BusinessDetail.Rows(0)("Address").ToString() & "¤"

        WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, "", EmailSubject, EmailTemplateFile, fileName, ReplacingWords, "")

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Dim ProductIDsList As String = ""
        Dim tblCartProducts As New DataTable
        tblCartProducts = General.ConvertJSONToDataTable(txtCartData.Text)
        For i As Integer = 0 To tblCartProducts.Rows.Count - 1
            If IsDBNull(tblCartProducts.Rows(i)("ProductID")) = False AndAlso tblCartProducts.Rows(i)("ProductID").ToString() <> "" Then
                ProductIDsList = ProductIDsList & tblCartProducts.Rows(i)("ProductID") & "|" & tblCartProducts.Rows(i)("ProductPrice") & "|" & tblCartProducts.Rows(i)("ProductQuantity") & "|'" & tblCartProducts.Rows(i)("ProductUnit") & "'|'" & tblCartProducts.Rows(i)("ProductTitle") & "',"
            End If
        Next
        If ProductIDsList.Length > 3 Then
            ProductIDsList = ProductIDsList.Substring(0, ProductIDsList.Length - 1)
        End If
        Dim dr As DataRow
        dr = Website.GetWebsiteDetailRow(Val(Session("CurrentBusinessID")))
        Dim tbl As New DataTable

        Dim OrderDate As String = ""
        Dim tmp()
        Dim tmpTM As String = ""

        If txtOrderDateFrom.Text = "" Then
            OrderDate = Now.ToString() '"MM-dd-yyyy")
        Else
            ''Dim tmpdtAry = txtOrderDateFrom.Text.Split("-")
            tmp = txtOrderDateFrom.Text.Trim().Split(" ")
            If (tmp.Length > 2) Then
                tmpTM = tmp(1)
            End If
            Dim tmpdtAry = tmp(0).Split("-")
            If (tmpdtAry.Length >= 3) Then
                OrderDate = tmpdtAry(1) & "-" & tmpdtAry(0) & "-" & tmpdtAry(2) & " " & tmpTM
                If (IsDate(OrderDate) = False) Then
                    OrderDate = Now.ToString("MM-dd-yyyy hh:mm")
                End If
            End If
        End If

            Dim OrderToDate As String = ""
        If txtOrderToDate.Text = "" Then
            OrderToDate = Now.ToString() '"MM-dd-yyyy")
        Else
            'Dim tmpdtAry = txtOrderToDate.Text.Split("-")
            tmp = txtOrderToDate.Text.Trim().Split(" ")
            If (tmp.Length > 2) Then
                tmpTM = tmp(1)
            End If
            Dim tmpdtAry = tmp(0).ToString.Split("-")
            If (tmpdtAry.Length >= 3) Then
                OrderToDate = tmpdtAry(1) & "-" & tmpdtAry(0) & "-" & tmpdtAry(2) & " " & tmpTM
                'Dim tmpdtAry = tmp(0).ToString.Split("-")
                If (IsDate(OrderToDate) = False) Then
                    OrderToDate = Now.ToString("MM-dd-yyyy hh:mm")
                End If
            End If
        End If

        If LoggedInUserSession.BusinessCategoryID = 9 Then 'ineed Services
            tbl = Products.PlaceAnOrder(LoggedInUserSession.BusinessID, ddlCustomer.SelectedValue, LblUserName.Text, LblEmailAddress.Text.Trim(), LblMobile.Text.Trim(),
                                        LblLandlineNo.Text.Trim(), "", LblAddress.Text.Trim(), LblMessage.Text.Trim(), CDate(OrderDate), ProductIDsList,
                                        CDate(OrderToDate), Latitude:=txtLat.Text, Longitude:=txtLng.Text, DeliveryBoy:=Val(DDLDeliveryPerson.SelectedValue))
        ElseIf LoggedInUserSession.BusinessCategoryID = 4 Then 'Showroom
            tbl = Products.PlaceAnOrder(LoggedInUserSession.BusinessID, ddlCustomer.SelectedValue, LblUserName.Text, LblEmailAddress.Text.Trim(), LblMobile.Text.Trim(),
                                        LblLandlineNo.Text.Trim(), "", LblAddress.Text.Trim(), LblMessage.Text.Trim(), CDate(OrderDate), ProductIDsList, CDate(OrderToDate),
                                        Latitude:=txtLat.Text, Longitude:=txtLng.Text, DeliveryBoy:=Val(DDLDeliveryPerson.SelectedValue))
        Else
            tbl = Products.PlaceAnOrder(LoggedInUserSession.BusinessID, ddlCustomer.SelectedValue, LblUserName.Text, LblEmailAddress.Text.Trim(), LblMobile.Text.Trim(),
                                        LblLandlineNo.Text.Trim(), "", LblAddress.Text.Trim(), LblMessage.Text.Trim(), CDate(OrderDate), ProductIDsList, Latitude:=txtLat.Text,
                                        Longitude:=txtLng.Text)
        End If

        Products.AddOrderHistory(LoggedInUserSession.BusinessID, tbl.Rows(0)("OrderID"), ddlOrderStatus.SelectedValue, txtRemarks.Text, LoggedInUserSession.UserID)

        Dim OrderID As Integer
        If (tbl.Rows.Count > 0) Then
            OrderID = tbl.Rows(0)("OrderID")
            If (tbl.Rows.Count = 1) Then
                ProductIDsList = tbl.Rows(0)("ProductID")
            Else
                ProductIDsList = ""
            End If
            Log.Notifications_Add("Order Created ", OrderID, "Order Created", 0, Val(Session("CurrentBusinessID")))
        End If

        Dim ReplacingWords As String = ""
        Dim ToUserEmail As String = ReferenceData.Setting("ToOrderNotificationEmail", LblEmailAddress.Text)
        Dim EmailTemplateFile As String = ""
        Dim FromUserEmail As String = ""
        Dim Subject As String = dr("WebsiteTitle").ToString() & " - " & ReferenceData.Setting("OrderNotificationEmailSubject", "Order Notification") ''& " :" & ProductIDsList

        FromUserEmail = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
        EmailTemplateFile = ReferenceData.Setting("OrderNotificationEmailTemplate", "OrderNotificationTemplate")

        ReplacingWords = ReplacingWords & "[UserName]♦" & LblUserName.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[UserEmail]♦" & LblEmailAddress.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
        ReplacingWords = ReplacingWords & "[LandlineNo]♦" & LblLandlineNo.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[MobileNo]♦" & LblMobile.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
        ReplacingWords = ReplacingWords & "[Message]♦" & LblMessage.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
        ReplacingWords = ReplacingWords & "[City]♦" & "" & "¤"
        ReplacingWords = ReplacingWords & "[Address]♦" & LblAddress.Text.Trim() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessID]♦" & Cryptography.Encrypt(Val(Session("CurrentBusinessID"))) & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & dr("WebsiteTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & dr("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
        ReplacingWords = ReplacingWords & "[BusinessWebsiteURL]♦" & dr("WebsiteURL").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[Business]♦" & dr("WebsiteLogo").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & dr("CurrencyCode").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & dr("Email").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & dr("Phone").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessFax]♦" & dr("Fax").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCity]♦" & dr("City").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessTown]♦" & dr("Town").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & dr("CategoryTitle").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & dr("Address").ToString() & "¤"
        ReplacingWords = ReplacingWords & "[Products]♦" & ProductIDsList & "¤"
        ReplacingWords = ReplacingWords & "[OrderID]♦" & Cryptography.Encrypt(OrderID.ToString()) & "¤"
        Dim CCEmail As String = dr("Email").ToString()

        WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, CCEmail, Subject, EmailTemplateFile, "", ReplacingWords)
        Page.RegisterStartupScript("OrderAlreadyCompleted", "<script>ShowMessage('Order created successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
        txtCartData.Text = ""
        txtOrderDateFrom.Text = Now.ToString("dd-MM-yyyy")
        txtOrderToDate.Text = Now.ToString("dd-MM-yyyy")
    End Sub
End Class