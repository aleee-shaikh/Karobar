﻿Public Class TaskTeamMembers
    Inherits System.Web.UI.UserControl


    Public Property TaskID() As Integer
        Get
            Return HdnTaskID.Value
        End Get
        Set(value As Integer)
            HdnTaskID.Value = value
        End Set
    End Property

    Public Property TaskMemberType() As Integer
        Get
            Return HdnTaskMemberType.Value
        End Get
        Set(value As Integer)
            HdnTaskMemberType.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()

            DDLTaskUsers.DataValueField = "UserID"
            DDLTaskUsers.DataTextField = "FirstName"
            If TaskMemberType = TaskManagement.TaskUsersType.Members Then
                DDLTaskUsers.DataSource = Person.GetUsersList(LoggedInUserSession.BusinessID, "", 2)
            ElseIf TaskMemberType = TaskManagement.TaskUsersType.Clients Then
                DDLTaskUsers.DataSource = Person.GetUsersList(LoggedInUserSession.BusinessID, "", 4)
                DivTaskRoles.Visible = False
                GrdTaskUsers.Columns(1).Visible = False
            End If

            DDLTaskUsers.DataBind()

            DDLTaskRoles.DataValueField = "TaskRoleID"
            DDLTaskRoles.DataTextField = "RoleName"
            DDLTaskRoles.DataSource = TaskManagement.GetRoles(LoggedInUserSession.BusinessID, TaskMemberType)
            DDLTaskRoles.DataBind()

        End If
    End Sub

    Sub LoadData()
        Dim ds As New DataSet
        ds = TaskManagement.GetTaskMembers(LoggedInUserSession.BusinessID, TaskID, TaskMemberType)
        GrdTaskUsers.DataSource = ds
        GrdTaskUsers.DataBind()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        TaskManagement.AddTaskMember(LoggedInUserSession.BusinessID, TaskID, -1, TaskMemberType, DDLTaskUsers.SelectedValue, DDLTaskRoles.SelectedValue)
        LoadData()
    End Sub
End Class