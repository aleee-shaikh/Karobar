﻿Public Class PurchaseInvoice
    Inherits System.Web.UI.Page
    Dim _TotalAmount As Single

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open purchase invoice", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If Not Page.IsPostBack Then
            HdnPurchaseID.Value = Request("PurchaseID")
        End If
        If HdnPurchaseID.Value > 0 Then
            Dim tbl As New DataTable
            tbl = Products.GetPurchaseDetails(Session("CurrentBusinessID"), Val(HdnPurchaseID.Value))
            If tbl.Rows.Count > 0 Then
                LblSupplier.Text = IIf(IsDBNull(tbl.Rows(0)("SupplierName")), "", tbl.Rows(0)("SupplierName"))
                LblDeliveryCharges.Text = IIf(IsDBNull(tbl.Rows(0)("OtherCharges")), "", tbl.Rows(0)("OtherCharges"))
                LblPurchaseDate.Text = IIf(IsDBNull(tbl.Rows(0)("PurchaseDate")), "", tbl.Rows(0)("PurchaseDate"))
                LblReference.Text = IIf(IsDBNull(tbl.Rows(0)("Reference")), "", tbl.Rows(0)("Reference"))
                LblStockLocation.Text = IIf(IsDBNull(tbl.Rows(0)("StockLocation")), "", tbl.Rows(0)("StockLocation"))
                LblPurchaseInvoiceID.Text = "Purchase-Inv-" & IIf(IsDBNull(tbl.Rows(0)("PurchaseID")), "", tbl.Rows(0)("PurchaseID"))
            End If
            GrdProducts.DataSource = tbl
            GrdProducts.DataBind()
        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim LnkEditProduct As New System.Web.UI.WebControls.LinkButton
            LnkEditProduct = CType(e.Row.FindControl("LnkEditProduct"), LinkButton)
            If Not LnkEditProduct Is Nothing Then
                LnkEditProduct.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx?PID=" & drview("ArticleID") & "',$(window).height()*79/100,$(window).width()*72/100);return false"
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")

            _TotalAmount = _TotalAmount + ((drview("Quantity") * drview("PurchasePrice"))) - drview("Discount")
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalAmountLbl As New System.Web.UI.WebControls.Label
            Dim footerLblTotal As New System.Web.UI.WebControls.Label
            Dim footerLblGrossTotal As New System.Web.UI.WebControls.Label
            Dim footerLblOtherCharges As New System.Web.UI.WebControls.Label

            TotalAmountLbl = CType(e.Row.FindControl("TotalAmount"), Label)
            footerLblTotal = CType(e.Row.FindControl("lblTotal"), Label)
            footerLblGrossTotal = CType(e.Row.FindControl("LblGrossTotal"), Label)
            footerLblOtherCharges = CType(e.Row.FindControl("LblOtherCharges"), Label)


            If Not TotalAmountLbl Is Nothing Then
                TotalAmountLbl.Text = _TotalAmount
                footerLblTotal.Text = _TotalAmount
                footerLblOtherCharges.Text = Val(LblDeliveryCharges.Text)
                footerLblGrossTotal.Text = _TotalAmount + CSng(footerLblOtherCharges.Text)
            End If


        End If
    End Sub
End Class