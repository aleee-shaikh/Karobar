﻿Public Class PO_Print
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            lblPOReference.Text = ReferenceData.Setting("LblCashPaymentReference", "Reference", Session("CurrentBusinessID"))
            'LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
            LblPOParticular.Text = ReferenceData.Setting("LblPOParticular", "Remarks", Session("CurrentBusinessID"))
            'LblSalesPerson.Text = ReferenceData.Setting("LblSalesPerson", "Sales Person", Session("CurrentBusinessID"))
            LblPODate.Text = ReferenceData.Setting("LblPODate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Purchase Order", Session("CurrentBusinessID"))
            If Not Request("POID") Is Nothing Then
                hdnPOID.Value = Val(Request("POID"))
                LoadData()
            Else
                hdnPOID.Value = "0"
            End If
            Dim ds As New DataSet
            ds = WebSectionsBLL.GetSectionDetail(Session("CurrentBusinessID"), 6)
            If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0) Then
                LblPOParticular.Text = ds.Tables(0).Rows(0)("SectionDescription")
            End If
        End If
    End Sub

    Sub LoadData()
        If Val(hdnPOID.Value) > 0 Then
            Dim ds As New DataSet
            ds = POBLL.GetPODetailByID(Session("CurrentBusinessID"), hdnPOID.Value)
            If ds.Tables.Count > 1 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    lblOrderNo.Text = ds.Tables(0).Rows(0)("POID")
                    If IsDBNull(ds.Tables(0).Rows(0)("ReferenceNo")) = False Then
                        lblPOReference.Text = ds.Tables(0).Rows(0)("ReferenceNo")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("Remarks")) = False Then
                        LblPOParticular.Text = ds.Tables(0).Rows(0)("Remarks")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("Dated")) = False Then
                        LblPODate.Text = CMS.General.GetLocalDateTimeByTimeZone(ds.Tables(0).Rows(0)("Dated"), CMS.LoggedInUserSession.TimeZone)
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierID")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierID")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierName")) = False Then
                        lblSupplierName.Text = ds.Tables(0).Rows(0)("SupplierName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierAddress")) = False Then
                        lblSupplierAddress.Text = ds.Tables(0).Rows(0)("SupplierAddress")
                    End If


                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyName")) = False Then
                        lblCompanyName.Text = ds.Tables(0).Rows(0)("CompanyName")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("CompanyAddress")) = False Then
                        lblCompanyAddress.Text = ds.Tables(0).Rows(0)("CompanyAddress")
                    End If
                    GrdPODetails.DataSource = ds.Tables(1)
                    GrdPODetails.DataBind()
                End If
            End If
        End If
    End Sub
End Class