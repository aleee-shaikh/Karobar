﻿Public Class OrderDetails
    Inherits System.Web.UI.Page
    Dim _TotalAmount As Single
    Dim _TotalQuantity As Single

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''Dim BusinessDetailtbl As New DataTable
        '' BusinessDetailtbl = ChartOfAccount.GetBusinessDetails(Val(Session("CurrentBusinessID")))

        LblScreenTitle.Text = "Order Details"
        If Not Page.IsPostBack Then
            Dim ds As New DataSet

            ddlOrderStatus.DataSource = Products.GetOrderStatus(Val(Session("CurrentBusinessID")))
            ddlOrderStatus.DataTextField = "StatusName"
            ddlOrderStatus.DataValueField = "OrderStatusID"
            ddlOrderStatus.DataBind()

            If Not Request("PID") Is Nothing Then
                HdnProductID.Value = Val(Request("PID"))
            End If

            If (Not Request.QueryString("OID") Is Nothing) Then
                HdnOrderID.Value = Request.QueryString("OID")
                lnkGotoPOSScreen.Attributes.Add("href", "/WebsiteLayout.aspx?P=141&OID=" & CMS.Cryptography.Encrypt(HdnOrderID.Value))
                If (Val(HdnOrderID.Value) > 0) Then
                    ds = New DataSet
                    ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(HdnOrderID.Value))

                    If ds.Tables.Count > 0 Then

                        If ds.Tables(0).Rows.Count > 0 Then
                            'Distribution/ Wholesale, Store(Grocery, Phamacy, Garments, Mobile, Shoe), Hotel / Resturant, Store, Departmental Store
                            If LoggedInUserSession.BusinessCategoryID = 4 OrElse LoggedInUserSession.BusinessCategoryID = 13 OrElse LoggedInUserSession.BusinessCategoryID = 15 OrElse LoggedInUserSession.BusinessCategoryID = 16 OrElse LoggedInUserSession.BusinessCategoryID = 17 OrElse LoggedInUserSession.BusinessCategoryID = 18 Then

                                If IsDBNull(ds.Tables(0).Rows(0)("IsCompleted")) = False AndAlso ds.Tables(0).Rows(0)("IsCompleted") > 0 Then
                                    pnlAlreadyProceeded.Visible = True
                                    lnkGotoPOSScreen.Visible = False
                                End If

                                lnkVuOrder.NavigateUrl = "~/Modules/Karobar/Reports/POSSaleInvoice.aspx?SaleID=" & Val(ds.Tables(0).Rows(0)("IsCompleted"))
                                lnkVuOrder.Text = "View order invoice"
                            ElseIf (LoggedInUserSession.BusinessCategoryID = 4 AndAlso (IsDBNull(ds.Tables(0).Rows(0)("IsCompleted"))) OrElse Val(ds.Tables(0).Rows(0)("IsCompleted")) = 0) Then
                                lnkGotoPOSScreen.Visible = True
                                pnlAlreadyProceeded.Visible = False
                                lnkVuOrder.NavigateUrl = "~/Order.aspx?BID=" & Cryptography.Encrypt(LoggedInUserSession.BusinessID) & "&OID=" & Cryptography.Encrypt(HdnOrderID.Value)
                                lnkVuOrder.Text = "View booking invoice"
                            End If
                            'HdnProductID.Value = ds.Tables(1).Rows(0)("ProductID")

                            GrdOrderProducts.DataSource = ds.Tables(1)
                            GrdOrderProducts.DataBind()
                            If ds.Tables(0).Rows(0)("WebsiteID") = Session("CurrentBusinessID") Then
                                LblProductName.Text = IIf(IsDBNull(ds.Tables(1).Rows(0)("ArticleTitle")), "", ds.Tables(1).Rows(0)("ArticleTitle"))
                                LblAddress.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserAddress")), "", ds.Tables(0).Rows(0)("UserAddress"))
                                LblCity.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserCity")), "", ds.Tables(0).Rows(0)("UserCity"))
                                LblEmailAddress.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserEmail")), "", ds.Tables(0).Rows(0)("UserEmail"))
                                LblLandlineNo.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserLandLineNo")), "", ds.Tables(0).Rows(0)("UserLandLineNo"))
                                LblMessage.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("OrderMessage")), "", ds.Tables(0).Rows(0)("OrderMessage"))
                                LblMobile.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserMobileNo")), "", ds.Tables(0).Rows(0)("UserMobileNo"))
                                LblUserName.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("UserName")), "", ds.Tables(0).Rows(0)("UserName"))
                                LblPrice.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("OrderAmount")), "", ds.Tables(0).Rows(0)("OrderAmount"))
                                If (IsDBNull(ds.Tables(1).Rows(0)("ArticleImage")) = False AndAlso ds.Tables(1).Rows(0)("ArticleImage") <> "") Then
                                    Dim BusinessDirectory As String = "~/CMS/Product/Images"
                                    HdnProductImageFileName.Value = ds.Tables(1).Rows(0)("ArticleImage")
                                    ProductImage.ImageUrl = BusinessDirectory & "/" & ds.Tables(1).Rows(0)("ArticleImage")
                                    ProductImage.AlternateText = LblProductName.Text
                                End If

                                If (IsDBNull(ds.Tables(0).Rows(0)("Lat")) = False) Then
                                    txtLat.Text = ds.Tables(0).Rows(0)("Lat")
                                End If

                                If (IsDBNull(ds.Tables(0).Rows(0)("Lng")) = False) Then
                                    txtLng.Text = ds.Tables(0).Rows(0)("Lng")
                                End If

                                Try
                                    ddlOrderStatus.SelectedValue = ds.Tables(0).Rows(0)("OrderStatus")
                                Catch ex As Exception

                                End Try


                                GrdOrderHistory.DataSource = ds.Tables(2) 'Products.GetOrderHistory(Session("CurrentBusinessID"), Val(HdnOrderID.Value))
                                GrdOrderHistory.DataBind()
                            Else
                                ''If product is not related to current business
                                btnSave.Enabled = False
                                btnSave.Visible = False
                            End If
                        Else
                            ''if no product found
                            btnSave.Enabled = False
                            btnSave.Visible = False
                        End If
                    Else
                        ''if no product found
                        btnSave.Enabled = False
                        btnSave.Visible = False
                    End If
                Else
                    ''If invalid order id 
                    btnSave.Enabled = False
                    btnSave.Visible = False
                End If



                LnkOrderHistory.Text = LnkOrderHistory.Text + " (" & GrdOrderHistory.Rows.Count & ")"
            End If

            ''LoadData(Val(HdnProductID.Value))
        End If

    End Sub

    Sub LoadData(ByVal PID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Products.GetProductDetails(Session("CurrentBusinessID"), PID)
        If tbl.Rows.Count > 0 Then
            LblProductName.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleTitle")), "", tbl.Rows(0)("ArticleTitle"))
            If (IsDBNull(tbl.Rows(0)("ArticleImage")) = False AndAlso tbl.Rows(0)("ArticleImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Product/Images"
                HdnProductImageFileName.Value = tbl.Rows(0)("ArticleImage")
                ProductImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ArticleImage")
                ProductImage.AlternateText = LblProductName.Text
            End If

        End If
    End Sub

    Private Sub LnkOrderDetail_Click(sender As Object, e As EventArgs) Handles LnkOrderDetail.Click
        TblOrderHistory.Visible = False
        TblOrderDetail.Visible = True
        TblOrderLocationMap.Visible = False
    End Sub

    Private Sub LnkOrderHistory_Click(sender As Object, e As EventArgs) Handles LnkOrderHistory.Click
        TblOrderHistory.Visible = True
        TblOrderDetail.Visible = False
        TblOrderLocationMap.Visible = False
        GrdOrderHistory.DataSource = Products.GetOrderHistory(Session("CurrentBusinessID"), Val(HdnOrderID.Value))
        GrdOrderHistory.DataBind()
        LnkOrderHistory.Text = "Order History (" & GrdOrderHistory.Rows.Count & ")"
    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Products.AddOrderHistory(Session("CurrentBusinessID"), Val(HdnOrderID.Value), ddlOrderStatus.SelectedValue, txtRemarks.Text, Val(Session("UserID")))
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "OrderStatusDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Order status updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
    End Sub

    Private Sub LnkOrderLocation_Click(sender As Object, e As EventArgs) Handles LnkOrderLocation.Click
        TblOrderHistory.Visible = False
        TblOrderDetail.Visible = False
        TblOrderLocationMap.Visible = True

        ClientScript.RegisterClientScriptBlock(Me.GetType(), "initMap", "<script>initMap()</script>")

    End Sub

    Private Sub BtnSaveOrderLocation_Click(sender As Object, e As EventArgs) Handles BtnSaveOrderLocation.Click
        Products.UpdateOrderLocation(Session("CurrentBusinessID"), Val(HdnOrderID.Value), CSng(txtLat.Text), CSng(txtLng.Text))
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "OrderStatusDoneSuccessFully", "<script>parent.ShowMessage('Order location updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0');initMap();</script>")
    End Sub

    Private Sub GrdOrderProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdOrderProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then
            _TotalQuantity += (drview("ProductQuantity"))
            _TotalAmount += (drview("ProductPrice") * drview("ProductQuantity"))
            Dim LnkEdit As New LinkButton
            LnkEdit = CType(e.Row.FindControl("LnkEdit"), LinkButton)
            LnkEdit.Visible = Not pnlAlreadyProceeded.Visible

            If GrdOrderProducts.EditIndex = e.Row.RowIndex Then
                Dim LnkUpdate As LinkButton = CType(e.Row.FindControl("LnkUpdate"), LinkButton)
                ''Dim LnkEdit As LinkButton = CType(e.Row.FindControl("LnkEdit"), LinkButton)
                Dim LnkDeleteShift As LinkButton = CType(e.Row.FindControl("LnkDeleteShift"), LinkButton)
                Dim LnkCancelShift As LinkButton = CType(e.Row.FindControl("LnkCancel"), LinkButton)

                LnkUpdate.Visible = True
                LnkCancelShift.Visible = True
                ''LnkDeleteShift.Visible = False
                LnkEdit.Visible = False

            End If
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim lblTotalItems As New System.Web.UI.WebControls.Label
            Dim lblTotal As New System.Web.UI.WebControls.Label

            lblTotalItems = CType(e.Row.FindControl("lblTotalItems"), Label)
            lblTotal = CType(e.Row.FindControl("lblTotal"), Label)

            If Not lblTotal Is Nothing Then
                lblTotalItems.Text = _TotalQuantity
                lblTotal.Text = _TotalAmount
            End If
        End If
    End Sub

    Private Sub GrdOrderProducts_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdOrderProducts.RowEditing
        GrdOrderProducts.EditIndex = e.NewEditIndex
        'GrdOrderProducts.ShowFooter = False
        _TotalAmount = 0
        _TotalQuantity = 0
        GrdOrderProducts.DataBind()
        'LoadOrderProductsDetail()
    End Sub

    Private Sub GrdOrderProducts_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdOrderProducts.RowCommand
        If e.CommandName = "UpdateOrderDetail" Then
            Dim OrderDetailID As Integer = Val(CType(GrdOrderProducts.Rows(GrdOrderProducts.EditIndex).FindControl("HdnEditOrderDetailID"), HiddenField).Value)
            Dim ProductQuantity As Single = CSng("0" & CType(GrdOrderProducts.Rows(GrdOrderProducts.EditIndex).FindControl("txtEditProductQuantity"), TextBox).Text)
            Dim ProductUnit As String = CType(GrdOrderProducts.Rows(GrdOrderProducts.EditIndex).FindControl("HdnEditProductUnit"), HiddenField).Value
            Dim ProductPrice As Single = CType(GrdOrderProducts.Rows(GrdOrderProducts.EditIndex).FindControl("HdnEditProductPrice"), HiddenField).Value
            Dim ProductID As Integer = CType(GrdOrderProducts.Rows(GrdOrderProducts.EditIndex).FindControl("HdnEditProductID"), HiddenField).Value

            Products.UpdateOrderDetail(Session("CurrentBusinessID"), HdnOrderID.Value, OrderDetailID, ProductID, ProductPrice, ProductQuantity, ProductUnit)

            GrdOrderProducts.EditIndex = -1
        ElseIf e.CommandName = "UpdateCancel" Then
            GrdOrderProducts.EditIndex = -1
            'GrdOrderProducts.ShowFooter = True

            'ElseIf e.CommandName = "DeleteShift" Then
            '    Payroll.DeleteWorkingShift(Session("CurrentBusinessID"), e.CommandArgument)
            '    GrdOrderProducts.EditIndex = -1
            '    GrdOrderProducts.ShowFooter = True
        End If
        LoadOrderProductsDetail()
    End Sub

    Sub LoadOrderProductsDetail()
        Dim ds As New DataSet
        ds = Products.GetOrderDetails(Session("CurrentBusinessID"), Val(HdnOrderID.Value))
        GrdOrderProducts.DataSource = ds.Tables(1)
        GrdOrderProducts.DataBind()
    End Sub

End Class