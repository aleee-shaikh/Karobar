﻿Public Class POS
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If HttpContext.Current.Session("UserID") Is Nothing Then
                Log.WriteLog(-1, -1, "User Visited", "User Visited", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            End If
        End If
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        Dim sql As String
        Dim dbobj As New DBDAL
        Dim tbl As New DataTable
        Dim cmd As New SqlClient.SqlCommand

        Dim UserAccountFound As Boolean = False
        Dim UID As String = "-1"
        Dim UserName As String = ""
        Dim UserType As String = ""
        Dim UserStatus As String = ""

        'sql = "Select *from Users Where LoginID='" & LoginID.Text & "' and Password='" & Password.Text & "' and UserStatus='Active'"
        Try
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "AuthenticateUser"
            cmd.Parameters.AddWithValue("LoginID", LoginID.Text)
            cmd.Parameters.AddWithValue("Password", Password.Text)

            tbl = dbobj.GetDataTable(cmd)

            For i As Integer = 0 To tbl.Rows.Count - 1
                UserAccountFound = True
                UID = tbl.Rows(i)("UserID")
                Session("UserID") = UID
                Session("UserName") = tbl.Rows(0)("FirstName")
                Session("UserEmail") = tbl.Rows(i)("LoginID")
                Session("UserImage") = tbl.Rows(i)("ImageFilename")
            Next
        Catch ex As Exception

        End Try


        If UserAccountFound = False Then
            args.IsValid = False
            'Invalid Login attempt Log
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Invalid Login attempt", "Invalid Login[" & LoginID.Text.Replace("'", "~") & "~" & Password.Text.Replace("'", "~") & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        Else
            args.IsValid = True
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Successful Login", "Successful Login[" & LoginID.Text.Replace("'", "~") & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
                Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Business"))
            Else
                Response.Redirect(ReferenceData.Setting("StartPageURL4Others", "~/Business"))
            End If

        End If

    End Sub



End Class