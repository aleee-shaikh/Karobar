﻿Imports System.IO
Imports System.Drawing.Imaging
Imports System.Web
Imports System.Drawing
Imports System.Configuration


Public Class Image
    Inherits System.Web.UI.Page

    Private _missingImagePath As String

    Public Property MissingImagePath() As String
        Get
            Return "~/Images/missingimage.jpg" '_missingImagePath
        End Get
        Set(ByVal value As String)
            _missingImagePath = value
        End Set
    End Property

    ' T = Image type; 1=Photo, 3=Floorplan
    ' I = Image Filename
    ' W = Fit width
    ' H = Fit height
    ' R = Rotation. Valid values: 90, 180, 270
    ' C = Custom Image Path
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        

        Dim sType As String = HttpContext.Current.Request.QueryString("T")
        If sType = "" Then sType = "1"
        Dim iType As Integer = Integer.Parse(sType)
        Dim sPath As String '= GetTypePath(iType)
        sPath = ConfigurationManager.AppSettings("IM2FilePath") & iType.ToString()
        Dim ImageName As String = HttpContext.Current.Request.QueryString("I")
        ''Dim CustomPath As String = HttpContext.Current.Request.QueryString("C")
        Dim RealPath As String = ""
        ''RealPath = Server.MapPath(ResolveUrl(ImageName))
        If Not File.Exists(RealPath) Then RealPath = Server.MapPath(ResolveUrl("/Images/Notfound.png"))
        Dim iWidth As Integer = 0, sWidth As String = ""
        Dim iHeight As Integer = 0, sHeight As String = ""
        Dim scW As Double = 0
        Dim scH As Double = 0
        Dim scale As Double = 0

        Dim tbl As New DataTable
        tbl = WebsiteArticles.GetArticleByImageFileName(System.IO.Path.GetFileName(Server.MapPath(ImageName)))

        If tbl.Rows.Count > 0 Then
            Dim URL As String = ""
            URL = "~/" & tbl.Rows(0)("ArticleType") & "/" & tbl.Rows(0)("ArticleID") & "/" & tbl.Rows(0)("ArticleTitle")
            URL = General.Text.ReplaceCharsWith(URL, "@""$%#@!*;~`+()[]|\'<>,^", "")

            Response.Redirect(URL)
        End If

        
            sWidth = HttpContext.Current.Request.QueryString("W")
            sHeight = HttpContext.Current.Request.QueryString("H")
            If sWidth = "" And sHeight = "" Then
                sWidth = "450"
                sHeight = "480"
            End If
            If sWidth = "" Then sWidth = "100000"
            If sHeight = "" Then sHeight = "100000"
            iWidth = Integer.Parse(sWidth)
            iHeight = Integer.Parse(sHeight)

            Dim oBMP As New Bitmap(RealPath.ToString)

            scW = iWidth / oBMP.Width
            scH = iHeight / oBMP.Height
            If scW > scH Then scale = scH Else scale = scW ' Pick smaller of the two scales
            Dim iOutWidth As Integer = oBMP.Width * scale
            Dim iOutHeight As Integer = oBMP.Height * scale

            Dim Info As System.Drawing.Imaging.ImageCodecInfo() = System.Drawing.Imaging.ImageCodecInfo.GetImageEncoders()
            Dim Params As New System.Drawing.Imaging.EncoderParameters(1)
            Params.Param(0) = New EncoderParameter(Encoder.Quality, 100L)
            Response.ContentType = Info(1).MimeType

            Dim oBMPOut As New Bitmap(iOutWidth, iOutHeight, PixelFormat.Format32bppArgb)
            Dim oG As Graphics = Graphics.FromImage(oBMPOut)
            oG.InterpolationMode = Drawing2D.InterpolationMode.HighQualityBicubic
            oG.DrawImage(oBMP, -1, -1, iOutWidth + 1, iOutHeight + 1)
            oG.CompositingQuality = Drawing2D.CompositingQuality.HighQuality
            oG.SmoothingMode = Drawing2D.SmoothingMode.HighQuality
            oG.PixelOffsetMode = Drawing2D.PixelOffsetMode.HighQuality

            oG.Dispose()
            oBMP.Dispose()

            Select Case HttpContext.Current.Request.QueryString("R")
                Case 90
                    oBMPOut.RotateFlip(RotateFlipType.Rotate90FlipNone)
                Case 180
                    oBMPOut.RotateFlip(RotateFlipType.Rotate180FlipNone)
                Case 270
                    oBMPOut.RotateFlip(RotateFlipType.Rotate270FlipNone)
            End Select

            Response.ContentType = "image/jpeg"
            Dim oMS As New MemoryStream
            oBMPOut.Save(oMS, Info(1), Params)
            oMS.WriteTo(Response.OutputStream)
            oBMPOut.Dispose()




        
        
    End Sub

End Class