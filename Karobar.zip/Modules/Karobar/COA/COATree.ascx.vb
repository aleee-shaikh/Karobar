﻿Public Class COATree
    Inherits System.Web.UI.UserControl
    Dim _COAID As Integer = -1

    Public Property AccountHeadID() As Integer
        Get
            Return _COAID
        End Get
        Set(value As Integer)
            _COAID = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Sub LoadData()
        GrdCOATree.DataSource = ChartOfAccount.GetCOA(LoggedInUserSession.BusinessID, ParentAccountHeadID:=-1)
        GrdCOATree.DataBind()
    End Sub

    Private Sub GrdCOATree_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdCOATree.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim ChildHeads1 As New GridView
            ChildHeads1 = CType(e.Row.FindControl("ChildHeads1"), GridView)
            AddHandler ChildHeads1.RowDataBound, AddressOf ChildHeads1_DataBound
            Dim tbl As New DataTable
            tbl = ChartOfAccount.GetCOA(LoggedInUserSession.BusinessID, ParentAccountHeadID:=drview("AccountHeadID"))
            ChildHeads1.DataSource = tbl
            ChildHeads1.DataBind()

            'e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            'e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub ChildHeads1_DataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim ChildHeads2 As New GridView
            ChildHeads2 = CType(e.Row.FindControl("ChildHeads2"), GridView)
            AddHandler ChildHeads2.RowDataBound, AddressOf ChildHeads2_DataBound
            Dim tbl As New DataTable
            tbl = ChartOfAccount.GetCOA(LoggedInUserSession.BusinessID, ParentAccountHeadID:=drview("AccountHeadID"))
            ChildHeads2.DataSource = tbl
            ChildHeads2.DataBind()

            'e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            'e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub ChildHeads2_DataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim ChildHeads3 As New GridView
            ChildHeads3 = CType(e.Row.FindControl("ChildHeads3"), GridView)
            AddHandler ChildHeads3.RowDataBound, AddressOf ChildHeads3_DataBound
            Dim tbl As New DataTable
            tbl = ChartOfAccount.GetCOA(LoggedInUserSession.BusinessID, ParentAccountHeadID:=drview("AccountHeadID"))
            ChildHeads3.DataSource = tbl
            ChildHeads3.DataBind()

            'e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            'e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub


    Private Sub ChildHeads3_DataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim AccountHeadEditLnkBtn As New System.Web.UI.WebControls.LinkButton
            AccountHeadEditLnkBtn = CType(e.Row.FindControl("LnkEditAccountHead"), LinkButton)
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            If Not AccountHeadEditLnkBtn Is Nothing Then
                AccountHeadEditLnkBtn.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/COA/COA.aspx?AHID=" & drview("AccountHeadID") & "',$(window).height()*58/100,$(window).width()*47/100);return false"
            End If

            Dim LnkOpeningBalance As New LinkButton
            LnkOpeningBalance = CType(e.Row.FindControl("LnkAddOpeningBalance"), LinkButton)
            If Not LnkOpeningBalance Is Nothing Then
                LnkOpeningBalance.OnClientClick = "$('#" & txtOpeningBalanceAmount.ClientID & "').val('" & drview("OpeningBalance") & "');$('#" & HdnSelectedAccountHeadID.ClientID & "').val('" & drview("AccountHeadID") & "');return ShowDlg('DlgAccountOpeningBalance');"
            End If

            'e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            'e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Try
            ChartOfAccount.AddUpdateOpeningBalance(Val(Session("CurrentBusinessID")), Val(HdnSelectedAccountHeadID.Value), Val(txtOpeningBalanceAmount.Text))
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Opening Balance", "Opening Balance : " & HdnSelectedAccountHeadID.Value, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, -1)
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "OpeningBalanceDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Opening Balance done successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
            LoadData()

            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Account Head Opening Balance Updated", HdnSelectedAccountHeadID.Value & ": Account Head Opening Balance Updated", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)

        Catch ex As Exception
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "UpdateOpeningBalanceIssue", "<script>parent.ShowMessage('Unable to process opening balance','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub
End Class