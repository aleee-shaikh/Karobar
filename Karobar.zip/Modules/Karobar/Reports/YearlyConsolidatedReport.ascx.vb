﻿Public Class YearlyConsolidatedReport
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            'txtTransactionFromDate.Text = Now.ToString("dd-MM-yyyy")
            'txtTransactionToDate.Text = Now.ToString("dd-MM-yyyy")
            For i As Integer = 0 To 50
                DDLYears.Items.Add(New ListItem(Now.Year - i, Now.Year - i))
            Next
            LblSelectedYear.Text = Now.Year
            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim tbl As New DataTable
        Dim Sale(12) As Single
        Dim Purchase(12) As Single
        Dim Expenses(12) As Single
        Dim TotalSale As Single
        Dim TotalPurchase As Single
        Dim TotalExpenses As Single
        Dim ExpenseHeadID As Integer
        ExpenseHeadID = ReferenceData.Setting("ExpenseHeadID", "", Session("CurrentBusinessID"))

        Dim Saletr As New HtmlTableRow
        Dim Saletd As New HtmlTableCell
        Saletd.InnerHtml = "<b>Sale</b>"

        Dim Purchasetr As New HtmlTableRow
        Dim Purchasetd As New HtmlTableCell
        Purchasetd.InnerHtml = "<b>Purchase</b>"

        Dim Expensestr As New HtmlTableRow
        Dim Expensestd As New HtmlTableCell
        Expensestd.InnerHtml = "<b>Expenses</b>"

        Purchasetr.Cells.Add(Purchasetd)
        Saletr.Cells.Add(Saletd)
        Expensestr.Cells.Add(Expensestd)
        For i As Integer = 1 To 12
            tbl = New DataTable
            tbl = Products.SaleReport(Session("CurrentBusinessID"), -1, -1, "", IIf(i <= 9, "0" & i, i) & "-01-" & DDLYears.SelectedItem.Value & " 00:00:00 AM", CDate(IIf(i <= 9, "0" & i, i) & "-" & Now.DaysInMonth(DDLYears.SelectedItem.Value, i) & "-" & DDLYears.SelectedItem.Value) & " 23:59:59 PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                Sale(i - 1) = Sale(i - 1) + ((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount"))
            Next
            Saletd = New HtmlTableCell
            Saletd.ID = "Sale" & i
            Saletd.Align = "Center"
            Saletd.InnerText = Sale(i - 1)
            Saletr.Cells.Add(Saletd)
            TotalSale = TotalSale + Sale(i - 1)

            tbl = New DataTable
            tbl = Products.PurchaseReport(Session("CurrentBusinessID"), -1, -1, "", IIf(i <= 9, "0" & i, i) & "-01-" & DDLYears.SelectedItem.Value & " 00:00:00 AM", CDate(IIf(i <= 9, "0" & i, i) & "-" & Now.DaysInMonth(DDLYears.SelectedItem.Value, i) & "-" & DDLYears.SelectedItem.Value) & " 23:59:59 PM")
            For j As Integer = 0 To tbl.Rows.Count - 1
                Purchase(i - 1) = Purchase(i - 1) + ((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount"))
            Next
            Purchasetd = New HtmlTableCell
            Purchasetd.ID = "Purchase" & i
            Purchasetd.Align = "Center"
            Purchasetd.InnerText = Purchase(i - 1)
            Purchasetr.Cells.Add(Purchasetd)
            TotalPurchase = TotalPurchase + Purchase(i - 1)


            tbl = New DataTable
            tbl = ChartOfAccount.GetExpensesSummary(Session("CurrentBusinessID"), ExpenseHeadID, IIf(i <= 9, "0" & i, i) & "-01-" & DDLYears.SelectedItem.Value, CDate(IIf(i <= 9, "0" & i, i) & "-" & Now.DaysInMonth(DDLYears.SelectedItem.Value, i) & "-" & DDLYears.SelectedItem.Value))
            For j As Integer = 0 To tbl.Rows.Count - 1
                Expenses(i - 1) = Expenses(i - 1) + tbl.Rows(j)("Debit")
            Next
            Expensestd = New HtmlTableCell
            Expensestd.ID = "Expense" & i
            Expensestd.Align = "Center"
            Expensestd.InnerText = Expenses(i - 1)
            Expensestr.Cells.Add(Expensestd)
            TotalExpenses = TotalExpenses + Expenses(i - 1)
        Next

        Saletd = New HtmlTableCell
        Saletd.Align = "Center"
        Saletd.InnerText = TotalSale
        Saletr.Cells.Add(Saletd)

        Purchasetd = New HtmlTableCell
        Purchasetd.Align = "Center"
        Purchasetd.InnerText = TotalPurchase
        Purchasetr.Cells.Add(Purchasetd)

        Expensestd = New HtmlTableCell
        Expensestd.Align = "Center"
        Expensestd.InnerText = TotalExpenses
        Expensestr.Cells.Add(Expensestd)

        
        TblConsolidatedReport.Rows.Add(Purchasetr)
        TblConsolidatedReport.Rows.Add(Saletr)
        TblConsolidatedReport.Rows.Add(Expensestr)
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    
    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open yearly consolidated report", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
    End Sub
End Class