﻿Public Class UploadDocHistory
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer
    Dim _UploadDocumentPath As String

    Public Property EmployeeID() As Integer
        Get
            Return Val(HdnEmployeeID.Value)
        End Get
        Set(value As Integer)
            HdnEmployeeID.Value = value
            _EmployeeID = value
        End Set
    End Property

    Public Property UploadDocumentPath() As String
        Get
            Return HdnUploadDocumentPath.Value
        End Get
        Set(value As String)
            HdnUploadDocumentPath.Value = value
            _UploadDocumentPath = value
        End Set
    End Property

    Public Property DocumentTypeID() As Integer
        Get
            Return HdnDocumentType.Value
        End Get
        Set(value As Integer)
            HdnDocumentType.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
            'If GrdDocumentHistory.Rows.Count > 0 Then
            '    GrdDocumentHistory.Columns(5).Visible = True
            '    GrdDocumentHistory.Columns(6).Visible = True
            '    GrdDocumentHistory.Columns(7).Visible = False
            'Else
            '    GrdDocumentHistory.Columns(5).Visible = False
            '    GrdDocumentHistory.Columns(6).Visible = False
            '    GrdDocumentHistory.Columns(7).Visible = True
            'End If
        End If

    End Sub

    Private Sub GrdDocumentHistory_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdDocumentHistory.RowCommand
        If e.CommandName = "AddNewDocumentHistory" Then
            GrdDocumentHistory.ShowFooter = True

        ElseIf e.CommandName = "SaveNewDocumentHistory" Then
            Dim Subject As String = CType(GrdDocumentHistory.FooterRow.FindControl("txtSubject"), TextBox).Text
            Dim Description As String = CType(GrdDocumentHistory.FooterRow.FindControl("txtDescription"), TextBox).Text
            Dim File As String = Guid.NewGuid.ToString & System.IO.Path.GetExtension(CType(GrdDocumentHistory.FooterRow.FindControl("FileUploadEditDocument"), FileUpload).PostedFile.FileName)
            Dim Size As Integer = 0 ''(CType(GrdDocumentHistory.FooterRow.FindControl("FileUploadEditDocument"), FileUpload).PostedFile.FileName)
            Dim FileUploadDocument As New FileUpload
            FileUploadDocument = CType(GrdDocumentHistory.FooterRow.FindControl("FileUploadEditDocument"), FileUpload)
            If FileUploadDocument.PostedFile.FileName <> "" Then
                ''File = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadStaffImage.PostedFile.FileName)
                Dim BusinessDirectory As String = Server.MapPath(UploadDocumentPath) & "Docs"
                Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
                If dinfo.Exists() = False Then
                    System.IO.Directory.CreateDirectory(BusinessDirectory)
                End If

                FileUploadDocument.SaveAs(BusinessDirectory & "/" & File)
            End If
            If (DocumentTypeID = 0) Then
                Payroll.AddEmployeeDocument(EmployeeID, Subject, Description, File, Size, Payroll.DocumentTypes.EmployeeDocuments)
            Else
                Payroll.AddEmployeeDocument(EmployeeID, Subject, Description, File, Size, DocumentTypeID)
            End If

            GrdDocumentHistory.ShowFooter = False
            'GrdDocumentHistory.Columns(5).Visible = True
            'GrdDocumentHistory.Columns(6).Visible = True
            'GrdDocumentHistory.Columns(7).Visible = False
        ElseIf e.CommandName = "DeleteDocumentHistory" Then
            Payroll.DeleteEmployeeDocument(Val(e.CommandArgument))
        ElseIf e.CommandName = "Insert" Then

        ElseIf e.CommandName = "Cancel" Then
            GrdDocumentHistory.ShowFooter = False
            GrdDocumentHistory.EditIndex = -1
            'GrdDocumentHistory.Columns(5).Visible = True
            'GrdDocumentHistory.Columns(6).Visible = True
            'GrdDocumentHistory.Columns(7).Visible = False

        ElseIf e.CommandName = "Edit" Then
            'GrdDocumentHistory.Columns(5).Visible = True
            'GrdDocumentHistory.Columns(6).Visible = True
            'GrdDocumentHistory.Columns(7).Visible = False
        ElseIf e.CommandName = "Update" Then

        End If
        LoadData()

    End Sub

    Sub LoadData()
        If DocumentTypeID = 0 Then
            GrdDocumentHistory.DataSource = Payroll.GetEmployeeDocumentHistory(EmployeeID, Payroll.DocumentTypes.EmployeeDocuments)
        Else
            GrdDocumentHistory.DataSource = Payroll.GetEmployeeDocumentHistory(EmployeeID, DocumentTypeID)
        End If

        GrdDocumentHistory.DataBind()
    End Sub

    Private Sub LnkAddEmpDocumentHistory_Click(sender As Object, e As EventArgs) Handles LnkAddEmpDocumentHistory.Click
        GrdDocumentHistory.ShowFooter = True
        Dim tbl As New DataTable
        Dim row As DataRow

        tbl = Payroll.GetEmployeeDocumentHistory(EmployeeID)
        If tbl.Rows.Count = 0 Then
            row = tbl.NewRow
            tbl.Rows.InsertAt(row, 0)
        End If
        'GrdDocumentHistory.Columns(5).Visible = False
        'GrdDocumentHistory.Columns(6).Visible = False
        'GrdDocumentHistory.Columns(7).Visible = True
        GrdDocumentHistory.DataSource = tbl
        GrdDocumentHistory.DataBind()
    End Sub

    Private Sub GrdDocumentHistory_DataBound(sender As Object, e As EventArgs) Handles GrdDocumentHistory.DataBound

    End Sub

    Private Sub GrdDocumentHistory_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdDocumentHistory.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

        End If
    End Sub

    Private Sub GrdDocumentHistory_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdDocumentHistory.RowUpdating

    End Sub

    Private Sub GrdDocumentHistory_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdDocumentHistory.RowCancelingEdit

    End Sub

    Private Sub GrdDocumentHistory_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdDocumentHistory.RowEditing
        GrdDocumentHistory.EditIndex = e.NewEditIndex
        GrdDocumentHistory.DataBind()
    End Sub
End Class