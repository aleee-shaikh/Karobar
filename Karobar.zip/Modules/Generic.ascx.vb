﻿Public Class Generic
    Inherits System.Web.UI.UserControl
    Dim _ModuleID As Integer
    Dim _TemplatesPath As String = ""

    Public Property ModuleID() As Integer
        Get
            Return _ModuleID
        End Get
        Set(ByVal value As Integer)
            _ModuleID = value
        End Set
    End Property

    
    Public Property TemplatePath() As String
        Get
            _TemplatesPath = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "TemplatesPath")
            If _TemplatesPath = "" Then
                _TemplatesPath = Website.WebsiteID & "/Templates"
            End If
            Return _TemplatesPath
        End Get
        Set(ByVal value As String)
            
        End Set
    End Property


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'ModuleScripts :   file1.js,file2.js
        

        Try
            Dim ModuleScripts() As String = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "ModuleScripts").Split(";")
            Dim FileName As String
            For Each itm As String In ModuleScripts
                FileName = CMS.ReferenceData.Setting("JSScriptsPath", "/Modules/Scripts") & "/" & itm
                If itm <> "" AndAlso System.IO.File.Exists(Server.MapPath(FileName)) Then
                    Page.ClientScript.RegisterClientScriptInclude(itm.Split(".")(0), FileName)
                End If
            Next

            ''If CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "ShowTitle") Then ModuleTitle.Text = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "Title")
            Template.Value = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "Template")
            JsFunctionName.Value = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "JsFunctionName")
            JsFunctionParameters.Value = CMS.Website.Page.Layout.Section.Modules.GetModuleSettingValue(ModuleID, "JsFunctionParameters")
            If (Template.Value = String.Empty) Then
                Template.Value = "DefaultTemplate"
            End If
            PageSize.Value = Val(Website.Modules.GetModuleSettingValue(ModuleID, "PageSize"))
            If Page.IsPostBack = False Then
                PageNo.Value = 1
            End If
            WebsiteID.Value = Website.WebsiteID
            UserEmail.Value = HttpContext.Current.Session("UserEmail")
            UserName.Value = HttpContext.Current.Session("UserName")
            UserID.Value = HttpContext.Current.Session("UserID")
            MyID.Value = Me.ClientID
        Catch ex As Exception

        End Try
    End Sub
End Class