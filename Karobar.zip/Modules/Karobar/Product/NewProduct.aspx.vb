﻿Imports System.IO
Imports SD = System.Drawing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing

Public Class NewProduct
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 51) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If
        Dim BusinessDetailtbl As New DataTable
        BusinessDetailtbl = ChartOfAccount.GetBusinessDetails(Val(Session("CurrentBusinessID")))

        If (BusinessDetailtbl.Rows(0)("CategoryTitle").ToString().ToLower().IndexOf("job ") >= 0) Or (Not Session("CurrentBusinessCategoryID") Is Nothing AndAlso Val(Session("CurrentBusinessCategoryID")) = 5) Then
            trProductBarcode.Visible = False
            trProductPriceRow.Visible = False
            trProductUnitSizeColor.Visible = False
            FileUploadProductImage1.Visible = False
            FileUploadProductImage2.Visible = False
            FileUploadProductImage3.Visible = False
            FileUploadProductImage4.Visible = False
            FileUploadProductImage5.Visible = False
            FileUploadProductImage6.Visible = False
            FileUploadProductImage7.Visible = False
            DivMinAlertQty.Visible = False
            ParentProduct.Visible = False
            DivPromptPriceOnSale.Visible = False
            txtDescription.Height = 160
        End If

        If Not Page.IsPostBack Then
            Dim RetVlu As String = ""
            pnlHeaderLnks.Visible = (ReferenceData.Setting("RequiredProductSaleMapping", "No", Session("CurrentBusinessID")) = "Yes")

            LblProductName.Text = ReferenceData.Setting("LblProductName", "Product Name", Session("CurrentBusinessID"))
            LblCategory.Text = ReferenceData.Setting("LblProductCategory", "Category", Session("CurrentBusinessID"))
            LblSubCategory.Text = ReferenceData.Setting("LblProductSubCategory", "Sub Category", Session("CurrentBusinessID"))
            LblModel.Text = ReferenceData.Setting("LblProductModel", "Model", Session("CurrentBusinessID"))
            LblManufacturer.Text = ReferenceData.Setting("LblProductManufacturer", "Manufacturer", Session("CurrentBusinessID"))
            LblPurchasePrice.Text = ReferenceData.Setting("LblProductPurchasePrice", "Purchase Price", Session("CurrentBusinessID"))
            LblTax.Text = ReferenceData.Setting("LblProductTax", "Tax", Session("CurrentBusinessID"))

            LblOthers.Text = ReferenceData.Setting("LblProductOthers", "Others", Session("CurrentBusinessID"))
            ChkPromptPriceOnSale.Text = ReferenceData.Setting("LblProductPromptPriceOnSale", "Prompt price on sale", Session("CurrentBusinessID"))
            LblSalePrice.Text = ReferenceData.Setting("LblProductSalePrice", "Sale Price", Session("CurrentBusinessID"))

            LblUnit.Text = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))

            LblSize.Text = ReferenceData.Setting("LblProductSize", "Size", Session("CurrentBusinessID"))

            LblWeight.Text = ReferenceData.Setting("LblProductWeight", "Weight", Session("CurrentBusinessID"))

            LblColor.Text = ReferenceData.Setting("LblProductColor", "Color", Session("CurrentBusinessID"))

            LblBarCode.Text = ReferenceData.Setting("LblProductBarcode", "BarCode", Session("CurrentBusinessID"))
            LblDescription.Text = ReferenceData.Setting("LblProductDescription", "Description", Session("CurrentBusinessID"))
            LblMinAlertQty.Text = ReferenceData.Setting("LblMinAlertQty", "Min Alert Qty", Session("CurrentBusinessID"))

            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
            DDLProductCatagory.DataValueField = "ArticleTypeID"
            DDLProductCatagory.DataTextField = "ArticleType"
            DDLProductCatagory.DataSource = ds.Tables(0)
            DDLProductCatagory.DataBind()

            ''DDLProductCatagory.SelectedValue = Val(Website.GetWebsiteDetailColumn(Session("CurrentBusinessID"), "WebsiteCategoryID"))
            Dim SubCID As Integer = -1

            If DDLProductSubCatagory.Items.Count > 0 Then
                SubCID = DDLProductSubCatagory.SelectedItem.Value
            End If
            If SubCID = -1 Then
                If DDLProductCatagory.Items.Count > 0 Then
                    SubCID = DDLProductCatagory.SelectedItem.Value
                End If
            End If

            LoadProductSubCatagoriesAndUnits(SubCID)
            If Not Request("PID") Is Nothing Then
                HdnProductID.Value = Val(Request("PID"))
            Else

            End If

            LoadParentProducts(Val(HdnProductID.Value))

            If Val(HdnProductID.Value) > 0 Then
                LoadData(Val(HdnProductID.Value))
            End If


        End If
        If Val(HdnProductID.Value) <= 0 Then
            LblScreenTitle.Text = "Create New Product"
            'LnkFbShare.Visible = False
            ProductImage.ImageUrl = "~/Images/No-Image.png"
        Else
            LblScreenTitle.Text = "Update Product"
            If Val(HdnProductID.Value) > 0 Then
                LoadData(Val(HdnProductID.Value))
            End If
        End If
        If Val(HdnProductID.Value) > 0 Then
            'LnkFbShare.Visible = True
            'LnkFbShare.Attributes.Add("onclick", "window.open('https://www.facebook.com/sharer/sharer.php?u=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID=" & Val(HdnProductID.Value) & "','', 'toolbar=0,status=0,width=548,height=325');")
            'LnkFbShare.Visible = True


        Else
            'LnkFbShare.Visible = False
        End If
    End Sub

    Sub LoadParentProducts(ProductID As Integer)
        Dim ds As New DataSet
        ds = Products.GetParentProducts(Session("CurrentBusinessID"), 0, ProductID)
        DDLParentProduct.DataTextField = "ArticleTitle"
        DDLParentProduct.DataValueField = "ArticleID"
        DDLParentProduct.DataSource = ds
        DDLParentProduct.DataBind()
        DDLParentProduct.Items.Insert(0, New ListItem("None", "0"))
    End Sub

    Sub LoadData(ByVal PID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Products.GetProductDetails(Session("CurrentBusinessID"), PID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
            If ds.Tables(0).Rows.Count > 0 Then
                If (ds.Tables(1).Rows.Count > 0) Then
                    ProductImages1.Visible = True
                    pnlImageUploaders.Visible = False
                    ProductImages1.ProductID = PID
                    ProductImages1.LoadData()
                End If
            Else
                BtnSave.Visible = False
                BtnSave.Enabled = False
            End If
        End If
        If tbl.Rows.Count > 0 Then
            txtProductName.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleTitle")), "", tbl.Rows(0)("ArticleTitle"))
            txtModel.Text = IIf(IsDBNull(tbl.Rows(0)("Model")), "", tbl.Rows(0)("Model"))
            txtManufacturer.Text = IIf(IsDBNull(tbl.Rows(0)("Manufacturer")), "", tbl.Rows(0)("Manufacturer"))
            txtPurchasePrice.Text = IIf(IsDBNull(tbl.Rows(0)("PurchasePrice")), "", tbl.Rows(0)("PurchasePrice"))
            txtTax.Text = IIf(IsDBNull(tbl.Rows(0)("Tax")), "", tbl.Rows(0)("Tax"))
            txtOthers.Text = IIf(IsDBNull(tbl.Rows(0)("OtherCharges")), "", tbl.Rows(0)("OtherCharges"))
            txtSalePrice.Text = IIf(IsDBNull(tbl.Rows(0)("SalePrice")), "", tbl.Rows(0)("SalePrice"))
            txtSize.Text = IIf(IsDBNull(tbl.Rows(0)("Size")), "", tbl.Rows(0)("Size"))
            txtWeight.Text = IIf(IsDBNull(tbl.Rows(0)("Weight")), "", tbl.Rows(0)("Weight"))
            txtColor.Text = IIf(IsDBNull(tbl.Rows(0)("Color")), "", tbl.Rows(0)("Color"))
            txtBarCode.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleBarcode")), "", tbl.Rows(0)("ArticleBarcode"))
            txtDescription.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleText")), "", tbl.Rows(0)("ArticleText"))
            DDLProductCatagory.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("ArticleTypeID")), "", tbl.Rows(0)("ArticleTypeID"))
            LoadProductSubCatagoriesAndUnits(DDLProductCatagory.SelectedItem.Value)
            DDLProductSubCatagory.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("ArticleCatagory")), "", tbl.Rows(0)("ArticleCatagory"))
            DDLUnit.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Unit")), "", tbl.Rows(0)("Unit"))
            ChkFeatured.Checked = IIf(IsDBNull(tbl.Rows(0)("Featured")) = True OrElse tbl.Rows(0)("Featured") = False, False, True)
            ChkPromptPriceOnSale.Checked = IIf(IsDBNull(tbl.Rows(0)("Prompt4PriceOnSale")) = True OrElse tbl.Rows(0)("Prompt4PriceOnSale") = False, False, True)
            txtMinAlertQty.Text = IIf(IsDBNull(tbl.Rows(0)("MinAlertQty")), "0", tbl.Rows(0)("MinAlertQty"))

            If (IsDBNull(tbl.Rows(0)("ArticleImage")) = False AndAlso tbl.Rows(0)("ArticleImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Product/Images"
                HdnProductImageFileName.Value = tbl.Rows(0)("ArticleImage")
                ProductImage.ImageUrl = BusinessDirectory & "/Thumbnail_" & tbl.Rows(0)("ArticleImage")
                ProductImage.AlternateText = txtProductName.Text
            Else
                ProductImage.ImageUrl = "~/Images/No-Image.png"
            End If
            Dim ParentProductID As Integer = 0
            If (IsDBNull(ds.Tables(0).Rows(0)("ParentArticleID")) = False AndAlso Val(ds.Tables(0).Rows(0)("ParentArticleID")) > 0) Then
                ParentProductID = Val(ds.Tables(0).Rows(0)("ParentArticleID"))
            End If
            If Not DDLParentProduct.Items.FindByValue(ParentProductID) Is Nothing Then
                DDLParentProduct.SelectedValue = ParentProductID
            End If

            If pnlHeaderLnks.Visible Then
                Dim mappingDS As New DataSet
                mappingDS = WebsiteArticles.GetProductMapping(Session("CurrentBusinessID"), Val(HdnProductID.Value), -1)
                Dim BuyProducts As String = ""
                Dim GetProducts As String = ""
                Dim BuyProductsDtls As String = ""
                Dim GetProductsDtls As String = ""

                For i As Integer = 0 To mappingDS.Tables(1).Rows.Count - 1
                    BuyProducts = BuyProducts & mappingDS.Tables(1).Rows(i)("ProductID") & ";"
                    BuyProductsDtls = BuyProductsDtls & mappingDS.Tables(1).Rows(i)("ProductID") & "|" & mappingDS.Tables(1).Rows(i)("Qty") & ";"
                Next

                If mappingDS.Tables(0).Rows.Count > 0 Then
                    txtOfferDiscount.Text = mappingDS.Tables(0).Rows(0)("Discount")
                End If
                HdnBuyProductsSelected.Value = BuyProducts
                HdnBuyProductDtls.Value = BuyProductsDtls

                For i As Integer = 0 To mappingDS.Tables(2).Rows.Count - 1
                    GetProducts = GetProducts & mappingDS.Tables(2).Rows(i)("ProductID") & ";"
                    GetProductsDtls = GetProductsDtls & mappingDS.Tables(2).Rows(i)("ProductID") & "|" & mappingDS.Tables(2).Rows(i)("Qty") & ";"
                Next
                HdnGetProductsSelected.Value = GetProducts
                HdnGetProductDtls.Value = GetProductsDtls

                If mappingDS.Tables(0).Rows.Count > 0 Then
                    DDLSaleMappingType.SelectedValue = mappingDS.Tables(0).Rows(0)("SaleTypeID")
                    DDLSaleMappingType_SelectedIndexChanged(DDLSaleMappingType, Nothing)
                End If
                Dim ProductTbl As New DataTable
                ProductTbl = Products.GetProductsList(Session("CurrentBusinessID"))

                GrdBuyProducts.DataSource = ProductTbl
                GrdBuyProducts.DataBind()

                grdGetProducts.DataSource = ProductTbl
                grdGetProducts.DataBind()
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim ProductImageFilename As String = HdnProductImageFileName.Value
        Dim SubCID As Integer = -1
        Dim Unit As Integer = -1
        Dim PID As Integer
        Dim Discount As Single = 0
        Dim SalePrice As Single = 0

        If DDLProductSubCatagory.Items.Count > 0 Then
            SubCID = DDLProductSubCatagory.SelectedItem.Value
        End If
        If DDLUnit.Items.Count > 0 Then
            Unit = DDLUnit.SelectedItem.Value
        End If


        'If FileUploadProductImage.PostedFile.FileName <> "" AndAlso FileUploadProductImage.PostedFile.FileName <> ProductImageFilename Then
        '    ProductImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadProductImage.PostedFile.FileName)
        '    Dim BusinessDirectory As String = Server.MapPath("~/CMS/Product/") & "/Images"
        '    Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
        '    If dinfo.Exists() = False Then
        '        System.IO.Directory.CreateDirectory(BusinessDirectory)
        '    End If

        '    FileUploadProductImage.SaveAs(BusinessDirectory & "/" & ProductImageFilename)
        'End If



        If Val(HdnProductID.Value) > 0 Then
            HdnProductImageFileName.Value = SaveArticleImage(Val(HdnProductID.Value), FileUploadProductImage)
            ProductImageFilename = HdnProductImageFileName.Value
            tbl = Products.UpdateProduct(Session("CurrentBusinessID"), Val(HdnProductID.Value), DDLProductCatagory.SelectedItem.Value, SubCID, txtBarCode.Text.Trim,
                                   txtProductName.Text.Trim, txtDescription.Text.Trim, ProductImageFilename, txtModel.Text.Trim, txtManufacturer.Text.Trim,
                                   Val(txtPurchasePrice.Text.Trim), Val(txtTax.Text.Trim), Val(txtOthers.Text.Trim), Val(txtSalePrice.Text.Trim), Unit,
                                    txtSize.Text.Trim, txtWeight.Text.Trim, txtColor.Text.Trim, HttpContext.Current.Session("UserID"), 1, txtDescription.Text.Trim, "", ChkFeatured.Checked, DDLParentProduct.SelectedValue, ChkPromptPriceOnSale.Checked, Val(txtMinAlertQty.Text))
            PID = Val(HdnProductID.Value)
            If tbl.Rows.Count > 0 Then
                'SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage1)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage2)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage3)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage4)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage5)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage6)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage7)
            End If

            If tbl.Rows.Count > 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductUpdateSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Product updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Updated Product " & txtProductName.Text.Trim, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=PID)
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductUpdateIssue", "<script>parent.ShowMessage('Unable to update Product','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        Else

            tbl = Products.AddProduct(Session("CurrentBusinessID"), DDLProductCatagory.SelectedItem.Value, SubCID, txtBarCode.Text.Trim,
                                   txtProductName.Text.Trim, txtDescription.Text.Trim, ProductImageFilename, txtModel.Text.Trim, txtManufacturer.Text.Trim,
                                   Val(txtPurchasePrice.Text.Trim), Val(txtTax.Text.Trim), Val(txtOthers.Text.Trim), Val(txtSalePrice.Text.Trim), Unit,
                                    txtSize.Text.Trim, txtWeight.Text.Trim, txtColor.Text.Trim, HttpContext.Current.Session("UserID"), 1, txtDescription.Text.Trim, "", ChkFeatured.Checked, DDLParentProduct.SelectedValue, ChkPromptPriceOnSale.Checked, Val(txtMinAlertQty.Text))

            If tbl.Rows.Count > 0 Then
                PID = tbl.Rows(0)("ArticleID")
                'SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage)
                HdnProductImageFileName.Value = SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage, True)
                ProductImageFilename = HdnProductImageFileName.Value
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage1)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage2)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage3)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage4)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage5)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage6)
                SaveArticleImage(tbl.Rows(0)("ArticleID"), FileUploadProductImage7)
            End If

            If tbl.Rows.Count > 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Product added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Added New Product " & txtProductName.Text.Trim, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=PID)
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductAddingIssue", "<script>parent.ShowMessage('Unable to add Product','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If

        End If


        If (pnlHeaderLnks.Visible) Then
            Dim SaleMappingDs As New DataSet
            Dim BuyProducts As String = ""
            Dim GetProducts As String = ""
            For i As Integer = 0 To GrdBuyProducts.Rows.Count - 1
                Dim qty As New TextBox
                Dim chk As New CheckBox
                Dim hdnPid As New HiddenField

                chk = CType(GrdBuyProducts.Rows(i).FindControl("ChkProduct"), CheckBox)
                qty = CType(GrdBuyProducts.Rows(i).FindControl("txtQty"), TextBox)
                hdnPid = CType(GrdBuyProducts.Rows(i).FindControl("hdnProductID"), HiddenField)
                If chk.Checked Then
                    BuyProducts = BuyProducts & hdnPid.Value & "," & qty.Text & ";"
                End If
            Next

            For i As Integer = 0 To grdGetProducts.Rows.Count - 1
                Dim qty As New TextBox
                Dim chk As New CheckBox
                Dim hdnPid As New HiddenField

                chk = CType(grdGetProducts.Rows(i).FindControl("ChkProduct"), CheckBox)
                qty = CType(grdGetProducts.Rows(i).FindControl("txtQty"), TextBox)
                hdnPid = CType(grdGetProducts.Rows(i).FindControl("hdnProductID"), HiddenField)
                If chk.Checked Then
                    GetProducts = GetProducts & hdnPid.Value & "," & qty.Text & ";"
                End If
            Next

            Discount = CSng(IIf(txtOfferDiscount.Text.Trim() = "", "0", txtOfferDiscount.Text))
            SaleMappingDs = WebsiteArticles.AddSaleProductMapping(Session("CurrentBusinessID"), PID, DDLSaleMappingType.SelectedValue, SalePrice, Discount, Session("UserID"))
            If SaleMappingDs.Tables.Count > 0 Then
                WebsiteArticles.AddSaleMappedProducts(Session("CurrentBusinessID"), SaleMappingDs.Tables(0).Rows(0)("ProductMapID"), BuyProducts, GetProducts)
            End If
        End If
    End Sub

    Function SaveArticleImage(ByVal ArticleID As Integer, ByRef Fileupload As FileUpload, Optional IsMainImage As Boolean = False)
        Dim ProductImageFilename As String = ""
        If Fileupload.FileName <> "" Then
            ProductImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(Fileupload.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/Product/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If

            Fileupload.SaveAs(BusinessDirectory & "/" & ProductImageFilename)

            Products.AddProductImage(Session("CurrentBusinessID"), ArticleID,
                                     ProductImageFilename, "", LoggedInUserSession.UserID,
                                     IsMainImage:=IsMainImage)
            Using bigImage As Bitmap = New Bitmap(BusinessDirectory & "/" & ProductImageFilename)
                Dim height As Integer = bigImage.Height / 8
                Dim width As Integer = bigImage.Width / 8

                'Crop(ProductImageFilename, width, height, 0, 0)
                ReduceImageSize(0.3, Fileupload.PostedFile.InputStream, BusinessDirectory & "/Thumbnail_" & ProductImageFilename)
            End Using

        End If
        Return ProductImageFilename
    End Function

    Private Sub ReduceImageSize(ByVal scaleFactor As Double, ByVal sourcePath As Stream, ByVal targetPath As String)
        Using image = System.Drawing.Image.FromStream(sourcePath)
            Dim newWidth = CInt((image.Width * scaleFactor))
            Dim newHeight = CInt((image.Height * scaleFactor))
            Dim thumbnailImg = New Bitmap(newWidth, newHeight)
            Dim thumbGraph = Graphics.FromImage(thumbnailImg)
            thumbGraph.CompositingQuality = CompositingQuality.HighQuality
            thumbGraph.SmoothingMode = SmoothingMode.HighQuality
            thumbGraph.InterpolationMode = InterpolationMode.HighQualityBicubic
            Dim imageRectangle = New Rectangle(0, 0, newWidth, newHeight)
            thumbGraph.DrawImage(image, imageRectangle)
            thumbnailImg.Save(targetPath, image.RawFormat)
        End Using
    End Sub

    Private Shared Function Crop(ByVal Img As String, ByVal Width As Integer, ByVal Height As Integer, ByVal X As Integer, ByVal Y As Integer) As Byte()
        Try
            Dim BusinessDirectory As String = HttpContext.Current.Server.MapPath("~/CMS/Product/") & "/Images"
            Using OriginalImage As SD.Image = SD.Image.FromFile(BusinessDirectory & "/" & Img)

                Using bmp As SD.Bitmap = New SD.Bitmap(Width, Height)
                    bmp.SetResolution(OriginalImage.HorizontalResolution, OriginalImage.VerticalResolution)

                    Using Graphic As SD.Graphics = SD.Graphics.FromImage(bmp)
                        Graphic.SmoothingMode = SmoothingMode.AntiAlias
                        Graphic.InterpolationMode = InterpolationMode.HighQualityBicubic
                        Graphic.PixelOffsetMode = PixelOffsetMode.HighQuality
                        Graphic.DrawImage(OriginalImage, New SD.Rectangle(0, 0, Width, Height), X, Y, OriginalImage.Width, OriginalImage.Height, SD.GraphicsUnit.Pixel)
                        Dim ms As MemoryStream = New MemoryStream()
                        ''bmp.Save(ms, OriginalImage.RawFormat)
                        bmp.Save(BusinessDirectory & "/Thumbnail_" & Img, OriginalImage.RawFormat)
                        Return ms.GetBuffer()
                    End Using
                End Using
            End Using

        Catch Ex As Exception
            Throw (Ex)
        End Try
    End Function

    Private Sub DDLProductCatagory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        LoadProductSubCatagoriesAndUnits(DDLProductCatagory.SelectedItem.Value)
    End Sub

    Sub LoadProductSubCatagoriesAndUnits(ByVal GroupTypeID As Integer)
        DDLProductSubCatagory.Items.Clear()
        DDLUnit.Items.Clear()
        Dim ds As New DataSet
        ds = New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagory.DataValueField = "ArticleTypeID"
        DDLProductSubCatagory.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If
        If tbl.Rows.Count > 0 Then
            DDLProductSubCatagory.DataSource = tbl
            DDLProductSubCatagory.DataBind()
        End If

        ds = New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductUnits * -1)
        DDLUnit.DataValueField = "ArticleTypeID"
        DDLUnit.DataTextField = "ArticleType"
        tbl = New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If
        If tbl.Rows.Count > 0 Then
            DDLUnit.DataSource = tbl
            DDLUnit.DataBind()
        End If

    End Sub

    Private Sub DDLSaleMappingType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLSaleMappingType.SelectedIndexChanged
        If DDLSaleMappingType.SelectedItem.Value <= 0 Then
            pnlGetYFree.Visible = False
            pnlGetDiscount.Visible = False
            pnlBuyProducts.Visible = False
        ElseIf DDLSaleMappingType.SelectedItem.Value = 1 Then
            pnlGetYFree.Visible = True
            pnlGetDiscount.Visible = False
            pnlBuyProducts.Visible = True
        ElseIf DDLSaleMappingType.SelectedItem.Value = 2 Then
            pnlGetYFree.Visible = False
            pnlGetDiscount.Visible = True
            pnlBuyProducts.Visible = True
        End If
    End Sub

    Private Sub GrdBuyProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdBuyProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnProductID As New HiddenField
            Dim selectedProducts As String = HdnBuyProductsSelected.Value
            chk = CType(e.Row.FindControl("ChkProduct"), CheckBox)
            hdnProductID = CType(e.Row.FindControl("hdnProductID"), HiddenField)
            If (Not hdnProductID Is Nothing) Then
                Dim tmpAry() = selectedProducts.Split(";")
                For x As Integer = 0 To tmpAry.Length - 1
                    If (Val(tmpAry(x)) > 0 AndAlso Val(tmpAry(x)) = hdnProductID.Value) Then
                        chk.Checked = True
                        Dim BuyProducts() = HdnBuyProductDtls.Value.Split(";")
                        For i As Integer = 0 To BuyProducts.Length - 1
                            Dim tmp = BuyProducts(i).Split("|")
                            If (tmp(0) = hdnProductID.Value) Then
                                Dim Qty As New TextBox
                                Qty = CType(e.Row.FindControl("txtQty"), TextBox)
                                Qty.Text = tmp(1)
                            End If
                        Next
                    End If
                Next

            End If

        End If
    End Sub

    Private Sub grdGetProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles grdGetProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnProductID As New HiddenField
            Dim selectedProducts As String = HdnGetProductsSelected.Value
            chk = CType(e.Row.FindControl("ChkProduct"), CheckBox)
            hdnProductID = CType(e.Row.FindControl("hdnProductID"), HiddenField)
            If (Not hdnProductID Is Nothing) Then
                Dim tmpAry() = selectedProducts.Split(";")
                For x As Integer = 0 To tmpAry.Length - 1
                    If (Val(tmpAry(x)) > 0 AndAlso Val(tmpAry(x)) = hdnProductID.Value) Then
                        chk.Checked = True
                        Dim BuyProducts() = HdnBuyProductDtls.Value.Split(";")
                        For i As Integer = 0 To BuyProducts.Length - 1
                            Dim tmp = BuyProducts(i).Split("|")
                            If (tmp(0) = hdnProductID.Value) Then
                                Dim Qty As New TextBox
                                Qty = CType(e.Row.FindControl("txtQty"), TextBox)
                                Qty.Text = tmp(1)
                            End If
                        Next
                    End If
                Next

            End If

        End If
    End Sub

End Class