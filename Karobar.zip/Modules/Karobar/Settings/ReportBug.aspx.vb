﻿Public Class ReportBug
    Inherits System.Web.UI.Page



    Private Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
           
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim BugImageFilename As String = ""
        If FileUploadReportBug.PostedFile.FileName <> "" AndAlso FileUploadReportBug.PostedFile.FileName <> BugImageFilename Then
            BugImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadReportBug.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/Images/Bugs/")
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If
            FileUploadReportBug.SaveAs(BusinessDirectory & "/" & BugImageFilename)
        End If

        Tickets.AddTicket(Session("CurrentBusinessID"), ReferenceData.Setting("TicketType4Bug", "4"), _
                          ReferenceData.Setting("FromDepartment4BugComplaint", "6"), _
                          ReferenceData.Setting("FromTeam4BugCompalint", "3"), Session("UserID"), _
                          Session("UserName"), ReferenceData.Setting("ToDepartment4BugComplaint", "4"), _
                          ReferenceData.Setting("ToTeam4BugCompalint", "2"), -1, 1, txtSubject.Text, _
                          txtMessage.Text, ReferenceData.Setting("DefaultTicketStatusID", "1"), BugImageFilename)

        ClientScript.RegisterClientScriptBlock(Me.GetType(), "ComplaintDoneSuccessFully", "<script>parent.HideDlgForm();parent.ShowMessage('You Bug Report/Complaint has been sent successfully!','0',$(window).height()*2/100,$(window).width()*55/100)</script>")
    End Sub
End Class