﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services


' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class PayrollService
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function COA_GetLast12MonthConsolidatedSummary(KID As Integer, ByVal StartDate As DateTime, EndDate As DateTime) As String
        Dim tbl As New DataTable
        Dim Absent(12) As Single
        Dim Present(12) As Single
        Dim OnLeave(12) As Single
        Dim Months(12) As String
        Dim TotalAbsent As Single
        Dim TotalPresent As Single
        Dim TotalOnLeave As Single
        Dim ExpenseHeadID As Integer

        Dim ds As New DataSet
        KID = Val(Session("CurrentBusinessID"))
        ExpenseHeadID = ReferenceData.Setting("ExpenseHeadID", "", KID)


        Dim TotalMonths As Integer = DateDiff(DateInterval.Month, StartDate, EndDate)

        'For i As Integer = 1 To 12 'TotalMonths - 1

        '    Months(i - 1) = MonthName(StartDate.AddMonths((i - 1) * -1).Month).Substring(0, 3) & "-" & StartDate.AddMonths((i - 1) * -1).Year
        '    tbl = New DataTable
        '    tbl =Payroll.GetStaffMonthlyReport(Val(Session("CurrentBusinessID")), StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
        '    ''tbl = Products.AbsentReport(KID, -1, -1, "", StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
        '    For j As Integer = 0 To tbl.Rows.Count - 1
        '        Absent(i - 1) = Absent(i - 1) + ((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount"))
        '    Next
        '    TotalAbsent = TotalAbsent + Absent(i - 1)

        '    tbl = New DataTable
        '    tbl = Products.PresentReport(KID, -1, -1, "", StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
        '    For j As Integer = 0 To tbl.Rows.Count - 1
        '        Present(i - 1) = Present(i - 1) + ((tbl.Rows(j)("Price") * tbl.Rows(j)("Quantity")) - tbl.Rows(j)("Discount"))
        '    Next
        '    TotalPresent = TotalPresent + Present(i - 1)


        '    tbl = New DataTable
        '    tbl = ChartOfAccount.GetOnLeaveSummary(KID, ExpenseHeadID, StartDate.AddMonths((i - 1) * -1).ToString("MM-01-yyyy 00:00:00 ") & "AM", CDate(StartDate.AddMonths((i - 1) * -1).ToString("MM") & "-" & DateTime.DaysInMonth(StartDate.AddMonths((i - 1) * -1).Year, StartDate.AddMonths((i - 1) * -1).Month) & "-" & StartDate.AddMonths((i - 1) * -1).Year).ToString("MM-dd-yyyy 23:59:59 ") & "PM")
        '    For j As Integer = 0 To tbl.Rows.Count - 1
        '        OnLeave(i - 1) = OnLeave(i - 1) + tbl.Rows(j)("Debit")
        '    Next
        '    TotalOnLeave = TotalOnLeave + OnLeave(i - 1)
        'Next

        Dim dr As DataRow
        Dim Absenttbl As New DataTable
        For i As Integer = 1 To 12
            Absenttbl.Columns.Add(Months(i - 1))
        Next
        Absenttbl.Columns.Add("TotalAbsent")
        dr = Absenttbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = Absent(i - 1)
        Next
        dr(Absenttbl.Columns.Count - 1) = TotalAbsent
        Absenttbl.Rows.Add(dr)

        Dim Presenttbl As New DataTable
        For i As Integer = 1 To 12
            Presenttbl.Columns.Add(Months(i - 1))
        Next
        Presenttbl.Columns.Add("TotalPresent")

        dr = Presenttbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = Present(i - 1)
        Next
        dr(Presenttbl.Columns.Count - 1) = TotalPresent
        Presenttbl.Rows.Add(dr)

        Dim OnLeavetbl As New DataTable
        For i As Integer = 1 To 12
            OnLeavetbl.Columns.Add(Months(i - 1))
        Next
        OnLeavetbl.Columns.Add("TotalOnLeave")

        dr = OnLeavetbl.NewRow
        For i As Integer = 1 To 12
            dr(i - 1) = OnLeave(i - 1)
        Next
        dr(OnLeavetbl.Columns.Count - 1) = TotalOnLeave
        OnLeavetbl.Rows.Add(dr)

        Dim Monthstbl As New DataTable
        Monthstbl.Columns.Add("Months")
        For i As Integer = 0 To 11
            dr = Monthstbl.NewRow
            dr(0) = Months(i)
            Monthstbl.Rows.Add(dr)
        Next

        ds.Tables.Add(Presenttbl)
        ds.Tables.Add(Absenttbl)
        ds.Tables.Add(OnLeavetbl)
        ds.Tables.Add(Monthstbl)
        ds.Tables(0).TableName = "Present"
        ds.Tables(1).TableName = "Absent"
        ds.Tables(2).TableName = "OnLeave"
        ds.Tables(3).TableName = "Last12Months"

        Return ds.GetXml()
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetAttendanceStatistics() As String
        Dim ds As New DataSet
        Dim tbl As New DataTable
        Dim TotalPresent As Integer = 0
        Dim TotalAbsent As Integer = 0
        Dim TotalOnLeave As Integer = 0


        tbl = Payroll.GetEmployees4Attendance(Val(Session("CurrentBusinessID")), Now)
        If tbl.Select("AttendanceStatus='PRESENT'").Length > 0 Then
            Dim tmpTbl As New DataTable
            tmpTbl = tbl.Select("AttendanceStatus='PRESENT'").CopyToDataTable()
            TotalPresent = tmpTbl.Rows.Count
        End If

        If tbl.Select("AttendanceStatus='ABSENT'").Length > 0 Then
            Dim tmpTbl As New DataTable
            tmpTbl = tbl.Select("AttendanceStatus='ABSENT'").CopyToDataTable()
            TotalAbsent = tmpTbl.Rows.Count
        End If

        If tbl.Select("AttendanceStatus='ONLEAVE'").Length > 0 Then
            Dim tmpTbl As New DataTable
            tmpTbl = tbl.Select("AttendanceStatus='ONLEAVE'").CopyToDataTable()
            TotalOnLeave = tmpTbl.Rows.Count
        End If

        Dim AttendanceStatisticsTbl As New DataTable
        AttendanceStatisticsTbl.Columns.Add("TotalPresent")
        AttendanceStatisticsTbl.Columns.Add("TotalAbsent")
        AttendanceStatisticsTbl.Columns.Add("TotalOnLeave")

        Dim dr As DataRow
        dr = AttendanceStatisticsTbl.NewRow
        dr("TotalPresent") = TotalPresent
        dr("TotalAbsent") = TotalAbsent
        dr("TotalOnLeave") = TotalOnLeave
        AttendanceStatisticsTbl.Rows.Add(dr)

        ds.Tables.Add(AttendanceStatisticsTbl)

        ds.Tables(0).TableName = "EmployeesAttendance"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function GetTotalPeopleCount() As String
        Dim ds As New DataSet
        Dim tbl As New DataTable

        tbl = Payroll.GetTotalPeopleCount(Val(Session("CurrentBusinessID")))
        ds.Tables.Add(tbl)
        ds.Tables(0).TableName = "TotalPeopleCount"
        Return ds.GetXml
    End Function



End Class