﻿Public Class Customer
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Person.DoesPersonHavePageRights(Session("UserID"), 48) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If
        LblCustomerName.Text = ReferenceData.Setting("LblCustomerName", "Customer Name", Session("CurrentBusinessID"))
        LblCustomerCustomerDescription.Text = ReferenceData.Setting("LblCustomerCustomerDescription", "Description", Session("CurrentBusinessID"))
        LblCustomerTitle.Text = ReferenceData.Setting("LblCustomerTitle", "Title", Session("CurrentBusinessID"))
        LblCustomerType.Text = ReferenceData.Setting("LblCustomerType", "Customer Type", Session("CurrentBusinessID"))

        LblCustomerStatus.Text = ReferenceData.Setting("LblCustomerStatus", "Status", Session("CurrentBusinessID"))
        LblCustomerPhone.Text = ReferenceData.Setting("LblCustomerPhone", "Phone", Session("CurrentBusinessID"))
        LblCustomerFax.Text = ReferenceData.Setting("LblCustomerFax", "Fax", Session("CurrentBusinessID"))
        LblCustomerEmail.Text = ReferenceData.Setting("LblCustomerEmail", "Email", Session("CurrentBusinessID"))
        LblCustomerMobileNo.Text = ReferenceData.Setting("LblCustomerMobileNo", "Mobile No", Session("CurrentBusinessID"))
        LblCustomerOtherContactNo.Text = ReferenceData.Setting("LblCustomerOtherContactNo", "Other Contact #", Session("CurrentBusinessID"))
        LblCustomerAddress.Text = ReferenceData.Setting("LblCustomerAddress", "Address", Session("CurrentBusinessID"))

        LblCreditLimit.Text = ReferenceData.Setting("LblCustomerCreditLimit", "Credit Limit", Session("CurrentBusinessID"))

        LblScreenTitle.Text = ReferenceData.Setting("LblCustomerStatus", "Create New Customer", Session("CurrentBusinessID"))


        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.PersonTitles * -1)
            DDLTitle.DataValueField = "ArticleTypeID"
            DDLTitle.DataTextField = "ArticleType"
            DDLTitle.DataSource = ds.Tables(0)
            DDLTitle.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.CustomerType * -1)
            DDLCustomerType.DataValueField = "ArticleTypeID"
            DDLCustomerType.DataTextField = "ArticleType"
            DDLCustomerType.DataSource = ds.Tables(0)
            DDLCustomerType.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.CustomerStatus * -1)
            DDLCustomerStatus.DataValueField = "ArticleTypeID"
            DDLCustomerStatus.DataTextField = "ArticleType"
            DDLCustomerStatus.DataSource = ds.Tables(0)
            DDLCustomerStatus.DataBind()
            If Not Request("CID") Is Nothing Then
                HdnCustomerID.Value = Val(Request("CID"))
            End If
            If Val(HdnCustomerID.Value) > 0 Then
                LoadData(Val(HdnCustomerID.Value))
            End If

        End If
        If Val(HdnCustomerID.Value) <= 0 Then
            LblScreenTitle.Text = "Create New Customer"
            LnkCustomerPersonalDetails.Visible = False
            LnkCustomerDocuments.Visible = False
            LnkNotes.Visible = False
            lnkGiftCard.Visible = False
            CustomerImage.ImageUrl = "/Images/NoUserImage.png"
        Else
            LblScreenTitle.Text = "Update Customer"
            LnkCustomerPersonalDetails.Visible = True
            LnkCustomerDocuments.Visible = True
            LnkNotes.Visible = True
            lnkGiftCard.Visible = True
        End If
        UploadDocHistory.EmployeeID = Val(HdnCustomerID.Value)
        UploadDocHistory.UploadDocumentPath = "/CMS/" & Session("CurrentBusinessID") & "/Customer/"
        NotesBook.EmployeeID = Val(HdnCustomerID.Value)
        UserGiftCards.CustomerID = Val(HdnCustomerID.Value)
        AssignStudents.TeacherID = Val(HdnCustomerID.Value)
        CustomerOrderHistory.CustomerID = Val(HdnCustomerID.Value)
        CustomerSaleHistory.CustomerID = Val(HdnCustomerID.Value)

        If Val(HdnCustomerID.Value) <= 0 Then
            LnkTeacherStudents.Visible = False
            lnkGiftCard.Visible = False
            LnkOrderHistory.Visible = False
            LnkSaleHistory.Visible = False
        Else
            If (Not Session("CurrentBusinessCategoryID") Is Nothing AndAlso Val(Session("CurrentBusinessCategoryID")) = 5) Then 'School
                LnkTeacherStudents.Visible = True
                LnkOrderHistory.Visible = False
                LnkSaleHistory.Visible = False
            Else
                LnkTeacherStudents.Visible = False

            End If

            If (Not Session("CurrentBusinessCategoryID") Is Nothing) AndAlso Val(Session("CurrentBusinessCategoryID")) = 13 Or Val(Session("CurrentBusinessCategoryID")) = 5 Then
                lnkGiftCard.Visible = False
                DivCustomerTitleAndTypeDetails.Visible = False
            Else
                lnkGiftCard.Visible = True
            End If
        End If

    End Sub

    Sub LoadData(ByVal CID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), CID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
            If ds.Tables(0).Rows.Count > 0 Then
                If IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")) OrElse ds.Tables(0).Rows(0)("WebsiteID") <> Session("CurrentBusinessID") Then
                    BtnSave.Enabled = False
                    BtnSave.Visible = False
                    If IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")) = False AndAlso ds.Tables(0).Rows(0)("WebsiteID") = "-1" Then
                        pnlSubscribedUsers.Visible = True
                    End If
                    Exit Sub
                    End If
                Else
                BtnSave.Enabled = False
                BtnSave.Visible = False
            End If
        End If
        If tbl.Rows.Count > 0 Then
            txtCustomerAddress.Text = IIf(IsDBNull(tbl.Rows(0)("ResidentialAddress")), "", tbl.Rows(0)("ResidentialAddress"))
            txtCustomerDescription.Text = IIf(IsDBNull(tbl.Rows(0)("Description")), "", tbl.Rows(0)("Description"))
            txtCustomerFax.Text = IIf(IsDBNull(tbl.Rows(0)("Fax")), "", tbl.Rows(0)("Fax"))
            txtCustomerName.Text = IIf(IsDBNull(tbl.Rows(0)("FirstName")), "", tbl.Rows(0)("FirstName"))
            txtCustomerPhone.Text = IIf(IsDBNull(tbl.Rows(0)("TelephoneNo")), "", tbl.Rows(0)("TelephoneNo"))
            txtEmail.Text = IIf(IsDBNull(tbl.Rows(0)("EmailAddress")), "", tbl.Rows(0)("EmailAddress"))
            txtMobileNo.Text = IIf(IsDBNull(tbl.Rows(0)("MobileNo")), "", tbl.Rows(0)("MobileNo"))
            txtOtherContactNo.Text = IIf(IsDBNull(tbl.Rows(0)("OtherContactNo")), "", tbl.Rows(0)("OtherContactNo"))
            DDLCustomerStatus.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("AccountTypeID")), "", tbl.Rows(0)("AccountTypeID"))
            DDLCustomerType.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("AccountStatusTypeID")), "", tbl.Rows(0)("AccountStatusTypeID"))
            DDLTitle.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Title")), "", tbl.Rows(0)("Title"))
            txtCreditLimit.Text = IIf(IsDBNull(tbl.Rows(0)("CreditLimit")), "", tbl.Rows(0)("CreditLimit"))
            If (IsDBNull(tbl.Rows(0)("ImageFilename")) = False AndAlso tbl.Rows(0)("ImageFilename") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/" & Session("CurrentBusinessID") & "/Customer/Images"
                HdnCustomerImageFilename.Value = tbl.Rows(0)("ImageFilename")
                CustomerImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ImageFilename")
                CustomerImage.AlternateText = txtCustomerName.Text
            Else
                CustomerImage.ImageUrl = "/Images/NoUserImage.png"
            End If

            If Val(tbl.Rows(0)("WebsiteID")) <= 0 Then
                pnlHeaderLnks.Visible = False
                pnlSubscribedUsers.Visible = True
                BtnSave.Visible = False
            Else
                pnlSubscribedUsers.Visible = False
                pnlHeaderLnks.Visible = True
                BtnSave.Visible = True
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "DemoBusiness", "<script>parent.ShowMessage('Update/Delete is disabled on demo business ','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Exit Sub
        End If

        Dim tbl As New DataTable
        Dim UserImageFilename As String = HdnCustomerImageFilename.Value

        If FileUploadCustomerImage.PostedFile.FileName <> "" AndAlso FileUploadCustomerImage.PostedFile.FileName <> UserImageFilename Then
            UserImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadCustomerImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Session("CurrentBusinessID") & "/Customer/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If
            FileUploadCustomerImage.SaveAs(BusinessDirectory & "/" & UserImageFilename)
        End If

        If Val(HdnCustomerID.Value) > 0 Then
            tbl = Person.UpdateDetails(Session("CurrentBusinessID"), Val(HdnCustomerID.Value), txtEmail.Text.Trim, Guid.NewGuid.ToString, txtCustomerName.Text, "", "", DDLTitle.SelectedItem.Value,
                            1, "8/8/1888", "-1", txtCustomerPhone.Text, txtMobileNo.Text, txtOtherContactNo.Text, txtEmail.Text.Trim, txtCustomerAddress.Text.Trim, Person.UserTypes.Customer, -1,
                            False, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, txtCustomerFax.Text, txtCustomerDescription.Text, CreditLimit:=CDbl(txtCreditLimit.Text))
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "CustomerUpdateSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Customer updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "People", "Updated Customer Record " & txtCustomerName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, Val(HdnCustomerID.Value))
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "CustomerUpdatingIssue", "<script>parent.ShowMessage('Unable to Update Customer','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        Else

            tbl = Person.AddUser(Session("CurrentBusinessID"), txtEmail.Text.Trim, Guid.NewGuid.ToString, txtCustomerName.Text, "", "", DDLTitle.SelectedItem.Value,
                            1, "8/8/1888", "-1", txtCustomerPhone.Text, txtMobileNo.Text, txtOtherContactNo.Text, txtEmail.Text.Trim, txtCustomerAddress.Text.Trim, Person.UserTypes.Customer, -1,
                            False, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, txtCustomerFax.Text, txtCustomerDescription.Text, ParentAccountHeadID:=ReferenceData.Setting("CustomerAccountHeadID", "30", Session("CurrentBusinessID")), CreditLimit:=CDbl(IIf(txtCreditLimit.Text.Trim = "", "0", txtCreditLimit.Text.Trim)))
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "CustomerAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Customer added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "People", "Added New Customer " & txtCustomerName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, Val(tbl.Rows(0)("UserID")))
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "CustomerAddingIssue", "<script>parent.ShowMessage('Unable to add Customer','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        End If

    End Sub

    Private Sub LnkCustomerPersonalDetails_Click(sender As Object, e As EventArgs) Handles LnkCustomerPersonalDetails.Click
        DivCustomerDetails.Visible = True
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlGiftCard.Visible = False
        pnlTeacherStudents.Visible = False
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub LnkCustomerDocuments_Click(sender As Object, e As EventArgs) Handles LnkCustomerDocuments.Click
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = True
        pnlDoc.Visible = True
        pnlNotes.Visible = False
        pnlGiftCard.Visible = False
        pnlTeacherStudents.Visible = False
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub LnkNotes_Click(sender As Object, e As EventArgs) Handles LnkNotes.Click
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = True
        pnlGiftCard.Visible = False
        pnlTeacherStudents.Visible = False
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub lnkGiftCard_Click(sender As Object, e As EventArgs) Handles lnkGiftCard.Click
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlGiftCard.Visible = True
        pnlTeacherStudents.Visible = False
        UserGiftCards.CustomerID = Val(HdnCustomerID.Value)
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub LnkTeacherStudents_Click(sender As Object, e As EventArgs) Handles LnkTeacherStudents.Click
        pnlTeacherStudents.Visible = True
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlGiftCard.Visible = False
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub LnkOrderHistory_Click(sender As Object, e As EventArgs) Handles LnkOrderHistory.Click
        pnlTeacherStudents.Visible = False
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlGiftCard.Visible = False
        pnlCustomerOrders.Visible = True
        pnlCustomerSaleHistory.Visible = False
    End Sub

    Private Sub LnkSaleHistory_Click(sender As Object, e As EventArgs) Handles LnkSaleHistory.Click
        pnlTeacherStudents.Visible = False
        DivCustomerDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlGiftCard.Visible = False
        pnlCustomerOrders.Visible = False
        pnlCustomerSaleHistory.Visible = True
    End Sub
End Class