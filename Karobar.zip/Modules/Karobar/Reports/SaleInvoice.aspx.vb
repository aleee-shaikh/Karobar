﻿Public Class SaleInvoice
    Inherits System.Web.UI.Page

    Dim _TotalAmount As Single

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open sale invoice", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
        If Not Page.IsPostBack Then
            HiddenQtyValue.Value = ReferenceData.Setting("HiddenQtyValue", "1", Session("CurrentBusinessID"))
            HdnSaleID.Value = Request("SaleID")
        End If
        If HdnSaleID.Value > 0 Then
            Dim tbl As New DataTable
            tbl = Products.GetSaleDetails(Session("CurrentBusinessID"), Val(HdnSaleID.Value))
            If tbl.Rows.Count > 0 Then
                LblCustomer.Text = IIf(IsDBNull(tbl.Rows(0)("CustomerName")), "", tbl.Rows(0)("CustomerName"))
                LblDeliveryCharges.Text = IIf(IsDBNull(tbl.Rows(0)("DeliveryCharges")), "", tbl.Rows(0)("DeliveryCharges"))
                LblDueDate.Text = IIf(IsDBNull(tbl.Rows(0)("DueDate")), "", tbl.Rows(0)("DueDate"))
                LblOrderDate.Text = IIf(IsDBNull(tbl.Rows(0)("Dated")), "", tbl.Rows(0)("Dated"))
                LblReference.Text = IIf(IsDBNull(tbl.Rows(0)("Reference")), "", tbl.Rows(0)("Reference"))
                LblSalesPerson.Text = IIf(IsDBNull(tbl.Rows(0)("SalePersonName")), "", tbl.Rows(0)("SalePersonName"))
                LblSaleType.Text = IIf(IsDBNull(tbl.Rows(0)("SaleTypeName")), "", tbl.Rows(0)("SaleTypeName"))
                LblTax.Text = IIf(IsDBNull(tbl.Rows(0)("Tax")), "", tbl.Rows(0)("Tax"))
                LblStockLocation.Text = IIf(IsDBNull(tbl.Rows(0)("StockLocation")), "", tbl.Rows(0)("StockLocation"))
                LblSaleInvoiceID.Text = "Sale-Inv-" & IIf(IsDBNull(tbl.Rows(0)("SaleID")), "", tbl.Rows(0)("SaleID"))
            End If
            GrdProducts.DataSource = tbl
            GrdProducts.DataBind()
        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim LnkEditProduct As New System.Web.UI.WebControls.LinkButton
            LnkEditProduct = CType(e.Row.FindControl("LnkEditProduct"), LinkButton)
            If Not LnkEditProduct Is Nothing Then
                LnkEditProduct.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Product/NewProduct.aspx?PID=" & drview("ArticleID") & "',$(window).height()*79/100,$(window).width()*72/100);return false"
            End If

            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")

            _TotalAmount = _TotalAmount + ((HiddenQtyValue.Value * drview("Quantity") * drview("SalePrice")) + drview("OtherCharges")) - drview("Discount")
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalAmountLbl As New System.Web.UI.WebControls.Label
            Dim footerLblTotal As New System.Web.UI.WebControls.Label
            Dim footerLblGrossTotal As New System.Web.UI.WebControls.Label
            Dim footerLblDeliveryCharges As New System.Web.UI.WebControls.Label
            Dim footerLblTax As New System.Web.UI.WebControls.Label

            TotalAmountLbl = CType(e.Row.FindControl("TotalAmount"), Label)
            footerLblTotal = CType(e.Row.FindControl("lblTotal"), Label)
            footerLblGrossTotal = CType(e.Row.FindControl("LblGrossTotal"), Label)
            footerLblDeliveryCharges = CType(e.Row.FindControl("LblDeliveryCharges"), Label)
            footerLblTax = CType(e.Row.FindControl("LblTax"), Label)

            If Not TotalAmountLbl Is Nothing Then
                TotalAmountLbl.Text = _TotalAmount
                footerLblTotal.Text = _TotalAmount
                footerLblDeliveryCharges.Text = Val(LblDeliveryCharges.Text)
                footerLblTax.Text = Val(LblTax.Text)
                footerLblGrossTotal.Text = _TotalAmount + CSng(footerLblDeliveryCharges.Text) + CSng(footerLblTax.Text)
            End If


        End If
    End Sub

End Class