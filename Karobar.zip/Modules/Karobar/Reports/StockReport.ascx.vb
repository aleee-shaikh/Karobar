﻿Public Class StockReport
    Inherits System.Web.UI.UserControl
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
            DDLProductCatagory.DataValueField = "ArticleTypeID"
            DDLProductCatagory.DataTextField = "ArticleType"
            DDLProductCatagory.DataSource = ds.Tables(0)
            DDLProductCatagory.DataBind()
            ''LoadProductSubCatagories(DDLProductCatagory.SelectedItem.Value)

            ''ScriptManager.RegisterClientScriptBlock(Me, GetType(Page), "CatagorySelected", "$(document).ready(function() {LoadDDLOptions('" & DDLProductCatagory.ClientID & "', LoadSubCatagories(-1))})", True)

            LoadData()
        Else

        End If
    End Sub

    Sub LoadProductSubCatagories(ByVal GroupTypeID As Integer)
        DDLProductSubCatagories.Items.Clear()
        Dim ds As New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagories.DataValueField = "ArticleTypeID"
        DDLProductSubCatagories.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If

        DDLProductSubCatagories.Items.Add(New ListItem("All Sub Catagories", "-1"))
        DDLProductSubCatagories.DataSource = tbl
        DDLProductSubCatagories.DataBind()

    End Sub

    Protected Sub DDLProductCatagory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        ''LoadProductSubCatagories(DDLProductCatagory.SelectedItem.Value)

    End Sub

    Sub LoadData()
        _tbl = Products.StockReport(Session("CurrentBusinessID"), DDLProductCatagory.SelectedItem.Value, Val(HdnSelectSubCatagory.Value), txtFreeText.Text.Trim, DDLStockLocation.SelectedItem.Value.ToString())
        Session("StockReport-" & Session("UserID")) = _tbl
        GrdProducts.DataSource = _tbl
        GrdProducts.DataBind()

        If Not Page.IsPostBack Then

            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.StockLocations * -1)
            DDLStockLocation.DataValueField = "ArticleTypeID"
            DDLStockLocation.DataTextField = "ArticleType"
            DDLStockLocation.DataSource = ds.Tables(0)
            DDLStockLocation.DataBind()

        End If
    End Sub

    Private Sub GrdProducts_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            If (drview("Purchased") - drview("Sold")) < drview("MinAlertQty") Then

                e.Row.Attributes.Add("style", "background:#ef214a;Color:white")
                e.Row.Attributes.Add("onMouseOver", "this.style.backgroundColor='pink';this.style.cursor='pointer';")
                e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor='#ef214a';this.style.cursor='pointer';")
            Else
                e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
                e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
            End If

        End If
    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim ExportFileName As String = ""
        If Not Session("StockReport-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("StockReport-" & Session("UserID")), DataTable)
        End If

        'Dim Columns As String = "StockLocation,ArticleTitle,SubCatagory,Manufacturer,Purchased,Sold"
        Dim Columns As String = "ArticleTitle,SubCatagory,Manufacturer,Purchased,Sold"
        Dim CAry() As String = Columns.Split(",")

        If _tbl.Rows.Count = 0 Then
            ExportFileName = "attachment; filename=NoDataFound.csv"
        Else
            ExportFileName = "attachment; filename=StockReport" & Now.ToString("yyyyMMddhhmm") & ".csv"
            Data = Columns + ",BalanceQty"

            Data = Data & Environment.NewLine
            For i As Integer = 0 To _tbl.Rows.Count - 1
                For j As Integer = 0 To CAry.Count - 1
                    Data = Data & _tbl.Rows(i)(CAry(j)) & ","
                Next
                Data = Data & _tbl.Rows(i)("Purchased") - _tbl.Rows(i)("Sold") & ","
                Data = Data & Environment.NewLine
            Next
        End If

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", ExportFileName)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), Request("P")) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
    End Sub
End Class