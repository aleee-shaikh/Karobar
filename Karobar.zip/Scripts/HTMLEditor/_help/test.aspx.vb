
Partial Class test
    Inherits System.Web.UI.Page

    'Protected Sub Click_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Click.Click
    '    Response.Write(Request("wysiwyg"))
    'End Sub
End Class
