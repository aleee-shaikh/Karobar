﻿Public Class OFFDays
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Not Page.IsPostBack) Then
            LoadData()
        End If

    End Sub

    Public Sub Save()
        Payroll.AddCompanyOFFDays(Val(Session("CurrentBusinessID")), chkMonday.Checked, chkThursday.Checked, chkWednesday.Checked, chkThursday.Checked, chkFriday.Checked, chkSaturday.Checked, chkSunday.Checked, Session("UserID"))
    End Sub


    Public Sub LoadData()
        If Not Session("CurrentBusinessID") Is Nothing Then
            Dim tbl As New DataTable
            tbl = Payroll.GetCompanyOFFDays(Val(Session("CurrentBusinessID")))
            If (tbl.Rows.Count > 0) Then
                chkMonday.Checked = tbl.Rows(0)("Monday")
                chkTuesday.Checked = tbl.Rows(0)("Tuesday")
                chkWednesday.Checked = tbl.Rows(0)("Wednesday")
                chkThursday.Checked = tbl.Rows(0)("Thursday")
                chkFriday.Checked = tbl.Rows(0)("Friday")
                chkSaturday.Checked = tbl.Rows(0)("Saturday")
                chkSunday.Checked = tbl.Rows(0)("Sunday")
            End If
        End If
    End Sub
End Class