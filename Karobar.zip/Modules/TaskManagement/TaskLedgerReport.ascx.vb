﻿Public Class TaskLedgerReport
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _Balance As Single
    Dim _tbl As New DataTable

    Public Property AccountHeadID() As Integer
        Get
            Return Val(HdnAccountHeadID.Value)
        End Get
        Set(value As Integer)
            HdnAccountHeadID.Value = value
            LoadData()
        End Set
    End Property

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtTransactionFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtTransactionToDate.Text = Now.ToString("dd-MM-yyyy")
            'LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim DDLAccountHeadID As Integer = Val(HdnAccountHeadID.Value)


        'Dim FDate As String = ""
        'Dim FdateAry() = txtTransactionFromDate.Text.Replace("/", "-").Split("-")
        'Dim TDate As String = ""
        'Dim TdateAry() = txtTransactionToDate.Text.Replace("/", "-").Split("-")

        Dim AccountHeadIDs As String = ReferenceData.Setting("AccountsPayableID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("AccountsReceiveableID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("BankAccountHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("ExpenseHeadID", "", Session("CurrentBusinessID")) & "," & ReferenceData.Setting("CashInHandAccountHeadID", "", Session("CurrentBusinessID"))
        If DDLAccountHeadID > 0 Then
            AccountHeadIDs = DDLAccountHeadID & ","
        End If
        Dim tbl As New DataTable
        Dim COATbl As New DataTable
        Dim HeadIDsAry() = AccountHeadIDs.Split(",")
        Dim HeadIds As String = ""
        Dim ds As New DataSet


        COATbl = ChartOfAccount.GetCOA(HttpContext.Current.Session("CurrentBusinessID"))
        For Each itm In HeadIDsAry
            If itm <> "" Then
                HeadIds = HeadIds & ChartOfAccount.GetAccountHeadTree(COATbl, itm) & ","
                HeadIds = HeadIds.Replace(",,", ",")
            End If
        Next
        HeadIds = HeadIds.Replace(",,", ",")

        'ds = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds,
        '                            CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2) & " 00:00:00 AM"),
        '                            CDate(TdateAry(1) & "-" & TdateAry(0) & "-" & TdateAry(2) & " 23:59:59 PM"))
        ds = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds,
                                    Now.AddYears(-50), Now.AddYears(5))
        _tbl = ds.Tables(0)



        ''''_tbl = Transactions.GetLedger(Session("CurrentBusinessID"), DDLAccountHeadID, CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2) & " 00:00:00 AM"), CDate(TdateAry(1) & "-" & TdateAry(0) & "-" & TdateAry(2) & " 23:59:59 PM")).Tables(0)

        ''Dim _OldLedgerTbl As New DataTable()
        ''''_OldLedgerTbl = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, DateTime.Now.AddYears(-10), CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2) & " 23:59:59 PM").AddDays(-1)).Tables(0)
        ''_OldLedgerTbl = Transactions.GetLedger(Session("CurrentBusinessID"), HeadIds, DateTime.Now.AddYears(-10), Now.AddYears(10)).Tables(0)

        ''Dim Bal As Single
        ''Dim cr As Single
        ''Dim dr As Single

        ''If (ds.Tables.Count > 1 AndAlso ds.Tables(1).Rows.Count > 0) Then 'InitialOpeningBalance
        ''    Bal = ds.Tables(1).Rows(0)("InitialOpeningBalance")
        ''End If

        ''For i As Integer = 0 To _OldLedgerTbl.Rows.Count - 1
        ''    ' dr = dr + IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Debit")), 0, _OldLedgerTbl.Rows(i)("Debit"))
        ''    ' cr = cr + IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Credit")), 0, _OldLedgerTbl.Rows(i)("Credit"))
        ''    dr = IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Debit")), 0, _OldLedgerTbl.Rows(i)("Debit"))
        ''    cr = IIf(IsDBNull(_OldLedgerTbl.Rows(i)("Credit")), 0, _OldLedgerTbl.Rows(i)("Credit"))

        ''    'If IsDBNull(_OldLedgerTbl.Rows(i)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(i)("TransactionCode") = "CashSale" Then
        ''    '    ''_TotalDebit = _TotalDebit + Dr
        ''    'Else
        ''    '    If IsDBNull(_OldLedgerTbl.Rows(i)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(i)("TransactionCode") = "PRV" Then
        ''    '        If Bal < 0 Then
        ''    '            Bal = Bal + (dr + cr)
        ''    '        Else
        ''    '            Bal = Bal + (dr - cr)
        ''    '        End If
        ''    '    Else
        ''    '        If IsDBNull(_OldLedgerTbl.Rows(i)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(i)("TransactionCode") = "Sale" Then
        ''    '            If Bal < 0 Then
        ''    '                Bal = Bal - (dr - cr)
        ''    '            Else
        ''    '                Bal = Bal + (dr - cr)
        ''    '            End If
        ''    '        Else
        ''    '            Bal = Bal + (dr - cr)
        ''    '        End If

        ''    '    End If

        ''    'End If

        ''    If IsDBNull(_OldLedgerTbl.Rows(i)("TransactionCode")) = False AndAlso _OldLedgerTbl.Rows(i)("TransactionCode") = "CashSale" And cr > 0 Then
        ''        dr = cr
        ''    End If
        ''    Bal = Bal + (dr - cr)
        ''Next
        '''Bal = Bal + (dr - cr)
        ''Dim LgrTbl As New DataTable()
        ''LgrTbl = _tbl.Copy()
        ''LgrTbl.Clear()

        ''Dim Drow As DataRow
        ''Drow = LgrTbl.NewRow

        ''Drow("Particular") = "Opening Balance"
        ''Drow("Debit") = Bal
        ''Drow("Credit") = 0
        ''Drow("TransactionDate") = Now

        ''LgrTbl.Rows.Add(Drow)
        ''LgrTbl.Merge(_tbl)

        ''_tbl.Merge(_OldLedgerTbl)

        '' _tbl = LgrTbl
        Session("LedgerReport-" & Session("UserID")) = _tbl
        GrdTransactions.DataSource = _tbl
        GrdTransactions.DataBind()
    End Sub

    Private Sub GrdTransactions_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdTransactions.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
            Dim Dr As Single = IIf(IsDBNull(drview("Debit")), 0, drview("Debit"))
            Dim Cr As Single = IIf(IsDBNull(drview("Credit")), 0, drview("Credit"))

            'If IsDBNull(drview("TransactionCode")) = False AndAlso drview("TransactionCode") = "CashSale" Then
            '    ''_TotalDebit = _TotalDebit + Dr
            'Else

            '    If IsDBNull(drview("TransactionCode")) = False AndAlso drview("TransactionCode") = "PRV" Then
            '        If _Balance < 0 Then
            '            _Balance = _Balance + (Dr + Cr)
            '        Else
            '            _Balance = _Balance + (Dr - Cr)
            '        End If
            '    Else
            '        If IsDBNull(drview("TransactionCode")) = False AndAlso drview("TransactionCode") = "Sale" Then
            '            If _Balance < 0 Then
            '                _Balance = _Balance - (Dr - Cr)
            '            Else
            '                _Balance = _Balance + (Dr - Cr)
            '            End If
            '        Else
            '            _Balance = _Balance + (Dr - Cr)
            '        End If

            '    End If

            'End If

            If IsDBNull(drview("TransactionCode")) = False AndAlso drview("TransactionCode") = "CashSale" And Cr > 0 Then
                Dr = Cr
            End If
            _Balance = _Balance + (Dr - Cr)


            Dim BalanceLbl As New System.Web.UI.WebControls.Label
            BalanceLbl = CType(e.Row.FindControl("LblBalance"), Label)
            If Not BalanceLbl Is Nothing Then
                BalanceLbl.Text = _Balance
            End If

            Dim DebitLbl As New System.Web.UI.WebControls.Label
            Dim CreditLbl As New System.Web.UI.WebControls.Label
            Dim TransactionDateLbl As New System.Web.UI.WebControls.Label

            DebitLbl = CType(e.Row.FindControl("LblDr"), Label)
            CreditLbl = CType(e.Row.FindControl("LblCr"), Label)
            TransactionDateLbl = CType(e.Row.FindControl("LblTransactionDate"), Label)

            If drview("Particular") <> "Opening Balance" Then
                If Not DebitLbl Is Nothing Then
                    DebitLbl.Text = Dr
                End If

                If Not CreditLbl Is Nothing Then
                    CreditLbl.Text = Cr
                End If

                If Not CreditLbl Is Nothing Then
                    TransactionDateLbl.Text = General.GetLocalDateTimeByTimeZone(drview("Dated"), LoggedInUserSession.TimeZone)
                End If
                _TotalDebit += Dr
                _TotalCredit += Cr
            End If



            Dim Lnk As New LinkButton
            Lnk = CType(e.Row.FindControl("lnkViewDetail"), LinkButton)
            If IsDBNull(drview("TransactionCode")) = False Then
                If drview("TransactionCode") = "OPB" Then
                    Lnk.Visible = False
                Else
                    Lnk.Visible = True
                    If (drview("TransactionCode") = "CashSale" Or drview("TransactionCode") = "Sale") Then
                        Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/POSSaleInvoice.aspx?SaleID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100);return false;")
                    ElseIf (drview("TransactionCode") = "Buy") Then
                        Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/PurchaseInvoice.aspx?PurchaseID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100);return false;")
                    ElseIf (drview("TransactionCode") = "PRV") Then
                        Lnk.Attributes.Add("onclick", "ShowReceivePaymentInvoice(" & drview("TransactionID") & ");return false;")
                    ElseIf (drview("TransactionCode") = "CPV") Then
                        Lnk.Attributes.Add("onclick", "ShowCashPaymentInvoice(" & drview("TransactionID") & ");return false;")
                    ElseIf (drview("TransactionCode") = "BPV") Then
                        Lnk.Attributes.Add("onclick", "ShowBankPaymentInvoice(" & drview("TransactionID") & ");return false;")
                    Else
                        Lnk.Visible = False
                    End If
                End If
            Else
                Lnk.Visible = False
            End If

        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalDebitLbl As New System.Web.UI.WebControls.Label
            Dim TotalCreditLbl As New System.Web.UI.WebControls.Label

            Dim LblTotal As New System.Web.UI.WebControls.Label

            TotalDebitLbl = CType(e.Row.FindControl("LblTotalDebit"), Label)
            TotalCreditLbl = CType(e.Row.FindControl("LblTotalCredit"), Label)

            LblTotal = CType(e.Row.FindControl("LblTotal"), Label)

            If Not TotalDebitLbl Is Nothing Then
                TotalDebitLbl.Text = _TotalDebit
            End If

            If Not TotalCreditLbl Is Nothing Then
                TotalCreditLbl.Text = _TotalCredit
            End If

            If Not LblTotal Is Nothing Then
                LblTotal.Text = _Balance
            End If



        End If

    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
        'LblLedgerPartyName.Text = DDLAccountHead.SelectedText
        'LblFromDate.Text = txtTransactionFromDate.Text
        'LblMiddleSpace.Text = "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TO&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
        'LblToDate.Text = txtTransactionToDate.Text
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim ExportFileName As String = ""
        'If Not Session("LedgerReport-" & Session("UserID")) Is Nothing Then
        '    _tbl = CType(Session("LedgerReport-" & Session("UserID")), DataTable)
        'End If

        Dim Columns As String = "TransactionDate,TransactionCode,AccountHeadName,Particular,Amount,Balance"
        Dim CAry() As String = Columns.Split(",")

        ExportFileName = "attachment; filename=LedgerReport" & Now.ToString("yyyyMMddhhmm") & ".csv"
        Data = Columns '+ ",Balance"
        Dim Dr As Single
        Dim Cr As Single

        Data = Data & Environment.NewLine
        'For i As Integer = 0 To _tbl.Rows.Count - 1
        '    For j As Integer = 0 To CAry.Count - 1
        '        Data = Data & _tbl.Rows(i)(CAry(j)) & ","

        '    Next
        '    Dr += _tbl.Rows(i)("Debit")
        '    Cr += _tbl.Rows(i)("Credit")
        '    Data = Data & Dr - Cr & ","
        '    Data = Data & Environment.NewLine
        'Next

        For i As Integer = 0 To GrdTransactions.Rows.Count - 1
            'For j As Integer = 0 To CAry.Count - 1
            '    Data = Data & _tbl.Rows(i)(CAry(j)) & ","

            'Next



        Next

        Dim row As GridViewRow

        For Each row In GrdTransactions.Rows


            Dim LblTransactionDate As New System.Web.UI.WebControls.Label
            LblTransactionDate = CType(row.Cells(7).FindControl("LblTransactionDate"), Label)
            If Not LblTransactionDate Is Nothing Then
                Data = Data & LblTransactionDate.Text & "," 'TDate
            End If

            Data = Data & CType(row.Cells(3).Controls(0), DataBoundLiteralControl).Text.Trim() & "," 'TCode
            Data = Data & CType(row.Cells(5).Controls(0), DataBoundLiteralControl).Text.Trim() & "," 'THead
            Data = Data & CType(row.Cells(6).Controls(0), DataBoundLiteralControl).Text.Trim() & "," 'Particular
            Data = Data & CType(row.Cells(7).Controls(0), DataBoundLiteralControl).Text.Trim() & "," 'Amount

            Dim BalanceLbl As New System.Web.UI.WebControls.Label
            BalanceLbl = CType(row.Cells(7).FindControl("LblBalance"), Label)
            If Not BalanceLbl Is Nothing Then
                Data = Data & BalanceLbl.Text & "," 'Balance
            End If



            Data = Data & Environment.NewLine
        Next

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", ExportFileName)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 173) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
    End Sub
End Class