﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()> _
<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> _
 Public Class Share
    Inherits System.Web.Services.WebService

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
            <WebMethod()> _
    Public Function SharedData_GetCatagory() As String
        Dim ds As New DataSet
        ds = SharedData.SharedData_GetCatagory()
        ds.Tables(0).TableName = "SharedDataCatagory"
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
        <WebMethod()> _
    Public Function GetSharedDataDetail(ByVal SharedDataID As Integer) As String
        Dim ds As New DataSet
        ds = SharedData.GetSharedDataDetail(SharedDataID)
        ds.Tables(0).TableName = "SharedDataDetail"
        SharedData.LogSharedDataVisit(SharedDataID, HttpContext.Current.Session("UserID"), HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.UserHostAddress)
        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)> _
    <WebMethod(EnableSession:=True)> _
    Public Function GetSharedData(ByVal Category As Integer, ByVal SearchText As String, ByVal Total As String, ByVal SortBy As String, ByVal SortOrder As String, ByVal PageNumber As Integer) As String
        Dim ds As New DataSet
        ds = SharedData.GetSharedData(Category, SearchText, Total, SortBy, SortOrder, PageNumber)
        If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "SharedData"
        Return ds.GetXml
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function UploadData(ByVal Title As String, ByVal Description As String, ByVal URL As String) As Integer
        Dim SharedCatagory As Integer = 1
        Dim PostedBy As Integer = 1
        Dim EmbedScript As String = ""

        If URL.ToLower.IndexOf("youtube") >= 0 Then
            URL = URL.Replace("/watch?v=", "/embed/")
        End If

        If URL.ToLower.IndexOf(".gif") >= 0 OrElse URL.ToLower.IndexOf(".jpg") >= 0 OrElse URL.ToLower.IndexOf(".png") >= 0 OrElse URL.ToLower.IndexOf(".bmp") >= 0 Then
            SharedCatagory = 2
        End If

        SharedData.UploadData(Title, Description, URL, SharedCatagory, EmbedScript, PostedBy, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.Browser.Browser)

        Return 1

    End Function

End Class