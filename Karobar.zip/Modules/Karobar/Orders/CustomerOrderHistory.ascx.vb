﻿Public Class CustomerOrderHistory
    Inherits System.Web.UI.UserControl

    Public Property CustomerID() As Integer
        Get
            Return Val(HdnCustomerID.Value)
        End Get
        Set(value As Integer)
            HdnCustomerID.Value = value

        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Sub LoadData()
        GrdCustomerOrderHistory.DataSource = Products.GetOrdersByUser(LoggedInUserSession.BusinessID, UserID:=CustomerID)
        GrdCustomerOrderHistory.DataBind()
    End Sub


    Private Sub GrdCustomerOrderHistory_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdCustomerOrderHistory.PageIndexChanging
        GrdCustomerOrderHistory.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdCustomerOrderHistory_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdCustomerOrderHistory.RowCommand

    End Sub

    Private Sub GrdCustomerOrderHistory_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdCustomerOrderHistory.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim LnkViewOrder As New System.Web.UI.WebControls.LinkButton
            LnkViewOrder = CType(e.Row.FindControl("LnkViewOrder"), LinkButton)
            If Not LnkViewOrder Is Nothing Then
                LnkViewOrder.OnClientClick = " ShowOrderDetails(" + Val(drview("OrderID")).ToString() + ");return false"
            End If
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub

End Class