﻿Public Class Staff
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        LblStaffFirstName.Text = ReferenceData.Setting("LblStaffFirstName", "First Name", Session("CurrentBusinessID"))
        LblStaffMiddleName.Text = ReferenceData.Setting("LblStaffMiddleName", "Middle Name", Session("CurrentBusinessID"))
        LblStaffLastName.Text = ReferenceData.Setting("LblStaffLastName", "Last Name", Session("CurrentBusinessID"))
        LblStaffDOB.Text = ReferenceData.Setting("LblStaffDOB", "Date of Birth", Session("CurrentBusinessID"))

        LblStaffGender.Text = ReferenceData.Setting("LblStaffGender", "Gender", Session("CurrentBusinessID"))
        LblStaffTitle.Text = ReferenceData.Setting("LblStaffTitle", "Title", Session("CurrentBusinessID"))
        LblMaritalStatus.Text = ReferenceData.Setting("LblMaritalStatus", "Marital Status", Session("CurrentBusinessID"))
        LblStaffHomePhone.Text = ReferenceData.Setting("LblStaffHomePhone", "Home Phone", Session("CurrentBusinessID"))
        LblStaffMobileNo.Text = ReferenceData.Setting("LblStaffMobileNo", "Mobile No", Session("CurrentBusinessID"))
        LblStaffOtherContactNo.Text = ReferenceData.Setting("LblStaffOtherContactNo", "Other Contact #", Session("CurrentBusinessID"))
        LblStaffAddress.Text = ReferenceData.Setting("LblStaffAddress", "Address", Session("CurrentBusinessID"))

        LblStaffEmail.Text = ReferenceData.Setting("LblStaffEmail", "Email", Session("CurrentBusinessID"))
        LblStaffPassword.Text = ReferenceData.Setting("LblStaffPassword", "Password", Session("CurrentBusinessID"))
        LblStaffConfirmPassword.Text = ReferenceData.Setting("LblStaffConfirmPassword", "Confirm Password", Session("CurrentBusinessID"))
        ChkAccountEnabled.Text = ReferenceData.Setting("ChkAccountEnabled", "Account Enable", Session("CurrentBusinessID"))
        LblStaffRoles.Text = ReferenceData.Setting("LblStaffRoles", "Staff Roles", Session("CurrentBusinessID"))
        LblStaffBusinessAccessibility.Text = ReferenceData.Setting("LblStaffBusinessAccessibility", "Business Accessibility", Session("CurrentBusinessID"))
        LblStaffQualification.Text = ReferenceData.Setting("LblStaffQualification", "Qualification", Session("CurrentBusinessID"))

        LblStaffPassingYear.Text = ReferenceData.Setting("LblStaffPassingYear", "Passing year", Session("CurrentBusinessID"))
        LblStaffMarksCGPA.Text = ReferenceData.Setting("LblStaffMarksCGPA", "Marks/CGPA", Session("CurrentBusinessID"))
        LblStaffGradeDivision.Text = ReferenceData.Setting("LblStaffGradeDivision", "Grade/Division", Session("CurrentBusinessID"))
        LblStaffPreviousCompany.Text = ReferenceData.Setting("LblStaffPreviousCompany", "Previous Company", Session("CurrentBusinessID"))
        LblStaffPreviousDesignation.Text = ReferenceData.Setting("LblStaffPreviousDesignation", "Previous Designation", Session("CurrentBusinessID"))
        LblStaffJoiningDate.Text = ReferenceData.Setting("LblStaffJoiningDate", "Joining Date", Session("CurrentBusinessID"))
        LblStaffSalary.Text = ReferenceData.Setting("LblStaffSalary", "Salary", Session("CurrentBusinessID"))

        LblStaffDesignation.Text = ReferenceData.Setting("LblStaffDesignation", "Current Designation", Session("CurrentBusinessID"))
        LblStaffCurrentDepartment.Text = ReferenceData.Setting("LblStaffCurrentDepartment", "Department", Session("CurrentBusinessID"))
        LblStaffCurrentSalary.Text = ReferenceData.Setting("LblStaffCurrentSalary", "Salary", Session("CurrentBusinessID"))
        LblStaffCurrentJoiningDate.Text = ReferenceData.Setting("LblStaffCurrentJoiningDate", "Joining Date", Session("CurrentBusinessID"))





        If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
        End If
        If Not Page.IsPostBack Then
            Dim ds As New DataSet

            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.MaritalStatus * -1)
            DDLMaritalStatus.DataValueField = "ArticleTypeID"
            DDLMaritalStatus.DataTextField = "ArticleType"
            DDLMaritalStatus.DataSource = ds.Tables(0)
            DDLMaritalStatus.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.PersonTitles * -1)
            DDLTitle.DataValueField = "ArticleTypeID"
            DDLTitle.DataTextField = "ArticleType"
            DDLTitle.DataSource = ds.Tables(0)
            DDLTitle.DataBind()

            Dim tbl As New DataTable
            'tbl = Person.GetUserWebsites(Session("CurrentBusinessID"), Session("UserID"))
            'ChkLstBusinessAccessibility.DataValueField = "WebsiteID"
            'ChkLstBusinessAccessibility.DataTextField = "Websitetitle"
            'ChkLstBusinessAccessibility.DataSource = tbl
            'ChkLstBusinessAccessibility.DataBind()

            tbl = Website.GetWebsiteRoles(Session("CurrentBusinessID")).Select("RoleID<>1").CopyToDataTable
            ChkLstUserRoles.DataValueField = "RoleID"
            ChkLstUserRoles.DataTextField = "RoleName"
            ChkLstUserRoles.DataSource = tbl
            ChkLstUserRoles.DataBind()


            If Not Request("SID") Is Nothing Then
                HdnStaffID.Value = Val(Request("SID"))
            End If
            LoadData(Val(HdnStaffID.Value))
        End If
        If Val(HdnStaffID.Value) <= 0 Then
            LblScreenTitle.Text = "Create New Staff"
            StaffImage.ImageUrl = "/Images/NoUserImage.png"
        Else
            LblScreenTitle.Text = "Update Staff"
        End If
    End Sub

    Sub LoadData(ByVal SID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), SID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
        End If
        If tbl.Rows.Count > 0 Then
            txtAddress.Text = IIf(IsDBNull(tbl.Rows(0)("ResidentialAddress")), "", tbl.Rows(0)("ResidentialAddress"))
            txtFirstName.Text = IIf(IsDBNull(tbl.Rows(0)("FirstName")), "", tbl.Rows(0)("FirstName"))
            txtMiddleName.Text = IIf(IsDBNull(tbl.Rows(0)("MiddleName")), "", tbl.Rows(0)("MiddleName"))
            txtLastName.Text = IIf(IsDBNull(tbl.Rows(0)("LastName")), "", tbl.Rows(0)("LastName"))
            txtHomePhone.Text = IIf(IsDBNull(tbl.Rows(0)("TelephoneNo")), "", tbl.Rows(0)("TelephoneNo"))
            txtEmail.Text = IIf(IsDBNull(tbl.Rows(0)("EmailAddress")), "", tbl.Rows(0)("EmailAddress"))
            txtMobileNo.Text = IIf(IsDBNull(tbl.Rows(0)("MobileNo")), "", tbl.Rows(0)("MobileNo"))
            txtOtherContactNo.Text = IIf(IsDBNull(tbl.Rows(0)("OtherContactNo")), "", tbl.Rows(0)("OtherContactNo"))
            DDLTitle.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Title")), "", tbl.Rows(0)("Title"))
            DDLGender.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Gender")), "", tbl.Rows(0)("Gender"))
            If IsDBNull(tbl.Rows(0)("DateOfBirth")) = False Then
                txtDateOfBirth.Text = CDate(tbl.Rows(0)("DateOfBirth")).ToString("dd-MM-yyyy")
            End If

            txtPassword.Text = IIf(IsDBNull(tbl.Rows(0)("Password")), "", tbl.Rows(0)("Password"))
            txtConfirmPassword.Text = IIf(IsDBNull(tbl.Rows(0)("Password")), "", tbl.Rows(0)("Password"))
            ChkAccountEnabled.Checked = IIf(IsDBNull(tbl.Rows(0)("WebAccess")), False, tbl.Rows(0)("WebAccess"))

            ClientScript.RegisterClientScriptBlock(Me.GetType(), "SetPwd", "<script>$(document).ready(function () {$('#" & txtPassword.ClientID & "').val('" & tbl.Rows(0)("Password") & "');$('#" & txtConfirmPassword.ClientID & "').val('" & tbl.Rows(0)("Password") & "');})</script>")

            If (IsDBNull(tbl.Rows(0)("ImageFilename")) = False AndAlso tbl.Rows(0)("ImageFilename") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/AdminUser/Images" '' "~/CMS/" & Session("CurrentBusinessID") & "/Staff/Images"
                HdnStaffImageFilename.Value = tbl.Rows(0)("ImageFilename")
                StaffImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ImageFilename")
                StaffImage.AlternateText = txtFirstName.Text & " " & txtLastName.Text
            Else
                StaffImage.ImageUrl = "/Images/NoUserImage.png"
            End If


            If tbl.Rows(0)("AccountTypeID") = Person.UserTypes.Staff Then
                If ds.Tables.Count > 1 Then
                    Dim EduDtltbl As New DataTable
                    EduDtltbl = ds.Tables(1)
                    If EduDtltbl.Rows.Count > 0 Then
                        txtPassingYear.Text = IIf(IsDBNull(EduDtltbl.Rows(0)("FromDate")), "", EduDtltbl.Rows(0)("FromDate"))
                        txtQualification.Text = IIf(IsDBNull(EduDtltbl.Rows(0)("Degree")), "", EduDtltbl.Rows(0)("Degree"))
                        txtMarksCGPA.Text = IIf(IsDBNull(EduDtltbl.Rows(0)("CGPA")), "", EduDtltbl.Rows(0)("CGPA"))
                        txtGradeDivision.Text = IIf(IsDBNull(EduDtltbl.Rows(0)("Division")), "", EduDtltbl.Rows(0)("Division"))
                    End If
                End If
                If ds.Tables.Count > 2 Then
                    Dim PreviousJobDtltbl As New DataTable
                    PreviousJobDtltbl = ds.Tables(2)
                    If PreviousJobDtltbl.Rows.Count > 0 Then
                        txtPreviousCompanyName.Text = IIf(IsDBNull(PreviousJobDtltbl.Rows(0)("PreviousCompanyName")), "", PreviousJobDtltbl.Rows(0)("PreviousCompanyName"))
                        txtPrviouseDesgination.Text = IIf(IsDBNull(PreviousJobDtltbl.Rows(0)("PreviousJobDesignation")), "", PreviousJobDtltbl.Rows(0)("PreviousJobDesignation"))
                        txtPreviousJobSalary.Text = IIf(IsDBNull(PreviousJobDtltbl.Rows(0)("PreviousJobSalary")), "", PreviousJobDtltbl.Rows(0)("PreviousJobSalary"))
                        txtPreviousJobJoiningDate.Text = IIf(IsDBNull(PreviousJobDtltbl.Rows(0)("PreviousJobJoiningDate")), "", PreviousJobDtltbl.Rows(0)("PreviousJobJoiningDate"))
                    End If
                End If

                If ds.Tables.Count >= 3 Then
                    Dim CurrentJobDtltbl As New DataTable
                    CurrentJobDtltbl = ds.Tables(3)
                    If CurrentJobDtltbl.Rows.Count > 0 Then
                        txtCurrentJobDepartment.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Department")), "", CurrentJobDtltbl.Rows(0)("Department"))
                        txtCurrentJobDesignation.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Designation")), "", CurrentJobDtltbl.Rows(0)("Designation"))
                        txtCurrentJobSalary.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Salary")), "", CurrentJobDtltbl.Rows(0)("Salary"))
                        txtCurrentJobJoiningDate.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("JoiningDate")), "", CurrentJobDtltbl.Rows(0)("JoiningDate"))
                    End If
                End If

                ''If ds.Tables.Count >= 4 Then
                ''Dim TblUserBusinessAccess As New DataTable
                ''TblUserBusinessAccess = ds.Tables(4)
                'For i As Integer = 0 To TblUserBusinessAccess.Rows.Count - 1
                '    For j As Integer = 0 To ChkLstBusinessAccessibility.Items.Count - 1
                '        If ChkLstBusinessAccessibility.Items(j).Value = TblUserBusinessAccess.Rows(i)("WebsiteID") Then
                '            ChkLstBusinessAccessibility.Items(j).Selected = True
                '        End If
                '    Next
                'Next
                ''End If

                tbl = New DataTable
                tbl = Website.User.GetPersonRoles(SID)
                For i As Integer = 0 To tbl.Rows.Count - 1
                    For j = 0 To ChkLstUserRoles.Items.Count - 1
                        If ChkLstUserRoles.Items(j).Value = tbl.Rows(i)("RoleID") Then
                            ChkLstUserRoles.Items(j).Selected = True
                        End If
                    Next
                Next
            End If
        End If


    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim UserImageFilename As String = HdnStaffImageFilename.Value

        If FileUploadStaffImage.PostedFile.FileName <> "" AndAlso FileUploadStaffImage.PostedFile.FileName <> UserImageFilename Then
            UserImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadStaffImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Session("CurrentBusinessID") & "/Staff/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If

            FileUploadStaffImage.SaveAs(BusinessDirectory & "/" & UserImageFilename)
        End If
        Dim SelectedBusiness As String = ""
        For i As Integer = 0 To ChkLstBusinessAccessibility.Items.Count - 1
            If ChkLstBusinessAccessibility.Items(i).Selected Then
                SelectedBusiness = SelectedBusiness & ChkLstBusinessAccessibility.Items(i).Value & ","
            End If
        Next

        Dim DOBAry() = txtDateOfBirth.Text.Replace("/", "-").Split("-")

        If Val(HdnStaffID.Value) > 0 Then
            tbl = Person.UpdateDetails(Session("CurrentBusinessID"), Val(HdnStaffID.Value), txtEmail.Text.Trim, txtConfirmPassword.Text, txtFirstName.Text.Trim, txtMiddleName.Text.Trim, txtLastName.Text.Trim, DDLTitle.SelectedItem.Value, _
            DDLGender.SelectedItem.Value, CDate(DOBAry(1) & "-" & DOBAry(0) & "-" & DOBAry(2)), DDLMaritalStatus.SelectedItem.Value, txtHomePhone.Text.Trim, txtMobileNo.Text.Trim, txtOtherContactNo.Text.Trim, _
             txtEmail.Text.Trim, txtAddress.Text.Trim, Person.UserTypes.Staff, -1, ChkAccountEnabled.Checked, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, "", "")
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    Person.AddUserEducation(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), "", txtQualification.Text.Trim, txtPassingYear.Text, "", txtMarksCGPA.Text.Trim, txtGradeDivision.Text.Trim, "")
                    Person.AddUserAddiotionalDetails(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), txtPreviousCompanyName.Text, txtPrviouseDesgination.Text.Trim, txtPreviousJobJoiningDate.Text.Trim, txtPreviousJobSalary.Text.Trim, "", "")
                    Person.AddUserCurrentJobDetails(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), txtCurrentJobDesignation.Text.Trim, txtCurrentJobDepartment.Text.Trim, txtCurrentJobSalary.Text.Trim, txtCurrentJobJoiningDate.Text.Trim, "", "")

                    ''Person.AssignUserWebsiteAccess(SelectedBusiness, tbl.Rows(0)("UserID"))
                    Person.AssignUserWebsiteAccess(Session("CurrentBusinessID") & ",", tbl.Rows(0)("UserID"))

                    Dim Roles As String = ""
                    For i As Integer = 0 To ChkLstUserRoles.Items.Count - 1
                        If ChkLstUserRoles.Items(i).Selected = True Then
                            Roles = Roles & ChkLstUserRoles.Items(i).Value & ","
                        End If
                    Next
                    Roles = Roles & "6,7,"
                    If Roles.Length > 0 Then Roles = Roles.Substring(0, Roles.Length - 1)
                    Website.User.UpdatePersonRoles(tbl.Rows(0)("UserID"), Roles)

                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Staff updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatingIssue", "<script>parent.ShowMessage('Unable to add staff','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If

        Else
            tbl = Person.AddUser(Session("CurrentBusinessID"), txtEmail.Text.Trim, txtConfirmPassword.Text, txtFirstName.Text.Trim, txtMiddleName.Text.Trim, txtLastName.Text.Trim, DDLTitle.SelectedItem.Value, _
                        DDLGender.SelectedItem.Value, CDate(DOBAry(1) & "-" & DOBAry(0) & "-" & DOBAry(2)), DDLMaritalStatus.SelectedItem.Value, txtHomePhone.Text.Trim, txtMobileNo.Text.Trim, txtOtherContactNo.Text.Trim, _
                         txtEmail.Text.Trim, txtAddress.Text.Trim, Person.UserTypes.Staff, -1, ChkAccountEnabled.Checked, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, "", "", ParentAccountHeadID:=ReferenceData.Setting("StaffAccountHeadID", "31", Session("CurrentBusinessID")))
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    Person.AddUserEducation(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), "", txtQualification.Text.Trim, txtPassingYear.Text, "", txtMarksCGPA.Text.Trim, txtGradeDivision.Text.Trim, "")
                    Person.AddUserAddiotionalDetails(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), txtPreviousCompanyName.Text, txtPrviouseDesgination.Text.Trim, txtPreviousJobJoiningDate.Text.Trim, txtPreviousJobSalary.Text.Trim, "", "")
                    Person.AddUserCurrentJobDetails(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"), txtCurrentJobDesignation.Text.Trim, txtCurrentJobDepartment.Text.Trim, txtCurrentJobSalary.Text.Trim, txtCurrentJobJoiningDate.Text.Trim, "", "")
                    ''Person.AssignUserWebsiteAccess(SelectedBusiness, tbl.Rows(0)("UserID"))
                    Person.AssignUserWebsiteAccess(Session("CurrentBusinessID"), tbl.Rows(0)("UserID"))


                    Dim Roles As String = ""
                    For i As Integer = 0 To ChkLstUserRoles.Items.Count - 1
                        If ChkLstUserRoles.Items(i).Selected = True Then
                            Roles = Roles & ChkLstUserRoles.Items(i).Value & ","
                        End If
                    Next
                    Roles = Roles & "6,7,"
                    If Roles.Length > 0 Then Roles = Roles.Substring(0, Roles.Length - 1)
                    Website.User.UpdatePersonRoles(tbl.Rows(0)("UserID"), Roles)
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Staff added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffUpdatingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "StaffAddingIssue", "<script>parent.ShowMessage('Unable to add staff','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        End If
        
    End Sub

    Private Sub LnkEmployementDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkEmployementDetails.Click
        TblPersonalDetails.Visible = False
        EmployeeQualification.Visible = True
    End Sub

    Private Sub LnkStaffPersonalDetails_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkStaffPersonalDetails.Click
        TblPersonalDetails.Visible = True
        EmployeeQualification.Visible = False
    End Sub
End Class