﻿Public Class ProfileSettings
    Inherits System.Web.UI.Page



    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "DemoBusiness", "<script>parent.ShowMessage('Update/Delete is disabled on demo business ','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Exit Sub
        End If

        Dim tbl As New DataTable
        Dim UserImageFilename As String = HdnUserImageFileName.Value


        If FileUploadUserImage.PostedFile.FileName <> "" AndAlso FileUploadUserImage.PostedFile.FileName <> UserImageFilename Then
            UserImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadUserImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/") & "/AdminUser/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If
            Session("UserImage") = UserImageFilename
            FileUploadUserImage.SaveAs(BusinessDirectory & "/" & UserImageFilename)
        End If


        tbl = Person.UpdateProfileSettings(Session("UserID"), txtUserName.Text, "", "", txtCurrentPassword.Text, txtNewPassword.Text, UserImageFilename)
        If tbl.Rows(0)("err") = "1" Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProfileSettingsUpdatedIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errmsg") & "','1',$(window).height()*2/100,$(window).width()*40/100)</script>")
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProfileSettingsUpdatedSuccessFully", "<script>parent.HideDlgForm();parent.ShowMessage('Profile settings updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
        End If
        LoadData()
    End Sub

    Private Sub ProfileSettings_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Page.IsPostBack = False Then
            LoadData()
        End If


    End Sub

    Sub LoadData()
        Dim ds As New DataSet
        ds = Person.GetUserDetail(-1, Session("UserID"))
        If ds.Tables.Count > 0 Then
            If ds.Tables(0).Rows.Count > 0 Then

                txtUserName.Text = ds.Tables(0).Rows(0)("FirstName")
                Dim BusinessDirectory As String = "~/CMS/AdminUser/Images"
                

                If IsDBNull(ds.Tables(0).Rows(0)("ImageFilename")) = False AndAlso ds.Tables(0).Rows(0)("ImageFilename") <> "" Then
                    UserImage.ImageUrl = BusinessDirectory & "/" & ds.Tables(0).Rows(0)("ImageFilename")
                    HdnUserImageFileName.Value = ds.Tables(0).Rows(0)("ImageFilename")
                Else
                    UserImage.ImageUrl = "/Images/NoUserImage.png"
                End If

            End If
        End If
    End Sub
End Class