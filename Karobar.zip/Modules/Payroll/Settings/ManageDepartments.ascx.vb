﻿Public Class ManageDepartments
    Inherits System.Web.UI.UserControl


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
            If GrdDepartments.Rows.Count > 0 Then
                GrdDepartments.Columns(2).Visible = True
                GrdDepartments.Columns(3).Visible = True
                GrdDepartments.Columns(4).Visible = False
            Else
                GrdDepartments.Columns(2).Visible = False
                GrdDepartments.Columns(3).Visible = False
                GrdDepartments.Columns(4).Visible = True
            End If
        End If

    End Sub


    Sub LoadData()
        GrdDepartments.DataSource = Payroll.GetDepartments(Session("CurrentBusinessID"))
        GrdDepartments.DataBind()
    End Sub

    Private Sub GrdDepartments_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdDepartments.RowCommand
        If e.CommandName = "AddNewDepartment" Then
            GrdDepartments.ShowFooter = True
            GrdDepartments.Columns(2).Visible = False
            GrdDepartments.Columns(3).Visible = False
            GrdDepartments.Columns(4).Visible = True
        ElseIf e.CommandName = "SaveNewDepartment" Then
            Dim DepartmentName As String = CType(GrdDepartments.FooterRow.FindControl("txtDepartmentName"), TextBox).Text
            Dim Visible As Boolean = CType(GrdDepartments.FooterRow.FindControl("chkVisible"), CheckBox).Checked
            Payroll.AddDepartment(Session("CurrentBusinessID"), DepartmentName, Visible)
            GrdDepartments.Columns(2).Visible = True
            GrdDepartments.Columns(3).Visible = True
            GrdDepartments.Columns(4).Visible = False
        ElseIf e.CommandName = "Insert" Then

        ElseIf e.CommandName = "Cancel" Then
            GrdDepartments.ShowFooter = False
            GrdDepartments.EditIndex = -1
            GrdDepartments.Columns(7).Visible = True
            GrdDepartments.Columns(8).Visible = True
            GrdDepartments.Columns(9).Visible = False
        ElseIf e.CommandName = "DeleteDepartment" Then
            Dim ID As Integer = Val(e.CommandArgument)
            Payroll.DeleteDepartment(ID)
        ElseIf e.CommandName = "Edit" Then
            GrdDepartments.Columns(2).Visible = True
            GrdDepartments.Columns(3).Visible = True
            GrdDepartments.Columns(4).Visible = False
            GrdDepartments.ShowFooter = False
        ElseIf e.CommandName = "Update" Then
            Dim ID As Integer = Val(CType(GrdDepartments.Rows(GrdDepartments.EditIndex).FindControl("HdnDepartmentID"), HiddenField).Value)
            Dim DepartmentName As String = CType(GrdDepartments.Rows(GrdDepartments.EditIndex).FindControl("txteditDepartmentName"), TextBox).Text
            Dim Visible As Boolean = CType(GrdDepartments.Rows(GrdDepartments.EditIndex).FindControl("chkEditVisible"), CheckBox).Checked

            Payroll.UpdateDepartment(ID, DepartmentName, Visible)
            GrdDepartments.EditIndex = -1
            GrdDepartments.Columns(2).Visible = True
            GrdDepartments.Columns(3).Visible = True
            GrdDepartments.Columns(4).Visible = False
        End If
        LoadData()

    End Sub

    Private Sub GrdDepartments_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdDepartments.RowEditing
        GrdDepartments.EditIndex = e.NewEditIndex
        GrdDepartments.DataBind()
    End Sub

    Private Sub GrdDepartments_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdDepartments.RowCancelingEdit
        GrdDepartments.EditIndex = -1
        GrdDepartments.DataBind()
    End Sub

    Protected Sub LnkAddDepartment_Click(sender As Object, e As EventArgs) Handles LnkAddDepartment.Click
        GrdDepartments.ShowFooter = True
        GrdDepartments.Columns(2).Visible = False
        GrdDepartments.Columns(3).Visible = False
        GrdDepartments.Columns(4).Visible = True
        GrdDepartments.EditIndex = -1
        ''LoadData()
        Dim dr As DataRow
        Dim tbl As New DataTable
        tbl = Payroll.GetDepartments(Session("CurrentBusinessID"))
        dr = tbl.NewRow
        tbl.Rows.InsertAt(dr, 0)
        GrdDepartments.DataSource = tbl
        GrdDepartments.DataBind()
    End Sub
End Class