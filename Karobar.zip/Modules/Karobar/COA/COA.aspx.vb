﻿Public Class COA
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 40) = False Then ' And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then
            DDLAccountGroup.AddNewItem("None", "-1", "font-weight:bold; font-size:11pt")
            ''LoadCOADDL()
            ChartOfAccount.LoadCOADDL(DDLAccountGroup)
            If Not Request("AHID") Is Nothing Then
                HdnAHID.Value = Val(Request("AHID"))
                Dim tbl As New DataTable
                tbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), AccountHeadID:=Val(HdnAHID.Value))
                If tbl.Rows.Count > 0 Then
                    txtAccountCode.Text = tbl.Rows(0)("AccountHeadCode")
                    txtAccountName.Text = tbl.Rows(0)("AccountHeadName")
                    txtAccountDescription.Text = tbl.Rows(0)("AccountHeadDescription")
                    DDLAccountStatus.SelectedValue = tbl.Rows(0)("AccountStatus")
                    DDLAccountGroup.SelectedValue = tbl.Rows(0)("ParentAccountHeadID")
                End If
            End If
        End If

        BtnSave.Enabled = (ReferenceData.Setting("EnabledCOADeleteAddEditFunctionality", "No") = "Yes")
    End Sub

    Sub LoadCOADDL()
        Dim tbl As New DataTable
        Dim ParentHeads As New DataTable
        tbl = ChartOfAccount.GetCOA(Session("CurrentBusinessID"))

        If tbl.Rows.Count > 0 Then
            ParentHeads = tbl.Select("ParentAccountHeadID=-1").CopyToDataTable
            For i As Integer = 0 To ParentHeads.Rows.Count - 1
                If ChartOfAccount.ShowAccountHeadCode = "No" Then
                    DDLAccountGroup.AddNewItem(ParentHeads.Rows(i)("AccountHeadName"), ParentHeads.Rows(i)("AccountHeadID"), "font-weight:bold; font-size:11pt")
                Else
                    DDLAccountGroup.AddNewItem(ParentHeads.Rows(i)("AccountHeadCode") & "-" & ParentHeads.Rows(i)("AccountHeadName"), ParentHeads.Rows(i)("AccountHeadID"), "font-weight:bold; font-size:11pt")
                End If

                AddCOAItem(DDLAccountGroup, tbl, ParentHeads.Rows(i), 0)
            Next
        End If
    End Sub

    Sub AddCOAItem(ByRef DDLAccountGroup As GenericDropDown, ByVal tbl As DataTable, ByVal COAHeadRow As DataRow, Optional ByVal Padding As Integer = 0)
        Dim childtblrows() As DataRow
        childtblrows = tbl.Select("ParentAccountHeadID=" & COAHeadRow("AccountHeadID"), " AccountHeadName Asc")

        If childtblrows.Count() > 0 Then
            Padding += 30
            For Each dr In childtblrows
                If ChartOfAccount.ShowAccountHeadCode = "No" Then
                    DDLAccountGroup.AddNewItem(dr("AccountHeadName"), dr("AccountHeadID"), "padding-left:" & Padding & "px;font-weight:bold; font-size:10pt")
                Else
                    DDLAccountGroup.AddNewItem(dr("AccountHeadCode") & "-" & dr("AccountHeadName"), dr("AccountHeadID"), "padding-left:" & Padding & "px;font-weight:bold; font-size:10pt")
                End If
                AddCOAItem(DDLAccountGroup, tbl, dr, Padding)
            Next
        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        If Val(HdnAHID.Value) > 0 Then
            tbl = ChartOfAccount.UpdateCOAAccountHead(Session("CurrentBusinessID"), Val(HdnAHID.Value), txtAccountCode.Text.Trim, txtAccountName.Text.Trim, DDLAccountGroup.SelectedValue, txtAccountDescription.Text.Trim, DDLAccountStatus.SelectedItem.Value)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "AccountHeadUpdatedSuccessFully", "<script>parent.ShowMessage('Account head updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100)</script>")
        Else
            tbl = ChartOfAccount.AddCOAAccountHead(Session("CurrentBusinessID"), txtAccountCode.Text.Trim, txtAccountName.Text.Trim, DDLAccountGroup.SelectedValue, txtAccountDescription.Text.Trim, DDLAccountStatus.SelectedItem.Value)
            If tbl.Rows.Count = 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "AccountHeadAlreadyExist", "<script>parent.ShowMessage('Account head code already exist!','1',$(window).height()*2/100,$(window).width()*46/100)</script>")
            Else
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "COA", "Added New Account Head " & txtAccountName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "AccountHeadAddedSuccessFully", "<script>parent.ShowMessage('Account head added successfully!','0',$(window).height()*2/100,$(window).width()*46/100)</script>")
                txtAccountCode.Text = ""
                txtAccountName.Text = ""
                txtAccountDescription.Text = ""
                DDLAccountStatus.SelectedValue = ""
                LoadCOADDL()
            End If
        End If
        
    End Sub
End Class