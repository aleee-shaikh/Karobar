﻿Public Class BusinessPage
    Inherits WebPage


    Private Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

End Class