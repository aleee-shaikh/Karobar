function COA_GetBusinessDetail(BID) {
    var Data = [];
    var RequestData = {
        BID: BID
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/COA_GetBusinessDetails',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("BusinessDetails").length;
            if (Count == 0) {
                ;
            }
            else {
                //alert(JSON.stringify(xml))
                $(xml).find("BusinessDetails").each(function () {
                    Data.push({
                        BusinessID: $(this).find("WebsiteID").text(),
                        BusinessTitle: $(this).find("WebsiteTitle").text(),
                        BusinessDescription: $(this).find("WebsiteDescription").text(),
                        BusinessLogo: $(this).find("WebsiteLogo").text(),
                        Fax: $(this).find("Fax").text(),
                        Phone: $(this).find("Phone").text(),
                        Email: $(this).find("Email").text(),
                        City: $(this).find("City").text(),
                        Town: $(this).find("Town").text(),
                        ZipCode: $(this).find("ZipCode").text(),
                        Currency: $(this).find("CurrencyCode").text(),
                        CategoryID: $(this).find("WebsiteCategoryID").text(),
                        CategoryTitle: $(this).find("CategoryTitle").text(),
                        ThemeID: $(this).find("ThemeID").text(),
                        Address: $(this).find("Address").text(),
                        FacebookLink: $(this).find("FacebookLink").text(),
                        LinkedInLink: $(this).find("LinkedLink").text(),
                        TwitterLink: $(this).find("TwitterLink").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert("error:"+xhr.responseText);
        }
    });
    return Data
}

function COA_GetRecentTransactions(ControlID) {
    var HeadsData = [];
    var Data = []
    var RequestData = {
        AccountHeadIDs: ''
    };


    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Common.asmx/COA_GetRecentTransactions',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("RecentTransactions").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("RecentTransactions").each(function () {
                    Data.push({
                        TransactionID: $(this).find("TransactionID").text(),
                        Particular: $(this).find("Particular").text(),
                        Amount: $(this).find("TransactionAmount").text(),
                        Dated: $(this).find("TransactionDate").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });


    return Data;
}

function GetAccountHeadsLog(ControlID, Clicked) {
    var logids = $('#hdnNewNotifications').val()
    var HeadsData = [];
    var Data = []
    var RequestData = {
        AccountHeadIDs: '',
        LogIDs: logids
    };
   
   
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Common.asmx/COA_GetAccountsHeadLog',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("AccountsHeadLog").length;
            
            if (Count == 0) {
                ;
            }
            else {
                var TIDs = ''
                $(xml).find("AccountsHeadLog").each(function () {

                    if (TIDs.indexOf(('<' + $(this).find("TransactionID").text() + '>')) < 0 && $(this).find("NewLogCount").text() != '-1') {
                        Data.push({
                            TransactionID: $(this).find("ID").text(),
                            Particular: $(this).find("Particular").text(),
                            TransactionCode: $(this).find("TransactionCode").text(),
                            Dated: getDateTimeDifference(new Date($(this).find("Dated").text()), new Date()) + " ago",//$(this).find("Dated").text(),
                            Amount: $(this).find("TransactionAmount").text(),
                            ID: $(this).find("ID").text(),
                            NewLogCount: ($(this).find("NewLogCount").text() != '' && $(this).find("NewLogCount").text() > 0) ? $(this).find("NewLogCount").text() : -1
                        });
                        TIDs = TIDs + '<' + $(this).find("TransactionID").text() + '>'
                    }
                });


                //prompt('',JSON.stringify(AccountHeadsLogData))
                var NewNotificationFound = 0
                var logCnt = 0;
                var NewLogCount = 0;
                if (Data.length > 0) {
                    for (var i = 0; i < Data.length; i++) {
                        if (Data[i].NewLogCount > 0) {
                            NewLogCount += parseInt(Data[i].NewLogCount)

                            logCnt = Data[i].NewLogCount

                            NewNotificationFound = 1
                        }
                    }

                    $('#notification_count').html((NewLogCount > 9) ? "9+" : NewLogCount)
                    $('#notification_count').show()
                    //if (logCnt>0)
                    //document.title = "(" + logCnt + ") - " + document.title

                    if (NewNotificationFound == 0)
                        $('#notification_count').hide()


                    var newlogids = ''
                    if (Clicked == true) {

                        for (var i = 0; i < Data.length; i++) {
                            if (Data[i].NewLogCount != '-1')
                                newlogids = newlogids + Data[i].TransactionID + ','
                        }
                        $('#hdnNewNotifications').val(newlogids);
                        $('#notification_count').html('')
                        $('#notification_count').hide()
                        LoadNotifications(false)
                    }
                    //alert(newlogids + ',     ' + $('#hdnNewNotifications').val())

                    my.utils.renderExternalTemplate("Shared/Templates/Notification_AlertRows", "#notificationsBody", Data);


                }
                

            }
        },
        error: function (xhr, status, errord) {
            //alert("Notif error : "+xhr.responseText);
        }
    });


    return Data;
}


function COA_GetPurchaseSummary(ControlID, ProductIDs) {
    var RequestData = {
        ProductIDs: ProductIDs
    };
    var HeadsData = [];
    var PurchaseSummaryData = []
    var HeadIDsAry //= AccountHeads.split(",")

    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Common.asmx/COA_GetPurchaseSummary',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("PurchaseSummary").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("PurchaseSummary").each(function () {
                    PurchaseSummaryData.push({
                        TodaysPurchaseAmount: $(this).find("TodaysPurchaseAmount").text(),
                        YesterdayPurchaseAmount: $(this).find("YesterdayPurchaseAmount").text(),
                        ThisMonthPurchaseAmount: $(this).find("ThisMonthPurchaseAmount").text(),
                        Last6MonthsPurchaseAmount: $(this).find("Last6MonthsPurchaseAmount").text(),
                        Last12MonthsPurchaseAmount: $(this).find("Last12MonthsPurchaseAmount").text()
                    });
                });

                $('#TodaysPurchaseAmount').html(PurchaseSummaryData[0].TodaysPurchaseAmount)
                $('#YesterdayPurchaseAmount').html(PurchaseSummaryData[0].YesterdayPurchaseAmount)
                $('#ThisMonthPurchaseAmount').html(PurchaseSummaryData[0].ThisMonthPurchaseAmount)
                $('#Last6MonthsPurchaseAmount').html(PurchaseSummaryData[0].Last6MonthsPurchaseAmount)
                $('#Last12MonthsPurchaseAmount').html(PurchaseSummaryData[0].Last12MonthsPurchaseAmount)
            }
        },
        error: function (xhr, status, errord) {
            //alert(xhr.responseText);
        }
    });


    return PurchaseSummaryData;
}


function COA_GetExpenseSummary(ControlID) {
    
    var HeadsData = [];
    var ExpenseData = []
    var HeadIDsAry //= AccountHeads.split(",")

    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        //data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Common.asmx/COA_GetExpenseSummary',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("ExpenseSummary").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("ExpenseSummary").each(function () {
                    ExpenseData.push({
                        TodaysExpenseAmount: $(this).find("TodaysExpenseAmount").text(),
                        YesterdayExpenseAmount: $(this).find("YesterdayExpenseAmount").text(),
                        ThisMonthExpenseAmount: $(this).find("ThisMonthExpenseAmount").text(),
                        Last6MonthsExpenseAmount: $(this).find("Last6MonthsExpenseAmount").text(),
                        Last12MonthsExpenseAmount: $(this).find("Last12MonthsExpenseAmount").text()
                    });
                });

                $('#TodaysExpenseAmount').html(ExpenseData[0].TodaysExpenseAmount)
                $('#YesterdayExpenseAmount').html(ExpenseData[0].YesterdayExpenseAmount)
                $('#ThisMonthExpenseAmount').html(ExpenseData[0].ThisMonthExpenseAmount)
                $('#Last6MonthsExpenseAmount').html(ExpenseData[0].Last6MonthsExpenseAmount)
                $('#Last12MonthsExpenseAmount').html(ExpenseData[0].Last12MonthsExpenseAmount)
            }
        },
        error: function (xhr, status, errord) {
            //alert(xhr.responseText);
        }
    });


    return ExpenseData;
}


function COA_GetSaleSummary(ControlID,ProductIDs) {
    var RequestData = {
        ProductIDs: ProductIDs
    };
    var HeadsData = [];
    var SaleData = []
    var HeadIDsAry //= AccountHeads.split(",")

    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Common.asmx/COA_GetSaleSummary',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("SaleSummary").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("SaleSummary").each(function () {
                    SaleData.push({
                        TodaysSaleAmount: $(this).find("TodaysSaleAmount").text(),
                        YesterdaySaleAmount: $(this).find("YesterdaySaleAmount").text(),
                        ThisMonthSaleAmount: $(this).find("ThisMonthSaleAmount").text(),
                        Last6MonthsSaleAmount: $(this).find("Last6MonthsSaleAmount").text(),
                        Last12MonthsSaleAmount: $(this).find("Last12MonthsSaleAmount").text()
                    });
                });

                $('#TodaysSaleAmount').html(SaleData[0].TodaysSaleAmount)
                $('#YesterdaySaleAmount').html(SaleData[0].YesterdaySaleAmount)
                $('#ThisMonthSaleAmount').html(SaleData[0].ThisMonthSaleAmount)
                $('#Last6MonthsSaleAmount').html(SaleData[0].Last6MonthsSaleAmount)
                $('#Last12MonthsSaleAmount').html(SaleData[0].Last12MonthsSaleAmount)
            }
        },
        error: function (xhr, status, errord) {
            //alert(xhr.responseText);
        }
    });


    return SaleData;
}


function COA_GetAccountsHeadSummary(ControlID, AccountHeadIDs) {
    var RequestData = {
        AccountHeadIDs: AccountHeadIDs
    };
    var HeadsData = [];
    var Data=[]
    var HeadIDsAry=AccountHeads.split(",")

    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: true,
        url: '/Webservice/Common.asmx/COA_GetAccountsHeadSummary',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("AccountsHeadSummary").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("AccountsHeadSummary").each(function () {
                    Data.push({
                        AccountHeadID: $(this).find("AccountHeadID").text(),
                        ParentAccountHeadID: $(this).find("ParentAccountHeadID").text(),
                        AccountHeadName: $(this).find("AccountHeadName").text(),
                        Debit: $(this).find("Debit").text(),
                        Credit: $(this).find("Credit").text(),
                        Balance: $(this).find("Balance").text()
                    });
                });
            }

            if (isActive == true) {
                //AccountsSummaryData = COA_GetAccountsHeadSummary('{{:ControlID}}', AccountHeads)
                for (var i = 0; i < Data.length; i++) {
                    $('#' + Data[i].AccountHeadName.replace(/ /g, '')).html(Data[i].Balance)
                }

                //$('#AccountReceiveable').html(parseFloat($('#AccountReceiveable').html()) - parseFloat($('#SaleOnCash').html()))
                setTimeout("COA_GetAccountsHeadSummary('" + ControlID + "','" + AccountHeadIDs+"')", 60000)
            }
        },
        error: function (xhr, status, errord) {
            //alert(xhr.responseText);
        }
    });
     
     
    return Data;
}
