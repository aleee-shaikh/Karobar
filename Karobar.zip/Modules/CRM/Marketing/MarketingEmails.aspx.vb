﻿Public Class MarketingEmails
    Inherits System.Web.UI.Page

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then

            LblScreenTitle.Text = ReferenceData.Setting("LblEmailMarketing", "Email Marketing", Session("CurrentBusinessID"))
            LoadEmailTemplates()
        End If
    End Sub

    Sub LoadEmailTemplates()
        DDLEmails.DataValueField = "EmailTemplateID"
        DDLEmails.DataTextField = "EmailSubject"
        DDLEmails.DataSource = WebsiteEmail.GetExistingEmails()
        DDLEmails.DataBind()
        If Page.IsPostBack Then DDLEmails.SelectedIndex = DDLEmails.Items.Count - 1
    End Sub

    Private Sub BtnSend_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSend.Click
        Dim NewEmailTemplateID As Integer = -1
        Dim ToEmailAddresses As String = ""

        If RdoAllUsers.Checked Then
            Dim tbl As New DataTable
            tbl = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
            For i As Integer = 0 To tbl.Rows.Count - 1
                ToEmailAddresses = ToEmailAddresses & tbl.Rows(i)("LoginID") & ";"
            Next
        Else
            Dim UsersIds As String = ""
            For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
                Dim chk As New CheckBox
                Dim HdnLoginID As New HiddenField
                chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
                HdnLoginID = CType(GrdWebsiteUsers.Rows(i).FindControl("HdnToEmailAddress"), HiddenField)
                If chk.Checked Then
                    ToEmailAddresses = ToEmailAddresses & HdnLoginID.Value & ";"
                End If
            Next
        End If

        If DDLEmails.SelectedIndex = 0 Then
            NewEmailTemplateID = WebsiteEmail.SaveNewEmailTemplate(txtEmailSubject.Text.Trim, ContentEditor1.Text, "", HttpContext.Current.Session("UserID"), ToEmailAddresses, txtBCC.Text.Trim(), txtCC.Text.Trim())
            LoadEmailTemplates()
        Else
            WebsiteEmail.SaveNewEmailTemplate(txtEmailSubject.Text.Trim, ContentEditor1.Text, "", HttpContext.Current.Session("UserID"), ToEmailAddresses, txtBCC.Text.Trim(), txtCC.Text.Trim(), DDLEmails.SelectedValue)
            NewEmailTemplateID = DDLEmails.SelectedValue
            LoadEmailTemplates()
        End If

        If NewEmailTemplateID > 0 Then
            WebsiteEmail.SendToEmailQueue(NewEmailTemplateID, -1, Now)
        Else
            WebsiteEmail.SendToEmailQueue(DDLEmails.SelectedItem.Value, -1, Now)
        End If
        'If RdoAllUsers.Checked Then
        '    Dim tbl As New DataTable
        '    tbl = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
        '    For i As Integer = 0 To tbl.Rows.Count - 1
        '        If NewEmailTemplateID > 0 Then
        '            WebsiteEmail.SendToEmailQueue(NewEmailTemplateID, tbl.Rows(i)("UserID"), Now)
        '        Else
        '            WebsiteEmail.SendToEmailQueue(DDLEmails.SelectedItem.Value, tbl.Rows(i)("UserID"), Now)
        '        End If
        '    Next
        'Else
        '    Dim UsersIds As String = ""
        '    For i As Integer = 0 To GrdWebsiteUsers.Rows.Count - 1
        '        Dim chk As New CheckBox
        '        chk = GrdWebsiteUsers.Rows(i).FindControl("ChkUser")
        '        If chk.Checked Then
        '            UsersIds = UsersIds & GrdWebsiteUsers.DataKeys(i)(0) & ","
        '            If NewEmailTemplateID > 0 Then
        '                WebsiteEmail.SendToEmailQueue(NewEmailTemplateID, GrdWebsiteUsers.DataKeys(i)(0), Now)
        '            Else
        '                WebsiteEmail.SendToEmailQueue(DDLEmails.SelectedItem.Value, GrdWebsiteUsers.DataKeys(i)(0), Now)
        '            End If
        '        End If
        '    Next
        '    ''Response.Write(UsersIds)
        'End If

        If DDLEmails.SelectedIndex = 0 Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "MarketingEmailUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Email added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "MarketingEmailUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Email updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
        End If


    End Sub

    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        GrdWebsiteUsers.DataSource = Website.User.GetWebsiteUsers(Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
        GrdWebsiteUsers.DataBind()
    End Sub

    Private Sub DDLEmails_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLEmails.SelectedIndexChanged
        LoadEmailTemplate()

        ''LoadUsers()
    End Sub

    Sub LoadUsers()
        GrdWebsiteUsers.DataSource = Website.User.GetWebsiteUsers(WebsiteID:=Val(Session("CurrentBusinessID")), IsAdmin:=0, SearchText:=txtFilter.Text.Trim)
        GrdWebsiteUsers.DataBind()
    End Sub

    Sub LoadEmailTemplate()
        If DDLEmails.SelectedItem.Value > 0 Then
            Dim tbl As New DataTable

            tbl = WebsiteEmail.GetExistingEmails(DDLEmails.SelectedItem.Value)
            If tbl.Rows.Count > 0 Then
                txtEmailSubject.Text = tbl.Rows(0)("EmailSubject")
                ContentEditor1.Text = tbl.Rows(0)("EmailMessage")
                txtBCC.Text = tbl.Rows(0)("BCCEmails").ToString().Trim()
                txtCC.Text = tbl.Rows(0)("CCEmails").ToString().Trim()
                txtTOEmails.Text = IIf(IsDBNull(tbl.Rows(0)("ToEmails")), "", tbl.Rows(0)("ToEmails"))
            End If
        End If
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles BtnNext.Click
        pnlCampaignMessage.Visible = False
        pnlCampaignUsers.Visible = True
        ''LoadEmailTemplate()
        LoadUsers()
    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        pnlCampaignMessage.Visible = True
        pnlCampaignUsers.Visible = False
    End Sub

    Private Sub RdoSpecificUsers_CheckedChanged(sender As Object, e As EventArgs) Handles RdoSpecificUsers.CheckedChanged

    End Sub

    Private Sub btnDoneUserSelection_Click(sender As Object, e As EventArgs) Handles btnDoneUserSelection.Click
        HdnSpecificUserSelected.Value = 0
    End Sub

    Private Sub GrdWebsiteUsers_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdWebsiteUsers.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnLoginId As New HiddenField
            Dim emls As String = txtTOEmails.Text.ToLower.Trim()
            chk = CType(e.Row.FindControl("ChkUser"), CheckBox)
            hdnLoginId = CType(e.Row.FindControl("HdnLoginID"), HiddenField)
            If (Not hdnLoginId Is Nothing) Then
                If emls.IndexOf(hdnLoginId.Value.ToLower().Trim() & ";") >= 0 Then
                    chk.Checked = True
                End If
            End If

        End If
    End Sub
End Class