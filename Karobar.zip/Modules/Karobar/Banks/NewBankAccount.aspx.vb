﻿Imports System.Data.SqlClient

Public Class NewBankAccount
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 53) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then
            'DDLBankAccountType.DataSource = Bank.GetBankAccountTypesList(Session("CurrentBusinessID"))
            'DDLBankAccountType.DataTextField = "AccountTypeName"
            'DDLBankAccountType.DataValueField = "BankAccountTypeID"
            'DDLBankAccountType.DataBind()

            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.BankAccountType * -1)
            DDLBankAccountType.DataValueField = "ArticleTypeID"
            DDLBankAccountType.DataTextField = "ArticleType"
            DDLBankAccountType.DataSource = ds.Tables(0)
            DDLBankAccountType.DataBind()


            DDLBankName.DataSource = Bank.GetBanksList(Session("CurrentBusinessID"))
            DDLBankName.DataTextField = "BankName"
            DDLBankName.DataValueField = "BankID"
            DDLBankName.DataBind()

            DDLCurrency.DataSource = Website.GetCurrencies(Session("CurrentBusinessID"), HttpContext.Current.Session("UserID"))
            DDLCurrency.DataTextField = "CurrencyName"
            DDLCurrency.DataValueField = "CurrencyCode"
            DDLCurrency.DataBind()
            DDLCurrency.SelectedValue = ReferenceData.Setting("DefaultCurrency", "PKR", Session("CurrentBusinessID"))

            If Not Request("BID") Is Nothing Then HdnBID.Value = Val(Request("BID"))
            If Not Request("ACCID") Is Nothing Then HdnACCID.Value = Val(Request("ACCID"))

            DDLBankName.SelectedValue = Val(HdnBID.Value)
            If Val(HdnACCID.Value) > 0 Then
                If Val(Val(HdnBID.Value)) > 0 Then
                    Dim dr() As DataRow
                    Dim found As Boolean = False
                    Dim BID As Integer = Session("CurrentBusinessID")
                    dr = Bank.GetBanksAccountsList(Session("CurrentBusinessID"), HdnBID.Value).Select("BankAccountID=" & HdnACCID.Value)
                    lblScreenTitle.Text = "Update Bank Account"
                    For Each row In dr
                        txtBankAccountName.Text = IIf(IsDBNull(row("AccountbeneficiaryName")) = True OrElse row("AccountbeneficiaryName") = "", "", row("AccountbeneficiaryName"))
                        txtBankAccountDescription.Text = IIf(IsDBNull(row("AccountDescription")) = True OrElse row("AccountDescription") = "", "", row("AccountDescription"))
                        txtBranhName.Text = IIf(IsDBNull(row("BranchName")) = True OrElse row("BranchName") = "", "", row("BranchName"))
                        txtBranhCode.Text = IIf(IsDBNull(row("BranchCode")) = True OrElse row("BranchCode") = "", "", row("BranchCode"))
                        DDLBankAccountType.SelectedValue = IIf(IsDBNull(row("BankAccountType")) = True, "-1", row("BankAccountType"))
                        txtBankAccountNo.Text = IIf(IsDBNull(row("AccountNo")) = True OrElse row("AccountNo") = "", "", row("AccountNo"))
                        DDLCurrency.SelectedValue = IIf(IsDBNull(row("Currency")) = True OrElse row("Currency") = "", "-1", row("Currency"))
                        txtBankIBAN.Text = IIf(IsDBNull(row("AccountIBAN")) = True OrElse row("AccountIBAN") = "", "", row("AccountIBAN"))
                        txtBankAccountOpeningBalance.Text = IIf(IsDBNull(row("OpeningBalance")) = True, "", row("OpeningBalance"))
                        txtBankFax.Text = IIf(IsDBNull(row("BranchFax")) = True OrElse row("BranchFax") = "", "", row("BranchFax"))
                        txtBankPhone.Text = IIf(IsDBNull(row("BranchPhone")) = True OrElse row("BranchPhone") = "", "", row("BranchPhone"))
                        txtBankEmail.Text = IIf(IsDBNull(row("BranchEmail")) = True OrElse row("BranchEmail") = "", "", row("BranchEmail"))
                        txtBankAddress.Text = IIf(IsDBNull(row("BranchAddress")) = True OrElse row("BranchAddress") = "", "", row("BranchAddress"))
                        found = True
                        BID = Val(row("WebsiteID"))
                    Next

                    If found = False OrElse BID <> Session("CurrentBusinessID") Then
                        BtnSave.Visible = False
                        BtnSave.Enabled = False
                    End If
                Else
                    BtnSave.Visible = False
                    BtnSave.Enabled = False
                End If

            Else
                lblScreenTitle.Text = "Add New Bank Account"
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        If Val(HdnACCID.Value) > 0 AndAlso Val(HdnBID.Value) > 0 Then
            tbl = Bank.UpdateBankAccount(Session("CurrentBusinessID"), HttpContext.Current.Session("UserID"), HdnBID.Value, HdnACCID.Value, txtBankAccountName.Text.Trim,
                                     txtBankAccountDescription.Text.Trim, DDLBankAccountType.SelectedItem.Value, txtBankAccountNo.Text.Trim,
                                      DDLCurrency.SelectedItem.Value, txtBankIBAN.Text.Trim, Val(txtBankAccountOpeningBalance.Text.Trim), txtBranhName.Text.Trim,
                                       txtBranhCode.Text.Trim, txtBankPhone.Text.Trim, txtBankFax.Text, txtBankEmail.Text.Trim, txtBankAddress.Text.Trim)
            ChartOfAccount.AddUpdateOpeningBalance(Val(Session("CurrentBusinessID")), Val(HdnACCID.Value), Val(txtBankAccountOpeningBalance.Text))
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Bank", "Bank Account added " & txtBankAccountNo.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankAccountUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Bank account updated successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
        Else
            tbl = Bank.AddBankAccount(Session("CurrentBusinessID"), HttpContext.Current.Session("UserID"), DDLBankName.SelectedItem.Value, txtBankAccountName.Text.Trim,
                                     txtBankAccountDescription.Text.Trim, DDLBankAccountType.SelectedItem.Value, txtBankAccountNo.Text.Trim,
                                      DDLCurrency.SelectedItem.Value, txtBankIBAN.Text.Trim, Val(txtBankAccountOpeningBalance.Text.Trim), txtBranhName.Text.Trim,
                                       txtBranhCode.Text.Trim, txtBankPhone.Text.Trim, txtBankFax.Text, txtBankEmail.Text.Trim, txtBankAddress.Text.Trim)

            ChartOfAccount.AddUpdateOpeningBalance(Val(Session("CurrentBusinessID")), tbl.Rows(0)("BankAccountID"), Val(txtBankAccountOpeningBalance.Text))
            If tbl.Rows.Count = 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankAccountAlreadyExist", "<script>parent.ShowMessage('Bank account # already exist!','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            Else
                ''AddBankOpeningBalance(tbl.Rows(0)("BankAccountID"), Val(txtBankAccountOpeningBalance.Text.Trim))
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "BankAccountAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Bank account added successfully!','0',$(window).height()*2/100,$(window).width()*55/100,'1')</script>")
                txtBankAccountName.Text = ""
                txtBankAccountDescription.Text = ""
                txtBranhName.Text = ""
                txtBranhCode.Text = ""
                DDLBankAccountType.SelectedValue = "-1"
                txtBankAccountNo.Text = ""
                DDLCurrency.SelectedValue = "PKR"
                txtBankIBAN.Text = ""
                txtBankAccountOpeningBalance.Text = ""
                txtBankFax.Text = ""
                txtBankPhone.Text = ""
                txtBankEmail.Text = ""
                txtBankAddress.Text = ""
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Bank", "Bank Account updated " & txtBankAccountNo.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            End If
        End If
    End Sub

    Sub AddBankOpeningBalance(ByVal BankACCID As Integer, ByVal Amount As Single)
        Dim tbl As New DataTable
        Dim TID As Integer

        Dim trans As SqlTransaction
        Dim connection As New SqlConnection(DBDAL.ConnectionString)
        Try

            connection.Open()
            trans = connection.BeginTransaction()

            tbl = Transactions.AddTransaction(Session("CurrentBusinessID"), "", "OPN", "Opening Balance", "Active", True, Now, trans:=trans)
            If tbl.Rows.Count > 0 Then
                TID = tbl.Rows(0)("TransactionID")
                Transactions.AddTransactionDetails(TID, BankACCID, True, "Opening Balance", Amount, 0, 0, 0, "", trans:=trans)

            End If

            trans.Commit()
        Catch ex As Exception
            trans.Rollback()
        Finally
            connection.Close()
        End Try


    End Sub

End Class