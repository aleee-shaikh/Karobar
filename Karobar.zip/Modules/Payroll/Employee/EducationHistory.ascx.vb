﻿Public Class EducationHistory
    Inherits System.Web.UI.UserControl
    Dim _EmployeeID As Integer

    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(value As Integer)
            _EmployeeID = value
        End Set
    End Property


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
            If GrdEducationHistory.Rows.Count > 0 Then
                GrdEducationHistory.Columns(5).Visible = True
                GrdEducationHistory.Columns(6).Visible = True
                GrdEducationHistory.Columns(7).Visible = False
            Else
                GrdEducationHistory.Columns(5).Visible = False
                GrdEducationHistory.Columns(6).Visible = False
                GrdEducationHistory.Columns(7).Visible = True
            End If
        End If

    End Sub

    Private Sub GrdEducationHistory_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdEducationHistory.RowCommand
        If e.CommandName = "AddNewEducationHistory" Then
            GrdEducationHistory.ShowFooter = True
        ElseIf e.CommandName = "SaveNewEducationHistory" Then
            GrdEducationHistory.ShowFooter = False

            Dim Degree As String = CType(GrdEducationHistory.FooterRow.FindControl("txtDegree"), TextBox).Text
            Dim PassingYear As String = CType(GrdEducationHistory.FooterRow.FindControl("txtPassingYear"), TextBox).Text
            Dim CGPA As String = CType(GrdEducationHistory.FooterRow.FindControl("txtCGPA"), TextBox).Text
            Dim Division As String = CType(GrdEducationHistory.FooterRow.FindControl("txtDivision"), TextBox).Text
            Dim University As String = CType(GrdEducationHistory.FooterRow.FindControl("txtUniversity"), TextBox).Text

            Payroll.AddEducationHistory(EmployeeID, Degree, PassingYear, CGPA, Division, University)
            GrdEducationHistory.EditIndex = -1
            GrdEducationHistory.Columns(5).Visible = True
            GrdEducationHistory.Columns(6).Visible = True
            GrdEducationHistory.Columns(7).Visible = False
        ElseIf e.CommandName = "DeleteEducationHistory" Then
            Dim ID As Integer = Val(e.CommandArgument)
            Payroll.DeleteEducationHistory(ID)
        ElseIf e.CommandName = "Insert" Then
            GrdEducationHistory.ShowFooter = True
        ElseIf e.CommandName = "Cancel" Then
            GrdEducationHistory.ShowFooter = False
            GrdEducationHistory.EditIndex = -1
            GrdEducationHistory.Columns(5).Visible = True
            GrdEducationHistory.Columns(6).Visible = True
            GrdEducationHistory.Columns(7).Visible = False

        ElseIf e.CommandName = "Edit" Then
            GrdEducationHistory.Columns(5).Visible = True
            GrdEducationHistory.Columns(6).Visible = True
            GrdEducationHistory.Columns(7).Visible = False
            GrdEducationHistory.ShowFooter = False
        ElseIf e.CommandName = "Update" Then

            Dim Degree As String = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("txteditDegree"), TextBox).Text
            Dim PassingYear As String = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("txtEditPassingYear"), TextBox).Text
            Dim CGPA As String = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("txtEditCGPA"), TextBox).Text
            Dim Division As String = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("txtEditDivision"), TextBox).Text
            Dim University As String = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("txtEditUniversity"), TextBox).Text
            Dim ID As Integer = CType(GrdEducationHistory.Rows(GrdEducationHistory.EditIndex).FindControl("HdnEduID"), HiddenField).Value
            Payroll.UpdateEducationHistory(ID, EmployeeID, Degree, PassingYear, CGPA, Division, University)
            GrdEducationHistory.EditIndex = -1
            GrdEducationHistory.Columns(5).Visible = True
            GrdEducationHistory.Columns(6).Visible = True
            GrdEducationHistory.Columns(7).Visible = False
        End If
        LoadData()

    End Sub

    Sub LoadData()
        GrdEducationHistory.DataSource = Payroll.GetEmployeeEducationHistory(EmployeeID)
        GrdEducationHistory.DataBind()
    End Sub

    Private Sub LnkAddEmpEducationHistory_Click(sender As Object, e As EventArgs) Handles LnkAddEmpEducationHistory.Click
        GrdEducationHistory.ShowFooter = True
        Dim tbl As New DataTable
        Dim row As DataRow

        tbl = Payroll.GetEmployeeEducationHistory(EmployeeID)
        If tbl.Rows.Count = 0 Then
            row = tbl.NewRow
            tbl.Rows.InsertAt(row, 0)
        End If
        GrdEducationHistory.EditIndex = -1
        GrdEducationHistory.Columns(5).Visible = False
        GrdEducationHistory.Columns(6).Visible = False
        GrdEducationHistory.Columns(7).Visible = True
        GrdEducationHistory.DataSource = tbl
        GrdEducationHistory.DataBind()
    End Sub

    Private Sub GrdEducationHistory_DataBound(sender As Object, e As EventArgs) Handles GrdEducationHistory.DataBound

    End Sub

    Private Sub GrdEducationHistory_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdEducationHistory.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

        End If
    End Sub

    Private Sub GrdEducationHistory_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdEducationHistory.RowUpdating

    End Sub

    Private Sub GrdEducationHistory_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdEducationHistory.RowCancelingEdit

    End Sub

    Private Sub GrdEducationHistory_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdEducationHistory.RowEditing
        GrdEducationHistory.EditIndex = e.NewEditIndex
        GrdEducationHistory.DataBind()
    End Sub
End Class