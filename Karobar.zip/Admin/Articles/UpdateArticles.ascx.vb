﻿Public Class Articles
    Inherits System.Web.UI.UserControl

   
    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then

            
           

            HdnArticleID.Value = Session("ArticleID")
            LoadData(HdnArticleID.Value)
        Else
            If DDLURLType.SelectedItem.Value = 1 Then
                TRLocalFile.Visible = True
                TRWebURL.Visible = False
            Else
                TRLocalFile.Visible = False
                TRWebURL.Visible = True
            End If
        End If
    End Sub

    Sub LoadData(ByVal ArticleID As Integer)
        Dim ds As New DataSet

        ds = WebsiteArticles.GetArticleTypes(Website.WebsiteID, -1)
        If ds.Tables.Count > 0 Then
            DDLArticlesSecondaryType.DataSource = ds.Tables(0)
            DDLArticlesSecondaryType.DataTextField = "ArticleType"
            DDLArticlesSecondaryType.DataValueField = "ArticleTypeID"
            DDLArticlesSecondaryType.DataBind()
        End If
        If ds.Tables.Count >= 1 Then
            DDLArticlesPrimaryType.DataSource = ds.Tables(1)
            DDLArticlesPrimaryType.DataTextField = "ArticleType"
            DDLArticlesPrimaryType.DataValueField = "ArticleTypeID"
            DDLArticlesPrimaryType.DataBind()
        End If


        ds = WebsiteArticles.GetArticle(ArticleID)

        If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
            Dim dsatype As New DataSet
            DDLArticlesSecondaryType.Items.Clear()
            DDLArticlesPrimaryType.Items.Clear()
            dsatype = WebsiteArticles.GetArticleTypes(Website.WebsiteID, ds.Tables(0).Rows(0)("ArticleTypeID"))
            If dsatype.Tables.Count > 0 Then
                DDLArticlesSecondaryType.DataSource = dsatype.Tables(0)
                DDLArticlesSecondaryType.DataTextField = "ArticleType"
                DDLArticlesSecondaryType.DataValueField = "ArticleTypeID"
                DDLArticlesSecondaryType.DataBind()
            End If
            If dsatype.Tables.Count >= 1 Then
                DDLArticlesPrimaryType.DataSource = dsatype.Tables(1)
                DDLArticlesPrimaryType.DataTextField = "ArticleType"
                DDLArticlesPrimaryType.DataValueField = "ArticleTypeID"
                DDLArticlesPrimaryType.DataBind()
            End If

            If DDLArticlesSecondaryType.Items.Count > 0 Then
                DDLArticlesSecondaryType.SelectedValue = ds.Tables(0).Rows(0)("ArticleTypeID")
                TRSecondaryType.Visible = True
            Else
                DDLArticlesPrimaryType.SelectedValue = ds.Tables(0).Rows(0)("ArticleTypeID")
                TRSecondaryType.Visible = False
            End If
            txtArticleTitle.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("ArticleTitle")), "", ds.Tables(0).Rows(0)("ArticleTitle"))
            txtArticleDesc.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("ArticleText")), "", ds.Tables(0).Rows(0)("ArticleText"))
            ChkVisible.Checked = IIf(IsDBNull(ds.Tables(0).Rows(0)("Visible")), False, ds.Tables(0).Rows(0)("Visible"))
            txtSortOrder.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("SortOrder")), "", ds.Tables(0).Rows(0)("SortOrder"))
            txtSEODescription.Text = IIf(IsDBNull(ds.Tables(0).Rows(0)("SEODescription")), "", ds.Tables(0).Rows(0)("SEODescription"))

        End If
        If ds.Tables.Count > 1 Then
            GrdArticleImages.DataSource = ds.Tables(1)
            GrdArticleImages.DataBind()
        End If
    End Sub

    Private Sub BtnUpdateArticle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpdateArticle.Click
        If FileUploadArticleImage.PostedFile.FileName <> "" Then
            If Not System.IO.Directory.Exists(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images")) Then
                System.IO.Directory.CreateDirectory(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images"))
            End If
            FileUploadArticleImage.PostedFile.SaveAs(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images") & "/" & FileUploadArticleImage.PostedFile.FileName)
        End If
        Dim ArticleTypeID As Integer
        If DDLArticlesSecondaryType.Items.Count > 0 Then
            ArticleTypeID = DDLArticlesSecondaryType.SelectedItem.Value
        Else
            ArticleTypeID = DDLArticlesPrimaryType.SelectedItem.Value
        End If
        WebsiteArticles.UpdateArticle(Val(HdnArticleID.Value), ArticleTypeID, txtArticleTitle.Text.Trim, txtArticleDesc.Text, FileUploadArticleImage.PostedFile.FileName, ChkVisible.Checked, Val(txtSortOrder.Text), txtSEODescription.Text.Trim, HttpContext.Current.Session("UserID"))
        Response.Redirect("~/Admin/Admin.aspx?P=Articles")
    End Sub

    Private Sub BtnAddArticleImage_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAddArticleImage.Click
        If Not System.IO.Directory.Exists(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images")) Then
            System.IO.Directory.CreateDirectory(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images"))
        End If
        If DDLURLType.SelectedItem.Value = 1 Then

            If FileUploadLocalFile.PostedFile.FileName <> "" Then
                FileUploadLocalFile.PostedFile.SaveAs(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images") & "/" & FileUploadLocalFile.PostedFile.FileName)
                WebsiteArticles.AddArticleImage(Val(HdnArticleID.Value), FileUploadLocalFile.PostedFile.FileName, txtArticleImageDesc.Text.Trim, HttpContext.Current.Session("UserID"))
            End If

        Else

            If txtArticleImageVideoURL.Text.Trim <> "" Then
                ''FileUploadLocalFile.PostedFile.SaveAs(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images") & "/" & FileUploadLocalFile.PostedFile.FileName)
                WebsiteArticles.AddArticleImage(Val(HdnArticleID.Value), txtArticleImageVideoURL.Text.Trim, txtArticleImageDesc.Text.Trim, HttpContext.Current.Session("UserID"))
            End If

        End If
        Response.Redirect("~/Admin/Admin.aspx?P=Articles")
    End Sub

    Private Sub DDLArticlesPrimaryType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLArticlesPrimaryType.SelectedIndexChanged
        Dim ds As New DataSet
        ds = WebsiteArticles.GetArticleTypes(Website.WebsiteID, DDLArticlesPrimaryType.SelectedItem.Value)
        DDLArticlesSecondaryType.Items.Clear()
        If ds.Tables.Count > 0 Then
            DDLArticlesSecondaryType.DataSource = ds.Tables(0)
            DDLArticlesSecondaryType.DataTextField = "ArticleType"
            DDLArticlesSecondaryType.DataValueField = "ArticleTypeID"
            DDLArticlesSecondaryType.DataBind()
        End If
        TRSecondaryType.visible = (DDLArticlesSecondaryType.Items.Count > 0)
    End Sub

    Private Sub DDLArticlesSecondaryType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLArticlesSecondaryType.SelectedIndexChanged

    End Sub

    Private Sub GrdArticleImages_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdArticleImages.RowCommand
        If e.CommandName = "DeleteArticleImage" Then
            WebsiteArticles.DeleteArticleImage(HdnArticleID.Value, e.CommandArgument)
            LoadData(HdnArticleID.Value)
        End If
    End Sub
End Class