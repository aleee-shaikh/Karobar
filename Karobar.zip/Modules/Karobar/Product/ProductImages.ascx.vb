﻿Public Class ProductImages
    Inherits System.Web.UI.UserControl

    Dim _ProductID As Integer

    Public Property ProductID() As Integer
        Get
            Return _ProductID
        End Get
        Set(ByVal value As Integer)
            _ProductID = value
            hdnProductID.Value = value
        End Set
    End Property


    Public Sub LoadData()

        GrdProductImages.DataSource = Products.GetProductImages(Session("CurrentBusinessID"), hdnProductID.Value)

        GrdProductImages.DataBind()

    End Sub

    Private Sub GrdProductImages_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdProductImages.RowCommand
        If e.CommandName = "DeleteProductImage" Then
            Dim tbl As New DataTable
            Dim BusinessDirectory As String = "~/CMS/Product/Images"
            Dim imageFile As String = ""
            tbl = Products.GetProductImages(LoggedInUserSession.BusinessID, hdnProductID.Value).Tables(0)
            imageFile = tbl.Select("ArticleImageID=" & e.CommandArgument).CopyToDataTable().Rows(0)("ImageVideoURL")

            System.IO.File.Delete(Server.MapPath(BusinessDirectory & "/" & imageFile))
            If (System.IO.File.Exists(Server.MapPath(BusinessDirectory & "/Thumbnail_" & imageFile))) Then
                System.IO.File.Delete(Server.MapPath(BusinessDirectory & "/Thumbnail_" & imageFile))
            End If

            Products.DeleteProductImage(Session("CurrentBusinessID"), e.CommandArgument)
            LoadData()
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Product", "Deleted Product Image" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub
End Class