﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Web.Script.Services

' To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line.
<System.Web.Script.Services.ScriptService()>
<System.Web.Services.WebService(Namespace:="Joined24", Name:="Joined24DeviceService")>
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<ToolboxItem(False)>
Public Class Joined24
    Inherits System.Web.Services.WebService
    Dim WebKey As String = "W3bChat!2345"

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Website_GetUsers(Key As String, WebsiteID As Integer, UserAccountType As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            tbl = Person.GetUsersList(WebsiteID, "", UserAccountType)
            For i As Integer = 0 To tbl.Rows.Count - 1
                tbl.Rows(i)("Password") = ""
            Next
            ds.Tables.Add(tbl)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "Users"
        ds.Namespace = "Users"
        Dim jsonData As String = "{""Users"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

#Region "Web Chat"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Website_GetUserAllChatLog(Key As String, WebsiteID As Integer, UserID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        If Key = WebKey Then
            ''If (UserID <= 0) Then
            UserID = HttpContext.Current.Session("UserID")
            ''End If
            ds.Tables.Add(Chat.GetUserAllChatLog(WebsiteID, UserID))
            ds.Tables(0).TableName = "ChatLog"
        End If

        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function GetOffers4Web(WebsiteID As Integer,
                                           OfferID As Integer,
                                           FreeText As String,
                                           OfferTypeID As Integer,
                                           ValidTillDate As String,
                                           PageNo As Integer,
                                           PageSize As Integer,
                                           SortBy As String,
                                           SortOrder As String) As String
        Dim cmd As New SqlClient.SqlCommand
        Dim DBObj As New DBDAL
        Dim ds As New DataSet

        Dim tbl As New DataTable
        Dim jsonData As String = ""

        cmd.CommandType = CommandType.StoredProcedure
        cmd.CommandText = "Offer_GetOffers"
        cmd.Parameters.AddWithValue("@WebsiteID", WebsiteID)
        cmd.Parameters.AddWithValue("@OfferID", OfferID)
        cmd.Parameters.AddWithValue("@FreeText", FreeText)
        cmd.Parameters.AddWithValue("@OfferTypeID", OfferTypeID)
        cmd.Parameters.AddWithValue("@ValidTillDate", ValidTillDate)
        cmd.Parameters.AddWithValue("@PageNo", PageNo)
        cmd.Parameters.AddWithValue("@PageSize", PageSize)
        cmd.Parameters.AddWithValue("@SortBy", SortBy)
        cmd.Parameters.AddWithValue("@SortOrder", SortOrder)
        ds = DBObj.GetDataset(cmd)
        ds.Tables(0).TableName = "Offers"
        If (ds.Tables.Count > 1) Then
            ds.Tables(1).TableName = "OfferDetails"
        End If

        Return ds.GetXml
    End Function


    '<ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    '<WebMethod(EnableSession:=True)>
    'Public Function Website_GetChatDetails(ChatTypeID As Integer, RefID As Integer, ReadFromID As Integer, UserID As Integer) As String
    '    Dim tbl As New DataTable
    '    Dim ds As New DataSet

    '    ''If (UserID <= 0) Then
    '    UserID = HttpContext.Current.Session("UserID")
    '    ''End If

    '    ds = Chat.GetChatDetails(ChatTypeID, RefID, ReadFromID, UserID)

    '    ds.Tables(0).TableName = "Chat"
    '    ds.Namespace = "Chat"

    '    Return "{""ChatMaster"":" & General.GetDataTableJson(ds.Tables(0)) & ",""ChatLog"":" & General.GetDataTableJson(ds.Tables(1)) & ",""ChatUsers"":" & General.GetDataTableJson(ds.Tables(2)) & "}"
    'End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Website_GetChatDetails(Key As String, ChatTypeID As Integer, RefID As Integer, ReadFromID As Integer, UserID As Integer, UnreadMsgIds As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        If Key = WebKey Then
            ''If (UserID <= 0) Then
            UserID = HttpContext.Current.Session("UserID")
            ''End If

            ds = Chat.GetChatDetails(ChatTypeID, RefID, ReadFromID, UserID, UnreadMsgIds)
            ds.Tables(0).TableName = "ChatMaster"
            ds.Tables(1).TableName = "ChatLog"
            ds.Tables(2).TableName = "ChatUsers"
        End If

        Return ds.GetXml
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod(EnableSession:=True)>
    Public Function Website_SendMessage(Key As String, ChatID As Integer,
                                      UserID As Integer,
                                      Message As String,
                                ReadFromID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        If Key = WebKey Then
            UserID = HttpContext.Current.Session("UserID")
            ds.Tables.Add(Chat.SendMessage(ChatID, UserID, Message, ReadFromID))

            'tbl = Chat.GetChatUsers(ChatID)
            'For i As Integer = 0 To tbl.Rows.Count - 1
            '    If UserID <> tbl.Rows(i)("UserID") Then
            '        Log.Notifications_Add(tbl.Rows(i)("ChatTitle"), ChatID, "ClientNotification", 4, Val(HttpContext.Current.Session("CurrentBusinessID"))) '4=chat msg
            '    End If
            'Next
            ds.Tables(0).TableName = "ChatLog"
            'ds.Namespace = "ChatLog"

            ''Return "{""ChatLog"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        End If
        Return ds.GetXml
    End Function
#End Region

#Region "Mobile Chat"

    ''<ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SendImage() As String
        Dim ds As New DataSet
        Dim Key As String = HttpContext.Current.Request("TokenKey")
        'Dim UserID As Integer = HttpContext.Current.Request("UserID")
        Dim HttpPostedFile = HttpContext.Current.Request.Files("ChatMsgImage")
        Dim Msg As String = ""

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim UserID As Integer = HttpContext.Current.Request("UserID")
            Dim ChatID As Integer = HttpContext.Current.Request("ChatID")
            Dim ReadFromID As Integer = HttpContext.Current.Request("MessageReadFromID")

            Dim path As String = HttpContext.Current.Server.MapPath("~/CMS/AppUsers/Images")
            Dim file As System.Web.HttpPostedFile = HttpPostedFile
            Dim FileSize As Long = file.ContentLength
            Dim fileExt As String = System.IO.Path.GetExtension(file.FileName).ToLower().Trim()


            'If (FileSize / 1000) > 70 Then
            '    Msg = "Image Size should not be greater than 70KB"
            'Else
            ''Dim filename As String = Guid.NewGuid.ToString & ".png" '& fileExt
            Dim filename As String = StringManipulation.ReplaceCharsWith(Cryptography.Encrypt(ChatID & "|" & UserID & "|" & Now.ToString("yyyyMMddhhmmss")), "+?$'=-_!", "") & ".png" ''& fileExt
            ''If (fileExt.EndsWith("jpeg") Or fileExt.EndsWith("jpg") Or fileExt.EndsWith(".png") Or fileExt.EndsWith(".gif")) Then
            file.SaveAs(HttpContext.Current.Server.MapPath("~/CMS/Chat/Images/") & "/" & filename)
            ''Chat.SendMessage(ChatID, UserID, "#MessageImage#" & HttpContext.Current.Server.MapPath("~/CMS/Chat/Images/") & "/" & filename, ReadFromID)
            ''Else
            ''Msg = "Only images files (jpg,png,gif)"
            ''End If
            'End If
            Msg = "/CMS/Chat/Images/" & filename
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return Msg ''"{""UserFileUpload"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function UploadProfilePic() 'As String
        Dim ds As New DataSet
        Dim Key As String = HttpContext.Current.Request("value1")
        'Dim UserID As Integer = HttpContext.Current.Request("UserID")
        Dim HttpPostedFile = HttpContext.Current.Request.Files("UserProfilePic")
        Dim Msg As String = ""

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then

            Dim path As String = HttpContext.Current.Server.MapPath("~/CMS/AppUsers/Images")
            Dim file As System.Web.HttpPostedFile = HttpPostedFile
            Dim FileSize As Long = file.ContentLength
            Dim fileExt As String = System.IO.Path.GetExtension(file.FileName).ToLower().Trim()

            'If (FileSize / 1000) > 70 Then
            '    Msg = "Image Size should not be greater than 70KB"
            'Else
            ''Dim filename As String = Guid.NewGuid.ToString & ".png" '& fileExt
            Dim filename As String = HttpContext.Current.Request("value2") & ".png" ''& fileExt
            ''If (fileExt.EndsWith("jpeg") Or fileExt.EndsWith("jpg") Or fileExt.EndsWith(".png") Or fileExt.EndsWith(".gif")) Then
            file.SaveAs(HttpContext.Current.Server.MapPath("~/CMS/AppUsers/Images/") & "/" & filename)
            Person.UpdateUserProfilePicture(HttpContext.Current.Request("value2"), filename)
            ''Else
            ''Msg = "Only images files (jpg,png,gif)"
            ''End If
            'End If
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return Msg ''"{""UserFileUpload"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserAllChatLog(Key As String, WebsiteID As Integer, UserID As Integer) As String
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.GetUserAllChatLog(WebsiteID, UserID))
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return "{""ChatLog"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function CreateChat(Key As String, ChatTitle As String,
                                      ChatTypeID As Integer,
                                      RefID As Integer,
                                      CreatedBy As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.CreateChat(ChatTitle, ChatTypeID, RefID, CreatedBy))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""ChatCreated"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function AddChatUser(Key As String, ChatID As Integer, UserID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.AddUser(ChatID, UserID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""AddedChatUser"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function RemoveChatUser(Key As String, ChatID As Integer, UserID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.RemoveUser(ChatID, UserID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""RemovedChatUser"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetChatDetails(Key As String, ChatTypeID As Integer, RefID As Integer, ReadFromID As Integer, UserID As Integer, UnreadMsgIds As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Chat.GetChatDetails(ChatTypeID, RefID, ReadFromID, UserID, UnreadMsgIds)
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""ChatMaster"":" & General.GetDataTableJson(ds.Tables(0)) & ",""ChatLog"":" & General.GetDataTableJson(ds.Tables(1)) & ",""ChatUsers"":" & General.GetDataTableJson(ds.Tables(2)) & "}"
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetChatDetailsNew(Key As String, ChatTypeID As Integer,
                                   RefID As Integer,
                                   ReadFromID As Integer, UserID As Integer,
                                   UnreadMsgIds As String,
                                   ExtraParam As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim ToUserIDs As String = ""
            Dim Tmp() = ExtraParam.Split("#")
            Dim Params() = Tmp(0).Split("=")
            If Params(0) = "ToUserIDs" Then
                ToUserIDs = Params(1)
            End If
            ds = Chat.GetChatDetails(ChatTypeID, RefID, ReadFromID, UserID, UnreadMsgIds, ToUserIDs)
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""ChatMaster"":" & General.GetDataTableJson(ds.Tables(0)) & ",""ChatLog"":" & General.GetDataTableJson(ds.Tables(1)) & ",""ChatUsers"":" & General.GetDataTableJson(ds.Tables(2)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SearchChat(Key As String, ChatID As Integer, UserID As Integer, ChatTypeID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.SearchChat(ChatID, UserID, ChatTypeID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Chat"
        ds.Namespace = "Chat"

        Return "{""ChatSearchResult"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SendMessage(Key As String, ChatID As Integer,
                                      UserID As Integer,
                                      Message As String,
                                ReadFromID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.SendMessage(ChatID, UserID, Message, ReadFromID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "ChatLog"
        ds.Namespace = "ChatLog"

        Return "{""ChatLog"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetChatUsers(Key As String, ChatID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.GetChatUsers(ChatID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "ChatUsers"
        ds.Namespace = "ChatUsers"

        Return "{""ChatUsers"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetChatUsersByOrderID(Key As String, OrderID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Chat.GetChatUsersByOrderID(OrderID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "ChatUsers"
        ds.Namespace = "ChatUsers"

        Return "{""ChatUsers"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function
#End Region

#Region "Favourite"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function AddToFavourite(Key As String, UserID As Integer, FavGroup As String, ID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Favourite.Add(UserID, FavGroup, ID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Add2Favourite"
        ds.Namespace = "Add2Favourite"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserFavourites(Key As String, UserID As Integer, FavGroup As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String = ""

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Favourite.GetUserFavourites(UserID, FavGroup))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "UserFavourites"
        ds.Namespace = "UserFavourites"
        jsonData = "{""UserFavourites"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function DeleteFromFavourite(Key As String, UserID As Integer, FavGroup As String, ID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds.Tables.Add(Favourite.Delete(UserID, FavGroup, ID))
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "DeleteFromFavourite"
        ds.Namespace = "DeleteFromFavourite"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function
#End Region

#Region "Deals & Offers"

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetOffers(Key As String, WebsiteID As Integer,
                                           OfferID As Integer,
                                           FreeText As String,
                                           OfferTypeID As Integer,
                                           ValidTillDate As String,
                                           PageNo As Integer,
                                           PageSize As Integer,
                                           SortBy As String,
                                           SortOrder As String) As String
        Dim cmd As New SqlClient.SqlCommand
        Dim DBObj As New DBDAL
        Dim ds As New DataSet

        Dim tbl As New DataTable
        Dim jsonData As String = ""

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "Offer_GetOffers"
            cmd.Parameters.AddWithValue("@WebsiteID", WebsiteID)
            cmd.Parameters.AddWithValue("@OfferID", OfferID)
            cmd.Parameters.AddWithValue("@FreeText", FreeText)
            cmd.Parameters.AddWithValue("@OfferTypeID", OfferTypeID)
            cmd.Parameters.AddWithValue("@ValidTillDate", ValidTillDate)
            cmd.Parameters.AddWithValue("@PageNo", PageNo)
            cmd.Parameters.AddWithValue("@PageSize", PageSize)
            cmd.Parameters.AddWithValue("@SortBy", SortBy)
            cmd.Parameters.AddWithValue("@SortOrder", SortOrder)
            ds = DBObj.GetDataset(cmd)
            jsonData = "{""Offers"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetNotificationDetails(Key As String,
                                        BusinessID As Integer,
                                        NotificationGroup As String,
                                        NotificationID As Integer,
                                        ID As Integer,
                                        UserID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String = ""

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Log.GetNotificationDetails(BusinessID, NotificationGroup, NotificationID, ID, UserID)
            jsonData = "{""NotificationMasterDetail"":" & General.GetDataTableJson(ds.Tables(0)) & ",""NotificationProducts"":" & General.GetDataTableJson(ds.Tables(1)) & ",""NotificationUsers"":" & General.GetDataTableJson(ds.Tables(2)) & "}"
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "NotificationDetails"
        ds.Namespace = "NotificationDetails"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserNotifications(Key As String,
                                        WebsiteID As Integer,
                                        UserID As Integer,
                                        ViewedNotificationIDs As String,
                                        SearchText As String,
                                        PageNo As Integer,
                                        PageSize As Integer,
                                        SortBy As String,
                                        SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = OffersAndDeals.Offer_GetUserNotifications(WebsiteID, UserID, ViewedNotificationIDs, SearchText, PageNo, PageSize, SortBy, SortOrder)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "UserNotifications"
        ds.Namespace = "UserNotifications"
        jsonData = "{""UserNotifications"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function
#End Region

#Region "Ineed.joined24.com"

    <WebMethod(True)>
    Public Function IneedPlaceAnOrder(Key As String, ByVal WebsiteID As Integer, ByVal UserID As Integer, ByVal UserName As String,
                               ByVal UserEmail As String, ByVal UserMobileNo As String, ByVal UserLandlineNo As String,
                               UserCity As String, UserAddress As String, OrderMessage As String, ProductIDsList As String,
                                      Lat As String, Lng As String, OrderType As Integer) As String

        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim dr As DataRow

            dr = Website.GetWebsiteDetailRow(WebsiteID)
            'If Not (WebsiteID > 0) Then
            '    WebsiteID = Val(HttpContext.Current.Session("CurrentBusinessID"))
            'End If

            tbl = Products.PlaceAnOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage, Now, ProductIDsList, OrderType:=Val(OrderType), Latitude:=Lat, Longitude:=Lng)
            Dim OrderID As Integer
            If (tbl.Rows.Count > 0) Then
                OrderID = tbl.Rows(0)("OrderID")
                If (tbl.Rows.Count = 1) Then
                    ProductIDsList = tbl.Rows(0)("ProductID")
                Else
                    ProductIDsList = ""
                End If
                Log.Notifications_Add("Order Received ", OrderID, "Order Received", UserID, WebsiteID)
            End If
            'Dim ReplacingWords As String = ""
            'Dim ToUserEmail As String = ReferenceData.Setting("ToOrderNotificationEmail", UserEmail)
            'Dim EmailTemplateFile As String = ""
            'Dim FromUserEmail As String = ""
            'Dim Subject As String = dr("WebsiteTitle").ToString() & " - " & ReferenceData.Setting("OrderNotificationEmailSubject", "Order Notification") '& " :" & ProductIDsList

            'FromUserEmail = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
            'EmailTemplateFile = ReferenceData.Setting("OrderNotificationEmailTemplate", "OrderNotificationTemplate")

            'ReplacingWords = ReplacingWords & "[UserName]♦" & UserName & "¤"
            'ReplacingWords = ReplacingWords & "[UserEmail]♦" & UserEmail & "¤"
            'ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
            'ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
            'ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
            'ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
            'ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
            'ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
            'ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
            'ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessID]♦" & Cryptography.Encrypt(WebsiteID.ToString()) & "¤"
            'ReplacingWords = ReplacingWords & "[BID]♦" & WebsiteID.ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & dr("WebsiteTitle").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & dr("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessWebsiteURL]♦" & dr("WebsiteURL").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & dr("WebsiteLogo").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & dr("CurrencyCode").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & dr("Email").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & dr("Phone").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessFax]♦" & dr("Fax").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessCity]♦" & dr("City").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessTown]♦" & dr("Town").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & dr("CategoryTitle").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & dr("Address").ToString() & "¤"
            'ReplacingWords = ReplacingWords & "[Products]♦" & ProductIDsList & "¤"
            'ReplacingWords = ReplacingWords & "[OrderID]♦" & Cryptography.Encrypt(OrderID.ToString()) & "¤"
            'Dim CCEmail As String = dr("Email").ToString()

            'WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, CCEmail, Subject, EmailTemplateFile, "", ReplacingWords)
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return "1"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetAssignedServices(Key As String,
                                        WebsiteID As Integer,
                                        ProductIDs As String,
                                        UserID As Integer,
                                        OrderIDs As Integer,
                                        FromDate As String,
                                        ToDate As String,
                                        PageNo As Integer,
                                        PageSize As Integer,
                                        SortBy As String,
                                        SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = ServiceProvider.GetAssignedServices(WebsiteID, ProductIDs, UserID, OrderIDs, FromDate, ToDate, PageNo, PageSize, SortBy, SortOrder)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "AssignedServices"
        ds.Namespace = "AssignedServices"
        jsonData = "{""AssignedServices"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <WebMethod(True)>
    Public Function UpdateOrderStatus(Key As String, ByVal WebsiteID As Integer, ByVal UserID As Integer, OrderID As Integer, Remarks As String, StatusID As Integer) As String
        Dim Res As String = "1"
        Try
            Products.AddOrderHistory(WebsiteID, OrderID, StatusID, Remarks, UserID)
        Catch ex As Exception
            Res = ex.Message
        End Try
        Return Res
    End Function
#End Region

#Region "DMS"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Order_AddOrderDeliveryHistory(Key As String,
                                                  WebsiteID As Integer,
                                                  DeviceID As String,
                                                  OrderID As Integer,
                                                  VehicleID As Integer,
                                                  DeliveryBoyID As Integer,
                                                  OdoStartReading As Single,
                                                  OdoEndReading As Single,
                                                  DeliveryStartDateTime As DateTime,
                                                  DeliveryEndDateTime As DateTime,
                                                  Comments As String,
                                                  CreatedByID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.AddOrderDeliveryHistory(WebsiteID, DeviceID, OrderID, VehicleID, DeliveryBoyID, OdoStartReading, OdoEndReading, DeliveryStartDateTime, DeliveryEndDateTime, Comments, CreatedByID)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "OrderAddDeliveryHistory"
        ds.Namespace = "OrderAddDeliveryHistory"
        jsonData = "{""OrderAddDeliveryHistory"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Order_GetOrderDeliveryHistory(Key As String,
                                                  WebsiteID As Integer,
                                                  DeviceID As String,
                                                  OrderID As Integer,
                                                  DeliveryStartDateTime As DateTime,
                                                  DeliveryEndDateTime As DateTime,
                                                  VehicleID As Integer,
                                                  DeliveryBoyID As Integer,
                                                  OdoStartReading As Single,
                                                  OdoEndReading As Single,
                                                  FreeText As String,
                                                  PageNo As Integer,
                                                  PageSize As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetOrderDeliveryHistory(WebsiteID, DeviceID, OrderID, DeliveryStartDateTime, DeliveryEndDateTime, VehicleID, DeliveryBoyID, OdoStartReading, OdoEndReading, FreeText, PageNo, PageSize)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "OrderDeliveryHistory"
        ds.Namespace = "OrderDeliveryHistory"
        jsonData = "{""OrderDeliveryHistory"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

#End Region

#Region "Business"

    <WebMethod(True)>
    Public Function PlaceAnOrder(Key As String, ByVal WebsiteID As Integer, ByVal UserID As Integer, ByVal UserName As String,
                               ByVal UserEmail As String, ByVal UserMobileNo As String, ByVal UserLandlineNo As String,
                               UserCity As String, UserAddress As String, OrderMessage As String, ProductIDsList As String) As String

        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim dr As DataRow

            dr = Website.GetWebsiteDetailRow(WebsiteID)
            'If Not (WebsiteID > 0) Then
            '    WebsiteID = Val(HttpContext.Current.Session("CurrentBusinessID"))
            'End If

            tbl = Products.PlaceAnOrder(WebsiteID, UserID, UserName, UserEmail, UserMobileNo, UserLandlineNo, UserCity, UserAddress, OrderMessage, Now, ProductIDsList)
            Dim OrderID As Integer
            If (tbl.Rows.Count > 0) Then
                OrderID = tbl.Rows(0)("OrderID")
                If (tbl.Rows.Count = 1) Then
                    ProductIDsList = tbl.Rows(0)("ProductID")
                Else
                    ProductIDsList = ""
                End If
                Log.Notifications_Add("Order Received ", OrderID, "Order Received", UserID, WebsiteID)
            End If
            Dim ReplacingWords As String = ""
            Dim ToUserEmail As String = ReferenceData.Setting("ToOrderNotificationEmail", UserEmail)
            Dim EmailTemplateFile As String = ""
            Dim FromUserEmail As String = ""
            Dim Subject As String = dr("WebsiteTitle").ToString() & " - " & ReferenceData.Setting("OrderNotificationEmailSubject", "Order Notification") '& " :" & ProductIDsList

            FromUserEmail = ReferenceData.Setting("FromOrderNotificationEmail", "info@joined24.com")
            EmailTemplateFile = ReferenceData.Setting("OrderNotificationEmailTemplate", "OrderNotificationTemplate")

            ReplacingWords = ReplacingWords & "[UserName]♦" & UserName & "¤"
            ReplacingWords = ReplacingWords & "[UserEmail]♦" & UserEmail & "¤"
            ReplacingWords = ReplacingWords & "[FromUserEmail]♦" & FromUserEmail & "¤"
            ReplacingWords = ReplacingWords & "[LandlineNo]♦" & UserLandlineNo & "¤"
            ReplacingWords = ReplacingWords & "[MobileNo]♦" & UserMobileNo & "¤"
            ReplacingWords = ReplacingWords & "[Subject]♦" & Subject & "¤"
            ReplacingWords = ReplacingWords & "[Message]♦" & OrderMessage & "¤"
            ReplacingWords = ReplacingWords & "[Department]♦" & "-1" & "¤"
            ReplacingWords = ReplacingWords & "[City]♦" & UserCity & "¤"
            ReplacingWords = ReplacingWords & "[Address]♦" & UserAddress & "¤"
            ReplacingWords = ReplacingWords & "[BusinessID]♦" & Cryptography.Encrypt(WebsiteID.ToString()) & "¤"
            ReplacingWords = ReplacingWords & "[BID]♦" & WebsiteID.ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessTitle]♦" & dr("WebsiteTitle").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessTitle4URL]♦" & dr("WebsiteTitle").ToString().Replace(" ", "-") & "¤"
            ReplacingWords = ReplacingWords & "[BusinessWebsiteURL]♦" & dr("WebsiteURL").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessLogo]♦" & dr("WebsiteLogo").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessCurrency]♦" & dr("CurrencyCode").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessContactEmail]♦" & dr("Email").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessPhone]♦" & dr("Phone").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessFax]♦" & dr("Fax").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessCity]♦" & dr("City").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessTown]♦" & dr("Town").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessCategory]♦" & dr("CategoryTitle").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[BusinessAddress]♦" & dr("Address").ToString() & "¤"
            ReplacingWords = ReplacingWords & "[Products]♦" & ProductIDsList & "¤"
            ReplacingWords = ReplacingWords & "[OrderID]♦" & Cryptography.Encrypt(OrderID.ToString()) & "¤"
            Dim CCEmail As String = dr("Email").ToString()

            WebsiteEmail.SendEmail(FromUserEmail, ToUserEmail, CCEmail, Subject, EmailTemplateFile, "", ReplacingWords)
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return "1"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetOrders(Key As String, WebsiteID As Integer, UserID As Integer, OrderID As Integer, ProductIDs As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetOrders(WebsiteID, OrderID, UserID, ProductIDs)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "Orders"
        ds.Namespace = "OrdersHistory"
        jsonData = "{""Orders"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function UpdateProductOrderStatus(Key As String,
                                   WebsiteID As Integer,
                                   OrderID As Integer,
                                   OrderStatusID As Integer,
                                   OrderStatusComments As String,
                                   OrderStatusAddedBy As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Products.AddOrderHistory(WebsiteID, OrderID, OrderStatusID, OrderStatusComments, OrderStatusAddedBy)
        Else
            ds.Tables.Add(New DataTable())
        End If

        jsonData = "{""Done"":""1""}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetOrderDetails(Key As String, WebsiteID As Integer, OrderID As Integer, ViewerID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetOrderDetails(WebsiteID, OrderID, ViewerID:=ViewerID)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "OrderMaster"
        ds.Tables(0).TableName = "OrderDetail"
        ds.Namespace = "Orders"
        jsonData = "{""OrderMaster"":" & General.GetDataTableJson(ds.Tables(0)) & ",""OrderDetail"":" & General.GetDataTableJson(ds.Tables(1)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod(EnableSession:=True)>
    Public Function GetOrderSummaryByStatus(Key As String, FromDate As String,
                                            ToDate As String,
                                            OrderStatus As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetOrderSummaryByStatus(LoggedInUserSession.BusinessID, FromDate, ToDate, OrderStatus, LoggedInUserSession.UserID)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "OrderSummary"
        ds.Namespace = "OrderSummary"
        jsonData = "{""OrderSummary"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserOrders(Key As String,
                                  WebsiteID As Integer,
                                  UserID As Integer,
                                  OrderID As Integer,
                                  ProductIDs As String,
                                  OrderType As Integer,
                                  FromDate As String,
                                  ToDate As String,
                                  FreeText As String,
                                  PageNo As Integer,
                                  PageSize As Integer,
                                  SortBy As String,
                                  SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        If FromDate = "-1" Or FromDate = "" Then 'All dates order
            FromDate = Now.AddYears(-100).ToString("yyyyMMdd")
            ToDate = Now.ToString("yyyyMMdd")
        ElseIf FromDate = "1" Then 'Todays
            FromDate = Now.ToString("yyyyMMdd")
            ToDate = Now.ToString("yyyyMMdd")
        ElseIf FromDate = "2" Then 'Last 7 days
            FromDate = Now.AddDays(-7).ToString("yyyyMMdd")
            ToDate = Now.ToString("yyyyMMdd")
        ElseIf FromDate = "3" Then 'Last 30 days
            FromDate = Now.AddDays(-30).ToString("yyyyMMdd")
            ToDate = Now.ToString("yyyyMMdd")
        ElseIf FromDate = "4" Then 'Last 12 months days
            FromDate = Now.AddMonths(-12).ToString("yyyyMMdd")
            ToDate = Now.ToString("yyyyMMdd")
        End If
        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetUserOrders(WebsiteID, OrderID, UserID, ProductIDs, OrderType, FromDate:=FromDate, ToDate:=ToDate, FreeText:=FreeText, PageNo:=PageNo, PageSize:=PageSize, SortBy:=SortBy, SortOrder:=SortOrder)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "Orders"
        ds.Namespace = "OrdersHistory"
        jsonData = "{""Orders"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetMyCloseLocations(Key As String, UserID As Integer, MyLat As Single, MyLng As Single) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetMyCloseLocations(UserID, MyLat, MyLng)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "CloseBusinessLocations"
        ds.Namespace = "CloseBusinessLocations"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetBusinessDetailsWithProducts(Key As String, BusinessID As Integer, UserID As Integer, SearchText As String, PageNo As Integer, PageSize As Integer, SortBy As String, SortOrder As String,
     BusinessCategoryID As Integer, BusinessTypeID As Integer, DistanceNearTo As Single, MyLat As Single, MyLng As Single) As String

        Dim tbl As New DataTable
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetBusiness4Subscription(BusinessID, UserID, 1, SearchText, PageNo, PageSize, SortBy, SortOrder, BusinessCategoryID, BusinessTypeID, DistanceNearTo, MyLat, MyLng)
            tbl = Products.GetProductsList(Val(BusinessID), -1, -1, "", 1, 99999)
            ds.Tables.Add(tbl)
            ds.Tables(0).TableName = "BusinessDetail"
            ds.Tables(1).TableName = "BusinessProducts"
            ds.Namespace = "GetBusinessDetails"
            jsonData = "{""BusinessDetail"":" & General.GetDataTableJson(ds.Tables(0)) & ",""BusinessProducts"":" & General.GetDataTableJson(ds.Tables(1)) & "}"
        Else
            ds.Tables.Add(New DataTable())
        End If

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod(EnableSession:=True)>
    Public Function Products_GetProducts(Key As String, ByVal BID As String, Catagory As String, SubCatagory As String, SearchText As String, PageNo As Integer, PageSize As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            tbl = Products.GetProductsList(Val(BID), Catagory:=Catagory, SubCatagory:=SubCatagory, SearchText:=SearchText, PageNo:=Val(PageNo), PageSize:=Val(PageSize))
            ds.Tables.Add(tbl)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "ProductsList"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod(EnableSession:=True)>
    Public Function Products_GetProductDetails(Key As String, BID As String, ByVal PID As String, UserID As Integer) As String
        Dim ds As New DataSet
        Dim jsonData As String

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = Products.GetProductDetails(BID, PID, UserID)

            If ds.Tables.Count > 0 Then ds.Tables(0).TableName = "ProductDetail"
            If ds.Tables.Count > 1 Then ds.Tables(1).TableName = "ProductImages"
            jsonData = "{""ProductDetail"":" & General.GetDataTableJson(ds.Tables(0)) & ",""ProductImages"":" & General.GetDataTableJson(ds.Tables(1)) & "}"
        Else
            ds.Tables.Add(New DataTable())
        End If


        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetBusiness4Subscription(Key As String, BusinessID As Integer, UserID As Integer, SearchText As String, PageNo As Integer, PageSize As Integer, SortBy As String, SortOrder As String,
                                             BusinessCategoryID As Integer, BusinessTypeID As Integer, DistanceNearTo As Single, MyLat As Single, MyLng As Single) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetBusiness4Subscription(BusinessID, UserID, 1, SearchText, PageNo, PageSize, SortBy, SortOrder, BusinessCategoryID, BusinessTypeID, DistanceNearTo, MyLat, MyLng)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserSubscribedBusinesses(Key As String, UserID As Integer, SearchText As String, PageNo As Integer, PageSize As Integer, SortBy As String, SortOrder As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetUserSubscribedBusiness(UserID:=UserID, SearchText:=SearchText, PageNo:=PageNo, PageSize:=PageSize, SortBy:=SortBy, SortOrder:=SortOrder)
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "Businesses"
        ds.Namespace = "SearchBusinesses"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SubscribeMe(Key As String, UserID As Integer, BusinessID As Integer, SubscriptionTypeID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.SubscribeMeWithBusiness(UserID, BusinessID, SubscriptionTypeID)
            Log.Notifications_Add("New User Subscription :" & UserID, ds.Tables(0).Rows(0)("ID"), "New User Subscription", UserID, BusinessID)
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "SubscribeMe"
        ds.Namespace = "SubscribeMe"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function UnSubscribeMe(Key As String, UserID As Integer, BusinessID As Integer) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.UnSubscribeMeWithBusiness(UserID, BusinessID)

            Log.Notifications_Add("User UnSubscription :" & UserID, ds.Tables(0).Rows(0)("ID"), "User UnSubscription", UserID, BusinessID)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "UnSubscribeMe"
        ds.Namespace = "UnSubscribeMe"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function
#End Region

#Region "Device"

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetTemplates(Key As String,
                                 BusinessID As String,
                                 AppName As String,
                                 AppVersion As String,
                                 TemplateType As Integer) As String
        Dim ds As New DataSet
        Dim jsonData As String
        'Dim TokenKey As String = Cryptography.Decrypt(Key)
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetTemplates(-1, BusinessID, AppName, AppVersion, TemplateType)
        Else
            ds.Tables.Add(New DataTable())
        End If
        ds.Tables(0).TableName = "DeviceTemplates"
        ds.Namespace = "DeviceTemplates"
        jsonData = "{""DeviceTemplates"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function IsDeviceRegisteredWithJoined24New(Key As String, DeviceID As String, AppName As String, BusinessID As String, UserAccountType As Integer) As String
        Dim ds As New DataSet

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.IsDeviceRegistered(DeviceID, AppName, BusinessID, UserAccountType)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "RegisteredDevice"
        ''ds.Namespace = "RegisteredDevice"

        ds.Namespace = "RegisteredDevice"

        Return "{""RegisteredDeviceInfo"":" & General.GetDataTableJson(ds.Tables(0)) & ",""RegisteredBusinessSettings"":" & General.GetDataTableJson(ds.Tables(1)) & "}"
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function IsDeviceRegisteredWithJoined24(Key As String, DeviceID As String) As String
        Dim ds As New DataSet

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.IsDeviceRegistered(DeviceID)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "RegisteredDevice"
        ''ds.Namespace = "RegisteredDevice"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Xml)>
    <WebMethod()>
    Public Function IsDeviceRegisteredXml(Key As String, DeviceID As String) As String
        Dim ds As New DataSet
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.IsDeviceRegistered(DeviceID)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "RegisteredDevice"
        ''ds.Namespace = "RegisteredDevice"

        Return ds.GetXml().ToString()
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetDeviceGeoLocation(Key As String, DeviceID As String, DateFrom As String, DateTo As String, FreeText As String) As String
        Dim ds As New DataSet
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.GetDeviceGEOLocation(DeviceID, DateFrom, DateTo, FreeText)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "DeviceGeoLocation"
        ds.Namespace = "DeviceGeoLocation"

        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function SaveDeviceGeoLocation(Key As String, AppName As String, DeviceID As String, Lat As String, Lng As String, Speed As String,
                                  Heading As String, Altitude As String, Accuracy As String, AltitudeAccuracy As String,
                                  TimeStamp As String) As Boolean
        Dim res As Boolean = False
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            res = DeviceGeoLocation.SaveDeviceGEOLocation(AppName, DeviceID, Lat, Lng, Speed, Heading, Altitude, Accuracy, AltitudeAccuracy, TimeStamp)
        End If

        Return res
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function RegisterDevice(Key As String, AppName As String, Model As String, CordovaVersion As String, DeviceID As String,
         Platform As String, DeviceVersion As String, UserName As String, LoginID As String, Password As String,
         BusinessID As Integer, UserAccountType As Integer) As String

        Dim ds As New DataSet
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            ds = DeviceGeoLocation.RegisterDevice(AppName, Model, CordovaVersion, DeviceID, Platform, DeviceVersion, UserName, LoginID, Password, BusinessID, UserAccountType)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "DeviceRegister"
        ds.Namespace = "DeviceRegister"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetDeviceLocationPathPoints(Key As String, DeviceID As String, Dated As String) As String

        Dim ds As New DataSet
        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim dary() = Dated.Split("/")
            Dated = dary(2) & IIf(dary(0) <= 9, "0" & Val(dary(0)), Val(dary(0))) & IIf(dary(1) <= 9, "0" & Val(dary(1)), Val(dary(1)))
            ds = DeviceGeoLocation.GetDeviceLocationPathPoints(DeviceID, Dated)
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "DeviceLocationPoints"
        ds.Namespace = "DeviceLocationPoints"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

#End Region

#Region "Gift Cards"
    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetUserGiftCards(Key As String, DeviceID As String, UserID As Integer) As String
        Dim ds As New DataSet
        Dim tbl As New DataTable

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            tbl = GiftCard.GetUserCards(-1, UserID)
            ds.Tables.Add(tbl)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "UserGiftCards"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function

#End Region

#Region "Students"

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function GetAssignedStudents(Key As String, DeviceID As String, WebsiteID As Integer, UserID As Integer) As String
        Dim ds As New DataSet
        Dim tbl As New DataTable
        'PunchPurposeID=1=Time Punch
        'PunchTypeID=1=Check IN, 2= Check OUT

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        Dim jsonData As String = ""
        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            tbl = Person.GetAssignedUsers(WebsiteID, UserID, "7,")
            ds.Tables.Add(tbl)
        Else
            ds.Tables.Add(New DataTable())
        End If
        jsonData = "{""AssignedUsers"":" & General.GetDataTableJson(ds.Tables(0)) & "}"

        ds.Tables(0).TableName = "AssignedUsers"
        Return jsonData
    End Function

    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function AddAttendancePunches(Key As String, DeviceID As String, WebsiteID As Integer, EmployeeID As Integer,
                                         ShiftID As Integer, PunchTypeID As Integer, PunchPurposeID As Integer, EmpPunchDateTime As DateTime, Comments As String, Lat As Single, Lng As Single, AddedBy As Integer) As String
        Dim ds As New DataSet
        Dim tbl As New DataTable
        'PunchPurposeID=1=Time Punch
        'PunchTypeID=1=Check IN, 2= Check OUT

        'Dim TokenKey As String = Cryptography.Decrypt(Key)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            BusinessTMS.AddEmpPunch(WebsiteID, EmployeeID, ShiftID, PunchTypeID, PunchPurposeID, Now, Comments, Lat, Lng)
            ds.Tables.Add(tbl)
        Else
            ds.Tables.Add(New DataTable())
        End If

        ds.Tables(0).TableName = "UserAttendance"
        Return General.GetDataTableJson(ds.Tables(0))
    End Function


    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    <WebMethod()>
    Public Function Messages(Key As String, Packet As String) As String
        Dim tbl As New DataTable
        Dim ds As New DataSet
        'Action[MsgOnly,Msg+Attendance]
        'Normal - 0-Action, 1-DeviceID, 2-WebsiteID, 3-FromUserID, 4-ChatID, 5-ToUserID, 6-Message, 7-ReadFromID
        'Atten  - 0-Action, 1-DeviceID, 2-WebsiteID, 3-FromUserID, 4-ChatID, 5-ToUserID, 6-Message, 7-ReadFromID, 8-ShiftID , 9-PunchTypeID, 10-PunchPurposeID, 11-AttendanceComments,12-Lat , 13-Lng

        Dim PacketAry = Packet.Split("^")

        Dim Action As String = PacketAry(0)

        If Key = ConfigurationManager.AppSettings("WebServiceTokenKey") Then
            Dim DeviceID As String = PacketAry(1)
            Dim WebsiteID As Integer = PacketAry(2)
            Dim FromUserID As Integer = PacketAry(3)
            Dim ChatID As Integer = PacketAry(4)
            Dim ToUserID As Integer = PacketAry(5)
            Dim Message As String = PacketAry(6)
            Dim ReadFromID As Integer = PacketAry(7)
            If Action = "MsgOnly" Then
                If PacketAry.Length <= 8 Then
                    ds.Tables.Add(Chat.SendMessage(ChatID, FromUserID, Message, ReadFromID))
                End If
            ElseIf Action = "Msg+Attendance" Then
                Dim ShiftID As Integer = PacketAry(8)
                Dim PunchTypeID As Integer = PacketAry(9)
                Dim PunchPurposeID As Integer = PacketAry(10)
                Dim AttendanceComments As String = PacketAry(11)
                Dim Lat As Single = PacketAry(12)
                Dim Lng As Single = PacketAry(13)
                If PacketAry.Length > 8 And PacketAry.Length <= 14 Then
                    ds.Tables.Add(Chat.SendMessage(ChatID, FromUserID, Message, ReadFromID, ToUserID))
                    BusinessTMS.AddEmpPunch(WebsiteID, ToUserID, ShiftID, PunchTypeID, PunchPurposeID, Now, AttendanceComments, Lat, Lng)
                End If
            End If
        Else
            ds.Tables.Add(New DataTable())
        End If


        ds.Tables(0).TableName = "ChatLog"
        ds.Namespace = "ChatLog"

        Return "{""ChatLog"":" & General.GetDataTableJson(ds.Tables(0)) & "}"
    End Function
#End Region
End Class