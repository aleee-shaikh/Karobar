﻿Public Class POTermsConditions
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 123) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        End If
        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            txtDescription.Text = ""
            ds = WebSectionsBLL.GetSectionDetail(Session("CurrentBusinessID"), 6)
            If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0) Then
                txtDescription.Text = ds.Tables(0).Rows(0)("SectionDescription")
            End If
            LblScreenTitle.Text = "PO Terms & Conditions"
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        WebSectionsBLL.AddUpdateWebSection(Session("CurrentBusinessID"), 6, txtDescription.Text.Replace("'", "''"))
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "POTermsDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('PO Terms & Condition has been saved successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
    End Sub
End Class