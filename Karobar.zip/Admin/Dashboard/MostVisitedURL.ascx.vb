﻿Public Class MostVisitedURL
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        GrdArticleViewsStatistics.DataSource = WebsiteArticles.GetArticlesViewsStatistics()
        GrdArticleViewsStatistics.DataBind()

    End Sub

    Private Sub GrdArticleViewsStatistics_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdArticleViewsStatistics.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='whitesmoke';this.style.cursor='pointer';")
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
        End If
    End Sub
End Class