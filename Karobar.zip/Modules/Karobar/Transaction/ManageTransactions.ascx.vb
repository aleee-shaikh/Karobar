﻿Public Class ManageTransactions
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtTransactionFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtTransactionToDate.Text = Now.ToString("dd-MM-yyyy")
            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim ds As New DataSet
        Dim FDate As String = ""
        Dim FdateAry() = txtTransactionFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtTransactionToDate.Text.Replace("/", "-").Split("-")

        ''_tbl = Log.GetNotifications(Session("CurrentBusinessID"), FdateAry(2) & FdateAry(1) & FdateAry(0), TdateAry(2) & TdateAry(1) & TdateAry(0))
        Dim AccountHeadIDs As String = ""

        AccountHeadIDs = ReferenceData.Setting("AccountHeadIDs4Log", "", Session("CurrentBusinessID"))
        _tbl = Log.GetAccountHeadsLog(HttpContext.Current.Session("UserID"), AccountHeadIDs, "", TdateAry(2) & TdateAry(1) & TdateAry(0), CDate(Now), "")

        Session("Transactions-" & Session("UserID")) = _tbl
        GrdNotifications.DataSource = _tbl
        GrdNotifications.DataBind()
        'ChartOfAccount.LoadCOADDL(DDLAccountHead)
        'ds = Transactions.GetTransactions(Session("CurrentBusinessID"), DDLAccountHead.SelectedValue, CDate(FdateAry(1) & "-" & FdateAry(0) & "-" & FdateAry(2) & " 00:00:00 AM"), CDate(TdateAry(1) & "-" & TdateAry(0) & "-" & TdateAry(2) & " 23:59:59 PM"), "")
        '_tbl = New DataTable
        'If ds.Tables.Count > 0 Then
        '    _tbl = ds.Tables(0)
        'End If

        'Session("Transactions-" & Session("UserID")) = _tbl
        'GrdTransactions.DataSource = _tbl
        'GrdTransactions.DataBind()
    End Sub

    'Private Sub GrdTransactions_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdTransactions.RowCommand
    '    If e.CommandName = "VoidTransaction" Then
    '        Transactions.VoidTransaction(Session("CurrentBusinessID"), Val(e.CommandArgument), "Void")
    '        Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Void Transaction", "Void Transaction :" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
    '        LoadData()
    '    ElseIf e.CommandName = "UnvoidTransaction" Then
    '        Transactions.VoidTransaction(Session("CurrentBusinessID"), Val(e.CommandArgument), "Active")
    '        Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "UnVoid Transaction", "UnVoid Transaction :" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
    '        LoadData()
    '    End If
    'End Sub

    'Private Sub GrdTransactions_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdTransactions.RowDataBound
    '    If e.Row.RowType = DataControlRowType.DataRow Then
    '        Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)


    '        If drview("TransactionStatus") = "Active" Then
    '            _TotalDebit = _TotalDebit + IIf(IsDBNull(drview("TransactionAmount")), 0, drview("TransactionAmount"))
    '            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
    '            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
    '            Dim BtnVoid As New Button
    '            BtnVoid = CType(e.Row.FindControl("BtnVoidTransaction"), Button)
    '            If Not BtnVoid Is Nothing Then
    '                BtnVoid.Text = "Void Transaction"
    '                BtnVoid.CommandName = "VoidTransaction"
    '                BtnVoid.OnClientClick = "return confirm('Void transaction?')"
    '            End If
    '        Else
    '            e.Row.Attributes.Add("style", "background:red;color:white")
    '            e.Row.Attributes.Add("onMouseOver", "this.style.backgroundColor='pink';this.style.cursor='pointer';")
    '            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor='Red';this.style.cursor='pointer';")

    '            Dim BtnVoid As New Button
    '            BtnVoid = CType(e.Row.FindControl("BtnVoidTransaction"), Button)
    '            If Not BtnVoid Is Nothing Then
    '                BtnVoid.Text = "Unvoid Transaction"
    '                BtnVoid.CommandName = "UnvoidTransaction"
    '                BtnVoid.OnClientClick = "return confirm('Unvoid transaction?')"
    '            End If
    '        End If
    '        ''_TotalCredit = _TotalCredit + IIf(IsDBNull(drview("Credit")), 0, drview("Credit"))
    '    ElseIf e.Row.RowType = DataControlRowType.Footer Then
    '        Dim TotalDebitLbl As New System.Web.UI.WebControls.Label
    '        Dim TotalCreditLbl As New System.Web.UI.WebControls.Label

    '        TotalDebitLbl = CType(e.Row.FindControl("LblTotalDebit"), Label)
    '        TotalCreditLbl = CType(e.Row.FindControl("LblTotalCredit"), Label)

    '        If Not TotalDebitLbl Is Nothing Then
    '            TotalDebitLbl.Text = _TotalDebit
    '        End If

    '        If Not TotalCreditLbl Is Nothing Then
    '            TotalCreditLbl.Text = _TotalCredit
    '        End If
    '    End If

    'End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim attachment As String = ""
        If Not Session("Transactions-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("Transactions-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            attachment = "attachment; filename=NoDataFound.csv"
        Else
            attachment = "attachment; filename=Transactions" & Now.ToString("yyyyMMddhhmm") & ".csv"

            For i As Integer = 0 To _tbl.Columns.Count - 1
                Data = Data & _tbl.Columns(i).ColumnName & ","
            Next
            Data = Data & Environment.NewLine
            For i As Integer = 0 To _tbl.Rows.Count - 1
                For j As Integer = 0 To _tbl.Columns.Count - 1
                    Data = Data & _tbl.Rows(i)(j) & ","
                Next
                Data = Data & Environment.NewLine
            Next
        End If

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", attachment)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub GrdNotifications_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdNotifications.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim Lnk As New HyperLink
            Lnk = CType(e.Row.FindControl("LnkNotification"), HyperLink)
            If (drview("NotificationGroup") = "Order Received") Then
                Lnk.Attributes.Add("onclick", "ShowOrderDetails('" & drview("ID") & "')")
            ElseIf (drview("NotificationGroup") = "Cash Sale") Or (drview("NotificationGroup") = "Credit Sale") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/SaleInvoice.aspx?SaleID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("NotificationGroup") = "Sale Return") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/SaleInvoice.aspx?SaleID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("NotificationGroup") = "Purchase Product") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/PurchaseInvoice.aspx?PurchaseID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("NotificationGroup") = "Payment Received") Then
                Lnk.Attributes.Add("onclick", "ShowReceivePaymentInvoice(" & drview("ID") & ")")
            ElseIf (drview("NotificationGroup") = "Cash Payment") Then
                Lnk.Attributes.Add("onclick", "ShowCashPaymentInvoice(" & drview("ID") & ")")
            ElseIf (drview("NotificationGroup") = "Bank Payment") Then
                Lnk.Attributes.Add("onclick", "ShowBankPaymentInvoice(" & drview("ID") & ")")
            Else
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/TransactionDetails.aspx?TID=" & drview("ID") & "', $(window).height() * 85 / 100, $(window).width() * 75 / 100)")

            End If
            Lnk.Text = drview("NotificationText")
        End If
    End Sub
End Class