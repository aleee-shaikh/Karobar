﻿Public Class Gallary
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 171) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If
        Dim BusinessDetailtbl As New DataTable
        BusinessDetailtbl = ChartOfAccount.GetBusinessDetails(Val(Session("CurrentBusinessID")))

        If (BusinessDetailtbl.Rows(0)("CategoryTitle").ToString().ToLower().IndexOf("job ") >= 0) Or (Not Session("CurrentBusinessCategoryID") Is Nothing AndAlso Val(Session("CurrentBusinessCategoryID")) = 5) Then
            trProductBarcode.Visible = False
            trProductPriceRow.Visible = False
            trProductUnitSizeColor.Visible = False
            FileUploadProductImage1.Visible = False
            FileUploadProductImage2.Visible = False
            FileUploadProductImage3.Visible = False
            FileUploadProductImage4.Visible = False
            FileUploadProductImage5.Visible = False
            FileUploadProductImage6.Visible = False
            FileUploadProductImage7.Visible = False
            DivMinAlertQty.Visible = False
            ParentProduct.Visible = False
            DivPromptPriceOnSale.Visible = False
            txtDescription.Height = 160
            trProductCategoryManufacture.Visible = False
        End If

        If Not Page.IsPostBack Then
            Dim RetVlu As String = ""
            pnlHeaderLnks.Visible = (ReferenceData.Setting("RequiredProductSaleMapping", "No", Session("CurrentBusinessID")) = "Yes")

            'LblProductName.Text = ReferenceData.Setting("LblProductName", "Product Name", Session("CurrentBusinessID"))
            'LblCategory.Text = ReferenceData.Setting("LblProductCategory", "Category", Session("CurrentBusinessID"))
            'LblSubCategory.Text = ReferenceData.Setting("LblProductSubCategory", "Sub Category", Session("CurrentBusinessID"))
            'LblModel.Text = ReferenceData.Setting("LblProductModel", "Model", Session("CurrentBusinessID"))
            'LblManufacturer.Text = ReferenceData.Setting("LblProductManufacturer", "Manufacturer", Session("CurrentBusinessID"))
            'LblPurchasePrice.Text = ReferenceData.Setting("LblProductPurchasePrice", "Purchase Price", Session("CurrentBusinessID"))
            'LblTax.Text = ReferenceData.Setting("LblProductTax", "Tax", Session("CurrentBusinessID"))
            'LblOthers.Text = ReferenceData.Setting("LblProductOthers", "Others", Session("CurrentBusinessID"))
            'ChkPromptPriceOnSale.Text = ReferenceData.Setting("LblProductPromptPriceOnSale", "Prompt price on sale", Session("CurrentBusinessID"))
            'LblSalePrice.Text = ReferenceData.Setting("LblProductSalePrice", "Sale Price", Session("CurrentBusinessID"))
            'LblUnit.Text = ReferenceData.Setting("LblProductUnit", "Unit", Session("CurrentBusinessID"))
            'LblSize.Text = ReferenceData.Setting("LblProductSize", "Size", Session("CurrentBusinessID"))
            'LblWeight.Text = ReferenceData.Setting("LblProductWeight", "Weight", Session("CurrentBusinessID"))
            'LblColor.Text = ReferenceData.Setting("LblProductColor", "Color", Session("CurrentBusinessID"))
            'LblBarCode.Text = ReferenceData.Setting("LblProductBarcode", "BarCode", Session("CurrentBusinessID"))
            'LblDescription.Text = ReferenceData.Setting("LblProductDescription", "Description", Session("CurrentBusinessID"))
            'LblMinAlertQty.Text = ReferenceData.Setting("LblMinAlertQty", "Min Alert Qty", Session("CurrentBusinessID"))

            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
            DDLProductCatagory.DataValueField = "ArticleTypeID"
            DDLProductCatagory.DataTextField = "ArticleType"
            DDLProductCatagory.DataSource = ds.Tables(0)
            DDLProductCatagory.DataBind()

            ''DDLProductCatagory.SelectedValue = Val(Website.GetWebsiteDetailColumn(Session("CurrentBusinessID"), "WebsiteCategoryID"))
            Dim SubCID As Integer = -1

            If DDLProductSubCatagory.Items.Count > 0 Then
                SubCID = DDLProductSubCatagory.SelectedItem.Value
            End If
            If SubCID = -1 Then
                If DDLProductCatagory.Items.Count > 0 Then
                    SubCID = DDLProductCatagory.SelectedItem.Value
                End If
            End If

            LoadProductSubCatagoriesAndUnits(SubCID)
            If Not Request("PID") Is Nothing Then
                HdnProductID.Value = Val(Request("PID"))
            Else

            End If

            LoadParentProducts(Val(HdnProductID.Value))

            If Val(HdnProductID.Value) > 0 Then
                LoadData(Val(HdnProductID.Value))
            End If

        End If
        If Val(HdnProductID.Value) <= 0 Then
            LblScreenTitle.Text = "Gallary"
            'LnkFbShare.Visible = False
            ProductImage.ImageUrl = "~/Images/No-Image.png"
        Else
            LblScreenTitle.Text = "Gallary"
        End If
        If Val(HdnProductID.Value) > 0 Then
            'LnkFbShare.Visible = True
            'LnkFbShare.Attributes.Add("onclick", "window.open('https://www.facebook.com/sharer/sharer.php?u=http://joined24.com/Modules/Karobar/Product/FBShareProduct.aspx?PID=" & Val(HdnProductID.Value) & "','', 'toolbar=0,status=0,width=548,height=325');")
            'LnkFbShare.Visible = True
            BtnSave.Text = "Update"

        Else
            'LnkFbShare.Visible = False
            BtnSave.Text = "Add Image"
        End If
    End Sub

    Sub LoadParentProducts(ProductID As Integer)
        Dim ds As New DataSet
        ds = Products.GetParentProducts(Session("CurrentBusinessID"), 0, ProductID)
        DDLParentProduct.DataTextField = "ArticleTitle"
        DDLParentProduct.DataValueField = "ArticleID"
        DDLParentProduct.DataSource = ds
        DDLParentProduct.DataBind()
        DDLParentProduct.Items.Insert(0, New ListItem("None", "0"))
    End Sub

    Sub LoadData(ByVal PID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Products.GetProductDetails(Session("CurrentBusinessID"), PID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
            If ds.Tables(0).Rows.Count > 0 Then
                If (ds.Tables(1).Rows.Count > 0) Then
                    ProductImages1.Visible = True
                    pnlImageUploaders.Visible = False
                    ProductImages1.ProductID = PID
                    ProductImages1.LoadData()
                End If
            Else
                BtnSave.Visible = False
                BtnSave.Enabled = False
            End If
        End If
        If tbl.Rows.Count > 0 Then
            txtProductName.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleTitle")), "", tbl.Rows(0)("ArticleTitle"))
            txtModel.Text = IIf(IsDBNull(tbl.Rows(0)("Model")), "", tbl.Rows(0)("Model"))
            txtManufacturer.Text = IIf(IsDBNull(tbl.Rows(0)("Manufacturer")), "", tbl.Rows(0)("Manufacturer"))
            txtPurchasePrice.Text = IIf(IsDBNull(tbl.Rows(0)("PurchasePrice")), "", tbl.Rows(0)("PurchasePrice"))
            txtTax.Text = IIf(IsDBNull(tbl.Rows(0)("Tax")), "", tbl.Rows(0)("Tax"))
            txtOthers.Text = IIf(IsDBNull(tbl.Rows(0)("OtherCharges")), "", tbl.Rows(0)("OtherCharges"))
            txtSalePrice.Text = IIf(IsDBNull(tbl.Rows(0)("SalePrice")), "", tbl.Rows(0)("SalePrice"))
            txtSize.Text = IIf(IsDBNull(tbl.Rows(0)("Size")), "", tbl.Rows(0)("Size"))
            txtWeight.Text = IIf(IsDBNull(tbl.Rows(0)("Weight")), "", tbl.Rows(0)("Weight"))
            txtColor.Text = IIf(IsDBNull(tbl.Rows(0)("Color")), "", tbl.Rows(0)("Color"))
            txtBarCode.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleBarcode")), "", tbl.Rows(0)("ArticleBarcode"))
            txtDescription.Text = IIf(IsDBNull(tbl.Rows(0)("ArticleText")), "", tbl.Rows(0)("ArticleText"))
            DDLProductCatagory.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("ArticleTypeID")), "", tbl.Rows(0)("ArticleTypeID"))
            LoadProductSubCatagoriesAndUnits(DDLProductCatagory.SelectedItem.Value)
            DDLProductSubCatagory.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("ArticleCatagory")), "", tbl.Rows(0)("ArticleCatagory"))
            'DDLUnit.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Unit")), "", tbl.Rows(0)("Unit"))
            ChkFeatured.Checked = IIf(IsDBNull(tbl.Rows(0)("Featured")) = True OrElse tbl.Rows(0)("Featured") = False, False, True)
            ChkPromptPriceOnSale.Checked = IIf(IsDBNull(tbl.Rows(0)("Prompt4PriceOnSale")) = True OrElse tbl.Rows(0)("Prompt4PriceOnSale") = False, False, True)
            txtMinAlertQty.Text = IIf(IsDBNull(tbl.Rows(0)("MinAlertQty")), "0", tbl.Rows(0)("MinAlertQty"))

            If (IsDBNull(tbl.Rows(0)("ArticleImage")) = False AndAlso tbl.Rows(0)("ArticleImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Product/Images"
                HdnProductImageFileName.Value = tbl.Rows(0)("ArticleImage")
                ProductImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ArticleImage")
                ProductImage.AlternateText = txtProductName.Text
            Else
                ProductImage.ImageUrl = "~/Images/No-Image.png"
            End If
            Dim ParentProductID As Integer = 0
            If (IsDBNull(ds.Tables(0).Rows(0)("ParentArticleID")) = False AndAlso Val(ds.Tables(0).Rows(0)("ParentArticleID")) > 0) Then
                ParentProductID = Val(ds.Tables(0).Rows(0)("ParentArticleID"))
            End If
            If Not DDLParentProduct.Items.FindByValue(ParentProductID) Is Nothing Then
                DDLParentProduct.SelectedValue = ParentProductID
            End If

            If pnlHeaderLnks.Visible Then
                Dim mappingDS As New DataSet
                mappingDS = WebsiteArticles.GetProductMapping(Session("CurrentBusinessID"), Val(HdnProductID.Value), -1)
                Dim BuyProducts As String = ""
                Dim GetProducts As String = ""
                Dim BuyProductsDtls As String = ""
                Dim GetProductsDtls As String = ""

                For i As Integer = 0 To mappingDS.Tables(1).Rows.Count - 1
                    BuyProducts = BuyProducts & mappingDS.Tables(1).Rows(i)("ProductID") & ";"
                    BuyProductsDtls = BuyProductsDtls & mappingDS.Tables(1).Rows(i)("ProductID") & "|" & mappingDS.Tables(1).Rows(i)("Qty") & ";"
                Next

                If mappingDS.Tables(0).Rows.Count > 0 Then
                    txtOfferDiscount.Text = mappingDS.Tables(0).Rows(0)("Discount")
                End If
                HdnBuyProductsSelected.Value = BuyProducts
                HdnBuyProductDtls.Value = BuyProductsDtls

                For i As Integer = 0 To mappingDS.Tables(2).Rows.Count - 1
                    GetProducts = GetProducts & mappingDS.Tables(2).Rows(i)("ProductID") & ";"
                    GetProductsDtls = GetProductsDtls & mappingDS.Tables(2).Rows(i)("ProductID") & "|" & mappingDS.Tables(2).Rows(i)("Qty") & ";"
                Next
                HdnGetProductsSelected.Value = GetProducts
                HdnGetProductDtls.Value = GetProductsDtls

                If mappingDS.Tables(0).Rows.Count > 0 Then
                    DDLSaleMappingType.SelectedValue = mappingDS.Tables(0).Rows(0)("SaleTypeID")
                    DDLSaleMappingType_SelectedIndexChanged(DDLSaleMappingType, Nothing)
                End If
                Dim ProductTbl As New DataTable
                ProductTbl = Products.GetProductsList(Session("CurrentBusinessID"))

                GrdBuyProducts.DataSource = ProductTbl
                GrdBuyProducts.DataBind()

                grdGetProducts.DataSource = ProductTbl
                grdGetProducts.DataBind()
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim GallaryDs As New DataSet
        Dim GallaryID As Integer
        If Val(hdnGallaryID.Value) <= 0 Then
            GallaryDs = Products.AddProductType(Session("CurrentBusinessID"), Website.DataTypes.ProductSubCatagories * -1, txtGallaryTitle.Text.Trim, DDLProductCatagory.SelectedValue)
            If (GallaryDs.Tables.Count > 0 AndAlso GallaryDs.Tables(0).Rows.Count > 0) Then
                GallaryID = GallaryDs.Tables(0).Rows(0)("ArticleTypeID")
            End If
        Else
            GallaryID = hdnGallaryID.Value
            Products.UpdateProductTypeName(Session("CurrentBusinessID"), GallaryID, txtGallaryTitle.Text.Trim(), DDLProductCatagory.SelectedValue)
        End If



        'Products.AddProductType(Session("CurrentBusinessID"), 0, txtGallaryTitle.Text.Trim())

        If FileUploadProductImage.PostedFile.FileName <> "" Or HdnProductImageFileName.Value <> "" Then


            Dim tbl As New DataTable
            Dim ProductImageFilename As String = HdnProductImageFileName.Value
            Dim SubCID As Integer = GallaryID
            Dim Unit As Integer = -1
            Dim PID As Integer
            Dim Discount As Single = 0
            Dim SalePrice As Single = 0


            If FileUploadProductImage.PostedFile.FileName <> "" AndAlso FileUploadProductImage.PostedFile.FileName <> ProductImageFilename Then
                ProductImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadProductImage.PostedFile.FileName)
                Dim BusinessDirectory As String = Server.MapPath("~/CMS/Product/") & "/Images"
                Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
                If dinfo.Exists() = False Then
                    System.IO.Directory.CreateDirectory(BusinessDirectory)
                End If

                Dim OldImage As String = HdnProductImageFileName.Value
                If (OldImage <> "") Then
                    If System.IO.File.Exists(Server.MapPath("~/CMS/Product/Images/" & OldImage)) Then
                        System.IO.File.Delete(Server.MapPath("~/CMS/Product/Images/" & OldImage))
                    End If
                End If

                FileUploadProductImage.SaveAs(BusinessDirectory & "/" & ProductImageFilename)
            End If
            If Val(HdnProductID.Value) > 0 Then
                tbl = Products.UpdateProduct(Session("CurrentBusinessID"), Val(HdnProductID.Value), DDLProductCatagory.SelectedItem.Value, SubCID, txtBarCode.Text.Trim,
                                       txtProductName.Text.Trim, txtDescription.Text.Trim, ProductImageFilename, txtModel.Text.Trim, txtManufacturer.Text.Trim,
                                       Val(txtPurchasePrice.Text.Trim), Val(txtTax.Text.Trim), Val(txtOthers.Text.Trim), Val(txtSalePrice.Text.Trim), Unit,
                                        txtSize.Text.Trim, txtWeight.Text.Trim, txtColor.Text.Trim, HttpContext.Current.Session("UserID"), 1, txtDescription.Text.Trim, "", ChkFeatured.Checked, DDLParentProduct.SelectedValue, ChkPromptPriceOnSale.Checked, Val(txtMinAlertQty.Text))
                PID = Val(HdnProductID.Value)
                Products.AddProductImage(Session("CurrentBusinessID"), Val(HdnProductID.Value), ProductImageFilename, "", HttpContext.Current.Session("UserID"))
                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductUpdateSuccessFully", "<script>parent.ShowMessage('Product updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductUpdateIssue", "<script>parent.ShowMessage('Unable to update Product','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
                hdnGallaryPhotoID.Value = 0
                HdnProductID.Value = 0
                txtProductName.Text = ""
                txtDescription.Text = ""
                ProductImage.ImageUrl = "~/Images/No-Image.png"
                LoadGallaryImages(Val(hdnGallaryID.Value))
                BtnSave.Text = " Add Image"
            Else
                tbl = Products.AddProduct(Session("CurrentBusinessID"), DDLProductCatagory.SelectedItem.Value, SubCID, txtBarCode.Text.Trim,
                                       txtProductName.Text.Trim, txtDescription.Text.Trim, ProductImageFilename, txtModel.Text.Trim, txtManufacturer.Text.Trim,
                                       Val(txtPurchasePrice.Text.Trim), Val(txtTax.Text.Trim), Val(txtOthers.Text.Trim), Val(txtSalePrice.Text.Trim), Unit,
                                        txtSize.Text.Trim, txtWeight.Text.Trim, txtColor.Text.Trim, HttpContext.Current.Session("UserID"), 1, txtDescription.Text.Trim, "", ChkFeatured.Checked, DDLParentProduct.SelectedValue, ChkPromptPriceOnSale.Checked, Val(txtMinAlertQty.Text))

                If tbl.Rows.Count > 0 Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductAddedSuccessFully", "<script>parent.ShowMessage('Product added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    LoadGallaryImages(GallaryID)
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "ProductAddingIssue", "<script>parent.ShowMessage('Unable to add Product','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
                hdnGallaryPhotoID.Value = 0
                HdnProductID.Value = 0
                txtProductName.Text = ""
                txtDescription.Text = ""
                ProductImage.ImageUrl = "~/Images/No-Image.png"
            End If
        End If

    End Sub

    Sub SaveArticleImage(ByVal ArticleID As Integer, ByRef Fileupload As FileUpload)
        If Fileupload.FileName <> "" Then
            Dim ProductImageFilename As String = Guid.NewGuid.ToString & System.IO.Path.GetExtension(Fileupload.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/Product/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If

            Fileupload.SaveAs(BusinessDirectory & "/" & ProductImageFilename)

            Products.AddProductImage(Session("CurrentBusinessID"), ArticleID, ProductImageFilename, "", HttpContext.Current.Session("UserID"))
        End If
    End Sub

    Private Sub DDLProductCatagory_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLProductCatagory.SelectedIndexChanged
        LoadProductSubCatagoriesAndUnits(DDLProductCatagory.SelectedItem.Value)
    End Sub

    Sub LoadProductSubCatagoriesAndUnits(ByVal GroupTypeID As Integer)
        DDLProductSubCatagory.Items.Clear()
        DDLUnit.Items.Clear()
        Dim ds As New DataSet
        ds = New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        DDLProductSubCatagory.DataValueField = "ArticleTypeID"
        DDLProductSubCatagory.DataTextField = "ArticleType"
        Dim tbl As New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If
        DDLProductSubCatagory.DataSource = tbl
        DDLProductSubCatagory.DataBind()
        rptCategory.DataSource = tbl
        rptCategory.DataBind()

        ds = New DataSet
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductUnits * -1)
        DDLUnit.DataValueField = "ArticleTypeID"
        DDLUnit.DataTextField = "ArticleType"
        tbl = New DataTable
        If ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).Length > 0 Then
            tbl = ds.Tables(0).Select("GroupTypeID=" & GroupTypeID).CopyToDataTable
        End If
        DDLUnit.DataSource = tbl
        DDLUnit.DataBind()
    End Sub

    Private Sub DDLSaleMappingType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLSaleMappingType.SelectedIndexChanged
        If DDLSaleMappingType.SelectedItem.Value <= 0 Then
            pnlGetYFree.Visible = False
            pnlGetDiscount.Visible = False
            pnlBuyProducts.Visible = False
        ElseIf DDLSaleMappingType.SelectedItem.Value = 1 Then
            pnlGetYFree.Visible = True
            pnlGetDiscount.Visible = False
            pnlBuyProducts.Visible = True
        ElseIf DDLSaleMappingType.SelectedItem.Value = 2 Then
            pnlGetYFree.Visible = False
            pnlGetDiscount.Visible = True
            pnlBuyProducts.Visible = True
        End If
    End Sub


    Private Sub GrdBuyProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdBuyProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnProductID As New HiddenField
            Dim selectedProducts As String = HdnBuyProductsSelected.Value
            chk = CType(e.Row.FindControl("ChkProduct"), CheckBox)
            hdnProductID = CType(e.Row.FindControl("hdnProductID"), HiddenField)
            If (Not hdnProductID Is Nothing) Then
                Dim tmpAry() = selectedProducts.Split(";")
                For x As Integer = 0 To tmpAry.Length - 1
                    If (Val(tmpAry(x)) > 0 AndAlso Val(tmpAry(x)) = hdnProductID.Value) Then
                        chk.Checked = True
                        Dim BuyProducts() = HdnBuyProductDtls.Value.Split(";")
                        For i As Integer = 0 To BuyProducts.Length - 1
                            Dim tmp = BuyProducts(i).Split("|")
                            If (tmp(0) = hdnProductID.Value) Then
                                Dim Qty As New TextBox
                                Qty = CType(e.Row.FindControl("txtQty"), TextBox)
                                Qty.Text = tmp(1)
                            End If
                        Next
                    End If
                Next

            End If

        End If
    End Sub


    Private Sub grdGetProducts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles grdGetProducts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim chk As New CheckBox
            Dim hdnProductID As New HiddenField
            Dim selectedProducts As String = HdnGetProductsSelected.Value
            chk = CType(e.Row.FindControl("ChkProduct"), CheckBox)
            hdnProductID = CType(e.Row.FindControl("hdnProductID"), HiddenField)
            If (Not hdnProductID Is Nothing) Then
                Dim tmpAry() = selectedProducts.Split(";")
                For x As Integer = 0 To tmpAry.Length - 1
                    If (Val(tmpAry(x)) > 0 AndAlso Val(tmpAry(x)) = hdnProductID.Value) Then
                        chk.Checked = True
                        Dim BuyProducts() = HdnBuyProductDtls.Value.Split(";")
                        For i As Integer = 0 To BuyProducts.Length - 1
                            Dim tmp = BuyProducts(i).Split("|")
                            If (tmp(0) = hdnProductID.Value) Then
                                Dim Qty As New TextBox
                                Qty = CType(e.Row.FindControl("txtQty"), TextBox)
                                Qty.Text = tmp(1)
                            End If
                        Next
                    End If
                Next

            End If

        End If
    End Sub

    Protected Sub btnAddGallary_Click(sender As Object, e As ImageClickEventArgs)
        pnlGallary.Visible = True
        pnlGalleryCategories.Visible = False
        pnlGallaryPhoto.Visible = True
        BtnSave.Visible = True
        hdnGallaryID.Value = -1
    End Sub

    Protected Sub lnkGallary_Click(sender As Object, e As EventArgs)
        Dim GID As Integer = Val(CType(sender, LinkButton).CommandArgument)
        hdnGallaryID.Value = GID
        pnlGallary.Visible = True
        pnlGalleryCategories.Visible = False
        pnlGallaryPhoto.Visible = True
        BtnSave.Visible = True

        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductSubCatagories * -1)
        If (ds.Tables.Count > 0) Then
            If ds.Tables(0).Select("ArticleTypeid=" & GID).Length > 0 Then

                tbl = ds.Tables(0).Select("ArticleTypeid=" & GID).CopyToDataTable()
                txtGallaryTitle.Text = tbl.Rows(0)("ArticleType")

            End If
        End If

        LoadGallaryImages(GID)
    End Sub

    Sub LoadGallaryImages(GID As Integer)
        Dim tbl As New DataTable
        tbl = Products.GetProductsList(Session("CurrentBusinessID"), DDLProductCatagory.SelectedItem.Value, GID)
        rptGallaryImages.DataSource = tbl
        rptGallaryImages.DataBind()
    End Sub

    Protected Sub lnkEditPhoto_Click(sender As Object, e As EventArgs)
        Dim gallaryPhotoID As Integer = Val(CType(sender, LinkButton).CommandArgument)
        hdnGallaryPhotoID.Value = gallaryPhotoID
        HdnProductID.Value = gallaryPhotoID
        LoadData(gallaryPhotoID)
        BtnSave.Text = "Update"
    End Sub

    Protected Sub lnkDeletePhoto_Click(sender As Object, e As EventArgs)
        Dim ds As New DataSet
        Dim gallaryPhotoID As Integer = Val(CType(sender, LinkButton).CommandArgument)
        ds = Products.GetProductDetails(Session("CurrentBusinessID"), gallaryPhotoID)
        If (ds.Tables.Count > 0) Then
            If (IsDBNull(ds.Tables(0).Rows(0)("ArticleImage")) = False AndAlso ds.Tables(0).Rows(0)("ArticleImage") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/Product/Images"
                If System.IO.File.Exists(Server.MapPath(BusinessDirectory & "/" & ds.Tables(0).Rows(0)("ArticleImage"))) Then
                    System.IO.File.Delete(Server.MapPath(BusinessDirectory & "/" & ds.Tables(0).Rows(0)("ArticleImage")))
                End If
                Products.DeleteProduct(Session("CurrentBusinessID"), gallaryPhotoID)
            End If
        End If


        LoadGallaryImages(Val(hdnGallaryID.Value))
    End Sub

    Protected Sub LnkBack_Click(sender As Object, e As EventArgs)
        hdnGallaryID.Value = 0
        HdnProductID.Value = 0
        hdnGallaryPhotoID.Value = 0

        pnlGallary.Visible = False
        pnlGalleryCategories.Visible = True
        pnlGallaryPhoto.Visible = False
    End Sub
End Class