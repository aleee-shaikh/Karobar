﻿Public Class Vendor
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 49) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            BtnSave.Visible = False
            Exit Sub
        End If
        LblSupplierName.Text = ReferenceData.Setting("LblSupplierName", "Supplier Name", Session("CurrentBusinessID"))
        LblSupplierDescription.Text = ReferenceData.Setting("LblSupplierSupplierDescription", "Description", Session("CurrentBusinessID"))
        LblSupplierTitle.Text = ReferenceData.Setting("LblSupplierTitle", "Title", Session("CurrentBusinessID"))
        LblSupplierType.Text = ReferenceData.Setting("LblSupplierType", "Supplier Type", Session("CurrentBusinessID"))

        LblSupplierStatus.Text = ReferenceData.Setting("LblSupplierStatus", "Status", Session("CurrentBusinessID"))
        LblSupplierPhone.Text = ReferenceData.Setting("LblSupplierPhone", "Phone", Session("CurrentBusinessID"))
        LblSupplierFax.Text = ReferenceData.Setting("LblSupplierFax", "Fax", Session("CurrentBusinessID"))
        LblSupplierEmail.Text = ReferenceData.Setting("LblSupplierEmail", "Email", Session("CurrentBusinessID"))
        LblSupplierMobileNo.Text = ReferenceData.Setting("LblSupplierMobileNo", "Mobile No", Session("CurrentBusinessID"))
        LblSupplierOtherContactNo.Text = ReferenceData.Setting("LblSupplierOtherContactNo", "Other Contact #", Session("CurrentBusinessID"))
        LblSupplierAddress.Text = ReferenceData.Setting("LblSupplierAddress", "Address", Session("CurrentBusinessID"))


        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open vendor screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        If Not Page.IsPostBack Then
            Dim ds As New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.PersonTitles * -1)
            DDLTitle.DataValueField = "ArticleTypeID"
            DDLTitle.DataTextField = "ArticleType"
            DDLTitle.DataSource = ds.Tables(0)
            DDLTitle.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SupplierType * -1)
            DDLVendorType.DataValueField = "ArticleTypeID"
            DDLVendorType.DataTextField = "ArticleType"
            DDLVendorType.DataSource = ds.Tables(0)
            DDLVendorType.DataBind()

            ds = New DataSet
            ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.SupplierStatus * -1)
            DDLVendorStatus.DataValueField = "ArticleTypeID"
            DDLVendorStatus.DataTextField = "ArticleType"
            DDLVendorStatus.DataSource = ds.Tables(0)
            DDLVendorStatus.DataBind()

            If Not Request("VID") Is Nothing Then
                HdnVendorID.Value = Val(Request("VID"))
            End If
            If Val(HdnVendorID.Value) > 0 Then
                LoadData(Val(HdnVendorID.Value))
            End If

        End If

        If LoggedInUserSession.BusinessCategoryID = 9 Then
            If Val(HdnVendorID.Value) <= 0 Then
                LblScreenTitle.Text = "Create New Service Provider"
                pnlHeaderLnks.Visible = False
                SupplierImage.ImageUrl = "/Images/NoUserImage.png"
            Else
                LblScreenTitle.Text = "Update Service Provider"
                pnlHeaderLnks.Visible = True
            End If
        Else
            If Val(HdnVendorID.Value) <= 0 Then
                LblScreenTitle.Text = "Create New Supplier"
                pnlHeaderLnks.Visible = False
                SupplierImage.ImageUrl = "/Images/NoUserImage.png"
            Else
                LblScreenTitle.Text = "Update Supplier"
                pnlHeaderLnks.Visible = True
            End If
        End If

        UploadDocHistory.EmployeeID = Val(HdnVendorID.Value)
        UploadDocHistory.UploadDocumentPath = "/CMS/" & Session("CurrentBusinessID") & "/Vendor/"
        NotesBook.EmployeeID = Val(HdnVendorID.Value)
        PurchaseHistory.VendorID = Val(HdnVendorID.Value)
    End Sub

    Sub LoadData(ByVal VID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        ds = Person.GetUserDetail(Session("CurrentBusinessID"), VID)
        If ds.Tables.Count > 0 Then
            tbl = ds.Tables(0)
            If ds.Tables(0).Rows.Count > 0 Then
                If IsDBNull(ds.Tables(0).Rows(0)("WebsiteID")) OrElse ds.Tables(0).Rows(0)("WebsiteID") <> Session("CurrentBusinessID") Then
                    BtnSave.Enabled = False
                    BtnSave.Visible = False
                    Exit Sub
                End If
            Else
                BtnSave.Enabled = False
                BtnSave.Visible = False
            End If
        End If
        If tbl.Rows.Count > 0 Then
            txtSupplierAddress.Text = IIf(IsDBNull(tbl.Rows(0)("ResidentialAddress")), "", tbl.Rows(0)("ResidentialAddress"))
            txtSupplierDescription.Text = IIf(IsDBNull(tbl.Rows(0)("Description")), "", tbl.Rows(0)("Description"))
            txtSupplierFax.Text = IIf(IsDBNull(tbl.Rows(0)("Fax")), "", tbl.Rows(0)("Fax"))
            txtSupplierName.Text = IIf(IsDBNull(tbl.Rows(0)("FirstName")), "", tbl.Rows(0)("FirstName"))
            txtSupplierPhone.Text = IIf(IsDBNull(tbl.Rows(0)("TelephoneNo")), "", tbl.Rows(0)("TelephoneNo"))
            txtEmail.Text = IIf(IsDBNull(tbl.Rows(0)("EmailAddress")), "", tbl.Rows(0)("EmailAddress"))
            txtMobileNo.Text = IIf(IsDBNull(tbl.Rows(0)("MobileNo")), "", tbl.Rows(0)("MobileNo"))
            txtOtherContactNo.Text = IIf(IsDBNull(tbl.Rows(0)("OtherContactNo")), "", tbl.Rows(0)("OtherContactNo"))
            DDLVendorStatus.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("AccountTypeID")), "", tbl.Rows(0)("AccountTypeID"))
            DDLVendorType.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("AccountStatusTypeID")), "", tbl.Rows(0)("AccountStatusTypeID"))
            DDLTitle.SelectedValue = IIf(IsDBNull(tbl.Rows(0)("Title")), "", tbl.Rows(0)("Title"))

            If (IsDBNull(tbl.Rows(0)("ImageFilename")) = False AndAlso tbl.Rows(0)("ImageFilename") <> "") Then
                Dim BusinessDirectory As String = "~/CMS/" & Session("CurrentBusinessID") & "/Supplier/Images"
                HdnVendorImageFilename.Value = tbl.Rows(0)("ImageFilename")
                SupplierImage.ImageUrl = BusinessDirectory & "/" & tbl.Rows(0)("ImageFilename")
                SupplierImage.AlternateText = txtSupplierName.Text
            Else
                SupplierImage.ImageUrl = "/Images/NoUserImage.png"
            End If

            If IsDBNull(tbl.Rows(0)("AccountTypeID")) = False AndAlso Val(tbl.Rows(0)("AccountTypeID")) <> 3 Then
                LnkPurchasingHistory.Visible = False
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        If ConfigurationManager.AppSettings("DemoBusinessIDs").IndexOf("," & LoggedInUserSession.BusinessID & ",") >= 0 Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "DemoBusiness", "<script>parent.ShowMessage('Update/Delete is disabled on demo business ','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Exit Sub
        End If

        Dim tbl As New DataTable
        Dim UserImageFilename As String = HdnVendorImageFilename.Value

        If FileUploadSupplierImage.PostedFile.FileName <> "" AndAlso FileUploadSupplierImage.PostedFile.FileName <> UserImageFilename Then
            UserImageFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadSupplierImage.PostedFile.FileName)
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Session("CurrentBusinessID") & "/Supplier/") & "/Images"
            Dim dinfo As New System.IO.DirectoryInfo(BusinessDirectory)
            If dinfo.Exists() = False Then
                System.IO.Directory.CreateDirectory(BusinessDirectory)
            End If
            FileUploadSupplierImage.SaveAs(BusinessDirectory & "/" & UserImageFilename)
        End If
        If Val(HdnVendorID.Value) <= 0 Then
            tbl = Person.AddUser(Session("CurrentBusinessID"), txtEmail.Text.Trim, "", txtSupplierName.Text, "", "", DDLTitle.SelectedItem.Value,
                            1, "8/8/1888", "-1", "", txtSupplierPhone.Text, "",
                             txtEmail.Text.Trim, txtSupplierAddress.Text.Trim, Person.UserTypes.Supplier, -1, False, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, "", "", ParentAccountHeadID:=ReferenceData.Setting("SupplierAccountHeadID", "32", Session("CurrentBusinessID")))
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Supplier added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "People", "Added New Vendor " & txtSupplierName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, Val(tbl.Rows(0)("UserID")))
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierAddingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierAddingIssue", "<script>parent.ShowMessage('Unable to add Supplier','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        Else
            tbl = Person.UpdateDetails(Session("CurrentBusinessID"), Val(HdnVendorID.Value), txtEmail.Text.Trim, Guid.NewGuid.ToString, txtSupplierName.Text, "", "", DDLTitle.SelectedItem.Value,
                            1, "8/8/1888", "-1", txtSupplierPhone.Text, txtMobileNo.Text, txtOtherContactNo.Text, txtEmail.Text.Trim, txtSupplierAddress.Text.Trim, Person.UserTypes.Supplier, -1,
                            False, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", UserImageFilename, txtSupplierFax.Text, txtSupplierDescription.Text)
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("errormsg") = "0" Then
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierUpdatedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Supplier updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                    Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "People", "Updated Vendor Record " & txtSupplierName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, Val(HdnVendorID.Value))
                Else
                    ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierAddingIssue", "<script>parent.ShowMessage('" & tbl.Rows(0)("errormsg") & "','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
                End If
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "SupplierUpdatingIssue", "<script>parent.ShowMessage('Unable to add Supplier','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        End If

    End Sub

    Private Sub LnkVendorDocuments_Click(sender As Object, e As EventArgs) Handles LnkVendorDocuments.Click
        DivVendorDetails.Visible = False
        UploadDocHistory.Visible = True
        pnlDoc.Visible = True
        pnlNotes.Visible = False
        pnlPurchasingHistory.Visible = False
    End Sub

    Private Sub LnkVendorPersonalDetails_Click(sender As Object, e As EventArgs) Handles LnkVendorPersonalDetails.Click
        DivVendorDetails.Visible = True
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlPurchasingHistory.Visible = False
    End Sub

    Private Sub LnkNotes_Click(sender As Object, e As EventArgs) Handles LnkNotes.Click
        DivVendorDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = True
        pnlPurchasingHistory.Visible = False

    End Sub

    Private Sub LnkPurchasingHistory_Click(sender As Object, e As EventArgs) Handles LnkPurchasingHistory.Click
        DivVendorDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlPurchasingHistory.Visible = True
    End Sub
End Class