﻿Public Class NotesBook
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer
    Dim _ModuleTitle As String

    Public Property EmployeeID() As Integer
        Get
            Return HdnEmployeeID.Value
        End Get
        Set(value As Integer)
            HdnEmployeeID.Value = value
            _EmployeeID = value
        End Set
    End Property

    Public Property ModuleTitle() As String
        Get
            Return _ModuleTitle
        End Get
        Set(value As String)
            _ModuleTitle = value
            LblHeading.Text = _ModuleTitle
        End Set
    End Property

    Public Property NotesType() As Integer
        Get
            Return Val(HdnNotesType.Value)
        End Get
        Set(value As Integer)
            HdnNotesType.Value = value
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            LoadData()
        End If
    End Sub

    Private Sub GrdNotes_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdNotes.RowCommand
        If e.CommandName = "AddNewNotes" Then
            GrdNotes.ShowFooter = True
        ElseIf e.CommandName = "SaveNewNotes" Then
            Dim Description As String = CType(GrdNotes.FooterRow.FindControl("txtDescription"), TextBox).Text
            If (NotesType = 0) Then
                BusinessNotes.AddNotes(Val(Session("CurrentBusinessID")), EmployeeID, BusinessNotes.NotesTypes.UserNotes, "", Description)
            Else
                BusinessNotes.AddNotes(Val(Session("CurrentBusinessID")), EmployeeID, NotesType, "", Description)
            End If
            GrdNotes.ShowFooter = False
        ElseIf e.CommandName = "DeleteNotes" Then
            BusinessNotes.DeleteNotes(Val(Session("CurrentBusinessID")), Val(e.CommandArgument))
        ElseIf e.CommandName = "Insert" Then

        ElseIf e.CommandName = "Cancel" Then
            GrdNotes.ShowFooter = False
            GrdNotes.EditIndex = -1
        ElseIf e.CommandName = "Edit" Then

        ElseIf e.CommandName = "Update" Then

        End If
        LoadData()

    End Sub

    Sub LoadData()
        If (Val(HdnNotesType.Value) = 0) Then
            GrdNotes.DataSource = BusinessNotes.GetNotes(Val(Session("CurrentBusinessID")), EmployeeID, BusinessNotes.NotesTypes.UserNotes)
        Else
            GrdNotes.DataSource = BusinessNotes.GetNotes(Val(Session("CurrentBusinessID")), EmployeeID, Val(HdnNotesType.Value))
        End If
        GrdNotes.DataBind()
    End Sub

    Private Sub LnkAddNotes_Click(sender As Object, e As EventArgs) Handles LnkAddNotes.Click
        GrdNotes.ShowFooter = True
        Dim tbl As New DataTable
        Dim row As DataRow
        tbl = BusinessNotes.GetNotes(Val(Session("CurrentBusinessID")), EmployeeID, BusinessNotes.NotesTypes.UserNotes)
        If tbl.Rows.Count = 0 Then
            row = tbl.NewRow
            tbl.Rows.InsertAt(row, 0)
        End If
        GrdNotes.DataSource = tbl
        GrdNotes.DataBind()
    End Sub

    Private Sub GrdNotes_DataBound(sender As Object, e As EventArgs) Handles GrdNotes.DataBound

    End Sub

    Private Sub GrdNotes_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdNotes.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then

        End If
    End Sub

    Private Sub GrdNotes_RowUpdating(sender As Object, e As GridViewUpdateEventArgs) Handles GrdNotes.RowUpdating

    End Sub

    Private Sub GrdNotes_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdNotes.RowCancelingEdit

    End Sub

    Private Sub GrdNotes_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdNotes.RowEditing
        GrdNotes.EditIndex = e.NewEditIndex
        GrdNotes.DataBind()
    End Sub
End Class