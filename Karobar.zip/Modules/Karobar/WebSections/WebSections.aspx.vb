﻿Public Class WebSections
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            DDLWebSections.Items.Clear()
            Dim ds As New DataSet
            ds = WebSectionsBLL.GetSections(Val(Session("CurrentBusinessID")))
            DDLWebSections.DataValueField = "SectionID"
            DDLWebSections.DataTextField = "SectionName"
            DDLWebSections.DataSource = ds.Tables(0)
            DDLWebSections.DataBind()
            DDLWebSections.Items.Insert(0, New ListItem(" -- Select page --", -1))
            LblScreenTitle.Text = "Manage Website Section"
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click

        Try
            WebSectionsBLL.AddUpdateWebSection(Session("CurrentBusinessID"), DDLWebSections.SelectedValue, txtDescription.Text.Replace("'", "''"))
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "WebContentDone", "<script>parent.HideDlgForm(1);parent.ShowMessage('Content updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Content Updated", DDLWebSections.SelectedItem.Text & " Content Updated", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)

        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "WebContentFail", "<script>parent.ShowMessage('Unable to process','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub DDLWebSections_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLWebSections.SelectedIndexChanged
        Dim ds As New DataSet
        txtDescription.Text = ""
        ds = WebSectionsBLL.GetSectionDetail(Session("CurrentBusinessID"), DDLWebSections.SelectedValue)
        If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0) Then
            txtDescription.Text = ds.Tables(0).Rows(0)("SectionDescription")
        End If
    End Sub
End Class