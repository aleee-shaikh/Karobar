﻿Public Class _Error
    Inherits WebPage

    Private Sub _Error_Error(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Error

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''Session("Error") = 1

        Try
            Log.WriteLog(Val(Session("CurrentBusinessID")), Val(HttpContext.Current.Session("UserID")), "Error", Server.GetLastError.Message.Replace("'", "''") & "<" & Server.GetLastError.StackTrace.Replace("'", "''") & ">", Request.Browser.Browser & "[" & Request.Browser.Version & "]", Request.UserHostAddress, Request.Browser.Platform, Request.RawUrl)
        Catch ex As Exception

        End Try

    End Sub

End Class