﻿Public Class DatePicker
    Inherits System.Web.UI.UserControl

    Dim _Dated As String

    Public Property SelectedDate() As String
        Get
            Return _Dated
        End Get
        Set(value As String)
            If value <> "" Then
                _Dated = value
                txtDate.Text = _Dated
            End If
        End Set
    End Property

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''Page.ClientScript.RegisterClientScriptInclude("DTPickerScript", "/CMS/1/Js/dhtmlgoodies_calendar.js")
    End Sub

End Class