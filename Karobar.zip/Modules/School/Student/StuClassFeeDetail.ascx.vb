﻿Public Class StuClassFeeDetail
    Inherits System.Web.UI.UserControl

    Dim _EmployeeID As Integer
    Dim _RenumerationTbl As New DataTable
    Dim _DeductionTbl As New DataTable

    Public Property EmployeeID() As Integer
        Get
            Return _EmployeeID
        End Get
        Set(value As Integer)
            _EmployeeID = value

        End Set
    End Property

    Public Sub LoadData()
        Dim tblRenumeration As New DataTable
        Dim tblDeduction As New DataTable
        Dim tbl As New DataTable
        Dim tmptbl As New DataTable
        If DDLPayScale.Items.Count = 0 Then
            tbl = Payroll.GetEmployeeJobDetail(EmployeeID)
            If (tbl.Rows.Count > 0) Then
                txtCurrentJobJoiningDate.Text = tbl.Rows(0)("JoiningDate")
                txtCurrentJobSalary.Text = tbl.Rows(0)("Salary")
                If DDLDesignation.Items.Count > 0 Then DDLDesignation.SelectedValue = tbl.Rows(0)("Designation")

                If Not DDLDepartments.Items.FindByValue(tbl.Rows(0)("Department")) Is Nothing Then
                    If DDLDepartments.Items.Count > 0 Then
                        DDLDepartments.SelectedValue = tbl.Rows(0)("Department")
                    End If
                End If

                If IsDBNull(tbl.Rows(0)("PayrollTypeID")) OrElse Val(tbl.Rows(0)("PayrollTypeID")) <= 0 Then
                    If ddlEmployeePayrollType.Items.Count > 0 Then
                        ddlEmployeePayrollType.SelectedIndex = 0
                    End If
                Else
                    ddlEmployeePayrollType.SelectedValue = Val(tbl.Rows(0)("PayrollTypeID"))
                    txtHourlyRate.Text = tbl.Rows(0)("HourlyRate")
                End If

                If DDLWorkingShift.Items.Count > 0 Then
                    If Not (DDLWorkingShift.Items.FindByValue(Val(tbl.Rows(0)("ShiftID").ToString())) Is Nothing) Then
                        DDLWorkingShift.SelectedValue = Val(tbl.Rows(0)("ShiftID").ToString())
                    End If

                End If
            End If
        Else
            ''tbl = Payroll.GetPayrollGroupTerms(Val(Session("CurrentBusinessID")), DDLPayScale.SelectedValue)
            tbl = Payroll.GetEmployeeSalary(EmployeeID, -1)
            Try
                tblRenumeration = tbl.Select("AddDeduct='+'").CopyToDataTable
                tblDeduction = tbl.Select("AddDeduct='-'").CopyToDataTable
                _RenumerationTbl = tblRenumeration
                _DeductionTbl = tblDeduction
            Catch ex As Exception

            Finally
                ''If tblRenumeration.Rows.Count > 0 Then
                GrdRenumerations.DataSource = tblRenumeration
                GrdRenumerations.DataBind()
                ''End If

                ''If tblDeduction.Rows.Count > 0 Then
                GrdDeductions.DataSource = tblDeduction
                GrdDeductions.DataBind()
                ''End If
            End Try
        End If
        tbl = Payroll.GetPayrollTypes(Val(Session("CurrentBusinessID")))
        If ddlEmployeePayrollType.Items.Count = 0 Then
            ddlEmployeePayrollType.DataValueField = "PayrollTypeID"
            ddlEmployeePayrollType.DataTextField = "PayrollType"
            ddlEmployeePayrollType.DataSource = tbl
            ddlEmployeePayrollType.DataBind()
        End If

        Dim script As String = "var PayrollTypes=[];" & Environment.NewLine
        For i As Integer = 0 To tbl.Rows.Count - 1
            script = script & "PayrollTypes.push({PayrollTypeID:" & tbl.Rows(i)("PayrollTypeID") & ", PayrollType :'" & tbl.Rows(i)("PayrollType") & "', Hourly:'" & tbl.Rows(i)("Hourly") & "'})" & Environment.NewLine
        Next
        script = script & "LoadPayrollRelatedFields(" & ddlEmployeePayrollType.ClientID & ")"
        Page.ClientScript.RegisterStartupScript(Me.GetType(), "PayrollData", "<script>" & script & "</script>")


        tbl = Payroll.GetEmployeeWorkingDays(Val(Session("CurrentBusinessID")), EmployeeID)

        If (tbl.Rows.Count > 0) Then
            chkMonday.Checked = tbl.Rows(0)("Monday")
            chkTuesday.Checked = tbl.Rows(0)("Tuesday")
            chkWednesday.Checked = tbl.Rows(0)("Wednesday")
            chkThursday.Checked = tbl.Rows(0)("Thursday")
            chkFriday.Checked = tbl.Rows(0)("Friday")
            chkSaturday.Checked = tbl.Rows(0)("Saturday")
            chkSunday.Checked = tbl.Rows(0)("Sunday")
            ddlAlternateOffDay.SelectedValue = tbl.Rows(0)("AlternateOffDay")
        End If
        If Not Session("CurrentBusinessCategoryID") Is Nothing AndAlso Val(Session("CurrentBusinessCategoryID")) > 0 Then
            If (Val(Session("CurrentBusinessCategoryID")) = 5) Then
                DivEmployeePayroll.Visible = False
                DivPayScale.Visible = False
                DivEmpWorkingDays.Visible = False
                DivHourlyRate.Visible = False
                DivSections.Visible = False
            End If
        End If

        LblStudentClass.Text = ReferenceData.Setting("LblDepartment", "Class", Session("CurrentBusinessID"))
        LblPayScale.Text = ReferenceData.Setting("LblPayScale", "Pay Scale", Session("CurrentBusinessID"))
        LblSection.Text = ReferenceData.Setting("LblSection", "Section", Session("CurrentBusinessID"))
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click

        Dim PayrollTypeID As Integer = -1
        Dim HourlyRate As Single = 0.0
        Dim ShiftID As Integer = -1

        If (ddlEmployeePayrollType.Items.Count > 0) Then
            PayrollTypeID = Val(ddlEmployeePayrollType.SelectedValue)
        End If
        If txtHourlyRate.Text.Trim() > 0 Then
            HourlyRate = txtHourlyRate.Text
        End If
        If DDLWorkingShift.Items.Count > 0 Then
            ShiftID = Val(DDLWorkingShift.SelectedValue)
        End If

        Dim DeptID As Integer = -1
        Dim DesigID As Integer = -1

        'If DDLDepartments.Items.Count > 0 Then
        '    DeptID = DDLDepartments.SelectedValue
        'End If

        If DDLDesignation.Items.Count > 0 Then
            DesigID = DDLDesignation.SelectedValue
        End If

        If DDLPayScale.Items.Count = 0 Then
            Payroll.UpdateEmployeeJobDetail(EmployeeID, DesigID, IIf(DDLDepartments.Items.Count > 0, DDLDepartments.SelectedValue, -1), Val(txtCurrentJobSalary.Text), txtCurrentJobJoiningDate.Text, Val(Session("UserID")), -1, PayrollTypeID, HourlyRate, ShiftID)
        Else
            For i As Integer = 0 To GrdRenumerations.Rows.Count - 1
                Dim Renumeration As String = CType(GrdRenumerations.Rows(i).FindControl("txtRenumeration"), TextBox).Text
                Dim GroupPolicyID As Integer = Val(CType(GrdRenumerations.Rows(i).FindControl("HdnGroupPolicyID"), HiddenField).Value)
                Payroll.UpdateEmployeeSalary(EmployeeID, GroupPolicyID, Renumeration, 1)
            Next

            For i As Integer = 0 To GrdDeductions.Rows.Count - 1
                Dim deduction As String = CType(GrdDeductions.Rows(i).FindControl("txtDeduction"), TextBox).Text
                Dim GroupPolicyID As Integer = Val(CType(GrdDeductions.Rows(i).FindControl("HdnGroupPolicyID"), HiddenField).Value)
                Payroll.UpdateEmployeeSalary(EmployeeID, GroupPolicyID, deduction, 1)
            Next
        End If
        ''Payroll.AddEmployeeWorkingDays(Val(Session("CurrentBusinessID")), EmployeeID, chkMonday.Checked, chkTuesday.Checked, chkWednesday.Checked, chkThursday.Checked, chkFriday.Checked, chkSaturday.Checked, chkSunday.Checked, ddlAlternateOffDay.SelectedValue, Val(Session("UserID")), "")
        LoadData()
        Page.RegisterStartupScript("StudentUpdatedSuccessFully", "<script>parent.ShowMessage('Student record updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
    End Sub

    Private Sub DDLPayScale_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLPayScale.SelectedIndexChanged
        LoadData()
    End Sub

    Private Sub EmpJobDetail_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim tbl As New DataTable
            tbl = Payroll.GetPayrollGroups(Val(Session("CurrentBusinessID")))
            DDLPayScale.DataValueField = "PayrollGroupID"
            DDLPayScale.DataTextField = "GroupName"
            DDLPayScale.DataSource = tbl
            DDLPayScale.DataBind()




            tbl = Payroll.GetDepartments(Val(Session("CurrentBusinessID")))
            DDLDepartments.DataValueField = "DepartmentID"
            DDLDepartments.DataTextField = "DepartmentName"
            DDLDepartments.DataSource = tbl
            DDLDepartments.DataBind()
            DDLDepartments.Items.Insert(0, New ListItem("None", "-1"))

            tbl = Payroll.GetDesignations(Val(Session("CurrentBusinessID")))
            DDLDesignation.DataValueField = "DesignationID"
            DDLDesignation.DataTextField = "DesignationName"
            DDLDesignation.DataSource = tbl
            DDLDesignation.DataBind()
            DDLDesignation.Items.Insert(0, New ListItem("None", "-1"))

            DDLWorkingShift.DataTextField = "ShiftName"
            DDLWorkingShift.DataValueField = "ShiftID"
            DDLWorkingShift.DataSource = Payroll.GetWokringShifts(Session("CurrentBusinessID"))
            DDLWorkingShift.DataBind()
            DDLWorkingShift.Items.Insert(0, New ListItem("None", "-1"))

            Dim tblRenumeration As New DataTable
            Dim tblDeduction As New DataTable
            Dim tmptbl As New DataTable

            tbl = Payroll.GetEmployeeSalary(EmployeeID)
            If tbl.Rows.Count > 0 Then
                DDLPayScale.SelectedValue = tbl.Rows(0)("PayrollGroupID")

                Try
                    tblRenumeration = tbl.Select("AddDeduct='+'").CopyToDataTable

                    tblDeduction = tbl.Select("AddDeduct='-'").CopyToDataTable
                Catch ex As Exception

                Finally
                    ''If tblRenumeration.Rows.Count > 0 Then
                    GrdRenumerations.DataSource = tblRenumeration
                    GrdRenumerations.DataBind()
                    ''End If

                    ''If tblDeduction.Rows.Count > 0 Then
                    GrdDeductions.DataSource = tblDeduction
                    GrdDeductions.DataBind()
                    ''End If
                End Try

            End If
            'If ds.Tables.Count >= 3 Then
            '    Dim CurrentJobDtltbl As New DataTable
            '    CurrentJobDtltbl = ds.Tables(3)
            '    If CurrentJobDtltbl.Rows.Count > 0 Then
            '        txtCurrentJobDepartment.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Department")), "", CurrentJobDtltbl.Rows(0)("Department"))
            '        txtCurrentJobDesignation.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Designation")), "", CurrentJobDtltbl.Rows(0)("Designation"))
            '        txtCurrentJobSalary.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("Salary")), "", CurrentJobDtltbl.Rows(0)("Salary"))
            '        txtCurrentJobJoiningDate.Text = IIf(IsDBNull(CurrentJobDtltbl.Rows(0)("JoiningDate")), "", CurrentJobDtltbl.Rows(0)("JoiningDate"))
            '    End If
            'End If


        End If

        If DDLPayScale.Items.Count = 0 Then
            DivPayScale.Visible = False
            DivSalary.Visible = True
        Else
            DivPayScale.Visible = True
            DivSalary.Visible = False
        End If
    End Sub

    Private Sub GrdRenumerations_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdRenumerations.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim CalculateonPercentage As Single
            Dim ItemValueBasedOn As Single
            Dim DeductiveValue As Single

            CalculateonPercentage = Val(drview("CalculateonPercentage"))
            ''to be done
            If _RenumerationTbl.Rows.Count > 0 And Val(drview("CalculateonPercentage")) > 0 Then
                If CalculateonPercentage > 0 Then
                    Dim tmlTbl As New DataTable
                    tmlTbl = _RenumerationTbl.Select("Name='" & drview("Name") & "'").CopyToDataTable()
                    ItemValueBasedOn = Val(tmlTbl.Rows(0)("FixedAmount"))
                End If

                If (drview("AddDeduct") = "+") Then
                    DeductiveValue = Math.Round((CalculateonPercentage * ItemValueBasedOn) / 100, 2)
                Else

                End If

                Dim Renumeration As New System.Web.UI.WebControls.TextBox
                Renumeration = CType(e.Row.FindControl("txtRenumeration"), TextBox)
                If Not Renumeration Is Nothing Then
                    Renumeration.Text = DeductiveValue
                End If
            End If
        End If
    End Sub
End Class