﻿Public Class RedeemGiftCardPoints
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 146) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open Gift card redeem points screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        If Not Page.IsPostBack Then
            Dim tbl As New DataTable

            tbl = Person.GetUsersList(Val(Session("CurrentBusinessID")), "", 4)
            DDLUsers.DataTextField = "FirstName"
            DDLUsers.DataValueField = "UserID"
            DDLUsers.DataSource = tbl
            DDLUsers.DataBind()
            DDLUsers.Items.Insert(0, New ListItem(" -- Select User -- ", "-1"))
        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        tbl = GiftCard.RedeemUserGiftCard(Session("CurrentBusinessID"), DDLUsers.SelectedValue, Val(DDLUserCards.SelectedValue), DDLUserCards.SelectedValue, txtPoints.Text, HttpContext.Current.Session("UserID"))
        If tbl.Columns.Contains("Error") Then
            If tbl.Rows.Count > 0 Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardRedeemError", "<script>parent.ShowMessage('" & tbl.Rows(0)("Error") & "','1',$(window).height()*2/100,$(window).width()*75/100)</script>")
            End If
        Else
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "GiftCardRedeemSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Gift card recharged successfully!','0',$(window).height()*2/100,$(window).width()*45/100,'1')</script>")
            DDLUserCards.SelectedIndex = 0
            DDLUsers.SelectedIndex = 0

        End If
    End Sub

    Private Sub DDLUserCards_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLUserCards.SelectedIndexChanged
        If DDLUsers.SelectedValue > 0 Then
            Dim tbl As New DataTable
            tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), DDLUsers.SelectedValue, DDLUserCards.SelectedValue)
            lblPoints.Text = "0"
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("CardStatusID") = 2 Then 'Cancelled
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardCancelled", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been cancelled.','1',$(window).height()*2/100,$(window).width()*45/100)</script>")
                ElseIf DateDiff(DateInterval.Day, Now, tbl.Rows(0)("ExpiryDate")) < 0 Then
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardExpired", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been expired.','1',$(window).height()*2/100,$(window).width()*45/100)</script>")
                Else
                    lblPoints.Text = tbl.Rows(0)("Points")
                End If
            End If
        End If
    End Sub

    Private Sub DDLUsers_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLUsers.SelectedIndexChanged
        Dim tbl As New DataTable
        txtGiftCardValidityDays.Text = ""
        txtPoints.Text = "0"
        HdnGiftCardID.Value = "-1"
        lblPoints.Text = "0"
        DDLUserCards.Items.Clear()
        tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), DDLUsers.SelectedValue)
        DDLUserCards.DataTextField = "UserCardName"
        DDLUserCards.DataValueField = "UserCardID"
        DDLUserCards.DataSource = tbl
        DDLUserCards.DataBind()
        DDLUserCards.Items.Insert(0, New ListItem("-- Select Gift Card --", "-1"))
        'If (tbl.Rows.Count > 0) Then
        'txtGiftCardValidityDays.Text = tbl.Rows(0)("ValidityDays")
        'HdnGiftCardID.Value = tbl.Rows(0)("GiftCardID")
        'End If

    End Sub
End Class