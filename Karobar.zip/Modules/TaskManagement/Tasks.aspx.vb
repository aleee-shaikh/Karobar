﻿Public Class Tasks
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(LoggedInUserSession.UserID, 173) = False Then
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), LoggedInUserSession.UserID, "Securtiy Issue", "Tried to create project screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If

        LblTaskName.Text = ReferenceData.Setting("LblTaskName", "Task Name", Session("CurrentBusinessID"))
        LblScreenTitle.Text = ReferenceData.Setting("LblTaskStatus", "Create New Task", Session("CurrentBusinessID"))

        If Not Page.IsPostBack Then
            If Not Request.QueryString("TaskID") Is Nothing Then
                HdnTaskID.Value = Request.QueryString("TaskID").Trim()
            End If

            If Not Request.QueryString("ParentTaskID") Is Nothing Then
                HdnTaskID.Value = Request.QueryString("ParentTaskID").Trim()
            End If
            Dim TID As Integer = 0
            Dim PTID As Integer = 0

            TID = Cryptography.Decrypt(HdnTaskID.Value)
            PTID = Cryptography.Decrypt(HdnParentTaskID.Value)

            If TID <= 0 Then
                LblScreenTitle.Text = "Create New Task"
                LnkTaskDetails.Visible = False
                LnkTaskDocuments.Visible = False
                LnkNotes.Visible = False
                LnkSaleHistory.Visible = False
            Else
                LblScreenTitle.Text = "Update Task"
                LnkTaskDetails.Visible = True
                LnkTaskDocuments.Visible = True
                LnkNotes.Visible = True
                LnkSaleHistory.Visible = True

                LoadData(TID)
            End If
            UploadDocHistory.EmployeeID = Val(TID)
            UploadDocHistory.UploadDocumentPath = "/CMS/" & Session("CurrentBusinessID") & "/Task/"
            UploadDocHistory.DocumentTypeID = Payroll.DocumentTypes.TaskDocuments

            TaskTeamMembers.TaskID = TID
            TaskTeamMembers.TaskMemberType = TaskManagement.TaskUsersType.Members

            TaskClients.TaskID = TID
            TaskClients.TaskMemberType = TaskManagement.TaskUsersType.Clients

            NotesBook.EmployeeID = Val(TID)
            NotesBook.NotesType = BusinessNotes.NotesTypes.ProjectNotes

            TaskLedgerReport.AccountHeadID = TID

            If TID <= 0 Then
                LnkTaskTeam.Visible = False
                LnkTaskClients.Visible = False
            End If
        End If

    End Sub

    Sub LoadData(ByVal TID As Integer)
        Dim ds As New DataSet
        Dim tbl As New DataTable
        tbl = TaskManagement.SearchTask(LoggedInUserSession.BusinessID, TaskID:=TID)
        pnlHeaderLnks.Visible = False
        If tbl.Rows.Count > 0 Then
            txtTaskDescription.Text = IIf(IsDBNull(tbl.Rows(0)("Description")), "", tbl.Rows(0)("Description"))
            txtTaskName.Text = IIf(IsDBNull(tbl.Rows(0)("Title")), "", tbl.Rows(0)("Title"))
            txtExpectedRevenue.Text = IIf(IsDBNull(tbl.Rows(0)("EstimatedProfit")), "", tbl.Rows(0)("EstimatedProfit"))
            txtInvestmentBudget.Text = IIf(IsDBNull(tbl.Rows(0)("EstimatedInvestment")), "", tbl.Rows(0)("EstimatedInvestment"))
            txtStartDate.Text = IIf(IsDBNull(tbl.Rows(0)("StartDateTime")), "", tbl.Rows(0)("StartDateTime").ToString())
            txtEndDate.Text = IIf(IsDBNull(tbl.Rows(0)("EndDateTime")), "", tbl.Rows(0)("EndDateTime").ToString())
            HdnTaskType.Value = IIf(IsDBNull(tbl.Rows(0)("TaskType")), "-1", tbl.Rows(0)("TaskType"))
            HdnParentTaskID.Value = Cryptography.Decrypt(IIf(IsDBNull(tbl.Rows(0)("ParentTaskID")), "-1", tbl.Rows(0)("ParentTaskID")))
            HdnTaskID.Value = Cryptography.Decrypt(Val(tbl.Rows(0)("TaskID")))
            HdnTaskStatus.Value = IIf(IsDBNull(tbl.Rows(0)("TaskType")), "1", tbl.Rows(0)("TaskType"))
            pnlHeaderLnks.Visible = True
        End If

    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim ds As New DataSet
        Dim TID As Integer = 0
        Dim PTID As Integer = 0

        TID = Cryptography.Decrypt(HdnTaskID.Value)
        PTID = Cryptography.Decrypt(HdnParentTaskID.Value)

        Dim TaskStartDate As String
        Dim TaskEndDate As String

        TaskStartDate = IIf(IsDate(txtStartDate.Text) = False, "", txtStartDate.Text)
        TaskEndDate = IIf(IsDate(txtEndDate.Text) = False, "", txtEndDate.Text)

        Dim InvestmentBudget As Single = 0, ExpectedRevenue As Single = 0
        If IsNumeric(txtInvestmentBudget.Text) Then
            InvestmentBudget = txtInvestmentBudget.Text
        End If
        If IsNumeric(txtExpectedRevenue.Text) Then
            ExpectedRevenue = txtExpectedRevenue.Text
        End If

        If TID > 0 Then
            ds = TaskManagement.UpdateTask(LoggedInUserSession.BusinessID, TID, PTID, LoggedInUserSession.UserID, HdnTaskType.Value, txtTaskName.Text.Trim(), txtTaskDescription.Text.Trim(), TaskStartDate, TaskEndDate, InvestmentBudget, ExpectedRevenue, HdnTaskStatus.Value, Now.ToUniversalTime())
            If (ds.Tables(0).Rows.Count > 0) Then
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TaskAddedSuccessFully", "<script>parent.ShowMessage('Project updated successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "Task", "Task Updated " & txtTaskName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, TID)
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TaskAddingIssue", "<script>parent.ShowMessage('Unable to update Project','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        Else
            ds = TaskManagement.CreateTask(LoggedInUserSession.BusinessID, PTID, LoggedInUserSession.UserID, HdnTaskType.Value, txtTaskName.Text.Trim(), txtTaskDescription.Text.Trim(), TaskStartDate, TaskEndDate, InvestmentBudget, ExpectedRevenue, HdnTaskStatus.Value, Now.ToUniversalTime())
            If (ds.Tables(0).Rows.Count > 0) Then
                LnkTaskDetails.Visible = True
                LnkTaskDocuments.Visible = True
                LnkNotes.Visible = True
                LnkSaleHistory.Visible = True
                LnkTaskTeam.Visible = True
                LoadData(ds.Tables(0).Rows(0)("TaskID"))
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TaskAddedSuccessFully", "<script>parent.ShowMessage('Project added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1')</script>")
                Log.WriteLog(LoggedInUserSession.BusinessID, HttpContext.Current.Session("UserID"), "Task", "Added New Task " & txtTaskName.Text, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, Val(ds.Tables(0).Rows(0)("TaskID")))
            Else
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "TaskAddingIssue", "<script>parent.ShowMessage('Unable to add Project','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End If
        End If

    End Sub

    Private Sub LnkTaskDetails_Click(sender As Object, e As EventArgs) Handles LnkTaskDetails.Click
        DivTaskDetails.Visible = True
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False

        pnlTaskTeam.Visible = False
        pnlTaskClients.Visible = False
        pnlTaskLedger.Visible = False
    End Sub

    Private Sub LnkTaskDocuments_Click(sender As Object, e As EventArgs) Handles LnkTaskDocuments.Click
        DivTaskDetails.Visible = False
        UploadDocHistory.Visible = True
        pnlDoc.Visible = True
        pnlNotes.Visible = False

        pnlTaskTeam.Visible = False
        pnlTaskClients.Visible = False
        pnlTaskLedger.Visible = False
    End Sub

    Private Sub LnkNotes_Click(sender As Object, e As EventArgs) Handles LnkNotes.Click
        DivTaskDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = True

        pnlTaskTeam.Visible = False
        pnlTaskClients.Visible = False
        pnlTaskLedger.Visible = False
    End Sub

    Private Sub LnkOrderHistory_Click(sender As Object, e As EventArgs) Handles LnkTaskTeam.Click
        DivTaskDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False

        pnlTaskTeam.Visible = True
        pnlTaskClients.Visible = False
        pnlTaskLedger.Visible = False
    End Sub

    Private Sub LnkSaleHistory_Click(sender As Object, e As EventArgs) Handles LnkSaleHistory.Click
        DivTaskDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlTaskTeam.Visible = False
        pnlTaskClients.Visible = False
        pnlTaskLedger.Visible = True
    End Sub

    Private Sub LnkTaskClients_Click(sender As Object, e As EventArgs) Handles LnkTaskClients.Click
        DivTaskDetails.Visible = False
        UploadDocHistory.Visible = False
        pnlDoc.Visible = False
        pnlNotes.Visible = False
        pnlTaskTeam.Visible = False
        pnlTaskClients.Visible = True
        pnlTaskLedger.Visible = False
    End Sub
End Class