﻿Public Class LabelSettings
    Inherits System.Web.UI.UserControl


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            AddPortalSettings("LblSaleProductReference", "Sale - Product Reference")
            AddPortalSettings("LblProductSaleType", "Sale - Sale Type")
            AddPortalSettings("LblProductOrderDate", "Sale - Order Date")
            AddPortalSettings("LblDueDate", "Due Date")
            AddPortalSettings("LblCustomer", "Customer")
            AddPortalSettings("LblSalesTax", "Tax")
            AddPortalSettings("LblDeliveryCharges", "Delivery Charges")
            AddPortalSettings("LblSalesPerson", "Sales Person")
            AddPortalSettings("LblStockLocation", "Stock Location")
            AddPortalSettings("LblNTNNumber", "NTN Number")

            AddPortalSettings("LblPurchaseProductReference", "Purchase - Product Reference")
            AddPortalSettings("LblProductSupplier", "Purchase - Product Supplier")
            AddPortalSettings("LblStockLocation", "Purchase - Stock Location")
            AddPortalSettings("LblPurchaseDate", "Purchase Date")
            AddPortalSettings("LblDescription", "Description")
            AddPortalSettings("LblOtherCharges", "Other Charges")

            AddPortalSettings("LblEmployeeDesignation", "Designation")
            AddPortalSettings("LblDepartment", "Department")
            AddPortalSettings("LblPayScale", "PayScale")

            AddPortalSettings("LblExchangeProductScreenTitle", "Exchange Product")
            AddPortalSettings("LblProductName", "Product")
            AddPortalSettings("LblProductUnit", "Unit")
            AddPortalSettings("LblProductSalePrice", "Price")

            AddPortalSettings("LblGridProductStockQuantity", "Stock Qty")
            AddPortalSettings("LblGridProductQuantity", "Quantity")
            'AddPortalSettings("LblGridSaleProductDiscount", "Discount")
            AddPortalSettings("LblProductDiscount", "Discount")

            AddPortalSettings("LblGridSaleProductTotal", "Total")
            AddPortalSettings("LblGridExchangeAction", "Action")

            AddPortalSettings("LblProductName", "Product")
            AddPortalSettings("LblGridProductQuantity", "Quantity")
            AddPortalSettings("LblProductUnit", "Unit")
            AddPortalSettings("LblProductPurchasePrice", "Price")
            'AddPortalSettings("LblGridPurchaseProductDiscount", "Discount")
            AddPortalSettings("LblGridPurchaseProductTotal", "Total")
            AddPortalSettings("LblGridPurchaseProductManufacturingDate", "Manufacturing Date")
            AddPortalSettings("LblGridPurchaseProductExpiryDate", "Expiry Date")



            AddPortalSettings("LblProductName", "Product")
            AddPortalSettings("LblProductUnit", "Unit")
            AddPortalSettings("LblProductSalePrice", "Price")

            AddPortalSettings("LblGridProductStockQuantity", "Stock Qty")
            AddPortalSettings("LblGridProductQuantity", "Quantity")
            'AddPortalSettings("LblGridSaleProductDiscount", "Discount")

            AddPortalSettings("LblGridSaleProductTotal", "Total")



            AddPortalSettings("LblProductName", "Product")
            AddPortalSettings("LblProductCategory", "Category")
            AddPortalSettings("LblProductSubCategory", "Sub Category")
            AddPortalSettings("LblProductUnit", "Unit")
            AddPortalSettings("LblProductPurchasePrice", "Purchase Price")
            AddPortalSettings("LblProductSalePrice", "Sale Price")
            AddPortalSettings("LblProductManufacturer", "Manufacturer")
            AddPortalSettings("LblGridManageProductsNewLink", "New Product")


            AddPortalSettings("LblProductName", "Product Name")
            AddPortalSettings("LblProductCategory", "Category")
            AddPortalSettings("LblProductSubCategory", "Sub Category")
            AddPortalSettings("LblProductModel", "Model")
            AddPortalSettings("LblProductManufacturer", "Manufacturer")
            AddPortalSettings("LblProductPurchasePrice", "Purchase Price")
            AddPortalSettings("LblProductTax", "Tax")

            AddPortalSettings("LblProductOthers", "Others")
            AddPortalSettings("LblProductPromptPriceOnSale", "Prompt price on sale")
            AddPortalSettings("LblProductSalePrice", "Sale Price")

            AddPortalSettings("LblProductUnit", "Unit")

            AddPortalSettings("LblProductSize", "Size")

            AddPortalSettings("LblProductWeight", "Weight")

            AddPortalSettings("LblProductColor", "Color")

            AddPortalSettings("LblProductBarcode", "BarCode")
            AddPortalSettings("LblProductDescription", "Description")


            AddPortalSettings("LblCustomerName", "Customer Name")
            AddPortalSettings("LblCustomerCustomerDescription", "Description")
            AddPortalSettings("LblCustomerTitle", "Title")
            AddPortalSettings("LblCustomerType", "Customer Type")

            AddPortalSettings("LblCustomerStatus", "Status")
            AddPortalSettings("LblCustomerPhone", "Phone")
            AddPortalSettings("LblCustomerFax", "Fax")
            AddPortalSettings("LblCustomerEmail", "Email")
            AddPortalSettings("LblCustomerMobileNo", "Mobile No")
            AddPortalSettings("LblCustomerOtherContactNo", "Other Contact #")
            AddPortalSettings("LblCustomerAddress", "Address")


            AddPortalSettings("LblCustomerStatus", "Create New Customer")


            AddPortalSettings("LblStudentFirstName", "Student First Name")
            AddPortalSettings("LblStudentMiddleName", "Student - Guardian Name")
            AddPortalSettings("LblStudentLastName", "Student - Last Name")
            AddPortalSettings("LblStudentRollNumber", "Student - Roll Number")
            AddPortalSettings("LblStudentTitle", "Student - Title")


            AddPortalSettings("LblStaffFirstName", "First Name")
            AddPortalSettings("LblStaffMiddleName", "Middle Name")
            AddPortalSettings("LblStaffLastName", "Last Name")
            AddPortalSettings("LblStaffDOB", "Supplier Date of Birth")

            AddPortalSettings("LblStaffGender", "Gender")
            AddPortalSettings("LblStaffTitle", "Title")
            AddPortalSettings("LblMaritalStatus", "Marital Status")
            AddPortalSettings("LblStaffHomePhone", "Home Phone")
            AddPortalSettings("LblStaffMobileNo", "Mobile No")
            AddPortalSettings("LblStaffOtherContactNo", "Other Contact #")
            AddPortalSettings("LblStaffAddress", "Address")

            AddPortalSettings("LblStaffEmail", "Email")
            AddPortalSettings("LblStaffPassword", "Password")
            AddPortalSettings("LblStaffConfirmPassword", "Confirm Password")
            AddPortalSettings("ChkAccountEnabled", "Account Enable")
            AddPortalSettings("LblStaffRoles", "Staff Roles")
            AddPortalSettings("LblStaffBusinessAccessibility", "Business Accessibility")
            AddPortalSettings("LblStaffQualification", "Qualification")

            AddPortalSettings("LblStaffPassingYear", "Passing year")
            AddPortalSettings("LblStaffMarksCGPA", "Marks/CGPA")
            AddPortalSettings("LblStaffGradeDivision", "Grade/Division")
            AddPortalSettings("LblStaffPreviousCompany", "Previous Company")
            AddPortalSettings("LblStaffPreviousDesignation", "Previous Designation")
            AddPortalSettings("LblStaffJoiningDate", "Joining Date")
            AddPortalSettings("LblStaffSalary", "Salary")

            'AddPortalSettings("LblStaffDesignation", "Current Designation")
            'AddPortalSettings("LblStaffCurrentDepartment", "Department")
            'AddPortalSettings("LblStaffCurrentSalary", "Salary")
            'AddPortalSettings("LblStaffCurrentJoiningDate", "Joining Date")

            AddPortalSettings("LblSupplierName", "Supplier Name")
            AddPortalSettings("LblSupplierSupplierDescription", "Description")
            AddPortalSettings("LblSupplierTitle", "Title")
            AddPortalSettings("LblSupplierType", "Supplier Type")

            AddPortalSettings("LblSupplierStatus", "Status")
            AddPortalSettings("LblSupplierPhone", "Phone")
            AddPortalSettings("LblSupplierFax", "Fax")
            AddPortalSettings("LblSupplierEmail", "Email")
            AddPortalSettings("LblSupplierMobileNo", "Mobile No")
            AddPortalSettings("LblSupplierOtherContactNo", "Other Contact #")
            AddPortalSettings("LblSupplierAddress", "Address")
            AddPortalSettings("LblDeliveryPerson", "Delivery Person:")
            AddPortalSettings("LblTableNo", "Table #:")
        End If
    End Sub

    Sub AddPortalSettings(Text As String, Value As String)
        If ddlLabelSettings.Items.FindByValue(Value) Is Nothing Then
            ddlLabelSettings.Items.Add(New ListItem(Value, Text))
        End If
        BtnSave.Visible = True
        txtSettingValue.Visible = True
        BtnSave.Visible = False
        txtSettingValue.Visible = False
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        ReferenceData.UpdateWebsiteSettings(ddlLabelSettings.SelectedValue, txtSettingValue.Text, Session("CurrentBusinessID"))
        Page.RegisterStartupScript("SettingSavedSuccessFully", "<script>parent.ShowMessage('Setting saved successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'0')</script>")
        ddlLabelSettings.SelectedIndex = 0
        txtSettingValue.Text = ""
    End Sub

    Private Sub ddlLabelSettings_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlLabelSettings.SelectedIndexChanged
        txtSettingValue.Text = ReferenceData.Setting(ddlLabelSettings.SelectedValue, "", Session("CurrentBusinessID"))
        BtnSave.Visible = True
        txtSettingValue.Visible = True
    End Sub
End Class