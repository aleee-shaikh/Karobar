﻿Public Class DownloadFile
    Inherits System.Web.UI.Page

    Private Sub form1_Load(sender As Object, e As EventArgs) Handles form1.Load
        If Request.QueryString("File").ToString().ToLower() = "/mobileapp/joined24.apk" Then
            Download("/mobileapp/joined24.apk")
        ElseIf Request.QueryString("File").ToString().ToLower() = "/mobileapp/joined24parents.apk" Then
            Download("/mobileapp/joined24parents.apk")
        ElseIf Request.QueryString("File").ToString().ToLower() = "/mobileapp/joined24teachers.apk" Then
            Download("/mobileapp/joined24teachers.apk")
        ElseIf Request.QueryString("File").ToString().ToLower() = "/mobileapp/j24ServiceProvider.apk" Then
            Download("/mobileapp/j24ServiceProvider.apk")
        End If
    End Sub

    Sub Download(filename As String)
        Dim path As String = (Server.MapPath(Request.ApplicationPath) & filename) 'get file object as FileInfo
        Dim file As System.IO.FileInfo = New System.IO.FileInfo(path) '-- if the file exists on the server
        If file.Exists Then 'set appropriate headers

            Dim BID As Integer = 0
            If Not Request.QueryString("Ref") Is Nothing Then
                BID = Val(Request.QueryString("Ref").ToString())
            End If

            Dim UID As Integer = 0
            If Not Request.QueryString("UID") Is Nothing Then
                UID = Val(Request.QueryString("UID").ToString())
            End If

            'If BID > 0 Or UID > 0 Then
            Log.WriteLog(BID, UID, file.Name, "Download " & file.FullName, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=BID)
            'End If

            Response.Clear()
            Response.AddHeader("Content-Disposition", "attachment; filename=" & file.Name)
            Response.AddHeader("Content-Length", file.Length.ToString())
            Response.ContentType = "application/octet-stream"
            Response.WriteFile(file.FullName)
            Response.End() 'if file does not exist
        Else
            Response.Write("This file does not exist.")
        End If 'nothing in the URL as HTTP GET
    End Sub
End Class