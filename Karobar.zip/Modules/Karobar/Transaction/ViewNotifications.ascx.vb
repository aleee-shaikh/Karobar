﻿Public Class ViewNotifications
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtTransactionFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtTransactionToDate.Text = Now.ToString("dd-MM-yyyy")
            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim ds As New DataSet
        Dim FDate As String = ""
        Dim FdateAry() = txtTransactionFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtTransactionToDate.Text.Replace("/", "-").Split("-")

        ''_tbl = Log.GetNotifications(Session("CurrentBusinessID"), FdateAry(2) & FdateAry(1) & FdateAry(0), TdateAry(2) & TdateAry(1) & TdateAry(0))
        Dim AccountHeadIDs As String = ""

        AccountHeadIDs = ReferenceData.Setting("AccountHeadIDs4Log", "", Session("CurrentBusinessID"))
        _tbl = Log.GetAccountHeadsLog(HttpContext.Current.Session("UserID"), AccountHeadIDs, "", CDate(FdateAry(2) & "-" & FdateAry(1) & "-" & FdateAry(0)), CDate(TdateAry(2) & "-" & TdateAry(1) & "-" & TdateAry(0)), "")

        Session("Transactions-" & Session("UserID")) = _tbl
        GrdNotifications.DataSource = _tbl
        GrdNotifications.DataBind()

    End Sub




    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    'Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles BtnExport.Click
    '    Dim ExportCSV As New StringBuilder("")
    '    Dim Data As String = ""
    '    Dim attachment As String = ""
    '    If Not Session("Transactions-" & Session("UserID")) Is Nothing Then
    '        _tbl = CType(Session("Transactions-" & Session("UserID")), DataTable)
    '    End If

    '    If _tbl.Rows.Count = 0 Then
    '        attachment = "attachment; filename=NoDataFound.csv"
    '    Else
    '        attachment = "attachment; filename=Transactions" & Now.ToString("yyyyMMddhhmm") & ".csv"

    '        For i As Integer = 0 To _tbl.Columns.Count - 1
    '            Data = Data & _tbl.Columns(i).ColumnName & ","
    '        Next
    '        Data = Data & Environment.NewLine
    '        For i As Integer = 0 To _tbl.Rows.Count - 1
    '            For j As Integer = 0 To _tbl.Columns.Count - 1
    '                Data = Data & _tbl.Rows(i)(j) & ","
    '            Next
    '            Data = Data & Environment.NewLine
    '        Next
    '    End If

    '    HttpContext.Current.Response.Clear()
    '    HttpContext.Current.Response.ClearHeaders()
    '    HttpContext.Current.Response.ClearContent()
    '    HttpContext.Current.Response.AddHeader("content-disposition", attachment)
    '    HttpContext.Current.Response.ContentType = "text/csv"
    '    HttpContext.Current.Response.AddHeader("Pragma", "public")
    '    HttpContext.Current.Response.Write(Data)
    '    HttpContext.Current.Response.End()
    'End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Private Sub GrdNotifications_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdNotifications.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            Dim Lnk As New HyperLink
            Lnk = CType(e.Row.FindControl("LnkNotification"), HyperLink)
            If (drview("TransactionCode") = "Order Received") Then
                Lnk.Attributes.Add("onclick", "ShowOrderDetails('" & drview("ID") & "')")
            ElseIf (drview("TransactionCode") = "POS Credit Sale") Or (drview("TransactionCode") = "POS Cash Sale") Or (drview("TransactionCode") = "POS Sale Return") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/POSSaleInvoice.aspx?SaleID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("TransactionCode") = "Sale Return") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/SaleInvoice.aspx?SaleID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("TransactionCode") = "Purchase Product") Then
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/PurchaseInvoice.aspx?PurchaseID=" & drview("ID") & "',$(window).height()*95/100,$(window).width()*90/100)")
            ElseIf (drview("TransactionCode") = "Payment Received") Then
                Lnk.Attributes.Add("onclick", "ShowReceivePaymentInvoice(" & drview("ID") & ")")
            ElseIf (drview("TransactionCode") = "Cash Payment") Then
                Lnk.Attributes.Add("onclick", "ShowCashPaymentInvoice(" & drview("ID") & ")")
            ElseIf (drview("TransactionCode") = "Bank Payment") Then
                Lnk.Attributes.Add("onclick", "ShowBankPaymentInvoice(" & drview("ID") & ")")
            ElseIf (drview("TransactionCode") = "User UnSubscription") Then
                Lnk.Attributes.Add("onclick", "ShowMessage('Sorry You can not view customer details, since the customer has unscubscribed from your store.', '1', $(window).height() * 2 / 100, $(window).width() * 55 / 100)")
            ElseIf (drview("TransactionCode") = "New User Subscription") Then
                Lnk.Attributes.Add("onclick", "AddCustomer(" & drview("ID") & ")")
            Else
                Lnk.Attributes.Add("onclick", "ShowDlgForm('/Modules/Karobar/Reports/TransactionDetails.aspx?TID=" & drview("ID") & "', $(window).height() * 85 / 100, $(window).width() * 75 / 100)")

            End If
            Lnk.Text = drview("Particular")
        End If
    End Sub

    Private Sub GrdNotifications_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GrdNotifications.PageIndexChanging
        GrdNotifications.PageIndex = e.NewPageIndex
        LoadData()
    End Sub
End Class