﻿Public Class SelectBusiness
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            DDLBusinessCategory.DataSource = Website.GetWebsitesCategories
            DDLBusinessCategory.DataTextField = "CategoryTitle"
            DDLBusinessCategory.DataValueField = "WebsiteCategoryID"
            DDLBusinessCategory.DataBind()
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Dim tbl As New DataTable
        Dim BusinessLogoFilename As String = ""
        If FileUploadBusinessLogo.PostedFile.FileName <> "" Then
            BusinessLogoFilename = Guid.NewGuid.ToString & System.IO.Path.GetExtension(FileUploadBusinessLogo.PostedFile.FileName)
        End If

        tbl = Website.AddWebsite(HttpContext.Current.Session("UserID"), txtBusinessName.Text.Trim, txtBusinessDescription.Text.Trim, DDLBusinessCategory.SelectedItem.Value, BusinessLogoFilename, txtPhone.Text.Trim, txtBusinessFax.Text.Trim, txtEmail.Text.Trim, txtBusinessAddress.Text.Trim)
        If tbl.Rows.Count > 0 Then
            Dim BusinessDirectory As String = Server.MapPath("~/CMS/" & Website.WebsiteID & "/Businesses/") & tbl.Rows(0)("WebsiteID") & "/Images"
            System.IO.Directory.CreateDirectory(BusinessDirectory)
            FileUploadBusinessLogo.SaveAs(BusinessDirectory & "/" & BusinessLogoFilename)
        End If
        ClientScript.RegisterClientScriptBlock(Me.GetType(), "BusinessAddedSuccessFully", "<script>parent.HideDlgForm();parent.ShowMessage('Business added successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
    End Sub
End Class