﻿Public Class PaymentPaidInvoice
    Inherits System.Web.UI.Page
    Dim _TotalAmount As Single

    Private Sub GrdPaymentDetails_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdPaymentDetails.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            _TotalAmount = _TotalAmount + drview("Debit")
        ElseIf e.Row.RowType = DataControlRowType.Footer Then
            Dim TotalAmountLbl As New System.Web.UI.WebControls.Label
            TotalAmountLbl = CType(e.Row.FindControl("TotalAmount"), Label)
            If Not TotalAmountLbl Is Nothing Then
                TotalAmountLbl.Text = _TotalAmount
            End If
        End If
    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open purchase invoice", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
        Dim tblCOAAccounts As New DataTable()
        tblCOAAccounts = ChartOfAccount.GetCOA(Session("CurrentBusinessID"), ParentAccountHeadID:=ReferenceData.Setting("ParentAccountHeadID4BankvoucherPaymentPayReceived", "10", Session("CurrentBusinessID")))

        If Not Page.IsPostBack Then
            HdnTID.Value = Request("TID")
            DDLCreditAccount.DataSource = tblCOAAccounts
            DDLCreditAccount.DataTextField = "AccountHeadName"
            DDLCreditAccount.DataValueField = "AccountHeadID"
            DDLCreditAccount.DataBind()
        End If
        If HdnTID.Value > 0 Then
            Dim tbl As New DataTable
            Dim dtlTbl As New DataTable
            tbl = Transactions.GetTransactionDetails(Session("CurrentBusinessID"), Val(HdnTID.Value))
            dtlTbl = tbl.Select("IsMasterEntry=0").CopyToDataTable()

            Dim TblMaster As New DataTable
            TblMaster = tbl.Select("IsMasterEntry=1").CopyToDataTable()

            Dim tblAccountDtl As New DataTable()

            GrdPaymentDetails.DataSource = dtlTbl
            GrdPaymentDetails.DataBind()
            If tbl.Rows.Count > 1 Then
                If tbl.Rows(0)("TransactionCode") = "CPV" Then
                    LblInvoiceTitle.Text = "Cash Payment"
                    GrdPaymentDetails.Columns(3).Visible = False
                    GrdPaymentDetails.Columns(4).Visible = False
                    GrdPaymentDetails.Columns(7).Visible = False
                    Dim TblCashAccount As New DataTable
                    tblAccountDtl = ChartOfAccount.GetCOA(LoggedInUserSession.BusinessID, TblMaster.Rows(0)("AccountHeadID"))

                Else
                    GrdPaymentDetails.Columns(3).Visible = True
                    GrdPaymentDetails.Columns(4).Visible = True
                    GrdPaymentDetails.Columns(7).Visible = False
                    DDLCreditAccount.SelectedValue = dtlTbl.Rows(0)("AccountHeadID")

                    If (tbl.Select("IsMasterEntry=1").Length > 0) Then
                        If (tblCOAAccounts.Select("AccountHeadID=" & TblMaster.Rows(0)("AccountHeadID")).Length > 0) Then
                            tblAccountDtl = tblCOAAccounts.Select("AccountHeadID=" & TblMaster.Rows(0)("AccountHeadID")).CopyToDataTable()
                        End If
                    End If
                End If
                If (tblAccountDtl.Rows.Count > 0) Then
                    PaidPaymentCreditAccount.Text = tblAccountDtl.Rows(0)("AccountHeadName")
                    LblAccountAddress.Text = tblAccountDtl.Rows(0)("AccountHeadDescription")
                End If
                PaidPaymentReference.Text = tbl.Rows(0)("Reference")
                PaidPaymentParticular.Text = tbl.Rows(0)("Particular")
                    PaidPaymentDate.Text = General.GetLocalDateTimeByTimeZone(tbl.Rows(0)("Dated"), LoggedInUserSession.TimeZone)
                End If
            End If
    End Sub


End Class