﻿Public Class ManageGRN
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

        If Not Me.IsPostBack Then

            txtGRNFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtGRNToDate.Text = Now.ToString("dd-MM-yyyy")
            LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))

            Dim tbl As New DataTable
            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Supplier)
            DDLSupplier.DataValueField = "UserID"
            DDLSupplier.DataTextField = "FirstName"
            DDLSupplier.DataSource = tbl
            DDLSupplier.DataBind()

            LoadData()
        Else

        End If
    End Sub


    Sub LoadData()
        Dim ds As New DataSet
        Dim FDate As String = ""
        Dim FdateAry() = txtGRNFromDate.Text.Replace("/", "-").Split("-")
        Dim TDate As String = ""
        Dim TdateAry() = txtGRNToDate.Text.Replace("/", "-").Split("-")
        Dim SID As Integer = -1
        If (DDLSupplier.Items.Count > 0) Then
            SID = DDLSupplier.SelectedItem.Value
        Else
            Sid = -1
        End If

        _tbl = GRNBLL.GetGRNs(Session("CurrentBusinessID"), FdateAry(2) & FdateAry(1) & FdateAry(0), TdateAry(2) & TdateAry(1) & TdateAry(0), SID, txtSearchText.Text, 999999, 1)

        Session("GRNs-" & Session("UserID")) = _tbl
        GrdGRNs.DataSource = _tbl
        GrdGRNs.DataBind()
    End Sub

    Private Sub GrdGRNs_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GrdGRNs.RowCommand

    End Sub

    Private Sub GrdGRNs_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdGRNs.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            Dim LnkViewGRN As New System.Web.UI.WebControls.LinkButton
            LnkViewGRN = CType(e.Row.FindControl("LnkViewGRN"), LinkButton)
            If Not LnkViewGRN Is Nothing Then
                LnkViewGRN.OnClientClick = "javascript: ShowDlgForm('/Modules/Karobar/Transaction/GRN/GRN_Print.aspx?GRNID=" & drview("GRNID") & "',$(window).height()*95/100,$(window).width()*85/100);return false"
            End If

        ElseIf e.Row.RowType = DataControlRowType.Footer Then


        End If

    End Sub


    Private Sub BtnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        LoadData()
    End Sub

    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim attachment As String = ""
        If Not Session("GRNs-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("GRNs-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            attachment = "attachment; filename=NoDataFound.csv"
        Else
            attachment = "attachment; filename=GRNs" & Now.ToString("yyyyMMddhhmm") & ".csv"

            For i As Integer = 0 To _tbl.Columns.Count - 1
                Data = Data & _tbl.Columns(i).ColumnName & ","
            Next
            Data = Data & Environment.NewLine
            For i As Integer = 0 To _tbl.Rows.Count - 1
                For j As Integer = 0 To _tbl.Columns.Count - 1
                    Data = Data & _tbl.Rows(i)(j) & ","
                Next
                Data = Data & Environment.NewLine
            Next
        End If

        HttpContext.Current.Response.Clear()
        HttpContext.Current.Response.ClearHeaders()
        HttpContext.Current.Response.ClearContent()
        HttpContext.Current.Response.AddHeader("content-disposition", attachment)
        HttpContext.Current.Response.ContentType = "text/csv"
        HttpContext.Current.Response.AddHeader("Pragma", "public")
        HttpContext.Current.Response.Write(Data)
        HttpContext.Current.Response.End()
    End Sub


    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class