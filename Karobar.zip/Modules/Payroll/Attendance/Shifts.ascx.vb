﻿Public Class Shifts
    Inherits System.Web.UI.UserControl

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadData()
        End If
    End Sub

    Private Sub LoadData()
        Dim tbl As New DataTable

        tbl = Payroll.GetWokringShifts(Val(Session("CurrentBusinessID")))
        If tbl.Rows.Count = 0 Then
            Dim dr As DataRow
            ''dr = tbl.NewRow
            ''tbl.Rows.Add(dr)
            pnlNoShifts.Visible = True
        End If
        GrdWorkingShifts.DataSource = tbl
        GrdWorkingShifts.DataBind()
    End Sub

    Private Sub GrdWorkingShifts_PageIndexChanging(sender As Object, e As GridViewPageEventArgs) Handles GrdWorkingShifts.PageIndexChanging
        GrdWorkingShifts.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdWorkingShifts_RowCancelingEdit(sender As Object, e As GridViewCancelEditEventArgs) Handles GrdWorkingShifts.RowCancelingEdit
        GrdWorkingShifts.EditIndex = -1
        LoadData()
    End Sub


    Private Sub GrdWorkingShifts_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GrdWorkingShifts.RowCommand
        If e.CommandName = "AddNewSettings" Then
            GrdWorkingShifts.ShowFooter = True
        ElseIf e.CommandName = "Insert" Then
            Dim ShiftName As String = CType(GrdWorkingShifts.FooterRow.FindControl("txtNewShiftName"), TextBox).Text
            Dim TimeIN As String = CType(GrdWorkingShifts.FooterRow.FindControl("TxtNewShiftTimeIN"), TextBox).Text
            Dim TimeOUT As String = CType(GrdWorkingShifts.FooterRow.FindControl("TxtNewShiftTimeOUT"), TextBox).Text
            Dim GraceTimeIN As String = CType(GrdWorkingShifts.FooterRow.FindControl("DDLNewGraceTimePunchIN"), DropDownList).SelectedValue
            Dim GraceTimeOUT As String = CType(GrdWorkingShifts.FooterRow.FindControl("DDLNewGraceTimePunchOUT"), DropDownList).SelectedValue

            Payroll.AddWorkingShift(Val(Session("CurrentBusinessID")), ShiftName, TimeIN, TimeOUT, GraceTimeIN, GraceTimeOUT, Session("UserID"))
            GrdWorkingShifts.EditIndex = -1
            GrdWorkingShifts.ShowFooter = True
        ElseIf e.CommandName = "UpdateCancel" Then
            GrdWorkingShifts.EditIndex = -1
            GrdWorkingShifts.ShowFooter = True
        ElseIf e.CommandName = "UpdateShift" Then
            Dim ShiftID As Integer = Val(CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("HdnEditShiftID"), HiddenField).Value)
            Dim ShiftName As String = CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("TxtEditShiftName"), TextBox).Text
            Dim TimeIN As String = CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("TxtEditShiftTimeIN"), TextBox).Text
            Dim TimeOUT As String = CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("TxtEditShiftTimeOUT"), TextBox).Text
            Dim GraceTimeIN As String = CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("DDLEditGraceTimePunchIN"), DropDownList).SelectedValue
            Dim GraceTimeOUT As String = CType(GrdWorkingShifts.Rows(GrdWorkingShifts.EditIndex).FindControl("DDLEditGraceTimePunchOUT"), DropDownList).SelectedValue

            Payroll.UpdateWorkingShift(Val(Session("CurrentBusinessID")), ShiftID, ShiftName, TimeIN, TimeOUT, GraceTimeIN, GraceTimeOUT, Session("UserID"))
            GrdWorkingShifts.EditIndex = -1
            GrdWorkingShifts.ShowFooter = True
        ElseIf e.CommandName = "DeleteShift" Then
            Payroll.DeleteWorkingShift(Session("CurrentBusinessID"), e.CommandArgument)
            GrdWorkingShifts.EditIndex = -1
            GrdWorkingShifts.ShowFooter = True
        End If
        LoadData()
        GrdWorkingShifts.ShowFooter = True
    End Sub

    Private Sub GrdWorkingShifts_RowEditing(sender As Object, e As GridViewEditEventArgs) Handles GrdWorkingShifts.RowEditing
        GrdWorkingShifts.EditIndex = e.NewEditIndex
        GrdWorkingShifts.ShowFooter = False
        LoadData()
    End Sub

    Private Sub GrdWorkingShifts_RowDataBound(sender As Object, e As GridViewRowEventArgs) Handles GrdWorkingShifts.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)

            If GrdWorkingShifts.EditIndex = e.Row.RowIndex Then
                Dim GraceTimeIN As DropDownList = CType(e.Row.FindControl("DDLEditGraceTimePunchIN"), DropDownList)
                Dim GraceTimeOUT As DropDownList = CType(e.Row.FindControl("DDLEditGraceTimePunchOUT"), DropDownList)

                If Not GraceTimeIN Is Nothing Then
                    GraceTimeIN.SelectedValue = Val(drview("GraceTimePunchIN").ToString())
                End If
                If Not GraceTimeOUT Is Nothing Then
                    GraceTimeOUT.SelectedValue = Val(drview("GraceTimePunchOUT").ToString())
                End If

                Dim LnkUpdate As LinkButton = CType(e.Row.FindControl("LnkUpdate"), LinkButton)
                Dim LnkEdit As LinkButton = CType(e.Row.FindControl("LnkEdit"), LinkButton)
                Dim LnkDeleteShift As LinkButton = CType(e.Row.FindControl("LnkDeleteShift"), LinkButton)
                Dim LnkCancelShift As LinkButton = CType(e.Row.FindControl("LnkCancel"), LinkButton)

                LnkUpdate.Visible = True
                LnkCancelShift.Visible = True
                LnkDeleteShift.Visible = False
                LnkEdit.Visible = False

            End If


        ElseIf e.Row.RowType = DataControlRowType.Footer Then
                'Dim DDLFooterParentType As DropDownList = CType(e.Row.FindControl("DDLFooterParentType"), DropDownList)
                'If Not DDLFooterParentType Is Nothing Then
                '    Dim ds As New DataSet
                '    ds = Products.GetProductTypes(Session("CurrentBusinessID"), PrimaryTypeID:=Website.DataTypes.ProductCatagories * -1)
                '    DDLFooterParentType.DataValueField = "ArticleTypeID"
                '    DDLFooterParentType.DataTextField = "ArticleType"
                '    DDLFooterParentType.DataSource = ds.Tables(0)
                '    DDLFooterParentType.DataBind()
                'End If
            End If
    End Sub

    Private Sub lnkAddNewShift_Click(sender As Object, e As EventArgs) Handles lnkAddNewShift.Click
        Dim tbl As New DataTable
        tbl = Payroll.GetWokringShifts(Val(Session("CurrentBusinessID")))
        If tbl.Rows.Count = 0 Then
            Dim dr As DataRow
            dr = tbl.NewRow
            tbl.Rows.Add(dr)
        End If
        GrdWorkingShifts.DataSource = tbl
        GrdWorkingShifts.DataBind()
        pnlNoShifts.Visible = False
    End Sub
End Class