﻿Public Class CompanyHolidays
    Inherits System.Web.UI.Page

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles BtnSave.Click
        Dim ApprovedBy As Integer = -1
        LblErrMsg.Visible = False
        If CDate(General.GetDateinMMDDYYYY(txtFromDate.Text, "-")) > CDate(General.GetDateinMMDDYYYY(txtToDate.Text, "-")) Then
            LblErrMsg.Visible = True
            LblErrMsg.Text = "To date should not be less than from date."
            Exit Sub
            'ElseIf CDate(GetDateinMMDDYYYY(txtFromDate.Text, "-")) < CDate(GetDateinMMDDYYYY(txtToDate.Text, "-")) Then
            '    LblErrMsg.Visible = True
            '    LblErrMsg.Text = "From date should be less than to date."
            '    Exit Sub
        End If

        Dim EventsTbl As New DataTable
        EventsTbl = BusinessEvents.GetEvents(Val(Session("CurrentBusinessID")), CDate(General.GetDateinMMDDYYYY(txtFromDate.Text, "-")), CDate(General.GetDateinMMDDYYYY(txtToDate.Text, "-")), BusinessEvents.EventTypes.Holidays, "", -1)
        If (EventsTbl.Rows.Count > 0) Then
            LblErrMsg.Visible = True
            LblErrMsg.Text = "Holiday is already set with in this date range."
            Exit Sub
        End If

        If (DDLApprovedBy.Items.Count > 0) Then
            ApprovedBy = DDLApprovedBy.SelectedValue
        End If

        Try
            BusinessEvents.AddEvent(Session("CurrentBusinessID"), Session("UserID"), BusinessEvents.EventTypes.Holidays, CDate(General.GetDateinMMDDYYYY(txtFromDate.Text, "-")), CDate(General.GetDateinMMDDYYYY(txtToDate.Text, "-")), txtHolidayReason.Text.Trim(), ApprovedBy)
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "HolidayAddedSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('Holiday added successfully!','0',$(window).height()*2/100,$(window).width()*35/100,'1');setTimeout(function(){parent.window.location='/Working-Days';},2000)</script>")
        Catch ex As Exception
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "HolidayAddingIssue", "<script>parent.ShowMessage('Unable to add Holiday','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
        End Try
    End Sub

    Private Sub ManageCompanyHolidays_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            DDLApprovedBy.DataSource = Person.GetUsersList(Session("CurrentBusinessID"), "", Person.UserTypes.Staff)
            DDLApprovedBy.DataValueField = "UserID"
            DDLApprovedBy.DataTextField = "FirstName"
            DDLApprovedBy.DataBind()
            txtFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtToDate.Text = Now.ToString("dd-MM-yyyy")
        End If
    End Sub
End Class