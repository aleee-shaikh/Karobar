﻿Public Class GiftCardRechargeReport
    Inherits System.Web.UI.UserControl

    Dim _TotalDebit As Single
    Dim _TotalCredit As Single
    Dim _TotalBalance As Single
    Dim _tbl As New DataTable

    Private Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        If Not Me.IsPostBack Then
            txtFromDate.Text = Now.ToString("dd-MM-yyyy")
            txtToDate.Text = Now.ToString("dd-MM-yyyy")
            Dim tbl As New DataTable

            tbl = Person.GetUsersList(Val(Session("CurrentBusinessID")), "", 4)
            DDLCustomer.DataTextField = "FirstName"
            DDLCustomer.DataValueField = "UserID"
            DDLCustomer.DataSource = tbl
            DDLCustomer.DataBind()
            DDLCustomer.Items.Insert(0, New ListItem(" -- Select User -- ", "-1"))
            LoadData()
        Else

        End If
    End Sub

    Sub LoadData()
        GrdRecharging.DataSource = GiftCard.GetRechargingReport(Val(Session("CurrentBusinessID")), General.GetDateinMMDDYYYY(txtFromDate.Text, "-"), General.GetDateinMMDDYYYY(txtToDate.Text, "-"))
        GrdRecharging.DataBind()
    End Sub

    Private Sub GrdRecharging_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles GrdRecharging.PageIndexChanging
        GrdRecharging.PageIndex = e.NewPageIndex
        LoadData()
    End Sub

    Private Sub GrdRecharging_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GrdRecharging.RowDataBound
        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim drview As DataRowView = CType(e.Row.DataItem, DataRowView)
            '    e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='white';this.style.cursor='pointer';")
            '    e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;")
            '    _TotalDebit = _TotalDebit + IIf(IsDBNull(drview("Debit")), 0, drview("Debit"))
            '    _TotalCredit = _TotalCredit + IIf(IsDBNull(drview("Credit")), 0, drview("Credit"))
            '    _TotalBalance = _TotalBalance + IIf(IsDBNull(drview("Balance")), 0, drview("Balance"))
            'ElseIf e.Row.RowType = DataControlRowType.Footer Then
            '    Dim TotalDebitLbl As New System.Web.UI.WebControls.Label
            '    Dim TotalCreditLbl As New System.Web.UI.WebControls.Label
            '    Dim TotalBalanceLbl As New System.Web.UI.WebControls.Label

            '    TotalDebitLbl = CType(e.Row.FindControl("LblTotalDebit"), Label)
            '    TotalCreditLbl = CType(e.Row.FindControl("LblTotalCredit"), Label)
            '    TotalBalanceLbl = CType(e.Row.FindControl("LblTotalBalance"), Label)

            '    If Not TotalDebitLbl Is Nothing Then
            '        TotalDebitLbl.Text = _TotalDebit
            '    End If

            '    If Not TotalCreditLbl Is Nothing Then
            '        TotalCreditLbl.Text = _TotalCredit
            '    End If

            '    If Not TotalCreditLbl Is Nothing Then
            '        TotalBalanceLbl.Text = _TotalBalance
            '    End If
        End If

    End Sub


    Private Sub BtnExport_Click(ByVal sender As Object, ByVal e As EventArgs) Handles BtnExport.Click
        Dim ExportCSV As New StringBuilder("")
        Dim Data As String = ""
        Dim ExportFileName As String = ""
        If Not Session("BankBalanceReport-" & Session("UserID")) Is Nothing Then
            _tbl = CType(Session("BankBalanceReport-" & Session("UserID")), DataTable)
        End If

        If _tbl.Rows.Count = 0 Then
            ExportFileName = "filename=NoDataFound.csv"
        Else
            ExportFileName = "BankBalanceReport" & Now.ToString("yyyyMMddhhmm") & ".csv"
        End If

        General.ExportGridToCSV(_tbl, ExportFileName, "AccountHeadID,AccountHeadName,Balance")

    End Sub

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
        '    Page.ClientScript.RegisterStartupScript(Me.GetType(), "InsufficientRights", "<script>setTimeout('history.go(-1)','2000');parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
        '    Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open bank balance report", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        'End If
    End Sub


    Private Sub DDLUserCards_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLUserCards.SelectedIndexChanged
        If DDLCustomer.SelectedValue > 0 Then
            Dim tbl As New DataTable
            tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), DDLCustomer.SelectedValue, DDLUserCards.SelectedValue)
            If tbl.Rows.Count > 0 Then
                If tbl.Rows(0)("CardStatusID") = 2 Then 'Cancelled
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardCancelled", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been cancelled.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                ElseIf DateDiff(DateInterval.Day, Now, tbl.Rows(0)("ExpiryDate")) < 0 Then
                    DDLUserCards.SelectedIndex = 0
                    Page.RegisterStartupScript("GiftCardExpired", "<script>parent.ShowMessage('" & tbl.Rows(0)("GiftCardName") & " - " & DDLUserCards.SelectedValue & " has been expired.','1',$(window).height()*2/100,$(window).width()*35/100)</script>")
                Else

                End If
            End If
        End If
    End Sub

    Private Sub ddlCustomer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLCustomer.SelectedIndexChanged
        Dim tbl As New DataTable
        DDLUserCards.Items.Clear()
        tbl = GiftCard.GetUserCards(Session("CurrentBusinessID"), DDLCustomer.SelectedValue)
        DDLUserCards.DataTextField = "UserCardName"
        DDLUserCards.DataValueField = "UserCardID"
        DDLUserCards.DataSource = tbl
        DDLUserCards.DataBind()
        DDLUserCards.Items.Insert(0, New ListItem("-- Select Gift Card --", "-1"))


    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles BtnSearch.Click
        GrdRecharging.DataSource = GiftCard.GetRechargingReport(Val(Session("CurrentBusinessID")), General.GetDateinMMDDYYYY(txtFromDate.Text, "-"), General.GetDateinMMDDYYYY(txtToDate.Text, "-"))
        GrdRecharging.DataBind()
    End Sub
End Class