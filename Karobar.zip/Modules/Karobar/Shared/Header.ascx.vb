﻿Public Class Header
    Inherits System.Web.UI.UserControl

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Val(LoggedInUserSession.BusinessID) > 0 Then
            If LoggedInUserSession.BusinessLogo <> "" Then
                Dim BusinessDirectory As String = "~/CMS/" & Website.WebsiteID & "/Businesses/" & LoggedInUserSession.BusinessID & "/Images"
                If System.IO.File.Exists(Server.MapPath(BusinessDirectory) & "/" & LoggedInUserSession.BusinessLogo) Then
                    BusinessLogo.ImageUrl = BusinessDirectory & "/" & LoggedInUserSession.BusinessLogo
                Else
                    BusinessLogo.ImageUrl = "~/Images" & "/NoBusinessImage.png"
                End If
            Else
                BusinessLogo.ImageUrl = "~/Images" & "/NoBusinessImage.png"
            End If

            If BusinessLogo.ImageUrl <> "" Then
                BusinessLogo.Visible = True
                BusinessLogo.AlternateText = LoggedInUserSession.BusinessTitle
                BusinessName.Visible = False
            Else
                BusinessLogo.Visible = False
                'businesslogo.alternatetext = ds.tables(0).rows(0)("websitetitle")
                BusinessName.Visible = True
                BusinessName.Text = LoggedInUserSession.BusinessTitle
            End If
        End If

        'If Val(Session("CurrentBusinessID")) > 0 Then

        '    Dim ds As New DataSet
        '    Dim BID As Integer = Val(Session("CurrentBusinessID"))
        '    ds = Website.GetWebsiteDetails(BID)
        '    If ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0 Then
        '        If (IsDBNull(ds.Tables(0).Rows(0)("WebsiteLogo")) = False AndAlso ds.Tables(0).Rows(0)("WebsiteLogo") <> "") Then
        '            Dim BusinessDirectory As String = "~/CMS/" & Website.WebsiteID & "/Businesses/" & BID & "/Images"
        '            If System.IO.File.Exists(Server.MapPath(BusinessDirectory) & "/" & ds.Tables(0).Rows(0)("WebsiteLogo")) Then
        '                BusinessLogo.ImageUrl = BusinessDirectory & "/" & ds.Tables(0).Rows(0)("WebsiteLogo")
        '            Else
        '                BusinessLogo.ImageUrl = "~/Images" & "/NoBusinessImage.png"
        '            End If

        '            ''Else
        '            '' BusinessLogo.ImageUrl = "~/Images" & "/NoBusinessImage.png"
        '        End If

        '        If BusinessLogo.ImageUrl <> "" Then
        '            BusinessLogo.Visible = True
        '            BusinessLogo.AlternateText = ds.Tables(0).Rows(0)("WebsiteTitle")
        '            BusinessName.Visible = False
        '        Else
        '            BusinessLogo.Visible = False
        '            'BusinessLogo.AlternateText = ds.Tables(0).Rows(0)("WebsiteTitle")
        '            BusinessName.Visible = True
        '            BusinessName.Text = ds.Tables(0).Rows(0)("WebsiteTitle")
        '        End If


        '    End If
        'Else
        '    BusinessLogo.AlternateText = "No Business Selected"

        'End If

    End Sub
End Class