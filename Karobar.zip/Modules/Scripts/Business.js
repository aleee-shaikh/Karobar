﻿function Website_GetBusiness4VirtualMarket(ControlID, BusinessID, CategoryID,UserID, SearchText, PageNo,PageSize) {
    var Data = [];
    
    var RequestData = {
        BusinessID: BusinessID,
        CategoryID: CategoryID,
        UserID: UserID,
        SearchText: SearchText,
        PageNo: PageNo,
        PageSize: PageSize
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Businesses.asmx/SearchBusinesses4VirtualMarket',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Businesses").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("Businesses").each(function () {
                    var redirectPage = 'mall';
                    if ($(this).find("CategoryTitle").text().indexOf('Job Portal') >= 0) {
                        redirectPage="job"
                    }
                    else if ($(this).find("CategoryTitle").text().indexOf('Ecommerce Website') >= 0) {
                        redirectPage = "mall"
                    }
                    Data.push({
                        BusinessID: $(this).find("WebsiteID").text(),
                        BusinessName: $(this).find("WebsiteTitle").text(),
                        BusinessName4URL: $(this).find("WebsiteTitle").text().replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),//.replace(/[\s]/g, ""),
                        BusinessDescription: $(this).find("WebsiteDescription").text(),
                        BusinessLogo: $(this).find("WebsiteLogo").text(),
                        CurrencyCode: $(this).find("CurrencyCode").text(),
                        Fax: $(this).find("Fax").text(),
                        Email: $(this).find("Email").text(),
                        Phone: $(this).find("Phone").text(),
                        City: $(this).find("City").text(),
                        Town: $(this).find("Town").text(),
                        ZipCode: $(this).find("ZipCode").text(),
                        CategoryID: $(this).find("WebsiteCategoryID").text(),
                        CategoryTitle: $(this).find("CategoryTitle").text(),
                        CountryID: $(this).find("CountryID").text(),
                        CountryName: '',
                        redirectPage: redirectPage,
                        WebsiteURL: $(this).find("WebsiteURL").text()
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert("error:" + xhr.responseText);
        }
    });
    return Data
}

function Website_GetBusiness(ControlID, BusinessID, CategoryID, UserID, SearchText, PageNo, PageSize) {
    var Data = [];

    var RequestData = {
        BusinessID: BusinessID,
        CategoryID: CategoryID,
        UserID: UserID,
        SearchText: SearchText,
        PageNo: PageNo,
        PageSize: PageSize
    };

    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Businesses.asmx/SearchBusinesses',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("Businesses").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("Businesses").each(function () {
                    var redirectPage = 'mall';
                    if ($(this).find("CategoryTitle").text().indexOf('Job Portal') >= 0) {
                        redirectPage = "job"
                    }
                    else if ($(this).find("CategoryTitle").text().indexOf('Ecommerce Website') >= 0) {
                        redirectPage = "mall"
                    }
                    Data.push({
                        BusinessID: $(this).find("WebsiteID").text(),
                        BusinessName: $(this).find("WebsiteTitle").text(),
                        BusinessName4URL: $(this).find("WebsiteTitle").text().replace(/([~!@#$%^&*()_+=`{}\[\]\|\\:;'<>,.\/? ])+/g, '-'),//.replace(/[\s]/g, ""),
                        BusinessDescription: $(this).find("WebsiteDescription").text(),
                        BusinessLogo: $(this).find("WebsiteLogo").text(),
                        CurrencyCode: $(this).find("CurrencyCode").text(),
                        Fax: $(this).find("Fax").text(),
                        Email: $(this).find("Email").text(),
                        Phone: $(this).find("Phone").text(),
                        City: $(this).find("City").text(),
                        Town: $(this).find("Town").text(),
                        ZipCode: $(this).find("ZipCode").text(),
                        CategoryID: $(this).find("WebsiteCategoryID").text(),
                        CategoryTitle: $(this).find("CategoryTitle").text(),
                        CountryID: $(this).find("CountryID").text(),
                        CountryName: '',
                        redirectPage: redirectPage
                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert("error:" + xhr.responseText);
        }
    });
    return Data
}
