﻿Public Class ManageOffers
    Inherits System.Web.UI.UserControl

    Dim _tbl As New DataTable

    Private Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            LoadEmailTemplates()
            LoadData(-1)

        End If
    End Sub

    Sub LoadData(EmailTemplateID As Integer)
        Dim ds As New DataSet
        ds = OffersAndDeals.Offer_GetOffers(Session("CurrentBusinessID"))
        grdOffers.DataSource = ds
        grdOffers.DataBind()

    End Sub

    Sub LoadEmailTemplates()
        DDLEmails.DataValueField = "EmailTemplateID"
        DDLEmails.DataTextField = "EmailSubject"
        DDLEmails.DataSource = WebsiteEmail.GetExistingEmails()
        DDLEmails.DataBind()
        If Page.IsPostBack Then DDLEmails.SelectedIndex = DDLEmails.Items.Count - 1
    End Sub


    Private Sub DDLEmails_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLEmails.SelectedIndexChanged
        LoadData(DDLEmails.SelectedItem.Value)
    End Sub

    Private Sub BtnSendOffers_Click(sender As Object, e As EventArgs) Handles BtnSendOffers.Click
        Dim offerTitle As String
        ''Log.Notifications_Add(offerTitle, offerID, "AppNotifications", userID, BusinessID)
    End Sub

    Private Sub grdOffers_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles grdOffers.RowCommand
        If e.CommandName = "DeleteOffer" Then
            OffersAndDeals.Offer_Delete(Val(Session("CurrentBusinessID")), e.CommandArgument)
            LoadData(-1)
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Offer", "Offer deleted" & e.CommandArgument, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=e.CommandArgument)
        End If
    End Sub
End Class