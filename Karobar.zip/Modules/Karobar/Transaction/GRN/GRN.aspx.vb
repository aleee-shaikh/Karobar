﻿Public Class GRN
    Inherits System.Web.UI.Page


    Private Sub PaymentsPayReceived_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Person.DoesPersonHavePageRights(Session("UserID"), 126) = False And Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
            ClientScript.RegisterClientScriptBlock(Me.GetType(), "InsufficientRights", "<script>parent.ShowMessage('Sorry You have insufficient rights to use this','1',$(window).height()*2/100,$(window).width()*55/100);parent.HideDlgForm(1);</script>")
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Securtiy Issue", "Tried to open staff screen", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Exit Sub
        End If
        If Not Page.IsPostBack Then

            LblSupplier.Text = ReferenceData.Setting("LblProductSupplier", "Supplier", Session("CurrentBusinessID"))
            LblGRNInspector.Text = ReferenceData.Setting("LblGRNInspector", "Inspector", Session("CurrentBusinessID"))
            LblGRNReference.Text = ReferenceData.Setting("LblGRNReference", "Reference", Session("CurrentBusinessID"))
            LblGRNParticular.Text = ReferenceData.Setting("LblGRNParticular", "Remarks", Session("CurrentBusinessID"))
            LblGRNDate.Text = ReferenceData.Setting("LblCashPaymentDate", "Date", Session("CurrentBusinessID"))
            LblScreenTitle.Text = ReferenceData.Setting("LblScreenTitle", "Goods Receive Note", Session("CurrentBusinessID"))

            Dim tbl As New DataTable

            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Supplier)
            DDLSupplier.DataValueField = "UserID"
            DDLSupplier.DataTextField = "FirstName"
            DDLSupplier.DataSource = tbl
            DDLSupplier.DataBind()


            tbl = Person.GetUsersList(Session("CurrentBusinessID"), , Person.UserTypes.Staff)
            DDLInspector.DataValueField = "UserID"
            DDLInspector.DataTextField = "FirstName"
            DDLInspector.DataSource = tbl
            DDLInspector.DataBind()


            GenericGRNRow1.AddColumn("Product", New DropDownList)

            GenericGRNRow1.AddColumn("Unit", New TextBox)
            GenericGRNRow1.AddColumn("ReceivedQuantity", New TextBox)
            GenericGRNRow1.AddColumn("RejectedQuantity", New TextBox)
            GenericGRNRow1.AddColumn("ActualReceived", New TextBox)


            txtDate.Text = Now.ToString("dd-MM-yyyy")
            If Not Request("GRNID") Is Nothing Then
                hdnGRNID.Value = Val(Request("GRNID"))
                LoadData()
                BtnSave.Visible = False
            Else
                hdnGRNID.Value = "0"
            End If
        End If


    End Sub

    Sub LoadData()
        If Val(hdnGRNID.Value) > 0 Then
            Dim ds As New DataSet
            ds = GRNBLL.GetGRNDetailByID(Session("CurrentBusinessID"), hdnGRNID.Value)
            If ds.Tables.Count > 1 Then
                If ds.Tables(0).Rows.Count > 0 Then
                    If IsDBNull(ds.Tables(0).Rows(0)("ReferenceNo")) = False Then
                        txtReference.Text = ds.Tables(0).Rows(0)("ReferenceNo")
                    End If
                    If IsDBNull(ds.Tables(0).Rows(0)("Remarks")) = False Then
                        txtParticular.Text = ds.Tables(0).Rows(0)("Remarks")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("Dated")) = False Then
                        txtDate.Text = ds.Tables(0).Rows(0)("Dated")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("Receivedby")) = False Then
                        DDLInspector.SelectedValue = ds.Tables(0).Rows(0)("ReceivedBy")
                    End If

                    If IsDBNull(ds.Tables(0).Rows(0)("SupplierID")) = False Then
                        DDLSupplier.SelectedValue = ds.Tables(0).Rows(0)("SupplierID")
                    End If
                    GenericGRNRow1.SetGRNData(ds.Tables(1))
                End If
            End If
        End If
    End Sub

    Private Sub BtnSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        If GenericGRNRow1.DataRowsCount.Value > 0 Then
            GenericGRNRow1.AddRow()
            GenericGRNRow1.UpdateRows()
        End If
        Dim tbl As New DataTable
        Dim GRNID As Integer = -1
        Dim SupplierID As Integer = -1
        Dim InspectorID As Integer = -1

        If DDLInspector.Items.Count > 0 Then
            InspectorID = DDLInspector.SelectedValue
        End If
        If (DDLSupplier.Items.Count > 0) Then
            SupplierID = DDLSupplier.SelectedValue
        End If

        Dim DatedAry() = txtDate.Text.Replace("/", "-").Split("-")
        tbl = GRNBLL.AddGRNMaster(Session("CurrentBusinessID"), txtReference.Text.Trim, SupplierID, InspectorID, txtParticular.Text.Trim())
        If tbl.Rows.Count > 0 Then
            GRNID = tbl.Rows(0)("grnid")
            tbl = New DataTable
            tbl = GenericGRNRow1.GetGRNData()
            Try
                For i As Integer = 0 To tbl.Rows.Count - 2
                    If tbl.Rows(i)("Product") > 0 Then
                        GRNBLL.AddGRNDetails(GRNID, tbl.Rows(i)("Product"), tbl.Rows(i)("Unit"), tbl.Rows(i)("ReceivedQuantity"), tbl.Rows(i)("RejectedQuantity"), tbl.Rows(i)("ActualReceived"))
                    End If
                Next
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GRNDoneSuccessFully", "<script>parent.HideDlgForm(1);parent.ShowMessage('GRN has been saved successfully!','0',$(window).height()*2/100,$(window).width()*35/100)</script>")
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "GRN done", "GRN ID :" & GRNID, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl, ID:=GRNID)
            Catch ex As Exception
                ClientScript.RegisterClientScriptBlock(Me.GetType(), "GRNAddingIssue", "<script>parent.ShowMessage('Unable to process grn','1',$(window).height()*2/100,$(window).width()*55/100)</script>")
            End Try

        End If
    End Sub
End Class