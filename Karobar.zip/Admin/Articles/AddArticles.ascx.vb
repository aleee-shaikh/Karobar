﻿Public Class AddArticles
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Page.IsPostBack = False Then
            Dim ds As New DataSet
            ds = WebsiteArticles.GetArticleTypes(Website.WebsiteID)
            If ds.Tables.Count > 0 Then
                DDLArticlesSecondaryType.DataSource = ds.Tables(0)
                DDLArticlesSecondaryType.DataTextField = "ArticleType"
                DDLArticlesSecondaryType.DataValueField = "ArticleTypeID"
                DDLArticlesSecondaryType.DataBind()
            End If
            If ds.Tables.Count >= 1 Then
                DDLArticlesPrimaryType.DataSource = ds.Tables(1)
                DDLArticlesPrimaryType.DataTextField = "ArticleType"
                DDLArticlesPrimaryType.DataValueField = "ArticleTypeID"
                DDLArticlesPrimaryType.DataBind()
            End If

            
            
        End If
    End Sub


    Private Sub BtnAddArticle_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnAddArticle.Click
        Dim NewArticleID As Integer
        If Not System.IO.Directory.Exists(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images")) Then
            System.IO.Directory.CreateDirectory(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images"))
        End If
        If FileUploadArticleImage.PostedFile.FileName <> "" Then
            FileUploadArticleImage.PostedFile.SaveAs(Server.MapPath("~/CMS/" & Website.WebsiteID & "/Articles/Images") & "/" & FileUploadArticleImage.PostedFile.FileName)
        End If
        Dim ArticleTypeID As Integer
        If DDLArticlesSecondaryType.Items.Count > 0 Then
            ArticleTypeID = DDLArticlesSecondaryType.SelectedItem.Value
        Else
            ArticleTypeID = DDLArticlesPrimaryType.SelectedItem.Value
        End If
        NewArticleID = WebsiteArticles.AddArticles(ArticleTypeID, txtArticleTitle.Text.Trim, txtArticleDesc.Text, FileUploadArticleImage.PostedFile.FileName, ChkVisible.Checked, Val(txtSortOrder.Text), txtSEODescription.Text.Trim, HttpContext.Current.Session("UserID"))
        ''Response.Redirect("~/Admin/Admin.aspx?P=Articles")
        Session("ArticleID") = NewArticleID
        Response.Redirect("~/Admin/Admin.aspx?P=Articles&S=2")
    End Sub



    Private Sub DDLArticlesPrimaryType_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DDLArticlesPrimaryType.SelectedIndexChanged
        Dim ds As New DataSet
        ds = WebsiteArticles.GetArticleTypes(Website.WebsiteID, DDLArticlesPrimaryType.SelectedItem.Value)
        DDLArticlesSecondaryType.Items.Clear()
        If ds.Tables.Count > 0 Then
            DDLArticlesSecondaryType.DataSource = ds.Tables(0)
            DDLArticlesSecondaryType.DataTextField = "ArticleType"
            DDLArticlesSecondaryType.DataValueField = "ArticleTypeID"
            DDLArticlesSecondaryType.DataBind()
        End If
        
        TRSecondaryType.visible = (DDLArticlesSecondaryType.Items.Count > 0)
    End Sub

End Class