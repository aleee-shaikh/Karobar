﻿Public Class MasterPage4Others
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ''Social Media Code Start
        Me.webpagehead.Description = CMS.WebPage.PageSEODescription()
        Me.webpagehead.Keywords = CMS.WebPage.PageSEOKeywords

        If (Session("UserID") Is Nothing OrElse Val(Session("UserID")) <= 0) And (Session("CurrentBusinessID") Is Nothing OrElse Val(Session("CurrentBusinessID")) <= 0) And Request.QueryString("PID") Is Nothing And Request.QueryString("OfferID") Is Nothing Then
            Response.Redirect("~/EzBusiness.aspx")
        End If

        txtCurrentURL.Text = Request.Url.PathAndQuery

        If Not Request("PID") Is Nothing Then
            Dim ArticleID As Integer
            Dim MetaTags As String = "" & Environment.NewLine
            Dim ds As New DataSet
            ArticleID = Val(Request("PID").ToString)

            ds = WebsiteArticles.GetArticle(ArticleID)
            If ds.Tables(0).Rows.Count > 0 Then
                If (IsDBNull(ds.Tables(0).Rows(0)("ArticleImage")) = False AndAlso ds.Tables(0).Rows(0)("ArticleImage") <> "") Then
                    OGImage.Content = "http://joined24.com/CMS/Product/Images/" & ds.Tables(0).Rows(0)("ArticleImage")
                Else
                    Dim tbl As New DataTable
                    tbl = ChartOfAccount.GetBusinessDetails(Val(ds.Tables(0).Rows(0)("WebsiteID")))
                    If tbl.Rows.Count > 0 Then
                        If (IsDBNull(tbl.Rows(0)("websiteLogo")) = False AndAlso tbl.Rows(0)("websiteLogo") <> "") Then
                            OGImage.Content = "/CMS/1/Businesses/" & tbl.Rows(0)("WebsiteID") & "/Images/" & tbl.Rows(0)("websiteLogo")
                        End If
                    End If
                End If

                Page.Title = ds.Tables(0).Rows(0)("ArticleTitle")

                'If ds.Tables(0).Rows(0)("ArticleTypeID") >= 8 And ds.Tables(0).Rows(0)("ArticleTypeID") <= 12 Then

                'ElseIf ds.Tables(0).Rows(0)("ArticleTypeID") = 7 Then
                '    OGImage.Content = ReferenceData.Setting("JobsLogo", "http://joined24.com/CMS/1/Upload/Jobslogo.jpg", Session("CurrentBusinessID"))
                'Else
                '    OGImage.Content = ReferenceData.Setting("WebsiteLogo", "http://joined24.com/CMS/1/images/Xplorewiki.png", Session("CurrentBusinessID"))
                'End If

                If ds.Tables(0).Rows(0)("ArticleImage").ToString().Trim() = "" Then
                    OGImage.Visible = False
                End If
                If (ds.Tables(0).Rows(0)("ArticleText").ToLower().IndexOf("<iframe")) >= 0 Then

                    Dim Desc As String = ""
                    Desc = ds.Tables(0).Rows(0)("ArticleText").Substring(ds.Tables(0).Rows(0)("ArticleText").ToLower().IndexOf("src=") + 5)
                    Desc = Desc.Substring(0, Desc.ToLower().IndexOf(" frameborder=") - 1)
                    MetaTags = MetaTags & "<meta property='og:title' content='" & ds.Tables(0).Rows(0)("ArticleTitle") & " " & Desc & "' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video' content='" & Desc.Replace("embed", "v") & "&fs=1' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:width' content='560' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:height' content='340' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:type' content='application/x-shockwave-flash' />" & Environment.NewLine
                    OGImage.Content = "http://i2.ytimg.com/vi/1F7DKyFt5pY/default.jpg"
                    Me.webpagehead.Description += ds.Tables(0).Rows(0)("ArticleText") & " " & Desc
                Else
                    MetaTags = MetaTags & "<meta Property='og:title' content='" & ds.Tables(0).Rows(0)("ArticleTitle") & "' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:description' content='" & IIf(ds.Tables(0).Rows(0)("ArticleText") <> "" AndAlso Len(ds.Tables(0).Rows(0)("ArticleText")) <= 200, ds.Tables(0).Rows(0)("ArticleText"), Left(ds.Tables(0).Rows(0)("ArticleText"), 200) & "...") & "' />" & Environment.NewLine
                    Me.webpagehead.Description += ds.Tables(0).Rows(0)("ArticleText")
                End If


            End If
            litMeta.Text = MetaTags
            ''If Session("Visited") Is Nothing Then
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Visit", "Visited at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Session("Visited") = Now
            ''End If
        ElseIf Not Request("OfferID") Is Nothing Then
            Dim ArticleID As Integer
            Dim MetaTags As String = "" & Environment.NewLine
            Dim ds As New DataSet
            ArticleID = Val(Request("OfferID").ToString)

            ''ds = WebsiteArticles.GetArticle(ArticleID)
            ds = OffersAndDeals.Offer_GetOffers(-1, ArticleID)
            If ds.Tables(0).Rows.Count > 0 Then
                If (IsDBNull(ds.Tables(0).Rows(0)("OfferImage")) = False AndAlso ds.Tables(0).Rows(0)("OfferImage") <> "") Then
                    OGImage.Content = "http://joined24.com/CMS/Offers/Images/" & ds.Tables(0).Rows(0)("OfferImage")
                Else
                    Dim tbl As New DataTable
                    tbl = ChartOfAccount.GetBusinessDetails(Val(ds.Tables(0).Rows(0)("WebsiteID")))
                    If tbl.Rows.Count > 0 Then
                        If (IsDBNull(tbl.Rows(0)("websiteLogo")) = False AndAlso tbl.Rows(0)("websiteLogo") <> "") Then
                            OGImage.Content = "/CMS/1/Businesses/" & tbl.Rows(0)("WebsiteID") & "/Images/" & tbl.Rows(0)("websiteLogo")
                        End If
                    End If
                End If
                Page.Title = ds.Tables(0).Rows(0)("OfferTitle")
                If ds.Tables(0).Rows(0)("OfferImage").ToString().Trim() = "" Then
                    ''OGImage.Visible = False
                End If
                If (ds.Tables(0).Rows(0)("OfferDescription").ToLower().IndexOf("<iframe")) >= 0 Then

                    Dim Desc As String = ""
                    Desc = ds.Tables(0).Rows(0)("OfferDescription").Substring(ds.Tables(0).Rows(0)("OfferDescription").ToLower().IndexOf("src=") + 5)
                    Desc = Desc.Substring(0, Desc.ToLower().IndexOf(" frameborder=") - 1)
                    MetaTags = MetaTags & "<meta property='og:title' content='" & ds.Tables(0).Rows(0)("OfferTitle") & " " & Desc & "' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video' content='" & Desc.Replace("embed", "v") & "&fs=1' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:width' content='560' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:height' content='340' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:video:type' content='application/x-shockwave-flash' />" & Environment.NewLine
                    OGImage.Content = "http://i2.ytimg.com/vi/1F7DKyFt5pY/default.jpg"
                    Me.webpagehead.Description += ds.Tables(0).Rows(0)("ArticleText") & " " & Desc
                Else
                    MetaTags = MetaTags & "<meta Property='og:title' content='" & ds.Tables(0).Rows(0)("OfferTitle") & "' />" & Environment.NewLine
                    MetaTags = MetaTags & "<meta property='og:description' content='" & IIf(ds.Tables(0).Rows(0)("OfferDescription") <> "" AndAlso Len(ds.Tables(0).Rows(0)("OfferDescription")) <= 200, ds.Tables(0).Rows(0)("OfferDescription"), Left(ds.Tables(0).Rows(0)("OfferDescription"), 200) & "...") & "' />" & Environment.NewLine
                    Me.webpagehead.Description += ds.Tables(0).Rows(0)("OfferDescription")
                End If


            End If
            litMeta.Text = MetaTags
            ''If Session("Visited") Is Nothing Then
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Offer Visit", "Offer Visited at " & Now, HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            Session("Visited") = Now
            ''End If
        End If

        ''Social Media Code End


    End Sub

End Class