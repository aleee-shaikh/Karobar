function LogOut(ControlID) {

    var RequestData = {
        LoginID: '',
        UserID: ''
    };

    $.ajax({
        type: "POST",
        //dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/LoginOut',
        contentType: "application/json; charset=utf-8",
        success: function (result) {

            if (result.d == -1) {
                window.location = '/EzBusiness.aspx'
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
}



function RegisterUser(ControlID) {
    var Parameters = ''

    if (ValidateForm(ControlID)) {
        Parameters = Parameters + 'FirstName^ ^' + $('#' + ControlID + 'FirstName').val() + '~';
        Parameters = Parameters + 'MiddleName^ ^' + $('#' + ControlID + 'MiddleName').val() + '~';
        Parameters = Parameters + 'LastName^ ^' + $('#' + ControlID + 'LastName').val() + '~';
        Parameters = Parameters + 'City^ ^' + $('#' + ControlID + 'City').val() + '~';
        Parameters = Parameters + 'Country^ ^' + $('#' + ControlID + 'Country').val() + '~';
        Parameters = Parameters + 'LoginID^ ^' + $('#' + ControlID + 'LoginID').val() + '~';
        Parameters = Parameters + 'Password^ ^' + $('#' + ControlID + 'Password').val() + '~';

        var RequestData = {
            P: '',
            Parameters: Parameters
        };

        //alert(JSON.stringify(RequestData))

        $.ajax({
            type: "POST",
            dataType: 'xml',
            data: JSON.stringify(RequestData),
            async: false,
            url: '/Webservice/Person.asmx/RegisterUser',
            contentType: "application/json; charset=utf-8",
            success: function (xml) {
                var UserID
                $(xml).find("Users").each(function () {
                    UserID = $(this).find("UserID").text()
                });
                if (UserID == -1) {
                    alert('User already exist with the same login id, please try different login id')
                }
                else {
                    window.location = '/Home'
                }
            },
            error: function (xhr, status, errord) {
                alert(xhr.responseText);
            }
        });
    }
}

function GetUserSpecificInfo(userID,key) {
    var RequestData = {
        UserID: userID,
        Key: key
    };

    var Data = [];
    var Value = "";
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/GetUserSpecificInfo',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("UserDetails").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("UserDetails").each(function () {
                    Value = $(this).find(key).text()
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Value;
}





function GetCusomerOutstandingBalance(userID) {
    var RequestData = {
        UserID: userID
    };
    var CustomerOutstandingBalance= 0;
    var Data = [];
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/GetCustomerOutstandingBalance',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("CustomerOutstandingBalance").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("CustomerOutstandingBalance").each(function () {
                    CustomerOutstandingBalance= $(this).find("Balance").text()
                    });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return CustomerOutstandingBalance;
}










function GetUserDetails(ControlID,UserID) {
    var RequestData = {
        UserID: UserID
    };
    
    var Data = [];
    //alert(JSON.stringify(RequestData))
    $.ajax({
        type: "POST",
        dataType: 'xml',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/GetUserDetails',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            var Count = $(xml).find("UserDetails").length;
            if (Count == 0) {
                ;
            }
            else {
                $(xml).find("UserDetails").each(function () {
                    Data.push({
                        UserID: $(this).find("UserID").text(),
                        FirstName: $(this).find("FirstName").text(),
                        LastName: $(this).find("LastName").text(),
                        MiddleName: $(this).find("MiddleName").text(),
                        Password: $(this).find("Password").text(),
                        LoginID: $(this).find("LoginID").text(),
                        CreditLimit: $(this).find("CreditLimit").text(),
                        ImageFilename: $(this).find("ImageFilename").text(),
                        TelephoneNo: $(this).find("TelephoneNo").text(),
                        MobileNo: $(this).find("MobileNo").text(),
                        Fax: $(this).find("Fax").text(),
                        ResidentialAddress: $(this).find("ResidentialAddress").text(),
                        Lat: $(this).find("Lat").text(),
                        Lng: $(this).find("Lng").text()

                    });
                });
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });
    //alert(JSON.stringify(Data))
    return Data;
}


function ForgotPasswordRequest(LoginID, SecretQuestion, SecretQuestionAnswer) {
    var RequestData = {
        LoginID: LoginID,
        SecretQuestion: SecretQuestion,
        SecretQuestionAnswer: SecretQuestionAnswer
    };
    if (verifyEmail(LoginID)==false) {
        alert("Invalid email address")
        return;
    }
    var Data = [];
    $.ajax({
        type: "POST",
        dataType: 'json',
        data: JSON.stringify(RequestData),
        async: false,
        url: '/Webservice/Person.asmx/ForgotPasswordRequest',
        contentType: "application/json; charset=utf-8",
        success: function (xml) {
            if (xml.d) {
                alert("email does not exist")
            }
            else {
                alert("Your password has been sent to your email address.")
                window.location = "/Ezbusiness.aspx"
            }
        },
        error: function (xhr, status, errord) {
            alert(xhr.responseText);
        }
    });

    return Data;
}