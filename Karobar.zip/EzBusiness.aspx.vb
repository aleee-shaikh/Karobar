﻿Public Class EzBusiness
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            If HttpContext.Current.Session("UserID") Is Nothing And HttpContext.Current.Session("Visited") Is Nothing Then
                Log.WriteLog(-1, -1, "User Visited", "User Visited", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                Session("Visited") = Now
            End If
        End If

        'Dim x As String = Cryptography.Encrypt("Z@hr33l@C0br@")
        'Dim y As String = Cryptography.Decrypt(x)
    End Sub

    Protected Sub CustomValidator1_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator1.ServerValidate
        Dim sql As String
        Dim dbobj As New DBDAL
        Dim tbl As New DataTable
        Dim cmd As New SqlClient.SqlCommand

        Dim UserAccountFound As Boolean = False
        Dim UID As String = "-1"
        Dim UserName As String = ""
        Dim UserType As String = ""
        Dim UserStatus As String = ""

        'sql = "Select *from Users Where LoginID='" & LoginID.Text & "' and Password='" & Password.Text & "' and UserStatus='Active'"
        Try
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "AuthenticateUser"
            cmd.Parameters.AddWithValue("LoginID", LoginID.Text)
            cmd.Parameters.AddWithValue("Password", Password.Text)

            tbl = dbobj.GetDataTable(cmd)

            For i As Integer = 0 To tbl.Rows.Count - 1
                UserAccountFound = True
                UID = tbl.Rows(i)("UserID")
                'Session("UserID") = UID
                'Session("UserName") = tbl.Rows(0)("FirstName")
                'Session("UserEmail") = tbl.Rows(i)("LoginID")
                'Session("UserImage") = tbl.Rows(i)("ImageFilename")
                'Session("ShiftID") = IIf(IsDBNull(tbl.Rows(0)("ShiftID")), 0, tbl.Rows(0)("ShiftID").ToString)
                LoggedInUserSession.UserID = UID
                If (IsDBNull(tbl.Rows(0)("WebsiteID")) = False AndAlso Val(tbl.Rows(0)("WebsiteID")) > 0) Then
                    LoggedInUserSession.BusinessID = Val(tbl.Rows(0)("WebsiteID"))
                    LoggedInUserSession.BusinessCategoryID = IIf(IsDBNull(tbl.Rows(0)("WebsiteCategoryID")), -1, tbl.Rows(0)("WebsiteCategoryID"))
                    LoggedInUserSession.BusienssTypeID = IIf(IsDBNull(tbl.Rows(0)("BusinessTypeID")), -1, tbl.Rows(0)("BusinessTypeID"))
                    LoggedInUserSession.BusinessLogo = IIf(IsDBNull(tbl.Rows(0)("WebsiteLogo")), "", tbl.Rows(0)("WebsiteLogo"))
                    LoggedInUserSession.TimeZone = IIf(IsDBNull(tbl.Rows(0)("UTCOffset")), 0, tbl.Rows(0)("UTCOffset").ToString().Trim())

                    Dim ds As New DataSet
                    ds = Website.GetWebsiteDetails(LoggedInUserSession.BusinessID)
                    If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0) Then
                        LoggedInUserSession.BusinessTitle = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))
                    End If
                End If
                LoggedInUserSession.UserName = tbl.Rows(0)("FirstName")
                LoggedInUserSession.UserEmail = tbl.Rows(i)("LoginID")
                LoggedInUserSession.UserImage = tbl.Rows(i)("ImageFilename")
                LoggedInUserSession.UserShiftID = IIf(IsDBNull(tbl.Rows(0)("ShiftID")), 0, tbl.Rows(0)("ShiftID").ToString)
            Next
        Catch ex As Exception

        End Try


        If UserAccountFound = False Then
            args.IsValid = False
            'Invalid Login attempt Log
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Invalid Login attempt", "Invalid Login[" & LoginID.Text.Replace("'", "~") & "~" & Password.Text.Replace("'", "~") & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
        Else
            args.IsValid = True
            Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Successful Login", "Successful Login[" & LoginID.Text.Replace("'", "~") & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
            If Person.DoesPersonHavePageRights(LoggedInUserSession.UserID, "2") Then
                'If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
                Response.Redirect(ReferenceData.Setting("StartPageURL4Others", "~/Dashboard"))
            Else
                If Person.DoesPersonHavePageRights(Session("UserID"), 1) = True Then 'Business
                    Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Business"))
                ElseIf Person.DoesPersonHavePageRights(Session("UserID"), 176) = True Then 'Products
                    Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Manage-Products"))
                ElseIf Person.DoesPersonHavePageRights(Session("UserID"), 152) = True Then 'POS
                    Response.Redirect(ReferenceData.Setting("StartPageURL", "~/POS-Sale"))
                Else
                    Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Dashboard"))
                End If

            End If

            End If

    End Sub

    Private Sub CustomValidator2_ServerValidate(ByVal source As Object, ByVal args As System.Web.UI.WebControls.ServerValidateEventArgs) Handles CustomValidator2.ServerValidate
        Dim tbl As New DataTable
        tbl = Person.GetUserDetailByLoginID(txtNewUserLoginID.Text.Trim)
        If tbl.Rows.Count > 0 Then
            args.IsValid = False
        Else
            args.IsValid = True
            tbl = New DataTable

            tbl = Person.AddUser(Val(Session("CurrentBusinessID")), txtNewUserLoginID.Text.Trim, txtNewUserConfirmPassword.Text.Trim, txtNewUserFullname.Text.Trim, "", "", 1,
    True, Now.ToString("MM-dd-yyyy"), 1, "", "", "",
     txtNewUserLoginID.Text.Trim, "", Person.UserTypes.Admin, -1, True, Now.ToString("yyyy-MM-dd hh:mm"), HttpContext.Current.Session("UserID"), "", "", "", "", "", ParentAccountHeadID:=ReferenceData.Setting("StaffAccountHeadID", "31", Session("CurrentBusinessID")))
            If tbl.Rows.Count > 0 Then
                Session("UserID") = tbl.Rows(0)("UserID")
                Website.User.UpdatePersonRoles(tbl.Rows(0)("UserID"), "7,2,")

                Dim rword As New StringBuilder("")

                rword.Append("[LoginID]♦").Append(txtNewUserLoginID.Text.Trim()).Append("¤[UserName]♦").Append(tbl.Rows(0)("FirstName")).Append("¤[Password]♦").Append(txtNewUserPassword.Text).Append("¤")
                WebsiteEmail.SendEmail(ReferenceData.Setting("FromEmailAddress", "info@joined24.com"), txtNewUserLoginID.Text.Trim(), "", "Welcome to Joined24.com", "WelcomeEmail", "", rword.ToString())
                ''System.Threading.Thread.Sleep(2000)
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "User Register", "User Register [" & txtNewUserLoginID.Text.Replace("'", "~") & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                ''Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Business"))
                If Person.DoesPersonHaveManagerialRoles(Session("UserID")) = False Then
                    Response.Redirect(ReferenceData.Setting("StartPageURL", "~/Transaction"))
                Else
                    Response.Redirect(ReferenceData.Setting("StartPageURL4Others", "~/Business"))
                End If

            End If
        End If
    End Sub

    Private Sub BtnRegisterUser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnRegisterUser.Click


    End Sub

    Private Sub ddlDemoAccounts_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlDemoAccounts.SelectedIndexChanged

    End Sub

    Private Sub btnDemoGo_Click(sender As Object, e As EventArgs) Handles btnDemoGo.Click
        Dim sql As String
        Dim dbobj As New DBDAL
        Dim tbl As New DataTable
        Dim cmd As New SqlClient.SqlCommand

        Dim UserAccountFound As Boolean = False
        Dim UID As String = "-1"
        Dim UserName As String = ""
        Dim UserType As String = ""
        Dim UserStatus As String = ""
        Dim DemoLoginID As String = ""
        Dim DemoLoginPwd As String = ""

        If ddlDemoAccounts.SelectedValue = "POS" Then
            DemoLoginID = "demo@pos.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "RetailStore" Then
            DemoLoginID = ""
            DemoLoginPwd = ""
        ElseIf ddlDemoAccounts.SelectedValue = "Distribution" Then
            DemoLoginID = "demo@distribution.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "School" Then
            DemoLoginID = "demo@school.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "Resturant" Then
            DemoLoginID = "demo@resturant.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "Showroom" Then
            DemoLoginID = "demo@showroom.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "DMS" Then
            DemoLoginID = "demo@dms.com"
            DemoLoginPwd = "demo"
        ElseIf ddlDemoAccounts.SelectedValue = "RealEstate" Then
            DemoLoginID = "demo@construction.com"
            DemoLoginPwd = "demo"
        End If

        Try
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "AuthenticateUser"
            cmd.Parameters.AddWithValue("LoginID", DemoLoginID)
            cmd.Parameters.AddWithValue("Password", DemoLoginPwd)

            tbl = dbobj.GetDataTable(cmd)

            For i As Integer = 0 To tbl.Rows.Count - 1
                UserAccountFound = True
                UID = tbl.Rows(i)("UserID")
                LoggedInUserSession.UserID = UID
                If (IsDBNull(tbl.Rows(0)("WebsiteID")) = False AndAlso Val(tbl.Rows(0)("WebsiteID")) > 0) Then
                    LoggedInUserSession.BusinessID = Val(tbl.Rows(0)("WebsiteID"))
                    LoggedInUserSession.BusinessCategoryID = IIf(IsDBNull(tbl.Rows(0)("WebsiteCategoryID")), -1, tbl.Rows(0)("WebsiteCategoryID"))
                    LoggedInUserSession.BusienssTypeID = IIf(IsDBNull(tbl.Rows(0)("BusinessTypeID")), -1, tbl.Rows(0)("BusinessTypeID"))
                    LoggedInUserSession.BusinessLogo = IIf(IsDBNull(tbl.Rows(0)("WebsiteLogo")), "", tbl.Rows(0)("WebsiteLogo"))
                    LoggedInUserSession.TimeZone = IIf(IsDBNull(tbl.Rows(0)("UTCOffset")), 0, tbl.Rows(0)("UTCOffset").ToString().Trim())

                    Dim ds As New DataSet
                    ds = Website.GetWebsiteDetails(LoggedInUserSession.BusinessID)
                    If (ds.Tables.Count > 0 AndAlso ds.Tables(0).Rows.Count > 0) Then
                        LoggedInUserSession.BusinessTitle = IIf(IsDBNull(ds.Tables(0).Rows(0)("WebsiteTitle")), "", ds.Tables(0).Rows(0)("WebsiteTitle"))
                    End If
                End If
                LoggedInUserSession.UserName = tbl.Rows(0)("FirstName")
                LoggedInUserSession.UserEmail = tbl.Rows(i)("LoginID")
                LoggedInUserSession.UserImage = tbl.Rows(i)("ImageFilename")
                LoggedInUserSession.UserShiftID = IIf(IsDBNull(tbl.Rows(0)("ShiftID")), 0, tbl.Rows(0)("ShiftID").ToString)
                Log.WriteLog(Val(Session("CurrentBusinessID")), HttpContext.Current.Session("UserID"), "Successful Login", "Successful Login[" & DemoLoginID & "]", HttpContext.Current.Request.UserAgent, HttpContext.Current.Request.UserHostAddress, HttpContext.Current.Request.Browser.Platform, HttpContext.Current.Request.RawUrl)
                Response.Redirect("~/Dashboard")

            Next
        Catch ex As Exception

        End Try

    End Sub
End Class